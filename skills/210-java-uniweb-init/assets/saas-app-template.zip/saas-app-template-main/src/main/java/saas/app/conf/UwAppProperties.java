package saas.app.conf;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * 配置类。
 *
 * @author axeon
 */
@Configuration
@ConfigurationProperties(prefix = "uw.app")
public class UwAppProperties {

}
