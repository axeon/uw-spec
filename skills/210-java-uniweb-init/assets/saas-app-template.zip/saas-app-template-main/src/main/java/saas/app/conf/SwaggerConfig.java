package saas.app.conf;

import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile({"debug","dev"})
public class SwaggerConfig {

    /**
     * 应用名称
     */
    @Value("${project.name}")
    private String appName;

    /**
     * 应用版本
     */
    @Value("${project.version}")
    private String appVersion;


    @Bean
    public OpenApiCustomizer customOpenAPI() {
        return openApi -> openApi
                .addSecurityItem(new SecurityRequirement().addList("AuthToken"))
                .components(openApi.getComponents().addSecuritySchemes("AuthToken",
                        new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").in(SecurityScheme.In.HEADER)))
                .info(new Info().title(appName).version(appVersion)
                        .contact(new Contact().name("axeon").email("23231269@qq.com")));
    }

    /**
     * rootApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi rootApi() {
        return GroupedOpenApi.builder()
                .group("rootApi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("saas.app.controller.rootApi")
                .build();
    }

    /**
     * ops API接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi opsApi() {
        return GroupedOpenApi.builder()
                .group("opsApi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("saas.app.controller.ops")
                .build();
    }

    /**
     * adminApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi adminApi() {
        return GroupedOpenApi.builder()
                .group("opsAadminApipi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("saas.app.controller.admin")
                .build();
    }

    /**
     * saasApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi saasApi() {
        return GroupedOpenApi.builder()
                .group("saasApi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("saas.app.controller.saas")
                .build();
    }

    /**
     * mchApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi mchApi() {
        return GroupedOpenApi.builder()
                .group("mchApi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("saas.app.controller.mch")
                .build();
    }

    /**
     * guestApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi guestApi() {
        return GroupedOpenApi.builder()
                .group("guestApi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("saas.app.controller.guest")
                .build();
    }


    /**
     * openApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi openApi() {
        return GroupedOpenApi.builder()
                .group("openApi")
                .packagesToScan("saas.app.controller.open")
                .addOpenApiCustomizer(customOpenAPI())
                .build();
    }



}
