package uw.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UwAppApplicationTests {

    @Test
    public void contextLoads() {
    }

}
