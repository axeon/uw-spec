package uw.app;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInstance;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest(classes = TestContextConfig.class)
@TestPropertySource(properties = {
    "spring.profiles.active=debug"
})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public abstract class BaseIntegrationTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
        cleanTestData();
    }

    @AfterAll
    void globalTearDown() {
        cleanAllTestData();
    }

    protected abstract void cleanTestData();

    protected void cleanAllTestData() {
        cleanTestData();
    }
}
