package uw.app.conf;

import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile({"debug","dev"})
public class SwaggerConfig {

    /**
     * 应用名称
     */
    @Value("${project.name}")
    private String appName;

    /**
     * 应用版本
     */
    @Value("${project.version}")
    private String appVersion;


    @Bean
    public OpenApiCustomizer customOpenAPI() {
        return openApi -> openApi
                .addSecurityItem(new SecurityRequirement().addList("AuthToken"))
                .components(openApi.getComponents().addSecuritySchemes("AuthToken",
                        new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").in(SecurityScheme.In.HEADER)))
                .info(new Info().title(appName).version(appVersion)
                        .contact(new Contact().name("axeon").email("23231269@qq.com")));
    }

    /**
     * rootApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi rootApi() {
        return GroupedOpenApi.builder()
                .group("rootApi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("uw.app.controller.rootApi")
                .build();
    }

    /**
     * opsApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi opsApi() {
        return GroupedOpenApi.builder()
                .group("opsApi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("uw.app.controller.ops")
                .build();
    }

    /**
     * adminApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi adminApi() {
        return GroupedOpenApi.builder()
                .group("adminApi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("uw.app.controller.admin")
                .build();
    }

    /**
     * saasApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi saasApi() {
        return GroupedOpenApi.builder()
                .group("saasApi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("uw.app.controller.saas")
                .build();
    }

    /**
     * mchApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi mchApi() {
        return GroupedOpenApi.builder()
                .group("mchApi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("uw.app.controller.mch")
                .build();
    }

    /**
     * guestApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi guestApi() {
        return GroupedOpenApi.builder()
                .group("guestApi")
                .addOpenApiCustomizer(customOpenAPI())
                .packagesToScan("uw.app.template.controller.guest")
                .build();
    }
    /**
     * userApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi userApi() {
        return GroupedOpenApi.builder()
                .group("userApi")
                .packagesToScan("uw.app.template.controller.user")
                .addOpenApiCustomizer(customOpenAPI())
                .build();
    }

    /**
     * openApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi openApi() {
        return GroupedOpenApi.builder()
                .group("openApi")
                .packagesToScan("uw.app.template.controller.open")
                .addOpenApiCustomizer(customOpenAPI())
                .build();
    }

}
