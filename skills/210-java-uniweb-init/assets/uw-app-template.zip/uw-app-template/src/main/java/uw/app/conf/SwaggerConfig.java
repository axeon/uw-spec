package uw.app.conf;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile({"debug","dev"})
public class SwaggerConfig {

    /**
     * 应用名称
     */
    @Value("${project.name}")
    private String appName;

    /**
     * 应用版本
     */
    @Value("${project.version}")
    private String appVersion;


    /**
     * 需要认证的API分组Customizer：添加Bearer Token安全认证和信息。
     */
    private OpenApiCustomizer authenticatedApiCustomizer() {
        return openApi -> {
            // 确保Components对象已初始化，避免空指针异常
            if (openApi.getComponents() == null) {
                openApi.setComponents(new Components());
            }

            openApi.addSecurityItem(new SecurityRequirement().addList("AuthToken"))
                    .getComponents().addSecuritySchemes("AuthToken",
                            new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").in(SecurityScheme.In.HEADER));

            openApi.info(new Info().title(appName).version(appVersion)
                    .contact(new Contact().name("axeon").email("23231269@qq.com")));
        };
    }

    /**
     * 公开API分组Customizer：仅添加基本信息，不要求Bearer Token认证。
     */
    private OpenApiCustomizer publicApiCustomizer() {
        return openApi -> openApi.info(new Info().title(appName).version(appVersion)
                .contact(new Contact().name("axeon").email("23231269@qq.com")));
    }

    /**
     * rootApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi rootApi() {
        return GroupedOpenApi.builder()
                .group("rootApi")
                .addOpenApiCustomizer(authenticatedApiCustomizer())
                .packagesToScan("uw.app.controller.rootApi")
                .build();
    }

    /**
     * opsApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi opsApi() {
        return GroupedOpenApi.builder()
                .group("opsApi")
                .addOpenApiCustomizer(authenticatedApiCustomizer())
                .packagesToScan("uw.app.controller.ops")
                .build();
    }

    /**
     * adminApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi adminApi() {
        return GroupedOpenApi.builder()
                .group("adminApi")
                .addOpenApiCustomizer(authenticatedApiCustomizer())
                .packagesToScan("uw.app.controller.admin")
                .build();
    }

    /**
     * saasApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi saasApi() {
        return GroupedOpenApi.builder()
                .group("saasApi")
                .addOpenApiCustomizer(authenticatedApiCustomizer())
                .packagesToScan("uw.app.controller.saas")
                .build();
    }

    /**
     * mchApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi mchApi() {
        return GroupedOpenApi.builder()
                .group("mchApi")
                .addOpenApiCustomizer(authenticatedApiCustomizer())
                .packagesToScan("uw.app.controller.mch")
                .build();
    }

    /**
     * guestApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi guestApi() {
        return GroupedOpenApi.builder()
                .group("guestApi")
                .addOpenApiCustomizer(authenticatedApiCustomizer())
                .packagesToScan("uw.app.controller.guest")
                .build();
    }
    /**
     * userApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi userApi() {
        return GroupedOpenApi.builder()
                .group("userApi")
                .packagesToScan("uw.app.controller.user")
                .addOpenApiCustomizer(authenticatedApiCustomizer())
                .build();
    }

    /**
     * openApi接口。
     *
     * @return
     */
    @Bean
    public GroupedOpenApi openApi() {
        return GroupedOpenApi.builder()
                .group("openApi")
                .packagesToScan("uw.app.controller.open")
                .addOpenApiCustomizer(publicApiCustomizer())
                .build();
    }

}
