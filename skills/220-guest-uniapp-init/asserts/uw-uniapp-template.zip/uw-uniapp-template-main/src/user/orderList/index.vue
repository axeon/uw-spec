<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { onLoad, onReachBottom } from '@dcloudio/uni-app'
import {
  guestOrderInfoList,
  guestOrderInfoPay,
  type GuestOrderInfoQueryParam,
  type MallOrderPayParam,
  type OrderInfo
} from '@/api/saasMallAppGuestApi'
import OrderItem from './components/OrderItem.vue'
import { clone } from 'lodash-es'
import type { Extend_AisLinkerConfigInfo } from '@/components/PaymentPopup/type'
import PaymentPopup from '@/components/PaymentPopup/index.vue'
import { useI18n } from 'vue-i18n'
import GbNavbar from '@/components/GbNavbar/index.vue'
import OrderTab from './components/OrderTab.vue'

const { t } = useI18n()

const pageLoading = ref(false)
// 触底加载状态
const loadStatus = ref('nomore')

const orderQuery = reactive<GuestOrderInfoQueryParam>({
  $pg: 1,
  $rn: 10,
  // $rt: 2, // 取总数 和 results
  $sn: ['id'],
  $st: [2],
  state: 1,
  orderState: undefined // 订单状态
  // orderType: 1  // 产品类型(1:产品,2:场次,3:规格)
})
const orderList = ref<OrderInfo[]>([])

// 搜索条件
const tabList = ref([
  { name: '全部' },
  { name: '待付款' },
  { name: '待确认' },
  { name: '待使用' },
  { name: '待评价' },
  { name: '已完成' },
  { name: '取消' }
])

// 搜索Order
const handleSearchOrderList = () => {
  orderQuery.$pg = 1
  orderList.value = []
  getOrderList()
}

// 根据orderIds获取POI列表 (景点列表)
const getOrderList = async () => {
  console.log('getOrderList', orderQuery)
  pageLoading.value = true
  try {
    loadStatus.value = 'loading'
    const copyOrderQuery = clone(orderQuery)
    if (copyOrderQuery.orderInfo) {
      copyOrderQuery.orderInfo = encodeURIComponent(
        `%${copyOrderQuery.orderInfo}%`
      )
    } else {
      copyOrderQuery.orderInfo = undefined
    }
    const res = await guestOrderInfoList(copyOrderQuery)
    // qrTotal.value = res.data?.sizeAll || 0
    if (res.state === 'success' && res.data?.results?.length) {
      if (orderQuery.$pg === 1) {
        orderList.value = res.data.results

        if (res.data.sizeAll! >= copyOrderQuery.$rn!) {
          loadStatus.value = 'loadmore'
        } else {
          loadStatus.value = 'nomore'
        }
      } else {
        orderList.value = [...orderList.value, ...res.data.results]
      }
    } else if (res.state === 'success' && !res.data?.results) {
      console.log('noMore')
      loadStatus.value = 'nomore'
    }

    if (import.meta.env.DEV) {
      orderList.value = [
        {
          id: 78,
          saasId: 65,
          poiId: 11,
          siteId: 75,
          agentId: 8,
          guestId: 3,
          orderInfo: 'laboris',
          orderLang: 'cillum pr',
          unpayCancelMinutes: 46,
          areaCode: 82,
          saleType: 78,
          payType: 16,
          payMoney: 82,
          payDate: '2026-07-16',
          useDateType: 72,
          useDateInfo: '2026-10-03',
          useDate: '2025-11-20',
          contactName: '抄梓诚',
          contactPhone: '19734024256',
          contactEmail: 'ui8_gbj@sina.com',
          deliveryType: 84,
          deliveryAddress: '澄栋83号',
          deliveryState: 10,
          deliveryDate: '2026-07-03',
          confirmType: 100,
          confirmDate: '2025-12-21',
          finishNum: 43,
          finishMoney: 53,
          finishDate: '2026-08-24',
          remark: 'quis',
          channelId: 77,
          distributorMchId: 96,
          distributorParentId: 33,
          distributorMoney: 78,
          distributorOrderId: '10',
          distributorOrderState: 99,
          distributorMoneyReceipted: 47,
          distributorMoneyRefund: 80,
          distributorVerifyDate: '2025-10-23',
          distributorVerifyState: 31,
          distributorRebate: 20,
          issueType: 40,
          issueInfo: 'Ut ullamco ipsum ut ut',
          issueState: 66,
          refundNum: 40,
          refundMoney: 97,
          refundState: 61,
          refundDate: '2026-01-26',
          orderCurrency: 'cupidata',
          orderMoney: 12,
          orderState: 50,
          orderDate: '2025-05-02',
          state: 15
        },
        {
          id: 67,
          saasId: 70,
          poiId: 4,
          siteId: 24,
          agentId: 38,
          guestId: 79,
          orderInfo: 'deserunt do sint minim',
          orderLang: 'sed i',
          unpayCancelMinutes: 96,
          areaCode: 30,
          saleType: 5,
          payType: 72,
          payMoney: 63,
          payDate: '2026-01-15',
          useDateType: 31,
          useDateInfo: '2026-03-10',
          useDate: '2025-02-28',
          contactName: '藤雨欣',
          contactPhone: '050 8885 0924',
          contactEmail: 'v9rlnf_rwa@gmail.com',
          deliveryType: 84,
          deliveryAddress: '印侬507号',
          deliveryState: 97,
          deliveryDate: '2025-10-24',
          confirmType: 86,
          confirmDate: '2026-11-12',
          finishNum: 83,
          finishMoney: 9,
          finishDate: '2025-07-01',
          remark: 'incididunt pariatur',
          channelId: 88,
          distributorMchId: 73,
          distributorParentId: 49,
          distributorMoney: 7,
          distributorOrderId: '47',
          distributorOrderState: 3,
          distributorMoneyReceipted: 71,
          distributorMoneyRefund: 78,
          distributorVerifyDate: '2025-12-22',
          distributorVerifyState: 36,
          distributorRebate: 95,
          issueType: 59,
          issueInfo: 'veniam sint esse et ut',
          issueState: 97,
          refundNum: 56,
          refundMoney: 67,
          refundState: 11,
          refundDate: '2025-07-27',
          orderCurrency: 'adipisici',
          orderMoney: 7,
          orderState: 21,
          orderDate: '2026-07-09',
          state: 7
        },
        {
          id: 54,
          saasId: 35,
          poiId: 96,
          siteId: 83,
          agentId: 9,
          guestId: 65,
          orderInfo: 'voluptate',
          orderLang: 'do',
          unpayCancelMinutes: 85,
          areaCode: 29,
          saleType: 78,
          payType: 64,
          payMoney: 85,
          payDate: '2025-12-11',
          useDateType: 99,
          useDateInfo: '2026-09-10',
          useDate: '2026-07-30',
          contactName: '歧敏',
          contactPhone: '30343892768',
          contactEmail: 'tw9izl_q6h@126.com',
          deliveryType: 6,
          deliveryAddress: '乌旁18号',
          deliveryState: 90,
          deliveryDate: '2026-04-15',
          confirmType: 59,
          confirmDate: '2026-09-15',
          finishNum: 37,
          finishMoney: 71,
          finishDate: '2025-11-19',
          remark: 'consequat',
          channelId: 39,
          distributorMchId: 69,
          distributorParentId: 92,
          distributorMoney: 59,
          distributorOrderId: '73',
          distributorOrderState: 75,
          distributorMoneyReceipted: 52,
          distributorMoneyRefund: 15,
          distributorVerifyDate: '2025-09-18',
          distributorVerifyState: 43,
          distributorRebate: 86,
          issueType: 58,
          issueInfo: 'voluptate',
          issueState: 81,
          refundNum: 28,
          refundMoney: 85,
          refundState: 87,
          refundDate: '2026-07-29',
          orderCurrency: 'i',
          orderMoney: 92,
          orderState: 41,
          orderDate: '2025-03-01',
          state: 40
        }
      ]
    }
  } catch (error) {
    console.log('error', error)
  } finally {
    pageLoading.value = false
  }
}

// 跳转到详情页
const goDetail = (id: number) => {
  console.log('跳转到详情页', id)
  uni.navigateTo({
    url: '/user/orderDetail/index?id=' + id
  })
}

// 当前订单项
const curOrderInfo = ref<OrderInfo>({})

const isShowPayPopup = ref(false)
const priceTotal = ref(0)

// 点击支付
const handleClickPay = (item: OrderInfo) => {
  console.log('handleClickPay', item)
  curOrderInfo.value = item || {}
  priceTotal.value = item.orderMoney || 0
  isShowPayPopup.value = true
}

// 微信支付链接 通过二维码展示 "weixin://wxpay/bizpayurl?pr=m3p8pIvz1"
const scanPayInfoUrl = ref('')

// 支付弹窗提交
const handlePaySubmit = (payItem: Extend_AisLinkerConfigInfo) => {
  console.log('handlePaySubmit', payItem)
  /* 
  {
    "id": 90,
    "state": 1,
    "appName": "saas-finance-app",
    "saasId": 8821909,
    "createDate": 1765243324164,
    "linkerId": 53,
    "linkerFunction": "payOrderNotify,payRefundNotify,payRefund,payOrder",
    "linkerVersion": "1.0.5",
    "linkerIcon": "",
    "mchId": 0,
    "configSid": "",
    "configName": "微信支付接口",
    "modifyDate": 1765275767758,
    "pubParamMap": {
        "pay.channel": "WECHAT"
    },
    "payRemark": "22"
}
  */

  uni.showToast({
    icon: 'loading',
    title: '提交申请中...',
    duration: 3000
  })

  /* payTradeType：
  APP( "APP", "APP支付" ),
  JSAPI_MP( "JSAPI_MP", "公众号支付" ),
  JSAPI_MA( "JSAPI_MA", "小程序支付" ),
  NATIVE( "NATIVE", "native支付" ),
  H5( "H5", "H5支付" )
  */
  const params: MallOrderPayParam = {
    payConfigId: payItem.id,
    payChannel: payItem.payChannel,
    payTradeType: 'NATIVE', // TODO 等后端完善后再根据情况使用对应的
    payCurrency: 'CNY', // 货币类型 人民币:CNY;
    payAmount: priceTotal.value, // 支付金额，单位分
    // bizOrderExt: '', // 应用订单扩展信息
    payRemark: payItem.payRemark,
    orderId: curOrderInfo.value.id // 类型忽略 不可强转大数字number （后端定义ID长度大于17位及以上）
  }
  guestOrderInfoPay(params)
    .then(async (res) => {
      /* 
      {
        "payOrderId": 8251212345908821909,
        "saasId": 0,
        "userId": 220,
        "userType": 1,
        "userInfo": "13652725969@163.com",
        "userIp": "192.168.89.212",
        "payConfigId": 90,
        "payChannel": "WECHAT",
        "payTradeType": "NATIVE",
        "orderInfo": "商城订单支付：123333",
        "orderCurrency": "CNY",
        "orderAmount": 2400,
        "bizAppInfo": "saas-mall-app",
        "bizOrderType": "saas.mall.entity.OrderInfo",
        "bizOrderId": "1251212347188821909",
        "scanPayInfo": "weixin://wxpay/bizpayurl?pr=m3p8pIvz1"
    }
      */
      if (res.state === 'success') {
        // isShowPayPopup.value = false
        scanPayInfoUrl.value = res.data?.scanPayInfo || ''

        // 跳转到订单详情页面
        // const params = {
        //   id: orderDetailInfo.value.id
        // }
        // uni.navigateTo({
        //   url: '/user/orderDetail/index?' + formatParam(params)
        // })
        // if (res.data && res.data.webPayInfo) {
        //   const url = res.data.webPayInfo.url
        //   // if (res.data.webUrl) {
        //   //   resolve(`${res.data.webUrl}`)
        //   // } else {
        //   //   payVISAPAY(res.data)
        //   // }
        //   // return
        //   if (['VISAPAY', 'MASTERCARDPAY'].includes(info.payChannel)) {
        //     payVISAPAY(res.data)
        //   } else if (
        //     ['ALIPAY', 'WXPAY', 'ALIPAYHK'].includes(info.payChannel)
        //   ) {
        //     loadingPage.value?.close()
        //     if (['ALIPAY', 'ALIPAYHK'].includes(info.payChannel)) {
        //       console.log('支付宝支付 --->', info)
        //       if (url) {
        //         // window.location.href = url
        //         window.location.replace(url)
        //         console.log('res.data', res.data)
        //       } else {
        //         loadingPage.value?.close()
        //         showFailToast(res.msg || t('orderStatus.orderFailed'))
        //         reject(res.msg)
        //       }
        //       resolve(`${res.data.webUrl}`)
        //     } else {
        //       resolve(res.data.scanPayInfo || '')
        //     }
        //   } else if (['UNIONPAY', 'CUPPAY'].includes(info.payChannel)) {
        //     // loadingPage.value?.close()
        //     // resolve(res.data.webUrl || '')
        //     payVISAPAY(res.data)
        //   }
        // } else {
        //   loadingPage.value?.close()
        //   showFailToast(res.msg || t('orderStatus.orderFailed'))
        //   reject(res.msg)
        // }
      } else {
        uni.showToast({
          icon: 'error',
          title: t('提交失败:') + res.msg,
          duration: 3000
        })
      }
    })
    .catch((err) => {
      uni.showToast({
        icon: 'error',
        title: t('提交失败') + err.msg,
        duration: 3000
      })
    })
    .finally(() => {
      setTimeout(() => {
        uni.hideToast()
      }, 2000)
    })
}

onLoad(() => {
  getOrderList()
})

onReachBottom(() => {
  console.log('触底了')
  if (orderQuery.$pg) {
    orderQuery.$pg++
    getOrderList()
  }
})
</script>

<template>
  <GbNavbar />

  <div class="order-list">
    <OrderTab :list="tabList" />
    <!-- <up-tabs :list="tabList"></up-tabs> -->

    <div>
      <div
        v-if="orderList.length"
        class="flex flex-col gap-[20rpx] py-[30rpx] pb-[50rpx]"
      >
        <!-- <up-waterfall
          v-model="orderList"
          columns="auto"
          ref="uWaterfallRef"
          class="gap-[20rpx] p-[20rpx]"
        >
          <template v-slot:column="{ colList }"> -->
        <OrderItem
          v-for="item in orderList"
          :key="item.id"
          :item="item"
          @click="goDetail(item.id!)"
          @clickPay="handleClickPay(item)"
          @getOrderList="handleSearchOrderList"
        />
        <!-- </template>
        </up-waterfall> -->

        <up-loadmore :status="loadStatus"></up-loadmore>
      </div>
      <template v-else>
        <up-empty mode="list"></up-empty>
      </template>
    </div>

    <!-- 支付弹窗 -->
    <PaymentPopup
      v-model="isShowPayPopup"
      :priceTotal="priceTotal"
      @submit="handlePaySubmit"
    >
      123订单信息slot?
      <up-qrcode
        v-if="scanPayInfoUrl"
        cid="ex1"
        :size="200"
        :val="scanPayInfoUrl"
      ></up-qrcode>
    </PaymentPopup>
  </div>
</template>

<style lang="scss" scoped>
.order-list {
  background: #f7f9fb;
  min-height: calc(100vh - 44px - 90rpx); // 44px为H5导航高度
}
</style>
