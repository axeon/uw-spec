<script lang="ts" setup>
import { computed, reactive, ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import {
  guestOrderInfoChangeApply,
  guestOrderInfoLoad,
  guestProductInfoLoad,
  type OrderChangeRequest,
  type OrderInfoEx,
  type ProductInfo
} from '@/api/saasMallAppGuestApi'
import dayjs from 'dayjs'
import { useI18n } from 'vue-i18n'
import { useCommonSelectTypes } from '@/utils/enumeration'
import {
  CalculationPrice,
  getProductSingleImg,
  isJSON,
  px2rpx
} from '@/utils/tool'
import GbNavbar from '@/components/GbNavbar/index.vue'

const { t } = useI18n()
const { handleTypeForLabel, StateOrderOptions, TypeSkuOptions } =
  useCommonSelectTypes()

const state = reactive({
  orderId: undefined as number | undefined
})
const orderDetailInfo = ref<OrderInfoEx>({})

// 凭证码
const isShowVoucherCode = ref(true)
const currentVoucherCode = computed(() => {
  return voucherCodeList.value[currentCodeIndex.value]?.id
})
const currentCodeIndex = ref(0)

const list = [
  {
    id: 1,
    url: 'https://qnimg.zowoyoo.com/img/84826/1716454786450.jpg'
  },
  {
    id: 2,
    url: 'https://qnimg.zowoyoo.com/img/84826/1757319569299.png'
  },
  {
    id: 3,
    url: 'https://qnimg.zowoyoo.com/img/84826/1620443426452.png'
  }
]
const voucherCodeList = computed(() => {
  // 并发生成所有二维码
  const newList = list.map((item) => {
    // const path = await makeQR({ text: item.id, width: 200 })
    return { ...item, url: item.url }
  })
  return newList
})

const sideMargin = computed(() => {
  return px2rpx(120) + 'rpx'
})

// 凭证码轮播点击
const handleClickVoucherSwiper = async () => {
  const index = currentCodeIndex.value
  console.log('handleClickVoucherSwiper', index)
  uni.previewImage({
    urls: [voucherCodeList.value[index].url]
  })
}

// swiper 切换
const handleChangeVoucherSwiper = (e: any) => {
  currentCodeIndex.value = e.detail.current
}

const getOrderInfo = async () => {
  const res = await guestOrderInfoLoad({ id: state.orderId! })
  if (res.state === 'success' && res.data) {
    orderDetailInfo.value = res.data
  } else {
    orderDetailInfo.value = {}
  }

  if (getInfo().productId) {
    getProductInfo()
  }
}

const productDetail = ref<ProductInfo>({})

// 获取产品信息
const getProductInfo = async () => {
  const res = await guestProductInfoLoad({ id: getInfo().productId })
  try {
    if (res.state === 'success' && res.data) {
      // console.log('guestProductInfoLoad', res.data)
      productDetail.value = res.data
    } else {
      productDetail.value = {}
    }
  } catch (error) {
    console.log('guestProductInfoLoad error', error)
  }
}

// 解析orderInfo的字段 前端DIY存储 list展示
const getInfo = (): any => {
  const orderInfo = orderDetailInfo.value?.orderInfo || ''
  let obj = {} as any
  if (isJSON(orderInfo)) {
    obj = JSON.parse(orderInfo)
  }
  return obj
}

// 订单退款
const handleOrderRefund = () => {
  uni.showModal({
    title: '提示',
    content: '',
    placeholderText: '请输入订单退款原因',
    editable: true,
    success: async function (modalRes) {
      console.log('modalRes', modalRes)
      if (modalRes.confirm) {
        const data: OrderChangeRequest = {
          orderId: orderDetailInfo.value.id, //订单ID
          cancelVoucherIds: '', //取消code(票码id:取消数量),多个用,分开
          applyType: 1, //申请类型1修改 0 取消
          // @ts-ignore
          applyInfo: modalRes.content //申请理由
        }
        console.log('用户点击确定', data)
        const res = await guestOrderInfoChangeApply(data)
        if (res.state === 'success') {
          uni.showToast({
            icon: 'none',
            title: '订单退款成功'
          })
        } else {
          uni.showToast({
            icon: 'none',
            title: res.msg
          })
        }
      } else if (modalRes.cancel) {
        console.log('用户点击取消')
      }
    }
  })
}

onLoad((options: any) => {
  // console.log('orderDetail')
  state.orderId = options.id
  if (state.orderId) {
    getOrderInfo()
  }
})
</script>

<template>
  <GbNavbar />

  <div class="orderDetail p-[30rpx] pb-[120rpx]">
    <div class="order-detail-box">
      <div
        class="flex items-center justify-center py-[30rpx] text-[#01060C] text-[32rpx]"
      >
        订单编号：{{ state.orderId }}
      </div>
    </div>
    <div class="div-br"></div>

    <!-- unpaid 待支付 -->
    <div class="order-detail-box">
      <div class="flex flex-col p-[30rpx] gap-[30rpx]">
        <div class="text-[32rpx] text-[#01060C]">
          {{ t('待支付') }} {{ '00:15:00' }}
        </div>

        <div class="text-[30rpx] text-[#01060C] font-bold">
          {{ 'CNY 69.00' }}
        </div>

        <div class="flex gap-[30rpx] justify-end">
          <div class="order-btn-item">取消</div>
          <div class="order-btn-item pay">支付</div>
        </div>
      </div>
    </div>
    <div class="div-br"></div>

    <!-- 已确认 / 已完成 -->
    <div class="order-detail-box">
      <div class="flex flex-col p-[30rpx] gap-[20rpx]">
        <div class="text-[32rpx] text-[#01060C]">
          <!-- {{ t('已确认') }} -->
          {{ t('订单已完成') }}
        </div>

        <div class="flex justify-between">
          <div class="text-[30rpx] text-[#01060C] font-bold">
            {{ 'CNY 69.00' }}
          </div>
          <span
            v-if="isShowVoucherCode === false"
            @click="isShowVoucherCode = true"
            class="text-[#14293F] underline"
          >
            {{ t('查看凭证') }}
          </span>
        </div>

        <template v-if="isShowVoucherCode">
          <div class="div-line"></div>
          <div class="">{{ t('凭证码') }}</div>
          <div class="bg-[#F7F9FB] rounded-[20rpx] py-[25rpx]">
            <!-- 当前券码 -->
            <div class="text-center text-[26rpx] text-[#8A9098]">
              {{ currentVoucherCode }}
            </div>

            <swiper
              class="h-[340rpx] mt-[20rpx]"
              :current="currentCodeIndex"
              :indicator-dots="false"
              :autoplay="false"
              :previous-margin="sideMargin"
              :next-margin="sideMargin"
              :circular="true"
              @change="handleChangeVoucherSwiper"
            >
              <swiper-item
                v-for="(item, index) in voucherCodeList"
                :key="index"
                class="border"
                @click="handleClickVoucherSwiper"
              >
                <!-- 真正的卡片 -->
                <div
                  class="w-full h-full border rounded-[24rpx] bg-white shadow-lg flex flex-col justify-center items-center transition-transform duration-300"
                  :class="{ 'opacity-60': index !== currentCodeIndex }"
                >
                  <up-qrcode
                    :cid="`cix-qrcode-${index}`"
                    :val="String(item.id)"
                    showLoading
                    loadingText="loading..."
                  ></up-qrcode>
                </div>
              </swiper-item>
            </swiper>

            <!-- 指示器 -->
            <div class="text-center text-[26rpx] text-[#14293F] mt-[20rpx]">
              {{ currentCodeIndex + 1 }}/{{ voucherCodeList.length }}
            </div>
          </div>
          <div
            @click="isShowVoucherCode = false"
            class="flex justify-center gap-[10rpx] text-[24rpx] text-[#8A9098]"
          >
            {{ t('收起') }}
            <up-icon
              name="arrow-up"
              size="24rpx"
            ></up-icon>
          </div>
        </template>

        <div class="flex justify-start">
          <div class="order-btn-item refund">{{ t('申请退款') }}</div>
        </div>
      </div>
    </div>
    <div class="div-br"></div>

    <div class="div-shadow flex flex-col gap-[10rpx]">
      <up-title>订单基本信息</up-title>
      <div class="flex items-center justify-between">
        <div class="text-gray-500">订单状态</div>
        <div class="font-bold text-black">
          {{
            handleTypeForLabel(orderDetailInfo.orderState!, StateOrderOptions)
          }}
        </div>
      </div>
      <div class="flex items-center justify-between">
        <div class="text-gray-500">订单编号</div>
        <div class="font-bold text-black">{{ orderDetailInfo.id }}</div>
      </div>
      <div class="flex items-center justify-between">
        <div class="text-gray-500">下单日期</div>
        <div class="font-bold text-black">
          {{ dayjs(orderDetailInfo.orderDate).format('YYYY-MM-DD HH:mm:ss') }}
        </div>
      </div>
      <div class="flex items-center justify-between">
        <div class="text-gray-500">订单金额</div>
        <div class="font-bold text-black">
          CNY {{ CalculationPrice(orderDetailInfo.orderMoney! / 100) }}
        </div>
      </div>
    </div>

    <div class="div-br"></div>

    <div class="div-shadow flex flex-col gap-[10rpx]">
      <up-title>产品信息</up-title>
      <div class="flex items-center justify-between">
        <div class="text-gray-500">产品图</div>
        <div class="w-[200rpx] h-[200rpx]">
          <img
            class="w-full h-full"
            :src="getProductSingleImg(productDetail.imgMain)"
          />
        </div>
      </div>
      <div class="flex items-center justify-between">
        <div class="text-gray-500">产品名称</div>
        <div class="font-bold text-black">{{ getInfo().productName }}</div>
      </div>
      <div class="flex items-center justify-between">
        <div class="text-gray-500">产品类型</div>
        <div class="font-bold text-black">
          {{ handleTypeForLabel(getInfo().skuType, TypeSkuOptions) }}
        </div>
      </div>
      <div class="flex items-center justify-between">
        <div class="text-gray-500">游玩日期</div>
        <div class="font-bold text-black">{{ getInfo().travelDate }}</div>
      </div>
      <div class="flex items-center justify-between">
        <div class="text-gray-500">规格信息</div>
        <div
          v-for="item in getInfo().specInfoList"
          :key="item.specId"
        >
          <div class="flex">
            {{ item.specName }} (CNY
            {{ CalculationPrice(item.priceSale! / 100) }}) *
            {{ item.purchaseNum }}
          </div>
        </div>
      </div>
    </div>

    <div class="div-br"></div>

    <div class="div-shadow flex flex-col gap-[10rpx]">
      <up-title>游客信息</up-title>
      <div class="flex flex-col gap-2">
        <div
          class="guest-item flex flex-col gap-1 border border-gray-300 rounded-2xl p-[20rpx]"
          v-for="(item, index) in orderDetailInfo.orderGuestList"
          :key="item.id"
        >
          <h4 class="guest-item__title">游客{{ index + 1 }}</h4>
          <div class="w-full h-[2rpx] bg-gray-100"></div>
          <div
            v-if="item.guestName"
            class="guest-item__row"
          >
            <span class="label">{{ t('姓名') }}</span>
            <span class="value">{{ item.guestName }}</span>
          </div>
          <div
            v-if="item.guestNamePinyin"
            class="guest-item__row"
          >
            <span class="label">{{ t('姓名拼音') }}</span>
            <span class="value">{{ item.guestNamePinyin }}</span>
          </div>
          <template v-if="item.idInfo">
            <div class="guest-item__row">
              <span class="label">{{ t('证件类型') }}</span>
              <span class="value">{{ item.idType }}</span>
            </div>
            <div class="guest-item__row">
              <span class="label">{{ t('证件号码') }}</span>
              <span class="value">{{ item.idInfo }}</span>
            </div>
          </template>
          <div
            v-if="item.guestGender"
            class="guest-item__row"
          >
            <span class="label">{{ t('guestGender') }}</span>
            <span class="value">{{ item.guestGender }}</span>
          </div>
          <div
            v-if="item.guestMobile"
            class="guest-item__row"
          >
            <span class="label">{{ t('手机号') }}</span>
            <span class="value">{{ item.guestMobile }}</span>
          </div>
          <div
            v-if="item.guestAddress"
            class="guest-item__row"
          >
            <span class="label">{{ t('地址') }}</span>
            <span class="value">{{ item.guestAddress }}</span>
          </div>
          <div
            v-if="item.guestEmail"
            class="guest-item__row"
          >
            <span class="label">{{ t('邮箱') }}</span>
            <span class="value">{{ item.guestEmail }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 底部悬浮 -->
    <div
      class="fixed bottom-0 left-0 right-0 z-50 bg-white flex justify-end h-[100rpx] items-center p-[0_30rpx] shadow-[0rpx_-1rpx_10rpx_0rpx_rgba(0,0,0,0.11)]"
    >
      <div
        class="order-btn-item refund"
        @click.stop="handleOrderRefund()"
      >
        申请退款
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.orderDetail {
  .order-detail-box {
    border-radius: 20rpx;
    background-color: #ffffff;
    box-shadow: 0px 2px 20px 0px rgba(0, 0, 0, 0.05);
  }
  .guest-item {
    .guest-item__title {
      font-size: 36rpx;
      font-weight: 700;
    }
    .guest-item__row {
      display: flex;
      justify-content: space-between;
    }
  }
}
</style>
