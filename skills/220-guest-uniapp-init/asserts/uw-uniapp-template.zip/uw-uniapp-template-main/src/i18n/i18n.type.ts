export type I18N = 'ja' | 'zh-CN' | 'zh-TW' | 'en'

export const localeEnum: Record<I18N, string> = {
  ja: '日本語',
  en: 'English',
  'zh-CN': '简体中文',
  'zh-TW': '繁體中文'
}

export interface LANG_LIST {
  label: string
  value: I18N
}

/**
 * 请求头国际化枚举
 */
export enum EnumHeaderLang {
  'ja' = 'ja',
  'zh-CN' = 'zh-Hans',
  'zh-TW' = 'zh-Hant',
  'en' = 'en'
}
