// 自动导入当前文件夹的所有文件下多语言包
const zhCN = import.meta.glob(['./*', '!./index', '!./type.d.ts'], {
  import: 'default',
  eager: true
})

let i18nZh = {
  ...zhCN
}

for (const key in zhCN) {
  if (Object.prototype.hasOwnProperty.call(zhCN, key)) {
    const item = zhCN[key]
    i18nZh = Object.assign(i18nZh, item)
  }
}
export default i18nZh
