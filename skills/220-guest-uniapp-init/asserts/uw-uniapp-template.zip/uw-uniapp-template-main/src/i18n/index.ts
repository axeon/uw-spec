// 定义语言国际化内容
import { createI18n } from 'vue-i18n'
import pinia from '../store'
import { useMainStore } from '../store/main'
import type { I18N } from './i18n.type'

export const messages = {}

// 引入i18n文件夹下所有集合index.ts文件
const modules: Record<string, any> = import.meta.glob(
  ['./*/index.ts', '!./*/type.ts', '!./type.d.ts'],
  {
    eager: true
  }
)
// console.log('modules >>>', modules)

// https://vitejs.cn/vite3-cn/guide/features.html#glob-import
for (const path in modules) {
  const match = path.match(/\.\/([\w-]+)\//)
  const key = match ? match[1] : null //  取出文件夹名的 en、zh-cn、zh-tw ... 作为key
  // @ts-ignore
  messages[key] = modules[path].default
}

const useI18n = () => {
  const mainStore = useMainStore(pinia)
  return createI18n({
    legacy: false, // 表示不使用 Vue 2 的传统 API，而是使用 Vue 3 的新 API。
    locale:
      mainStore.i18n || (mainStore.curBrownerLang as I18N).toLocaleLowerCase(), // 默认使用本地存储语言标识 || 浏览器默认语言标识
    fallbackLocale: 'zh-CN', // 没有定义的文件包 默认使用中文
    messages
  })
}

export default useI18n
