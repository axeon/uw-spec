import dayjs from 'dayjs'
import 'dayjs/locale/zh-cn'
import 'dayjs/locale/zh-tw'
import 'dayjs/locale/en'
import 'dayjs/locale/ja'
import type { I18N } from './i18n.type'
// 想支持更多语言就继续 import

/** 把业务里的语言标识映射成 dayjs 认识的 locale 名 */
const LOCALE_MAP: Record<I18N, string> = {
  'zh-CN': 'zh-cn',
  'zh-TW': 'zh-tw',
  en: 'en',
  ja: 'ja'
}

/** 切换 dayjs 语言 */
export function setDayjsLocale(lang: I18N) {
  const locale = LOCALE_MAP[lang] ?? 'zh-cn'
  dayjs.locale(locale)
}
