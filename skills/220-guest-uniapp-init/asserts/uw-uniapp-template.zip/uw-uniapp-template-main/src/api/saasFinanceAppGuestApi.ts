import request from '@/api/request'
import type { ResponseData } from '@/api/type/API_TYPE'

/**
 * 系统支付配置
 */
export const userCommonPaymentListSysConfig = () => {
  return request({
    url: '/saas-finance-app/user/common/payment/listSysConfig',
    method: 'GET'
  }) as Promise<ResponseData<Array<AisLinkerConfigInfo>>>
}
/**
 * 支付配置
 */
export const userCommonPaymentListConfig = () => {
  return request({
    url: '/saas-finance-app/user/common/payment/listConfig',
    method: 'GET'
  }) as Promise<ResponseData<Array<AisLinkerConfigInfo>>>
}

/**
 *
 */
export interface AisLinkerConfigInfo {
  id?: number //主键ID
  state?: number //状态
  appName?: string //应用信息
  saasId?: number //运营商编号
  createDate?: string //创建时间
  linkerId?: number //链接器ID
  linkerName?: string //链接器名称
  linkerFunction?: string //链接器功能
  linkerVersion?: string //链接器版本
  linkerIcon?: string //链接器图标
  mchId?: number //商户ID
  configSid?: string //标识id
  configName?: string //接口配置名称
  modifyDate?: string //修改时间
  pubParamMap?: any //开放配置参数
}
