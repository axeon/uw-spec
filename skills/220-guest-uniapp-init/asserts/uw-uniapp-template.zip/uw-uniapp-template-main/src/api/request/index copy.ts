// import axios, { AxiosRequestConfig } from 'axios'
import pinia from '@/store/index'
import { formatParam } from '@/utils/tool'
import { useUserStore } from '@/store/user'
import { Observer, Subject } from '@/utils/PubSub/index'
import systemConfig from '@/config/common'
import { EnumHeaderLang } from '@/i18n/i18n.type'
import i18n from '@/i18n/index'
// import { authRefreshToken } from '../authUwAuthCenterApi'
// import JSONBigint from 'json-bigint'

let __API_LOGIN_ = false
const subject = new Subject()

// 替换超大数字为String
function processLargeNumbersInJSON(jsonStr: string) {
  // 先处理字符串中的大数字，匹配16-20位数字，可以以L结尾
  const processedJsonStr = jsonStr.replace(
    /:\s*(\d{16,20}L?)/g,
    (match: string, number: number) => {
      return `: "${number}"`
    }
  )

  try {
    const parsed = JSON.parse(processedJsonStr)
    return parsed
  } catch (error) {
    console.error('JSON parsing error:', error)
    return null
  }
}

interface CONFIG {
  baseURL?: string
  url: string
  // #ifndef MP-ALIPAY
  responseType?: 'text' | 'arraybuffer'
  // #endif
  method?:
    | 'OPTIONS'
    | 'GET'
    | 'HEAD'
    | 'POST'
    | 'PUT'
    | 'DELETE'
    | 'TRACE'
    | 'CONNECT'
  data?: AnyObject | ArrayBuffer
  header?: AnyObject
  params?: AnyObject
}

// 接口白名单  这些接口可以不登录获取数据
const APIwhiteList = [
  '/saas-mall-app/guest/site/info/load',
  '/saas-mall-app/open/guest/auth/login', // 登录接口
  '/saas-mall-app/open/guest/auth/genCaptcha',
  '/saas-mall-app/open/guest/auth/sendVerifyCode', // 获取验证码
  '/saas-mall-app/open/guest/auth/registry', // 注册
  '/jtr-jwqs-app/open/account/info/registry',
  '/jtr-jwqs-app/open/account/info/login',
  '/jtr-jwqs-app/open/account/info/genCaptcha',
  '/jtr-jwqs-app/open/account/info/sendVerifyCode',
  '/jtr-jwqs-app/open/account/info/resetPassword',
  '/jtr-jwqs-app/open/account/info/getAllCountry', // 根据语言环境，获取全部国家信息
  '/jtr-jwqs-app/open/account/info/resetPasswordCheck',
  '/jtr-jwqs-app/open/account/info/resetPasswordSend'
]

// 错误信息提示 // uw-center 接口返回中文信息 i18n翻译
const handleErrorMsg = (val: string) => {
  const { t } = i18n().global
  let msg = ''
  if (val) {
    if (val.search('账号不可用') !== -1) {
      msg = t('AccountUnavailable')
    } else if (val.search('图形识别码验证错误') !== -1) {
      msg = t('imgCodeError')
    } else if (val.search('请输入图形识别码') !== -1) {
      msg = t('InputImgCode')
    } else if (val.search('用户名或密码不正确') !== -1) {
      msg = t('AccountOrPwdError')
    } else if (val.search('用户名密码错误或状态异常') !== -1) {
      msg = t('AccountPwdErrorOrStatusError')
    } else {
      msg = val
    }
  }
  return msg
}

/**
 * 不需要token权限的api地址
 */
const handlerVerify = (apiUrl: string) => {
  const userStore = useUserStore(pinia)
  if (userStore.token) return false
  return !APIwhiteList.includes(apiUrl)
}

function request(config: CONFIG) {
  const userStore = useUserStore(pinia)
  // const { t, locale } = i18n().global
  const { locale } = i18n().global

  return new Promise((resolve, reject) => {
    // debugger
    const baseURL = config.baseURL || systemConfig.baseUrl
    let url = baseURL + config.url
    if (Object.keys(config.params || {}).length > 0) {
      url += `?${formatParam(config.params || {})}`
    }

    const requestInfo = {
      url,
      method: config.method,
      data: config.data,
      // #ifndef MP-ALIPAY
      responseType: config.responseType,
      // #endif
      header: {
        'Accept-Language':
          EnumHeaderLang[locale.value as keyof typeof EnumHeaderLang],
        'Content-type': 'application/json; charset=UTF-8',
        Authorization: 'Bearer ' + userStore.token,
        // Authorization: userStore.token,
        ...config.header
      },
      dataType: 'String' //把接收来的数据转换成字符串类型，而不直接解析
    }
    // console.log('request 入参 :', requestInfo)
    // debugger

    uni.request({
      ...requestInfo,
      success: async (res) => {
        // console.log('request 响应success:', res)
        // console.log('request url :', url)
        // console.log('request token :', 'Bearer ' + userStore.token)
        // console.log('request config.header :', config.header)

        // debugger

        // @ts-ignore
        if (res.data && res.data.msg) {
          // @ts-ignore
          res.data.msg = handleErrorMsg(res.data.msg)
        }

        if (
          [
            '/uw-auth-center/auth/login',
            '/jtr-jwqs-app/open/account/info/login'
          ].includes(url)
        ) {
          // debugger
          // @ts-ignore
          if (res.data.state === 'success') {
            // @ts-ignore
            res.header.authtoken = res.data.data.token
          }
        }

        // #region 代码块 --> 重定向错误页面
        const statusCodeStr = res.statusCode?.toString()
        const redirectMap = {
          '404': '/packages/other/404',
          '503': '/packages/other/503',
          '500': '/packages/other/500'
        }
        for (const key in redirectMap) {
          if (statusCodeStr?.startsWith(key)) {
            uni.hideToast()
            uni.hideLoading()
            uni.reLaunch({
              url: redirectMap[key as keyof typeof redirectMap]
            })
            return false
          }
        }
        // #endregion
        resolve(processLargeNumbersInJSON(res.data as string))
        // if (res.statusCode === 200) {
        //   // 由于id会有超长的数字情况 所以需要特殊处理
        //   resolve(processLargeNumbersInJSON(res.data as string))
        // } else if (
        //   res.statusCode === 401 &&
        //   ![
        //     '/saas-mall-app/guest/site/info/load',
        //     '/saas-mall-app/open/guest/auth/login'
        //   ].includes(url)
        // ) {
        //   __API_LOGIN_ = false
        //   // 实例化订阅者
        //   const obs = new Observer(() => {
        //     request(config)
        //       .then((res) => {
        //         console.log('重新请求完成')
        //         console.log(res)
        //         // 移除订阅者
        //         subject.remove(obs)
        //         resolve(res)
        //       })
        //       .catch((err) => {
        //         console.log('res.statusCode === 401', err)
        //         // debugger
        //         reject(err)
        //       })
        //   })
        //   // 添加订阅者
        //   subject.add(obs)
        //   if (!__API_LOGIN_) {
        //     __API_LOGIN_ = true
        //     uni.reLaunch({
        //       url: '/pages/login/index',
        //       success: () => {
        //         __API_LOGIN_ = false
        //         // #ifdef H5
        //         window.location.reload()
        //         // #endif
        //       }
        //     })
        //   }
        // } else if (res.statusCode === 403) {
        //   uni.showToast({
        //     title: t('curUserNotPerm'),
        //     icon: 'none',
        //     mask: true,
        //     duration: 5000
        //   })
        // } else if (res.statusCode === 406) {
        //   // refreshToken 错误
        //   uni.showToast({
        //     title: t('tokenExpired'),
        //     icon: 'none',
        //     mask: true,
        //     duration: 2000
        //   })
        //   setTimeout(() => {
        //     uni.reLaunch({
        //       url: '/pages/login/index'
        //     })
        //   }, 3000)
        // } else if (res.statusCode === 409) {
        //   // 于区分用户重复登录，前端需要识别跳转登录页并展示错误。
        //   console.error(res)
        //   uni.showToast({
        //     title: `${res.statusCode} ${t('curAccountOtherLogin')}`,
        //     icon: 'none',
        //     mask: true,
        //     duration: 5000
        //   })
        //   // userStore.exceptClearStorage(['loginId', 'loginSecret', 'lang'])
        //   uni.reLaunch({
        //     url: '/pages/login/index'
        //   })
        // } else if (
        //   res.statusCode === 423 &&
        //   !url.includes('/uw-auth-center/auth/refreshToken')
        // ) {
        //   // 刷新token 没必要提示
        //   // uni.showToast({
        //   //   title: '身份信息过期正在重新登录',
        //   //   mask: true,
        //   //   icon: 'none'
        //   // })
        //   __API_LOGIN_ = false
        //   // 实例化订阅者
        //   const obs = new Observer(() => {
        //     request(config)
        //       .then((requestRes) => {
        //         // 移除订阅者
        //         subject.remove(obs)
        //         resolve(requestRes)
        //       })
        //       .catch((err) => {
        //         console.log('res.statusCode === 423  obs', err)
        //         reject(err)
        //       })
        //   })
        //   // 添加订阅者
        //   subject.add(obs)
        //   if (!__API_LOGIN_) {
        //     __API_LOGIN_ = true
        //     // debugger
        //     authRefreshToken({
        //       refreshToken: encodeURIComponent(userStore.refreshToken),
        //       loginAgent: userStore.loginAgent
        //     })
        //       .then((authRefreshRes) => {
        //         const authRefreshData = {
        //           createAt: authRefreshRes.data?.createAt || 0,
        //           expiresIn: authRefreshRes.data?.expiresIn || 0,
        //           token: authRefreshRes.data?.token || ''
        //         }
        //         userStore.setRefreshTokenInfo(authRefreshData)
        //         // 发布者 通知 订阅者
        //         subject.notify()
        //         __API_LOGIN_ = false
        //       })
        //       .catch((error) => {
        //         console.log('res.statusCode === 423  authRefreshToken', error)
        //         uni.navigateTo({
        //           url: `/pages/login/index`
        //         })
        //       })
        //   }
        // } else if (res.statusCode >= 500) {
        //   // console.log(res)
        //   // debugger
        //   // @ts-ignore
        //   if (res.data.msg) {
        //     uni.showToast({
        //       // title: `请求过于频繁，请稍后再试(${res.statusCode})`,
        //       // @ts-ignore
        //       title: res.data.msg,
        //       icon: 'none',
        //       duration: 3000,
        //       mask: true
        //     })
        //   }
        // } else {
        //   console.log('进入到 reject 条件')
        //   console.log(url)
        //   console.log(res.data)
        //   reject(res.data)
        // }
      },
      fail: (error) => {
        console.log('request 响应fail error:', error)
        reject(error)
      },
      complete: () => {
        //
      }
    })
  })
}

// 代理拦截器，有token才正常放行，不然先去登录再放行
export default new Proxy(request, {
  get(target, key, receiver) {
    if (
      ['request', 'get', 'delete', 'head', 'post', 'put', 'patch'].includes(
        key as string
      )
    ) {
      return new Proxy(Reflect.get(target, key, receiver), {
        apply: this.apply
      })
    } else {
      return Reflect.get(target, key, receiver)
    }
  },
  apply(target: any, thisArg, args) {
    return new Promise((resolve, reject) => {
      const apiUrl = args[0].url.replace(/\/[0-9]+$/, '/')
      const permission = handlerVerify(apiUrl)
      // console.log('apiUrl')
      // console.log(apiUrl)
      // console.log('permission')
      // console.log(permission)
      if (permission) {
        // 登录判断
        console.log('new Proxy 来静默登录了')
        const userStore = useUserStore(pinia)
        // 实例化订阅者
        const obs = new Observer(() => {
          target(...args)
            .then((res: unknown) => {
              // 移除订阅者
              subject.remove(obs)
              resolve(res)
            })
            .catch((err: any) => {
              console.log('permission new Proxy(request', err)
              reject(err)
            })
        })
        // 添加订阅者
        subject.add(obs)
        if (!__API_LOGIN_) {
          if (userStore.token) {
            // 发布者 通知 订阅者
            subject.notify()
            __API_LOGIN_ = false
          } else {
            // uni.showToast({
            //   icon: 'none',
            //   duration: 3000,
            //   title: t('tokenExpired')
            // })
            // debugger
            uni.reLaunch({
              url: `/pages/login/index`
            })
          }
        }
      } else {
        target(...args)
          .then((res: unknown) => {
            resolve(res)
          })
          .catch((err: any) => {
            console.log('!permission new Proxy(request', err)
            reject(err)
          })
      }
    })
  }
})
