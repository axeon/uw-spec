<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { onLoad, onPageScroll, onReachBottom } from '@dcloudio/uni-app'
import {
  guestPoiInfoList,
  type GuestPoiInfoQueryParam,
  type PoiInfo
} from '@/api/saasMallAppGuestApi'
import PoiItem from './component/PoiItem.vue'
import { clone } from 'lodash-es'
// import { useI18n } from 'vue-i18n'

// const { t } = useI18n()

const pageLoading = ref(false)
// 触底加载状态
const loadStatus = ref('nomore')

const poiQuery = reactive<GuestPoiInfoQueryParam>({
  $pg: 1,
  $rn: 10,
  // ids: [169386], // test
  // $rt: 2, // 取总数 和 results
  $sn: ['id'],
  $st: [2],
  state: 1
  // poiType: 1  // 产品类型(1:产品,2:场次,3:规格)
})
const poiList = ref<PoiInfo[]>([])

// 搜索Poi
const handleSearchPoiList = () => {
  poiQuery.$pg = 1
  poiList.value = []
  getPoiList()
}

// 根据poiIds获取POI列表 (景点列表)
const getPoiList = async () => {
  pageLoading.value = true
  try {
    loadStatus.value = 'loading'
    const copyPoiQuery = clone(poiQuery)
    if (copyPoiQuery.poiName) {
      copyPoiQuery.poiName = encodeURIComponent(`%${copyPoiQuery.poiName}%`)
    }
    const res = await guestPoiInfoList(copyPoiQuery)
    // qrTotal.value = res.data?.sizeAll || 0
    if (res.state === 'success' && res.data?.results?.length) {
      if (poiQuery.$pg === 1) {
        poiList.value = res.data.results

        if (res.data.sizeAll! >= copyPoiQuery.$rn!) {
          loadStatus.value = 'loadmore'
        } else {
          loadStatus.value = 'nomore'
        }
      } else {
        poiList.value = [...poiList.value, ...res.data.results]
      }
    } else if (res.state === 'success' && !res.data?.results) {
      console.log('noMore')
      loadStatus.value = 'nomore'
    }
  } catch (error) {
    console.log('error', error)
  } finally {
    pageLoading.value = false
  }
}

// 跳转到详情页
const goDetail = (id: number) => {
  console.log('跳转到详情页', id)
  uni.navigateTo({
    url: '/poi/detail?id=' + id
  })
}

onLoad(() => {
  getPoiList()
})

const scrollTop = ref(0)
// onPageScroll 方法来更新 scrollTop 的值
onPageScroll((e) => {
  scrollTop.value = e.scrollTop
})

onReachBottom(() => {
  console.log('触底了')
  if (poiQuery.$pg) {
    poiQuery.$pg++
    getPoiList()
  }
})
</script>

<template>
  <div
    class="bg-[#f4f4f4]"
    style="min-height: calc(100vh - 44px)"
  >
    <up-sticky bgColor="#fff">
      <div class="h-[100rpx] p-[20rpx] flex items-center">
        <up-search
          placeholder="请输入景点名称"
          v-model="poiQuery.poiName"
          clearable
          @search="handleSearchPoiList"
          @clear="handleSearchPoiList"
          @custom="handleSearchPoiList"
        ></up-search>
      </div>
    </up-sticky>

    <!-- POI景点列表 -->
    <div>
      <div
        v-if="poiList.length"
        class="poi-list pt-[20rpx] pb-[50rpx]"
      >
        <up-waterfall
          v-model="poiList"
          :columns="2"
          :add-time="200"
          ref="uWaterfallRef"
          class="gap-[20rpx] p-[20rpx] pt-0"
        >
          <template v-slot:column="{ colList }">
            <PoiItem
              v-for="item in colList"
              :key="item.id"
              :item="item"
              @click="goDetail(item.id!)"
            />
          </template>
        </up-waterfall>

        <up-loadmore :status="loadStatus"></up-loadmore>
      </div>
      <template v-else>
        <up-empty mode="list"></up-empty>
      </template>
    </div>

    <up-back-top :scroll-top="scrollTop"></up-back-top>
  </div>
</template>

<style lang="scss" scoped>
.poi-list {
  min-height: 100vh;
  :deep(.u-column) {
    display: flex;
    gap: 20rpx;
  }
}
</style>
