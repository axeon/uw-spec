<script lang="ts" setup>
// import { ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'

onLoad(() => {
  console.log('账号安全 ---')
})
</script>

<template>
  <view class="account-safe">账号安全</view>
</template>

<style lang="scss" scoped>
// .account-safe {}
</style>
