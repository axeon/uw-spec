view
<script lang="ts" setup>
import { reactive } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import { useUserStore } from '@/store/user'

import ZSetTitle from '@/packages/setting/components/ZSetTitle.vue'
import {
  guestUserInfoUpdate,
  type GuestUpdateRequest
} from '@/api/saasMallAppGuestApi'

const userStore = useUserStore()

// const genders = readonly([
//   {
//     value: '0',
//     name: '未知'
//   },
//   {
//     value: '1',
//     name: '男'
//   },
//   {
//     value: '2',
//     name: '女'
//   }
// ])

const state = reactive({
  userHeadImg:
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAMAAABHPGVmAAAA3lBMVEUAAADu7u7u7u7u7u7t7e3u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7s7Ozu7u7u7u7u7u7u7u7q6urm5ubu7u7MzMzu7u7u7u7MzMzu7u7u7u7MzMzMzMzMzMzu7u7u7u7u7u7u7u7u7u7MzMzu7u7MzMzu7u7u7u7e3t7g4ODMzMzu7u7MzMzMzMzMzMzPz8/u7u7u7u7Nzc3MzMzu7u7u7u7MzMzNzc3s7OzU1NTY2Nji4uLf39/Pz8/o6Ojk5OTa2trq6urR0dHm5ubc3Ny5zzWuAAAAOnRSTlMA7sonIhX7m/Pw4dzjsaaQbmtmRDcsGgcB95mVXCUTv/fw2dincj4zFPLEifTkpqaEc2VcNO2+i4uKpKHfVwAAA8hJREFUaN61mol22jAQRWUHAoFCWEKggTZtkzTpvm9P8krA8P8/1JTTHpcc/Ea2yP2Be8aaGUYalC31Ye+447e9JtD02n7nuDesq31S63db2EGr26/tx3DwsQ1C++OBq+Fp34eI33/qEkTjMax43DioqugewprDbhVNfZor7DTTstk2GXgojTeYlMrZc1TivERGz45QkaOZpWLcgAONsY3j1IcT/qnsGLXgSGskOU48OOOdcMfLJvZA8yWNgzrseUViGR1hTxyNCvPqEfbGo9OC+pByN4gXYWa01iYLF3EgZPLuehFqcLkw+n/MYsmrcmcv4VGsjb6PWdNoZjt6Ij30eah3Ec7Z4dfuOybfqSPVu0mZ5fx+5x9IjiqWwb2B4Rs7j0wXk5Fz8bYHjCkIa81Yo5jp1sxwyD6WoRJDPtjhgcrpghBpToRiupaBLI3mmKUUilzriZZIbOq+TufEUJSEbLb8N4xd0X5iRIlh3eXqr+QChJWWWaGYC7XhGm5Hwg8F1xvJG/AElolAeLORtOF27vzk0d70eFBSLZOC8afj98EItA0BCP07ySUYSyvJEoTLOwkfUeZWkjkdXJSq46ElqKshINeiXI2MoepBqkXXakRPHUPuXG7dC8eqA0as7YhB6CgfjIWlZAGCr1py53LtXi3lPXwknnoFxq2l5BaEpgIlSK0caQCGwsPXCcjnsj+VBShNcvDWpRKD4+UpzIpeLneewj4kQpsfX16MHbh+rxgCnbxBsjSW05c3yB5EEjl9hVY/hEwkdy3+o1WHkyWCTJ0OEnJJLiDziI5Ech6HsOCSDndyHsewoE/HVHk0msOCWj5wCyzp5CgO3OoXLAjoDCxfHa4fNpJrfp2Tf4dvIXKRX0xFoqqleEWu2CQQEgq5YqsGBFamQGJW4DSEZ4+cxOgiTIIc/oLTpWGEmhGuhAccOZQgtnj2iAMSSM60wBBZXh2i3Z7p9vOgtysGo+0xm3jo86AakHdgAn8nHqhtJufbdZHqKqS320+29PE50VVJyOPzHTOhvktfImZ8IZA6SNK81slqgwZiH4o/5kuaxEmS5Esatm6KnCRRvm5ii7NQc+Qhv3kirgAzJ0mWrwDZMtM4SQy8E4u1rHaTtEY2C2Y3yetTZcH4zMVxNlZ2fHleVfH8i7LmyeuKn+qJKsHk8/MKYXyeqHLcnD0rp3h2dqPK8+RDGccH8qW4Jo9GioIrODefXsiKF59ulCNff7yghp9f1V6oDd6/W0dRmGWp2ezjTZplYRS9ez+oqWrwv8O9Bd6W/Tvcb+Mc81EITelMAAAAAElFTkSuQmCC',
  btnLoading: false,
  isShowPopup: false,
  modalShow: false,
  modalData: {
    key: '' as keyof GuestUpdateRequest,
    value: ''
  }
})

/**
 * 修改用户信息接口调用
 */
const updateUserInfo = async () => {
  // const params = {
  //   ...userStore.userInfo,
  //   ...param
  // }
  // userUpdateProfile(params).then((res) => {
  //   console.log(res)
  // })
  state.btnLoading = true
  let params = {} as any
  params = userStore.userInfo
  params[state.modalData.key] = state.modalData.value
  try {
    console.log('params >>>>>>>', params)
    await guestUserInfoUpdate(params)
    state.btnLoading = false
    state.modalShow = false
    uni.showToast({
      icon: 'none',
      title: '资料修改成功'
    })
    userStore.setUserInfo()
  } catch (e) {
    state.btnLoading = false
    console.log('log输出的内容：e', e)
  }
}
/**
 * 性别修改
 */
// 监听性别更改
// const handleGenderChange = (e: any) => {
//   console.log(e)
//   // state.gender = e.detail.value
//   // updateUserInfo()
// }
/**
 * 打开编辑框
 */
const openModal = (key: keyof GuestUpdateRequest) => {
  state.modalData.key = key
  state.modalData.value = String(userStore.userInfo[key]! || '')
  state.modalShow = true
}
/**
 * 关闭编辑框
 */
const closeModal = () => {
  state.modalData.value = ''
  state.modalShow = false
}

onLoad(() => {
  console.log('用户信息 ---')
})
</script>

<template>
  <view class="userInfo-page">
    <view class="info-top flex-col flex-align flex-center">
      <img
        class="info-top__img"
        :src="state.userHeadImg"
        lazy-load
      />
      <text class="info-top__txt">点击头像更换照片</text>
    </view>

    <ZSetTitle
      title="姓名"
      :rightTxt="userStore.userInfo.username"
      @clickItem="openModal('username')"
    ></ZSetTitle>
    <!-- <ZSetTitle
      title="姓名"
      :rightTxt="userStore.userInfo.realName"
      @clickItem="openModal('realName')"
    ></ZSetTitle> -->
    <!-- <view class="title-item space-between">
      <text class="label">性别</text>
      <text class="icon-right flex-align flex-center">
        <text class="slot-txt">
          <picker
            :range="genders"
            :value="Number(userStore.userInfo.state)"
            range-key="name"
            :style="{ flex: 1 }"
            @change="handleGenderChange"
          >
            <view class="value font-color-base">男 | 女</view>
          </picker>
        </text>
        <uni-icons
          type="right"
          size="20"
        ></uni-icons>
      </text>
    </view> -->
    <ZSetTitle
      title="手机号"
      :rightTxt="userStore.userInfo.mobile"
      @clickItem="openModal('mobile')"
    ></ZSetTitle>
    <ZSetTitle
      title="邮箱"
      :rightTxt="userStore.userInfo.email"
      @clickItem="openModal('email')"
    ></ZSetTitle>

    <!-- 修改信息弹窗 -->
    <view
      v-if="state.modalShow"
      class="userInfo-modal"
      @tap="closeModal"
    >
      <view
        class="modal-box"
        @tap.stop="() => {}"
      >
        <view class="flex-center padding-20 fontBold">修改内容</view>
        <view class="padding-20">
          <input
            v-model="state.modalData.value"
            class="input"
            type="text"
          />
        </view>
        <view class="flex-align">
          <view
            class="flex-1 flex-center padding-20"
            @tap.stop="closeModal"
          >
            取消
          </view>
          <view
            class="flex-1 flex-center padding-20 primary-color"
            @tap.stop="updateUserInfo"
          >
            确认
          </view>
        </view>
      </view>
    </view>
  </view>

  <up-popup
    v-model="state.isShowPopup"
    @mask-click="state.isShowPopup = false"
  >
    123
  </up-popup>
  <!-- <up-popup :show="show" @close="close" @open="open"></up-popup> -->
</template>

<style lang="scss" scoped>
.userInfo-page {
  width: 100vw;
  height: 100vh;
  background-color: #f8f8f8;
  .info-top {
    box-sizing: border-box;
    background-color: #fff;
    height: 320rpx;
    width: 100%;
    margin-bottom: 20rpx;
    .info-top__img {
      height: 160rpx;
      width: 160rpx;
      border-radius: 50%;
      flex-shrink: 0;
    }
    .info-top__txt {
      color: #999999;
      margin-top: 10rpx;
    }
  }

  .title-item {
    padding: 20rpx 30rpx;
    border-bottom: 1px solid #eeeeee;
    background-color: #ffffff;
    // .label {}
    .icon-right {
      .slot-txt {
        margin-right: 10rpx;
      }
    }
  }

  .userInfo-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.4);
    z-index: 999;
    .modal-box {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 80%;
      background-color: #fff;
      border-radius: 20rpx;

      .input {
        background-color: #efefef;
        padding: 0 10rpx;
        font-size: 28rpx;
        height: 56rpx;
        border-radius: 8rpx;
      }
    }
  }
}
</style>
