<script lang="ts" setup>
import { onMounted, ref, computed } from 'vue'
import {
  guestAddressInfoList,
  guestAddressInfoSave,
  guestAddressInfoDelete,
  guestAddressInfoUpdate,
  type GuestAddress
} from '@/api/saasMallAppGuestApi'
import AddressCard from './components/AddressCard/index.vue'
import GbLoading from '@/components/GbLoading/index.vue'
import { useUserStore } from '@/store/user'
import areaData from './config/areaInfo'

const userStore = useUserStore()

const addressList = ref<GuestAddress[]>([])

const isAdd = ref(true) // 是否是新增
const showLoading = ref(true) // 是否显示加载
const isDefault = ref(false) // 是否是默认地址
const formRef = ref()
const uPickerRef = ref()
const show = ref(false)
const showDeleteTip = ref(false)
const showAddAddress = ref(false)
const addressForm = ref<GuestAddress>({
  guestName: '',
  guestPhone: '',
  areaCode: undefined,
  guestAddress: '',
  isDefault: isDefault.value ? 1 : 0
})
const areaName = ref('')
const deleteData = ref<{ id: number; remark: string }>({
  id: 0,
  remark: ''
})
const defaultIndex = ref<number[]>([0, 0, 0])
const testMobile = (val: string | number) => {
  return uni.$u.test.mobile(Number(val))
}
const rules = ref({
  guestName: {
    required: true,
    message: '请填写联系人姓名',
    trigger: ['change', 'blur']
  },
  guestAddress: {
    required: true,
    message: '请填写详细地址',
    trigger: ['change']
  },
  areaCode: [
    {
      required: true,
      message: '请选择所在城市'
    },
    {
      validator: (rule: any, value: string) => {
        if (value) {
          return true
        } else {
          return false
        }
      },
      message: '请选择所在城市',
      // 触发器可以同时用blur和change
      trigger: ['change']
    }
  ],
  guestPhone: [
    {
      required: true,
      message: '手机号不能为空',
      trigger: ['blur', 'change']
    },
    {
      validator: (rule: any, value: string) => {
        return testMobile(value)
      },
      message: '手机号码不正确',
      // 触发器可以同时用blur和change
      trigger: ['change', 'blur']
    }
  ]
})

// 省市区数据
const columns = computed(() => {
  let res = []
  if (defaultIndex.value.length === 3) {
    res = [
      areaData,
      areaData[defaultIndex.value[0]]?.children || [],
      areaData[defaultIndex.value[0]]?.children?.[defaultIndex.value[1]]
        ?.children || []
    ]
  } else {
    res = [areaData, [], []]
  }

  return res || []
})

// 获取地址列表
const getGuestAddressInfoList = () => {
  showLoading.value = true
  guestAddressInfoList({ state: 1, guestId: userStore.userInfo.id }).then(
    (res) => {
      if (res.data?.results) {
        addressList.value = res.data?.results
      }
      showLoading.value = false
    }
  )
}

// 修改地址信息
const editGuestAddressInfoUpdate = async (params: GuestAddress) => {
  const res = await guestAddressInfoUpdate(params)
  if (res.state === 'success') {
    uni.showToast({
      title: '修改成功',
      icon: 'success'
    })
    getGuestAddressInfoList()
  }
}

// 根据code查找省市区
const findAreaByCode = (data: any[], targetCode: string): any => {
  for (const item of data) {
    if (item.areaCode === targetCode) {
      return item
    }
    if (item.children && item.children.length > 0) {
      const result = findAreaByCode(item.children, targetCode)
      if (result) {
        return result
      }
    }
  }
  return null
}

// 编辑地址
const handleEdit = (record: GuestAddress) => {
  addressForm.value = record
  if (record.areaCode) {
    const area = findAreaByCode(areaData, String(record.areaCode))
    areaName.value = area && area.areaPath
  }
  isDefault.value = record.isDefault === 1 ? true : false
  isAdd.value = false
  showAddAddress.value = true
}
const handleDelete = (id: number) => {
  showDeleteTip.value = true
  deleteData.value.id = id
}
const confirm = async () => {
  const res = await guestAddressInfoDelete({
    id: deleteData.value.id,
    remark: ''
  })
  if (res) {
    getGuestAddressInfoList()
  }
  showDeleteTip.value = false
}
const handleCancel = () => {
  deleteData.value = {
    id: 0,
    remark: ''
  }
  showDeleteTip.value = false
}
const handleAddressOpen = () => {
  isAdd.value = true
  showAddAddress.value = true
}
const changeHandler = (e: any) => {
  const { columnIndex, indexs } = e

  if (columnIndex === 0) {
    uPickerRef.value.setColumnValues(1, areaData[indexs[0]].children)
    uPickerRef.value.setColumnValues(
      2,
      areaData[indexs[0]].children[indexs[1]].children
    )
  }
  if (columnIndex === 1) {
    uPickerRef.value.setColumnValues(
      2,
      areaData[indexs[0]].children[indexs[1]].children
    )
  }
}
const areaConfirm = (e: any) => {
  const { indexs } = e
  const province = areaData[indexs[0]]
  const city = province?.children?.[indexs[1]]
  const district = city?.children?.[indexs[2]]

  if (district) {
    const { areaCode, areaPath } = district
    areaName.value = ''
    // @ts-ignore 避免超16位BigInt转String 数据错误问题
    addressForm.value.areaCode = areaCode
    areaName.value = areaPath
    show.value = false
  } else {
    uni.showToast({
      title: '请选择有效的省市区',
      icon: 'none'
    })
  }
}

const handleBack = () => {
  showAddAddress.value = false
  resetForm()
}

const selectDefault = (item: GuestAddress) => {
  const params = Object.assign(item, {
    isDefault: 1
  })
  editGuestAddressInfoUpdate(params)
}

const resetForm = () => {
  // 重置表单数据
  addressForm.value = {
    guestName: '',
    guestPhone: '',
    areaCode: undefined,
    guestAddress: '',
    isDefault: 0
  }
  areaName.value = ''
  isDefault.value = false
}

// 保存地址信息
const handleSave = () => {
  // 表单验证
  if (formRef.value) {
    formRef.value.validate().then(async (valid: boolean) => {
      if (!valid) {
        uni.showToast({
          title: '请填写完整信息',
          icon: 'none'
        })
        return false
      } else {
        try {
          addressForm.value.isDefault = isDefault.value ? 1 : 0
          addressForm.value.guestId = userStore.userInfo.id
          if (isAdd.value) {
            const res = await guestAddressInfoSave(addressForm.value)
            if (res.state === 'success') {
              uni.showToast({
                title: '保存成功',
                icon: 'success'
              })
            }
          } else {
            editGuestAddressInfoUpdate(addressForm.value)
          }

          showAddAddress.value = false
          getGuestAddressInfoList()
        } catch (error) {
          if (isAdd.value) {
            uni.showToast({
              title: '保存失败',
              icon: 'none'
            })
            console.error('保存地址失败:', error)
          } else {
            uni.showToast({
              title: '修改失败',
              icon: 'none'
            })
          }
        }
      }
      resetForm()
    })
  } else {
    console.error('formRef is not bound to the form')
    return
  }
}

const findParentIds = (
  treeData: any[],
  targetCode: string,
  path: number[] = []
): number[] => {
  for (let i = 0; i < treeData.length; i++) {
    const node = treeData[i]
    if (node.areaCode === targetCode) {
      return [...path, i]
    }
    if (node.children) {
      const result = findParentIds(node.children, targetCode, [...path, i])
      if (result.length > 0) {
        return result
      }
    }
  }
  return []
}
const openChooseAddress = (leafId: any) => {
  defaultIndex.value = findParentIds(areaData, leafId)
  show.value = true
}

onMounted(() => {
  getGuestAddressInfoList()
})
</script>

<template>
  <view class="address-manage">
    <AddressCard
      class="address_card mb20"
      :addressList="addressList"
      @edit="handleEdit"
      @delete="handleDelete"
      @select="selectDefault"
    ></AddressCard>
  </view>
  <GbLoading v-model="showLoading" />
  <view
    class="address-manage-bottom"
    @click="handleAddressOpen"
  >
    <up-button
      class="ml10 mt10 mb10 mr10"
      iconColor="#f58c1c"
      color="#f58c1c"
      text="新建地址"
    ></up-button>
  </view>
  <!-- 删除确认弹框 -->
  <up-modal
    :show="showDeleteTip"
    title="确定该地址删除？"
    :showCancelButton="true"
    confirmColor="#f58c1c"
    @confirm="confirm"
    @cancel="handleCancel"
  ></up-modal>

  <!-- 新增 -->
  <up-popup :show="showAddAddress">
    <view class="popup-content">
      <up-form
        class="addressForm"
        labelPosition="left"
        :model="addressForm"
        :rules="rules"
        labelWidth="160rpx"
        ref="formRef"
      >
        <up-form-item
          label="收货人"
          prop="guestName"
        >
          <up-input
            border="bottom"
            v-model="addressForm.guestName"
            clearable
            placeholder="请填写收货人姓名"
          ></up-input>
        </up-form-item>
        <up-form-item
          label="手机号码"
          prop="guestPhone"
        >
          <up-input
            border="bottom"
            v-model="addressForm.guestPhone"
            clearable
            placeholder="请填写手机号码"
          ></up-input>
        </up-form-item>
        <up-form-item
          label="选择区域"
          prop="areaCode"
          @click="openChooseAddress(addressForm.areaCode)"
        >
          <up-input
            border="bottom"
            class="u-fb u-f-s-28"
            placeholder="请选择省市区"
            type="text"
            v-model="areaName"
            suffixIcon="arrow-right"
            suffixIconStyle="color: #B6B6B6"
            @focus="openChooseAddress(addressForm.areaCode)"
          />
        </up-form-item>
        <up-form-item
          label="详细地址"
          prop="guestAddress"
        >
          <up-input
            border="bottom"
            v-model="addressForm.guestAddress"
            clearable
            placeholder="请填写详细地址"
          ></up-input>
        </up-form-item>
        <up-form-item
          label="默认地址"
          prop="isDefault"
        >
          <up-switch
            v-model="isDefault"
            activeColor="#f58c1c"
          ></up-switch>
        </up-form-item>
      </up-form>
      <view class="popup-content-bottom">
        <up-button
          class="ml10 mt10 mb10 mr10"
          text="取消"
          @click="handleBack"
        ></up-button>
        <up-button
          class="mt10 mb10 mr10"
          iconColor="#f58c1c"
          color="#f58c1c"
          :text="isAdd ? '保存' : '修改'"
          @click="handleSave"
        ></up-button>
      </view>
    </view>
  </up-popup>

  <!-- 省市区选择器 -->
  <up-picker
    :show="show"
    ref="uPickerRef"
    keyName="areaName"
    :columns="columns"
    :defaultIndex="defaultIndex"
    @cancel="show = false"
    @confirm="areaConfirm"
    @change="changeHandler"
  ></up-picker>
</template>

<style lang="scss" scoped>
.address-manage {
  overflow: scroll;
  height: calc(100vh - 120rpx);
  padding: 30rpx;
}
.address-manage-bottom {
  position: fixed;
  bottom: 0;
  display: flex;
  align-items: center;
  width: 100%;
  // height: 100rpx;
  justify-content: center;
  font-size: 30rpx;
  color: #ffffff;
  background-color: #fff;
  // border-radius: 40rpx;
  // margin: 20rpx;
  // padding: 20rpx;
}

.popup-content {
  width: 100%;
  height: 100vh;
  background-color: #ffffff;

  .addressForm {
    margin: 0 30rpx;
  }
  .popup-content-bottom {
    position: fixed;
    bottom: 0;
    width: 100%;
    // height: 110rpx;
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
</style>
