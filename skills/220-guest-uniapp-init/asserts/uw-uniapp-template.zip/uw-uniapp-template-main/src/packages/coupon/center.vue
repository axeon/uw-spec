<template>
  <GbLoading v-model="showLoading" />

  <up-list
    v-if="!showLoading"
    class="voucher-center"
    @scrolltolower="scrolltolower"
  >
    <img
      class="voucher-center-bg"
      :src="bgImg"
      lazy-load
    />
    <view class="voucher-wrapper">
      <view
        class="coupon_list"
        v-if="receiveListData.length > 0"
      >
        <up-list-item
          v-for="(item, index) in receiveListData"
          :key="index"
        >
          <view class="coupon_card_list">
            <CouponCard
              :status="couponStatus"
              :data="{
                title: item.couponName as string,
                desc: item.couponDesc,
                time: item.endDate as string,
                rules: item.couponDesc as string,
                price: item.couponValue as number
              }"
              @onReceive="onReceive(item)"
            ></CouponCard>
          </view>
        </up-list-item>
      </view>
    </view>
  </up-list>
</template>

<script lang="ts" setup>
import { ref, reactive, computed, onMounted } from 'vue'
import CouponCard from './components/CouponCard/index.vue'
import {
  guestCouponInfoListCoupon,
  guestCouponInfoPickup,
  type CouponInfo
} from '@/api/saasMallAppGuestApi'
import GbLoading from '@/components/GbLoading/index.vue'
// import { useMainStore } from '@/store/main'
// const mainStore = useMainStore()

const bgImg = 'https://qnimg.zowoyoo.com/img/84826/1612230973660.jpg'
const showLoading = ref(false)

const receiveListData = ref<CouponInfo[]>([])
const state = reactive({
  $pg: 1,
  current: 0
})
const couponStatus = computed(() => {
  // 'use' : 'receive'
  return 'receive'
})
// function onLinkPage(couponId: string) {
//   // Logic for page link
//   window.location.href = `/coupon/detail?couponId=${couponId}`
// }

const onReceive = async (CouponInfo: CouponInfo) => {
  uni.showToast({
    title: '加载中...',
    icon: 'none'
  })
  const res = await guestCouponInfoPickup({ couponId: CouponInfo.id })
  if (res.state === 'success') {
    uni.showToast({
      title: '领券成功',
      icon: 'none'
    })
  } else {
    uni.showToast({
      title: '领券失败',
      icon: 'none'
    })
  }
}

const getCouponList = async () => {
  const res = await guestCouponInfoListCoupon({
    $pg: state.$pg,
    $rn: 10
  })
  if (res.state === 'success') {
    showLoading.value = false
    if (res.data && res.data.results && res.data.results?.length > 0) {
      state.$pg++
      receiveListData.value = [...receiveListData.value, ...res.data.results]
    }
  }
}
async function scrolltolower() {
  getCouponList()
}

onMounted(() => {
  showLoading.value = true
  getCouponList()
})
</script>

<style lang="scss" scoped>
.voucher-center {
  position: relative;
  // padding-top: 173px;
  background: #fff1b5;
  .voucher-center-bg {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
  }
  .voucher-wrapper {
    position: relative;
    z-index: 1;
    padding: 0 16px;

    .coupon_list {
      padding-top: 160px;
      .coupon_card_list {
        padding: 10rpx 0;
      }
    }
  }
}
</style>
