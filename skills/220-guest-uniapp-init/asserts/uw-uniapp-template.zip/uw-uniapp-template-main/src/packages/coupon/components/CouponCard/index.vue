<template>
  <view class="coupon_center_card">
    <view class="top">
      <view class="top_l">
        <!-- 优惠券价格 -->
        <text class="icon">￥</text>
        <text class="price">{{ data.price }}</text>
      </view>
      <view class="top_c">
        <!-- 优惠券标题 -->
        <text class="title">{{ data.title }}</text>
        <text
          v-if="data.desc"
          class="desc"
        >
          {{ data.desc }}
        </text>
      </view>
      <view
        class="top_r"
        :class="{ receive: status === 'use' }"
      >
        <!-- 未领取 -->
        <button
          v-if="status === 'receive'"
          class="use_btn"
          @click="toReceive"
        >
          立即领取
        </button>
        <!-- 已领取 -->
        <view v-else>
          <img
            class="status_img"
            :src="couponImg"
            lazy-load
          />
          <button
            class="use_btn"
            @click="$emit('onUse')"
          >
            去使用
          </button>
        </view>
      </view>
    </view>
    <view class="bottom">
      <view class="bottom_t">
        <!-- 显示时间 -->
        <view class="time">{{ data.time }}</view>
        <view
          class="use_rules"
          :class="{ notUse }"
          @click="toShowRules"
        >
          详细规则
          <uni-icons
            class="arrow"
            color="#999"
            :type="rulesStates ? 'up' : 'down'"
          />
        </view>
      </view>
      <!-- 使用规则 -->
      <view
        class="rules"
        v-show="rulesStates"
      >
        {{ data.rules }}
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'

const props = defineProps<{
  status: string // 优惠券的状态 use receive
  data: {
    title: string
    desc?: string
    time: string
    rules: string
    price: number
  }
}>()

const couponImg = 'https://qnimg.zowoyoo.com/img/84826/1612425266177.png'
const emit = defineEmits(['onReceive', 'onUse'])

const rulesStates = ref(false)

const notUse = computed(() => props.status !== 'use')

function toShowRules() {
  rulesStates.value = !rulesStates.value
}

function toReceive() {
  emit('onReceive')
}
</script>

<style lang="scss" scoped>
.coupon_center_card {
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  width: 100%;
  min-height: 122.5px;
  padding: 17px 16px 0;
  background: #fff;
  box-shadow: 0 2px 6px 0 rgba(201, 201, 201, 0.3);
  border-radius: 10px;
  .top {
    display: flex;
    height: 91px;
    padding-bottom: 13px;
    border-bottom: 1px solid #f6f6f6;
    .top_l {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 89px;
      color: #f47f02;
      border-right: 1px solid #f6f6f6;
      flex: 1;
      .icon {
        border: unset;
        display: flex;
        align-items: flex-end;
        height: 34px;
        margin-top: -6px;
        font-size: 15px;
        font-family: PingFang SC;
        font-weight: 500;
      }
      .price {
        line-height: 34px;
        font-size: 34px;
        font-weight: 800;
        font-family: PingFang SC;
      }
    }
    .top_c {
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding-left: 13.5px;
      flex-grow: 1;
      flex: 3;
      .title {
        line-height: 17px;
        font-size: 17px;
        font-weight: 500;
        color: #28303a;
      }
      .desc {
        line-height: 13px;
        margin-top: 13.5px;
        font-size: 13px;
        color: #666;
      }
    }
    .top_r {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 99px;
      transform: translateX(8px);
      &.receive {
        display: flex;
        flex-direction: column;
        text-align: center;
      }
      button {
        border: unset;
      }
      .use_btn {
        padding: 0;
        width: 70px;
        height: 30px;
        line-height: 30px;
        font-size: 13px;
        color: #fff;
        background: linear-gradient(90deg, #fca172, #fb7030);
        border-radius: 15px;
        ::after {
          display: none;
        }
      }
      .status_img {
        width: 60px;
        height: 45px;
        margin-bottom: 4.5px;
      }
    }
  }
  .bottom {
    padding: 10px 0;
    font-size: 13px;
    color: #999;
    .bottom_t {
      display: flex;
      justify-content: space-between;
      .time {
        color: #bcbcbc;
      }
      .use_rules {
        .arrow {
          margin-left: 10px;
        }
      }
    }
    .rules {
      padding-top: 20px;
      word-break: break-all;
    }
  }
}
</style>
