<script lang="ts" setup>
import { reactive, ref } from 'vue'
import {
  onLoad,
  onPageScroll
  // onShareTimeline,
  // onShareAppMessage
} from '@dcloudio/uni-app'
import ZUp from '@/components/ZUp/index.vue'
// import ZParseHtml from '@/components/ZParseHtml/index.vue'

import ZDetailSwiper from './components/ZDetailSwiper/index.vue'
import ZBottomBtn from './components/ZBottomBtn/index.vue'
import { navToUrl } from '@/utils/tool'
import {
  guestProductInfoLoad,
  type ProductInfo
} from '@/api/saasMallAppGuestApi'

const state = reactive({
  id: NaN,
  scrollTop: 0
})
const detailData = ref<ProductInfo>({})

const imgList = ref<string[]>([])
// const content = ref(
//   '<p><img src="https://v3.b2b2c.rageframe.com/attachment/images/2023/06/20/image_1687243756_vPMCP8n3.jpg" style=""/></p><p><img src="https://v3.b2b2c.rageframe.com/attachment/images/2023/06/20/image_1687243757_Y1MK6EED.jpg" style=""/></p><p><img src="https://v3.b2b2c.rageframe.com/attachment/images/2023/06/20/image_1687243757_UXSIBR9r.jpg" style=""/></p><p><br/></p>'
// )

const handleLoad = async (id: number) => {
  const res = await guestProductInfoLoad({ id })
  if (res.state === 'success' && res.data) {
    console.log('res.data', res.data)

    detailData.value = res.data
    imgList.value = [res.data.imgMain as string]
  }
}
const handleClick = () => {
  navToUrl(
    `/packages/order/placeOrder/index?productData=${JSON.stringify(
      detailData.value
    )}`
  )
}

onLoad((options: any) => {
  const { id } = options
  state.id = id || NaN
  console.log('产品详情页 ---')
  if (state.id) {
    handleLoad(state.id)
  }
})
// 滚动页面
onPageScroll((e) => {
  state.scrollTop = e.scrollTop
})
</script>

<template>
  <view class="product-page">
    <ZDetailSwiper :covers="imgList" />

    <view class="parse flex-center m-t-100">——产品介绍——</view>
    <!-- <ZParseHtml :content="content" /> -->
    <view class="parse flex-center m-t-100">{{ detailData.productName }}</view>
    <!-- 底部操作菜单 -->
    <ZBottomBtn @click="handleClick" />

    <ZUp :scrollTop="state.scrollTop" />
  </view>
</template>

<style lang="scss" scoped>
.product-page {
  width: 100vw;
  overflow: hidden;
  box-sizing: border-box;
  background-color: #f7f7f7;
  padding-bottom: calc(env(safe-area-inset-bottom) / 2 + 100rpx);
}
</style>
