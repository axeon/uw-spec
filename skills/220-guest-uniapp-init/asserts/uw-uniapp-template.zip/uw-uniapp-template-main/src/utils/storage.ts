export function getLocal(key: string) {
  if (!key) throw new Error('key不能为空')
  const val = uni.getStorageSync(key)
  return val ? JSON.parse(val) : null
}

export function setLocal(key: string, value: any) {
  if (!key || !value) throw new Error('key or value不能为空')
  return uni.setStorageSync(key, JSON.stringify(value))
}

export function removeLocal(key: string) {
  if (!key) throw new Error('key不能为空')
  return uni.removeStorageSync(key)
}

export function clearLocal() {
  return uni.clearStorageSync()
}

export function getSession(key: string) {
  if (!key) throw new Error('key不能为空')
  const val = uni.getStorageSync(key)
  return val ? JSON.parse(val) : null
}

export function setSession(key: string, value: any) {
  if (!key || !value) throw new Error('key or value不能为空')
  return uni.setStorageSync(key, JSON.stringify(value))
}

export function removeSession(key: string) {
  if (!key) throw new Error('key不能为空')
  return uni.removeStorageSync(key)
}

export function clearSession() {
  return uni.clearStorageSync()
}
