import { JSEncrypt } from 'jsencrypt'
import config from '@/config/common'
import i18n from '@/i18n/index'
import dayjs from 'dayjs'
import CryptoJS from 'crypto-js'

import { useUserStore } from '@/store/user'
import { useMainStore } from '@/store/main'

// 解析时间日期函数
export function parseTime(time: any, cFormat: any) {
  time = time || new Date()
  if (arguments.length === 0) {
    return null
  }
  const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}'
  // eslint-disable-next-line init-declarations
  let date
  if (typeof time === 'object') {
    date = time
  } else {
    if (('' + time).length === 10) time = parseInt(time) * 1000
    date = new Date(time)
  }
  const formatObj: { [key: string]: number } = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay()
  }
  const timeStr = format.replace(
    /{(y|m|d|h|i|s|a)+}/g,
    (result: string, key: string) => {
      let value: string | number = formatObj[key]
      if (key === 'a')
        return ['一', '二', '三', '四', '五', '六', '日'][value - 1]
      if (result.length > 0 && value < 10) {
        value = '0' + value
      }
      return value || 0
    }
  )
  return timeStr
}

/**
 * 格式化请求参数
 * @param {object} params 传参对象
 */
export function formatParam(params: Record<string, any>): string {
  let parameter = ''
  for (const key in params) {
    if (params[key] !== undefined && params[key] !== null) {
      parameter += `${key}=${params[key]}&`
    }
  }
  parameter = parameter.substr(0, parameter.length - 1)
  return parameter
}

/**
 * RSA非对称加密
 * @param data 需要加密的数据
 */
export const rsaEncrypt = (data: string): string | false => {
  const { t } = i18n().global
  if (!data || typeof data !== 'string') {
    console.error('Invalid input data, it should be a non-empty string.')
    uni.showToast({
      icon: 'none',
      mask: true,
      title: t('longTips23')
    })
    return false
  }
  let retryCount = 0
  let result: string | false = false
  // 重试加密操作3次
  while (retryCount < 3 && result === false) {
    const encrypt = new JSEncrypt()
    // 使用公钥加密
    encrypt.setPublicKey(config.PUBLIC_KEY)
    result = encrypt.encrypt(data)

    // 如果结果不是 false，则跳出循环
    if (result !== false) break
    retryCount++
  }
  // 超过3次仍然返回 false 的情况
  if (result === false) {
    uni.showToast({
      icon: 'none',
      mask: true,
      title: t('longTips24')
    })
    return false
  }
  return result
}

/**
 * RSA 解密
 * @param data 需要解密的数据
 */
export const rsaDecrypt = (data: string): string | false => {
  const { t } = i18n().global
  if (!data || typeof data !== 'string') {
    console.error('Invalid input data, it should be a non-empty string.')
    uni.showToast({
      icon: 'none',
      mask: true,
      title: t('longTips23')
    })
    return false
  }
  let retryCount = 0
  let result: string | false = false
  // 重试解密操作3次
  while (retryCount < 3 && result === false) {
    const decrypt = new JSEncrypt()
    decrypt.setPrivateKey(config.PRIVATE_KEY)
    try {
      // 使用私钥尝试解密
      result = decrypt.decrypt(data)
    } catch (error) {
      console.error('An error occurred during decryption:', error)
      result = false
    }
    // 如果结果不是 false，则跳出循环
    if (result !== false) break
    retryCount++
  }
  // 超过3次仍然返回 false 的情况
  if (result === false) {
    uni.showToast({
      icon: 'none',
      mask: true,
      title: t('longTips25')
    })
    return false
  }
  return result
}

/**
 * 二进制转十进制
 * @param binaryString  二进制数据
 * @returns
 */
export const decimalNumberFn = (binaryString: string): number => {
  return parseInt(binaryString, 2)
}

/**
 * 十进制转二进制
 * @param binaryString  二进制数据
 * @returns
 */
export const decimalToBinary = (decimal: number): string => {
  return decimal.toString(2)
}

/**
 * 二进制转十进制 的倒序排列
 * @param binaryString  二进制数据
 * @returns
 */
export const reserveDecimalNumberFn = (binaryString: string): number => {
  const reversedStr = binaryString.split('').reverse().join('')
  return parseInt(reversedStr, 2)
}
// 为兼容 大小端情况 后端java接受的小端 前端这边需以倒序二进制排列数据传输

/**
 * 数字小于10补0
 * @param num
 * @returns
 */
export const addZero = (num: number): string => {
  return num < 10 ? '0' + num : num.toString()
}

/**
 * 根据 1-1-A 、 2-3-B 这样的座位信息返回对应国际化
 * @param seatInfo 1-1-A
 * @returns
 */
export const getSeatInfo = (seatInfo: string) => {
  const { t } = i18n().global
  const arr = seatInfo.split('-')
  return t('carriageSeatInfo', {
    num: arr[0],
    seat: arr[1] + arr[2]
  })
}

/**
 * 计算两个时间点之间的差值
 *
 * @param timeA 第一个时间点，格式为 "HH:mm"。
 * @param timeB 第二个时间点，格式为 "HH:mm"。
 * @returns 返回一个字符串，表示时间差，格式为 "HH:mm"。
 */
export function calculateTimeDifference(timeA: string, timeB: string): string {
  // 将时间字符串转换为小时和分钟
  const [hoursA, minutesA] = timeA.split(':').map(Number)
  const [hoursB, minutesB] = timeB.split(':').map(Number)
  // 计算时间差
  let hoursDiff = hoursB - hoursA
  let minutesDiff = minutesB - minutesA
  // 如果分钟数为负，向前借一小时
  if (minutesDiff < 0) {
    minutesDiff += 60
    hoursDiff--
  }
  // 如果小时数为负，表示timeB在第二天，所以加上24小时
  if (hoursDiff < 0) {
    hoursDiff += 24
  }
  // 格式化输出
  const formattedHours = hoursDiff.toString()
  const formattedMinutes = minutesDiff.toString().padStart(2, '0')
  return `${formattedHours}h${formattedMinutes}min`
}

/**
 * 返回上一页 （H5原生History）
 */
export const navBack = () => {
  const pages = getCurrentPages()
  if (pages && pages.length > 1) {
    uni.navigateBack()
  } else {
    if (window.history?.length > 2) {
      history.back()
    } else {
      // 重定向首页
      uni.reLaunch({
        url: '/pages/ticket/list'
      })
    }
  }
}

/**
 * navigateTo 到某个页面
 * @param url uniapp路由页
 */
export const navToUrl = (url: string) => {
  const userStore = useUserStore()
  if (['/packages/account/index'].includes(url) && !userStore.token) {
    url = '/pages/login/index'
  }
  uni.navigateTo({
    url
  })
}

/**
 * 链接到列表首页
 * 兼容当前已经是list首页的判断
 * @returns
 */
export const reLaunchList = () => {
  const indexUrl = '/pages/ticket/list'
  const page = getCurrentPages().pop()
  if (indexUrl.includes(page?.route as string)) return
  uni.reLaunch({
    url: indexUrl
  })
}

/**
 * @word 要加密的内容
 * @keyWord String  服务器随机返回的关键字
 *  */
export function aesEncrypt(word: string, keyWord = 'XwKsGlMcdPMEhR1B') {
  const key = CryptoJS.enc.Utf8.parse(keyWord)
  const srcs = CryptoJS.enc.Utf8.parse(word)
  const encrypted = CryptoJS.AES.encrypt(srcs, key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  })
  return encrypted.toString()
}

/**
 *
 * @param cipherText 要解密的内容
 * @param passphrase 服务器随机返回的关键字
 * @returns
 */
export const aesDecrypt = (
  cipherText: string,
  passphrase = 'XwKsGlMcdPMEhR1B'
) => {
  const keyBytes = CryptoJS.enc.Utf8.parse(passphrase)
  const bytes = CryptoJS.AES.decrypt(cipherText, keyBytes, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  })
  return bytes.toString(CryptoJS.enc.Utf8)
}

/**
 * 解决js计算精度问题 f:计算的价格 如: CalculationPrice(0.1+0.2)
 */
export function CalculationPrice(f: number): number {
  const num = Math.round(f * 100)
  return num / 100
}

/**
 * 判断是否是JSON格式字符串
 * @param str
 * @returns
 */
export const isJSON = (str: any) => {
  if (typeof str === 'string') {
    try {
      JSON.parse(str)
      return true
    } catch (e: any) {
      console.warn(e.toString())
      return false
    }
  } else {
    return false
  }
}

/**
 * Rpx转px的函数
 * @param rpx
 * @returns num + px
 */
export const rpxToPx = (rpx: number): string => {
  if (!rpx) return '0px'
  const deviceWidth = uni.getSystemInfoSync().windowWidth
  return Math.floor((deviceWidth! / 750) * rpx) + 'px'
}

/**
 * 判断对象是否为空
 * @param obj
 * @returns boolean
 */
export function isEmpty(obj: any): boolean {
  return Object.entries(obj).length === 0
}

// 解决小数位数
export function computeNumber(a: any, type: any, b: any) {
  /**
   * 获取数字小数点的长度
   * @param {number} n 数字
   */
  function getDecimalLength(n: any) {
    const decimal = n.toString().split('.')[1]
    return decimal ? decimal.length : 0
  }
  /** 倍率 */
  const power = Math.pow(10, Math.max(getDecimalLength(a), getDecimalLength(b)))
  let result = 0
  // 防止出现 `33.33333*100000 = 3333332.9999999995` && `33.33*10 = 333.29999999999995` 这类情况做的暴力处理
  a = Math.round(a * power)
  b = Math.round(b * power)

  switch (type) {
    case '+':
      result = (a + b) / power
      break
    case '-':
      result = (a - b) / power
      break
    case '*':
      result = (a * b) / (power * power)
      break
    case '/':
      result = a / b
      break
  }
  return {
    /** 计算结果 */
    result,
    /**
     * 继续计算
     * @param {'+'|'-'|'*'|'/'} nextType 继续计算方式
     * @param {number} nextValue 继续计算的值
     */
    next(nextType: any, nextValue: any) {
      return computeNumber(result, nextType, nextValue)
    }
  }
}

// 计算日期相差天数sDate1和sDate2是yyyy-mm-dd
export function datedifference(sDate1: any, sDate2: any) {
  // eslint-disable-next-line init-declarations
  let dateSpan
  sDate1 = Date.parse(sDate1)
  sDate2 = Date.parse(sDate2)
  dateSpan = sDate2 - sDate1
  dateSpan = Math.abs(dateSpan)
  const iDays = Math.floor(dateSpan / (24 * 3600 * 1000))
  return iDays
}

/**
 * 格式化日期指定目标 时区
 * @param {string | number | Date} value 指定日期
 * @param {string} format 格式化的规则
 * @param {number} timezone 转换为指定时区时间 默认 东八区
 * @example
 * ```js
 * formatDateUTC();
 * formatDateUTC(1603264465956);
 * formatDateUTC(1603264465956, 'h:m:s');
 * formatDateUTC(1603264465956, 'Y年M月D日');
 * ```
 */
export function formatDateUTC(
  value: any,
  format = 'Y-M-D h:m:s',
  timezone = 8
) {
  // 数据转化 个位天数前面＋0
  function formatNumber(n: any) {
    n = n.toString()
    return n[1] ? n : '0' + n
  }
  const formateArr = ['Y', 'M', 'D', 'h', 'm', 's']
  const returnArr = []
  // const timezone = 8 // 目标时区时间，东八区
  const offsetGMT = new Date().getTimezoneOffset() // 本地时间和格林威治的时间差，单位为分钟
  const nowDate = new Date(value).getTime() // 本地时间距 1970 年 1 月 1 日午夜（GMT 时间）之间的毫秒数
  const targetDate = new Date(
    nowDate + offsetGMT * 60 * 1000 + timezone * 60 * 60 * 1000
  )

  // const date = new Date(targetDate)
  returnArr.push(targetDate.getFullYear())
  returnArr.push(formatNumber(targetDate.getMonth() + 1))
  returnArr.push(formatNumber(targetDate.getDate()))

  returnArr.push(formatNumber(targetDate.getHours()))
  returnArr.push(formatNumber(targetDate.getMinutes()))
  returnArr.push(formatNumber(targetDate.getSeconds()))

  for (const i in returnArr) {
    format = format.replace(formateArr[i], returnArr[i])
  }
  return format
}

/**
 * @param {string} time=new Date()
 * @description: 获取日期的1号和最后一天(30号?31号?28、29号?)
 * @return {array} 返回一个数组[当月第一天, 当月最后一天]
 * @example
 * getMonthStarEnd() 返回当月
 * getMonthStarEnd('2020-05') 返回的是2020年5月
 * getMonthStarEnd('2020-02-02') 返回的是2020年2月
 */
export function getMonthStarEnd(time?: any) {
  const now = time ? new Date(time) : new Date() // 当前日期
  const year = now.getUTCFullYear()
  const month = now.getUTCMonth() + 1
  const timeStar = formatDateUTC(Date.UTC(year, month - 1, 1), 'Y/M/D')
  const timeEnd = formatDateUTC(Date.UTC(year, month, 0), 'Y/M/D')
  return [timeStar, timeEnd]
}

export function formatDate(
  number: number | string | Date,
  format = 'Y-M-D h:m:s'
) {
  // 数据转化
  function formatNumber(n: any) {
    n = n.toString()
    return n[1] ? n : '0' + n
  }
  const formateArr = ['Y', 'M', 'D', 'h', 'm', 's']
  const returnArr = []

  const date = new Date(number)
  returnArr.push(date.getFullYear())
  returnArr.push(formatNumber(date.getMonth() + 1))
  returnArr.push(formatNumber(date.getDate()))

  returnArr.push(formatNumber(date.getHours()))
  returnArr.push(formatNumber(date.getMinutes()))
  returnArr.push(formatNumber(date.getSeconds()))

  for (const i in returnArr) {
    format = format.replace(formateArr[i], returnArr[i])
  }
  return format
}

/**
 * 正则替换富文本section为div
 * @param {string} contentRichText 被替换的富文本数据
 * @returns {*}
 */
export function replaceSection(contentRichText: string) {
  if (contentRichText) return contentRichText.replace(/section/g, 'div')
  return ''
}

/**
// 正则修改文本内容图片为 style="max-width: 100%;样式
 * @param {content}  要改的变量
 * @param {originText}  要被替换的文本值
 * @param {targetText}  替换的新值
 * @returns {resContent} 最后的值
 */
export function replaceImgStyle(
  content: any,
  originText: any,
  targetText: any
) {
  const reg = /<img(?:(?!\/>).|\n)*?\/>/g
  const tmpContent = `<div>${content}</div>`
  const resContent = tmpContent.replace(reg, (s) => {
    if (!s.includes('style')) {
      return s.replace(/<img\s/g, () => {
        return '<img style="max-width: 100% !important;" '
      })
    }
    return s.replace(new RegExp(originText, 'g'), () => {
      return targetText
    })
  })
  return replaceSection(resContent.substring(5, resContent.length - 6))
}

// 根据开始日期和结束日期获取所有日期的方法
export function getAllDate(start: any, end: any) {
  const format = (time: any) => {
    let ymd = ''
    const mouth =
      time.getMonth() + 1 >= 10
        ? time.getMonth() + 1
        : '0' + (time.getMonth() + 1)
    const day = time.getDate() >= 10 ? time.getDate() : '0' + time.getDate()
    ymd += time.getFullYear() + '-' // 获取年份。
    ymd += mouth + '-' // 获取月份。
    ymd += day // 获取日。
    return ymd // 返回日期。
  }
  const dateArr = []
  const startArr = start.split('-')
  const endArr = end.split('-')
  const db = new Date()
  db.setUTCFullYear(startArr[0], startArr[1] - 1, startArr[2])
  const de = new Date()
  de.setUTCFullYear(endArr[0], endArr[1] - 1, endArr[2])
  const unixDb = db.getTime()
  const unixDe = de.getTime()
  let stamp = 0
  const oneDay = 24 * 60 * 60 * 1000
  for (stamp = unixDb; stamp <= unixDe; ) {
    dateArr.push(format(new Date(parseInt(String(stamp)))))
    stamp = stamp + oneDay
  }
  return dateArr
}
/**
 * @param {number} longitude 经度
 * @param {number} latitude 纬度
 * @description: 百度转腾讯（传入经度、纬度）
 * @return {object} { lng: lng, lat: lat }
 * @example
 */
export function bd09togcj02(longitude: any, latitude: any) {
  const xPI = (Math.PI * 3000.0) / 180.0
  const newBdLon = +longitude
  const newBdLat = +latitude
  const x = newBdLon - 0.0065
  const y = newBdLat - 0.006
  const z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * xPI)
  const theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * xPI)
  const ggLng = z * Math.cos(theta)
  const ggLat = z * Math.sin(theta)
  return {
    lng: ggLng,
    lat: ggLat
  }
}
// 自定义页面的方法
// 定义初始配置的类型
type InitialConfig = {
  config: {
    navigation: {
      label: string
      styles: {
        background: string
      }
      list: Array<{
        id: string
        icon: string
        text: string
        jump: {
          type: string
          id: string
        }
      }>
    }
    backgroundColor: string
    isShowTabbar: boolean
  }
  pages: Array<{
    id: string
    name: string
    home: boolean
    backgroundColor: string
    backgroundImage: string
    backgroundImageSize: string
    backgroundImagePostion: string
    showTopSearch: boolean
    showMpTopNav: boolean
    isShowTabbar: string
    componentList: Array<any>
  }>
}

/**
 * 从变更配置和初始配置还原完整配置
 * @param initialConfig 初始配置
 * @param changedConfig 变更配置（由getChangedConfig生成）
 * @returns 还原后的完整配置
 */
// export function restoreConfig(
//   initialConfig: InitialConfig,
//   changedConfig: any
// ): InitialConfig {
//   console.log('log输出的内容：initialConfig', JSON.stringify(initialConfig))
//   console.log('log输出的内容：changedConfig', JSON.stringify(changedConfig))
//   // 创建完整配置的深拷贝，避免修改原始配置
//   const restoredConfig = JSON.parse(
//     JSON.stringify(initialConfig)
//   ) as InitialConfig

//   // 恢复config部分
//   if (changedConfig.config) {
//     // 递归合并config变更
//     mergeChanges(restoredConfig.config, changedConfig.config)
//   }

//   // 恢复pages部分
//   if (changedConfig.pages && changedConfig.pages.length > 0) {
//     const restoredPages = [...restoredConfig.pages]

//     changedConfig.pages.forEach((pageChange: any) => {
//       const pageId = pageChange.id
//       const pageIndex = restoredPages.findIndex((page) => page.id === pageId)

//       if (pageIndex !== -1) {
//         // 现有页面：合并变更
//         mergeChanges(restoredPages[pageIndex], pageChange)
//       } else {
//         // 新增页面：直接添加
//         restoredPages.push(pageChange as InitialConfig['pages'][0])
//       }
//     })

//     // 处理删除的页面（如果changedConfig中某个页面被标记为undefined）
//     const filteredPages = restoredPages.filter((page, index) => {
//       const change = changedConfig.pages?.[index]
//       return !(change && change === undefined)
//     })

//     restoredConfig.pages = filteredPages
//   }

//   return restoredConfig
// }
export function restoreConfig(
  initialConfig: InitialConfig,
  changedConfig: any
): InitialConfig {
  // 创建完整配置的深拷贝，避免修改原始配置
  const restoredConfig = JSON.parse(
    JSON.stringify(initialConfig)
  ) as InitialConfig

  // 恢复config部分
  if (changedConfig.config) {
    mergeChanges(restoredConfig.config, changedConfig.config)
  }

  // 恢复pages部分
  if (changedConfig.pages && changedConfig.pages.length > 0) {
    const restoredPages = [...restoredConfig.pages]

    changedConfig.pages.forEach((pageChange: any) => {
      if (pageChange === undefined) return

      const pageId = pageChange.id
      const pageIndex = restoredPages.findIndex((page) => page.id === pageId)

      if (pageIndex !== -1) {
        // 现有页面：合并变更
        mergeChanges(restoredPages[pageIndex], pageChange)

        // 还原组件component
        if (pageChange.componentList) {
          restoredPages[pageIndex].componentList = pageChange.componentList.map(
            (comp: any) => {
              const { name, ...rest } = comp
              return {
                ...rest,
                component: name
              }
            }
          )
        }
      } else {
        // 新页面：使用初始页面模板的默认值添加
        const newPage = {
          ...restoredPages[0], // 使用第一页作为模板
          ...pageChange,
          id: pageId,
          home: false
        }

        // 复原component
        if (pageChange.componentList) {
          newPage.componentList = pageChange.componentList.map((comp: any) => {
            const { name, ...rest } = comp
            return {
              ...rest,
              component: name
            }
          })
        }
        restoredPages.push(newPage)
      }
    })

    // 过滤掉标记为删除的页面
    restoredConfig.pages = restoredPages.filter(
      (page) =>
        !changedConfig.pages.some(
          (change: any) =>
            change === undefined ||
            (typeof change === 'object' &&
              change.id === page.id &&
              change === undefined)
        )
    )
  }

  return restoredConfig
}
/**
 * 递归合并变更到目标对象
 * @param target 目标对象（初始配置）
 * @param source 源对象（变更配置）
 */
function mergeChanges(target: any, source: any): any {
  if (typeof source !== 'object' || source === null) {
    // 基本类型：直接覆盖
    return source
  }

  if (Array.isArray(source)) {
    // 数组处理
    if (!Array.isArray(target)) {
      // 目标不是数组，直接替换
      return source
    }

    // 数组长度不同，直接替换
    if (target.length !== source.length) {
      return source
    }

    // 逐项合并
    for (let i = 0; i < source.length; i++) {
      if (typeof source[i] === 'object' && source[i] !== null) {
        // 对象或数组：递归合并
        if (target[i] === undefined) {
          target[i] = JSON.parse(JSON.stringify(source[i]))
        } else {
          mergeChanges(target[i], source[i])
        }
      } else {
        // 基本类型：直接替换
        if (source[i] !== undefined) {
          target[i] = source[i]
        }
      }
    }

    return target
  }

  // 对象处理
  for (const key in source) {
    // eslint-disable-next-line no-prototype-builtins
    if (source.hasOwnProperty(key)) {
      const sourceValue = source[key]

      // 处理删除标记
      if (sourceValue === undefined) {
        delete target[key]
        continue
      }

      const targetValue = target[key]

      if (typeof sourceValue === 'object' && sourceValue !== null) {
        // 对象或数组：递归合并
        if (targetValue === undefined) {
          // 目标没有该属性，直接添加
          target[key] = JSON.parse(JSON.stringify(sourceValue))
        } else {
          mergeChanges(target[key], sourceValue)
        }
      } else {
        // 基本类型：直接替换
        target[key] = sourceValue
      }
    }
  }

  return target
}

// 取出产品接口的图片地址 [{id: 1, img: ''}, {id:2 , img: ''}]
export const getProductImgList = (infoImg?: string) => {
  if (!infoImg) return []
  try {
    const arr: { img: string; id: string }[] = []
    const mainStore = useMainStore()
    const JsonObj = JSON.parse(infoImg)
    if (!JsonObj) return []
    Object.keys(JsonObj).forEach((id) => {
      const img = JsonObj[id]
      arr.push({
        img: mainStore.saasDomain + img,
        // img: 'https://yanshiqn.zowoyoo.com/' + img,
        id
      })
    })
    return arr
  } catch (error) {
    // console.warn('getProductImg error', error)
    console.log('getProductImg error', error)
  }
  return []
}

// 取出产品接口的单张图
export const getProductSingleImg = (infoImg?: string) => {
  if (!infoImg) return ''
  if (infoImg?.startsWith('http')) {
    return infoImg
  }
  return getProductImgList(infoImg)[0]?.img || ''
}

/**
 * 将数字格式化为价格格式（后端传入的是分，需要转换为元）
 * @param num 要格式化的数字（分单位）
 * @returns 格式化后的价格字符串，如"291.00"
 * console.log(formatPrice(29100)) // 输出: "291.00"
 * console.log(formatPrice(1234567)) // 输出: "12,345.67"
 */
export function formatPrice(num: number | string): string {
  // 处理字符串输入
  const numberValue = typeof num === 'string' ? parseFloat(num) : num
  // 处理NaN情况
  if (isNaN(numberValue)) {
    return '0.00'
  }
  // 将分转换为元
  const yuanValue = numberValue / 100
  return `${yuanValue.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}`
}

type MediaType = 'image' | 'video'

interface MediaItem {
  url: string
  id: string
  type: MediaType
}

/**
 * 根据资源链接推断媒体类型
 * @param url - 原始链接，可能为相对路径
 * @returns 'image'|'video'|null
 */
export function resolveMedia(url: string): 'image' | 'video' | null {
  const extension = url.split('.').pop()?.toLowerCase()

  let type: 'image' | 'video' | null = null

  if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(extension!)) {
    type = 'image'
  } else if (['mp4', 'avi', 'mov', 'mkv', 'flv'].includes(extension!)) {
    type = 'video'
  }

  return type
}

/**
 * 将JSON字符串解析为媒体列表
 * @param jsonStr JSON字符串
 * @returns 媒体列表
 */
export function parseJsonToMediaList(jsonStr: string): MediaItem[] {
  if (!jsonStr) return []
  try {
    const obj: Record<string, string> = JSON.parse(jsonStr)
    const result: MediaItem[] = []

    for (const [id, url] of Object.entries(obj)) {
      const realUrl = url.startsWith('http')
        ? url
        : useMainStore().saasDomain + url
      const type: MediaType | null = resolveMedia(url)
      if (type) {
        result.push({ url: realUrl, id, type })
      }
    }

    return result
  } catch (error) {
    console.error('Invalid JSON string:', error)
    return []
  }
}

// 示例用法
// const jsonStr = '{"1809":"8821909/product_info/0_1809.png"}'
// const result = parseJsonToMediaList(jsonStr)
// console.log(result)
// 输出: [{ url: '8821909/product_info/0_1809.png', id: '1809', type: 'image' }]

/**
 * 从 onLoad 的 options 中拼出当前页面完整 hash 路径（不含域名）
 * 兼容小程序 + H5（H5 下如需要完整 hash 可再拼一次，这里统一用 route + options 方式）
 * @param {Object} options  页面 onLoad 收到的参数
 * @returns {string}        形如：#/pages/demo/index?id=1&name=abc
 */
export function getCurrentPath(options?: AnyObject) {
  // 空对象直接返回兜底
  if (!options || JSON.stringify(options) === '{}') {
    // 仍然需要拿到当前页面路由
    const pages = getCurrentPages()
    const cur = pages[pages.length - 1]
    const route = cur && (cur.route || '')
    return route ? `/${route}` : ''
  }

  const pages = getCurrentPages()
  const cur = pages[pages.length - 1]
  if (!cur) return ''

  const route = cur.route || ''
  if (!route) return ''

  // 把 options 转成 query 字符串
  const query = formatParam(options)

  return encodeURIComponent(`/${route}${query ? '?' + query : ''}`)
}

interface AreaNode {
  areaCode: string // 地区代码
  areaName: string // 地区名称
  children?: AreaNode[]
}

/**
 * 反向推导地区代码
 * @param tree
 * @param code
 * @returns
 */
export function findAreaPath(tree: AreaNode[], code: string): string[] | null {
  const dfs = (nodes: AreaNode[], path: string[]): string[] | null => {
    for (const node of nodes) {
      const cur = [...path, node.areaCode]
      if (node.areaCode === code) return cur
      if (node.children) {
        const hit = dfs(node.children, cur)
        if (hit) return hit
      }
    }
    return null
  }
  return dfs(tree, [])
}

/**
 * 根据最后一级地区代码，反查完整地区名称路径
 * @param tree  完整的地区树
 * @param code  最后一级地区代码
 * @returns     完整名称路径，如 ["北京市","市辖区","东城区"]；找不到返回 null
 */
export function findAreaLabelPath(
  tree: AreaNode[],
  code: string
): string[] | null {
  const dfs = (nodes: AreaNode[], path: string[]): string[] | null => {
    for (const node of nodes) {
      const cur = [...path, node.areaName]
      if (node.areaCode === code) return cur
      if (node.children) {
        const hit = dfs(node.children, cur)
        if (hit) return hit
      }
    }
    return null
  }
  return dfs(tree, [])
}

/**
 * 获取指定日期所在月份的完整首尾时间
 * @param {string|Date} date - 任意合法日期格式
 * @param {number} month -  结束日期 + month月
 * @returns {[string, string]} 首日与末日的格式化结果
 * @example   console.log(getFullMonthRange('2026-02-05')) // ['2026-02-01 00:00:00', '2026-02-28 23:59:59']
              console.log(getFullMonthRange('2008-02-05')) // []
 */
export function getFullMonthRange(date: string | Date | number, month = 0) {
  const target = dayjs(date)
  if (!target.isValid()) return []

  let startDate = target.startOf('month').format('YYYY-MM-DD 00:00:00')
  const endDate = target
    .add(month, 'month')
    .endOf('month')
    .format('YYYY-MM-DD 23:59:59')
  // 首日时间不能早于当前时间
  if (dayjs(startDate).isBefore(dayjs())) {
    startDate = dayjs().format('YYYY-MM-DD 00:00:00')
  }
  // 首日时间不能晚于末日时间
  if (dayjs(endDate).isBefore(dayjs(startDate))) {
    return []
  }
  return [
    startDate, // 首日时间固定
    endDate // 自动适配月末日期 或 自定义添加month月末后的日期
  ]
}

/**
 * 把 rpx 转成当前机型对应的 px（整数）
 * 1rpx = 1/750 * 屏幕宽度(px)
 */
export function rpx2px(rpx: number): number {
  const sys = uni.getSystemInfoSync()
  return Math.round((rpx / 750) * (sys.windowWidth || 375))
}

/**
 * 把 px 转成当前机型对应的 rpx（保留 2 位小数）
 * 1px = 750 / 屏幕宽度(px) rpx
 */
export function px2rpx(px: number): number {
  const sys = uni.getSystemInfoSync()
  return Math.round(((px * 750) / (sys.windowWidth || 375)) * 100) / 100
}
