import { useMainStore } from '@/store/main'

// export function jump(data: { id: string; type: string; query?: string }) {
//   console.log('data', data)
//   const { id, type, query } = data

//   let resName = null
//   let name = ''
//   switch (type) {
//     case 'component': // 组件
//       name = 'component'
//       break
//     case 'fixed': // 固定页面
//       name = id
//       break
//     case 'custom': // 自定义页面是否已配置首页或Tab页，如果已配置则对应跳转
//       if (!id) {
//         console.warn('自定义页面跳转未传递id')
//         return
//       }
//       if (id === '000000') {
//         name = 'home'
//       } else {
//         const target = findTab(id)
//         name = target ? target.jump.type : type
//       }
//       break
//     case 'link': // 外链
//       if (!id) {
//         uni.showModal({
//           title: '提示:跳转失败',
//           content: '未提供跳转路径'
//         })
//         return
//       }
//       // // #ifdef H5
//       // window.location.href = id;
//       // // #endif
//       // // #ifndef H5
//       // uni.navigateTo({
//       //   url: `/pages/iframe/index?iframeUrl=${id}`,
//       // });
//       // // #endif
//       if (/^http/.test(id)) {
//         // #ifdef H5
//         window.location.href = id
//         // #endif
//         // #ifndef H5
//         uni.navigateTo({
//           url: `/pages/iframe/index?iframeUrl=${id}`,
//           fail: () => {
//             uni.showModal({
//               title: '提示:跳转失败',
//               content: '路径：' + id
//             })
//           }
//         })
//         // #endif
//       } else {
//         uni.navigateTo({
//           url: id + query ? '?' + query : '',
//           fail: () => {
//             uni.showModal({
//               title: '提示:跳转失败',
//               content: '路径：' + id
//             })
//           }
//         })
//       }
//       return

//       break
//   }
//   // 路由前缀
//   const defaultUrl = '/template/template/'

//   switch (name) {
//     case 'home':
//       resName = 'home'
//       uni.redirectTo({
//         url: defaultUrl + resName + query ? '?' + query : ''
//       })
//       break
//     case 'category':
//       resName = 'tab-frist'
//       uni.redirectTo({
//         url: defaultUrl + resName
//       })
//       break
//     case 'car':
//       resName = 'tab-second'
//       uni.redirectTo({
//         url: defaultUrl + resName
//       })
//       break
//     case 'my':
//       resName = 'tab-third'
//       uni.redirectTo({
//         url: defaultUrl + resName
//       })
//       break
//     case 'detail':
//       resName = 'detail'
//       uni.navigateTo({
//         url: defaultUrl + resName
//       })
//       break
//     case 'custom':
//       resName = `custom-page?pageId=${id}`
//       uni.navigateTo({
//         url: defaultUrl + resName + (query ? '&' + query : '')
//       })
//       break
//     case 'component':
//       resName = id
//       uni.navigateTo({
//         url: id
//       })
//       break

//     default:
//       console.error('找不到路由：' + name)
//       resName = 'home'
//       break
//   }

//   console.log(defaultUrl + resName)

//   // router.push(defaultUrl + resName);
// }

// function findTab(name: string) {
//   return useMainStore().customProject.siteConfig?.config.navigation.list.find(
//     (item: any) => item.jump.id === name
//   )
// }
export function jump(data: { id: string; type: string; query?: string }) {
  const { id, type, query } = data
  const defaultUrl = '/template/template/'

  const buildUrl = (path: string, queryStr?: string) => {
    return path + (queryStr ? `?${queryStr}` : '')
  }

  if (type === 'link') {
    if (!id) {
      uni.showModal({
        title: '提示:跳转失败',
        content: '未提供跳转路径'
      })
      return
    }

    if (/^http/.test(id)) {
      // #ifdef H5
      window.location.href = id
      // #endif
      // #ifndef H5
      uni.navigateTo({
        url: `/pages/iframe/index?iframeUrl=${encodeURIComponent(id)}`,
        fail: () => showJumpFailModal(id)
      })
      // #endif
    } else {
      uni.navigateTo({
        url: buildUrl(id, query),
        fail: () => showJumpFailModal(id)
      })
    }
    return
  }

  let routeName = ''
  switch (type) {
    case 'component':
      routeName = 'component'
      break
    case 'fixed':
      routeName = id
      break
    case 'custom':
      if (!id) {
        console.warn('自定义页面跳转未传递id')
        return
      }
      routeName = id === '000000' ? 'home' : findTab(id)?.jump.type || type
      break
    default:
      console.error(`未知的跳转类型: ${type}`)
      return
  }

  switch (routeName) {
    case 'home':
      navigateTo(defaultUrl + 'home', query, 'redirectTo')
      break
    case 'category':
      navigateTo(defaultUrl + 'tab-frist', undefined, 'redirectTo')
      break
    case 'car':
      navigateTo(defaultUrl + 'tab-second', undefined, 'redirectTo')
      break
    case 'my':
      navigateTo(defaultUrl + 'tab-third', undefined, 'redirectTo')
      break
    case 'detail':
      navigateTo(defaultUrl + 'detail')
      break
    case 'custom':
      navigateTo(defaultUrl + `custom-page?pageId=${id}`, query)
      break
    case 'component':
      uni.navigateTo({
        url: id,
        fail: () => showJumpFailModal(id)
      })
      break
    default:
      console.error('找不到路由：' + routeName)
      navigateTo(defaultUrl + 'home', query, 'redirectTo')
  }
}

function findTab(id: string) {
  return useMainStore().customProject.siteConfig?.config.navigation.list.find(
    (item: any) => item.jump.id === id
  )
}

function navigateTo(
  url: string,
  query?: string,
  method: 'navigateTo' | 'redirectTo' = 'navigateTo'
) {
  const fullUrl = query ? `${url}?${query}` : url
  if (method === 'navigateTo') {
    uni.navigateTo({
      url: fullUrl,
      fail: () => showJumpFailModal(url)
    })
  } else {
    uni.redirectTo({
      url: fullUrl,
      fail: () => showJumpFailModal(url)
    })
  }
}

function showJumpFailModal(path: string) {
  uni.showModal({
    title: '提示:跳转失败',
    content: '路径：' + path
  })
}
