import {
  getSession,
  getLocal,
  setLocal,
  setSession,
  removeSession
} from '@/utils/storage'

const TokenKey = 'token'
const ProjectKey = 'mall-project'

export function getAuthToken() {
  return getSession(TokenKey)
}

export function setAuthToken(token: any) {
  return setSession(TokenKey, token)
}

export function removeAuthToken() {
  return removeSession(TokenKey)
}

export function getProject() {
  return getLocal(ProjectKey)
}

export function settingProject(project: any) {
  return setLocal(ProjectKey, project)
}

export function removeProject() {
  return removeSession(ProjectKey)
}
