export class Observer {
  // eslint-disable-next-line
  constructor(fun: Function) {
    this.fun = fun
  }

  fun

  // 目标对象更新时触发的回调，即收到更新通知后的回调
  update() {
    this.fun()
  }
}

export class Subject {
  constructor() {
    this.observers = [] // 观察者列表
  }

  observers: any[] = []

  // 添加订阅者
  add(observer: any) {
    this.observers.push(observer)
  }

  // 删除...
  remove(observer: any) {
    const idx = this.observers.findIndex((item) => item === observer)
    if (idx > -1) this.observers.splice(idx, 1)
  }

  // 通知
  notify() {
    for (const o of this.observers) {
      o.update()
    }
  }
}

export default Subject
