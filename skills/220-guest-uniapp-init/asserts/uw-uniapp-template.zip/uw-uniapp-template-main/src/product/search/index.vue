<script lang="ts" setup>
import { reactive } from 'vue'
import { onLoad } from '@dcloudio/uni-app'

// import RouterUtil from '@/utils/RouterUtil'
import ZSearch from '../components/ZSearch/index.vue'

let state = reactive({
  keyword: '',
  oldKeywordList: [] as string[] // 搜索记录
})

// 搜索
const handleSearch = (key: string) => {
  console.log('搜索', key)
  saveKeyword(key) // 保存为历史
  // RouterUtil.push({
  //   url: '/packages/product/search/searchList',
  //   query: { keyword: key }
  // })
}

// 保存关键字到历史记录
const saveKeyword = (keyword: string) => {
  if (!keyword) return
  uni.getStorage({
    key: 'OldKeys',
    success: (res) => {
      let OldKeys = JSON.parse(res.data)
      let findIndex = OldKeys.indexOf(keyword)
      if (findIndex === -1) {
        OldKeys.unshift(keyword)
      } else {
        OldKeys.splice(findIndex, 1)
        OldKeys.unshift(keyword)
      }
      // 最多10个纪录
      if (OldKeys.length > 10) OldKeys.pop()
      uni.setStorage({
        key: 'OldKeys',
        data: JSON.stringify(OldKeys)
      })
      state.oldKeywordList = OldKeys // 更新历史搜索
    },
    fail: () => {
      let OldKeys = [keyword]
      uni.setStorage({
        key: 'OldKeys',
        data: JSON.stringify(OldKeys)
      })
      state.oldKeywordList = OldKeys // 更新历史搜索
    }
  })
}

// 清除历史搜索
const oldDelete = () => {
  uni.showModal({
    content: '确定清除历史搜索记录？',
    success: (res) => {
      if (res.confirm) {
        state.oldKeywordList = []
        uni.removeStorage({ key: 'OldKeys' })
      }
    }
  })
}

// 失去表单焦点
const blur = () => {
  uni.hideKeyboard()
}

onLoad(() => {
  // console.log('搜索页 ---')
})
</script>

<template>
  <view class="search-page">
    <view class="search-page__ZSearch">
      <ZSearch
        :mode="2"
        button="inside"
        :placeholder="'请输入关键字'"
        @search="handleSearch"
      />
    </view>
    <view
      class="search-page__content"
      @tap="blur"
    >
      <view class="keyword-box">
        <view class="keyword-block">
          <view class="keyword-list-header">
            <view>历史搜索</view>
            <i
              class="iconfont icon-shanchu"
              @tap="oldDelete"
            ></i>
          </view>
          <view class="keyword">
            <view
              v-for="(keyword, index) in state.oldKeywordList"
              :key="index"
              @tap="handleSearch(keyword)"
            >
              {{ keyword }}
            </view>
          </view>
          <view
            v-if="state.oldKeywordList.length === 0"
            class="hide-hot-tis"
          >
            <view>暂无记录</view>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<style lang="scss" scoped>
.search-page {
  &__ZSearch {
    background-color: rgb(242, 242, 242);
    padding: 15rpx 2.5%;
  }
  &__content {
    width: 100%;
    background-color: rgb(242, 242, 242);
    .keyword-box {
      border-radius: 20rpx 20rpx 0 0;
      background-color: #fff;
      .keyword-block {
        padding: 10rpx 0;
        .keyword-list-header {
          width: 100vw;
          padding: 10rpx 3%;
          font-size: 27rpx;
          color: #333;
          display: flex;
          justify-content: space-between;
        }
        .keyword {
          width: 100vw;
          padding: 3px 3%;
          display: flex;
          flex-flow: wrap;
          justify-content: flex-start;
        }
        .hide-hot-tis {
          display: flex;
          justify-content: center;
          font-size: 28rpx;
          color: #6b6b6b;
        }
        .keyword > view {
          display: flex;
          justify-content: center;
          align-items: center;
          border-radius: 60rpx;
          padding: 0 20rpx;
          margin: 10rpx 20rpx 10rpx 0;
          height: 60rpx;
          font-size: 28rpx;
          background-color: rgb(242, 242, 242);
          color: #6b6b6b;
        }
      }
    }
  }
}
</style>
