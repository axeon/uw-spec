<template>
  <u-overlay :show="YyPopupFlag">
    <view class="YY-popup">
      <!-- 日历 -->
      <scroll-view
        :scroll-y="true"
        style="height: 70vh"
      >
        <view class="YY-popup-box">
          <view class="YY-popup__title flex-align flex-center">
            预约库存查看
          </view>
          <template v-if="prodReplacesList && prodReplacesList.length">
            <view class="YY-popup-content">
              <view class="sub-title">选择套餐</view>
              <view class="popup-item">
                <view
                  class="item"
                  :class="{
                    disabled: detail.isStore === 1 && item.stock === 0
                  }"
                  v-for="item in prodReplacesList.slice(
                    0,
                    expendAll ? prodReplacesList.length : limitNum
                  )"
                  :key="item.id"
                  @click.stop="chooseProduct(item)"
                >
                  <i
                    class="i-sel"
                    :class="{ sel: item.infoId === params.infoId }"
                  ></i>
                  <mp-html
                    class="title"
                    ref="rich"
                    :content="item.infoTitleDesc || item.infoTitle"
                  ></mp-html>
                </view>
              </view>
            </view>
            <view
              class="YY-popup__expendAllBtn"
              @click="expendAll = !expendAll"
              v-if="prodReplacesList.length > limitNum"
            >
              {{ !expendAll ? t('appoint.Open') : t('prod.expend2')
              }}{{ t('appoint.Allproudcts') }}
            </view>
          </template>
          <template v-else>
            <view
              class="YY-popup-content__tips flex-col flex-align flex-center"
            >
              <image
                class="image"
                src="http://qnimg.zowoyoo.com/img/84826/1683789522597.png"
              />
              <text class="text">暂无更多产品套餐</text>
            </view>
          </template>

          <!-- 没选择产品不显示日历 -->
          <template v-if="params.infoId">
            <view class="YY-popup-content">
              <view class="sub-title">库存日历</view>
              <view class="popup-item calendar-box">
                <view
                  class="months flex-align flex-center"
                  v-if="
                    detail.isValidity === 0 ||
                    (detail.isValidity !== 0 && detail.treeId === '5')
                  "
                >
                  <view
                    style="padding: 0 10px"
                    @click="prevMonth"
                  >
                    <span class="i-arrow0"></span>
                  </view>
                  <span class="flex-center">
                    {{ currentYear }} {{ t('components.Year') }}
                    {{ currentMonth }} {{ t('components.Month') }}
                  </span>
                  <view
                    style="padding: 0 10px"
                    @click="nextMonth"
                  >
                    <span class="i-arrow1"></span>
                  </view>
                </view>
                <appointCalendar
                  v-if="params.infoId && calendarObj.state === 1"
                  ref="calendar"
                  :type="detail.treeId === '5' ? 'range' : 'single'"
                  :nights="params.nights"
                  v-model="travelDate"
                  :dateList="dateList"
                  :showStock="
                    detail.showStock === 1 &&
                    ['0', '3', '5'].includes(detail.treeId!)
                  "
                  @change="changeDate"
                  :treeId="detail.treeId"
                  :currentMonth="currentMonth"
                  :currentYear="currentYear"
                />
                <view
                  v-else
                  class="no-date flex-center flex-align flex-col"
                >
                  <span
                    v-if="detail.isValidity === 1"
                    style="margin-bottom: 10px"
                  >
                    {{ t('appoint.ticket') }}
                  </span>
                  <span>{{ calendarObj.msg }}</span>
                </view>
              </view>
            </view>
          </template>
        </view>
      </scroll-view>
      <view
        class="YY-pupup-colseBtn flex-align flex-center"
        @click="emit('update:modelValue', false)"
      >
        <view
          class="colse-btn flex-align flex-center"
          @click="emit('update:modelValue', false)"
        >
          关闭
        </view>
      </view>
    </view>
  </u-overlay>
</template>

<script lang="ts" setup>
import { ref, computed, watch, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { parseTime } from '@/utils/tool'
import { getCalQueryByYYLink, detailQueryByYYLink } from '@/api/text'
import appointCalendar from './appointCalendar.vue'
import mpHtml from 'mp-html/dist/uni-app/components/mp-html/mp-html'

// 定义接口
interface ProdReplacesItem {
  id: number
  infoId: string
  infoTitle: string
  infoTitleDesc?: string
  stock?: number
  [key: string]: any
}

interface DetailData {
  isStore?: number
  isValidity?: number
  treeId?: string
  showStock?: number
  prodGroupType?: string
  prodReplaces?: ProdReplacesItem[]
  [key: string]: any
}

interface CalendarItem {
  date: string
  [key: string]: any
}

interface CalendarObj {
  state: number
  msg: string
}

interface Params {
  infoId: string
  nights: number
  num: number
}

// 定义props
const props = withDefaults(
  defineProps<{
    modelValue: boolean
    infoId?: string
    yyLink?: string
  }>(),
  {
    modelValue: false,
    infoId: '',
    yyLink: ''
  }
)

const emit = defineEmits(['update:modelValue', 'change'])

const { t } = useI18n()

// 响应式数据
const expendAll = ref(false) // 展开/收起
const detail = ref<DetailData>({}) // 接口详情信息
const prodReplacesList = ref<ProdReplacesItem[]>([]) // 套餐列表
const dateList = ref<CalendarItem[]>([]) // 日历价格
const calendarObj = ref<CalendarObj>({
  // 日历对象
  state: 1,
  msg: ''
})
const params = ref<Params>({
  // 日历价格传参
  infoId: '',
  nights: 1,
  num: 1
})
const currentYear = ref(Number(parseTime(new Date().getTime(), '{y}')))
const currentMonth = ref(Number(parseTime(new Date().getTime(), '{m}')))
const difPrice = ref(0) // 补差
const travelDate = ref<string[]>([]) // 选中值、酒店是一个包含开始日期-结束日期的范围数组
const currentDate = ref('') // 当前选中日期

// 计算属性
// 弹窗开关
const YyPopupFlag = computed({
  get: () => props.modelValue,
  set: (val: boolean) => emit('update:modelValue', val)
})

const limitNum = computed(() => {
  // 不分组默认显示6条
  if (detail.value && detail.value.prodGroupType === '0') {
    return 6
  }
  return 10
})

// 监听
watch(
  () => props.yyLink,
  (nVal, oVal) => {
    if (nVal !== oVal && nVal) {
      console.log('watch --- yyLink', nVal, oVal)
      getDetailQueryByYYLink()
    }
  }
)

// 生命周期
onMounted(() => {
  getDetailQueryByYYLink()
})

// 方法
// 预约产品详情查询
const getDetailQueryByYYLink = async () => {
  try {
    const res: any = await detailQueryByYYLink({
      yyLink: props.yyLink
    })

    if (res.state === 1) {
      console.log(res)
      detail.value = res.data
      prodReplacesList.value = res.data.prodReplaces || []
      if (detail.value.prodReplaces && detail.value.prodReplaces.length) {
        // 默认选中第一个
        params.value.infoId = prodReplacesList.value[0].infoId
        getCalendarData()
      }
    }
  } catch (error) {
    console.error('获取详情失败', error)
  }
}

// 获取价格日历
const getCalendarData = async () => {
  console.log('获取价格日历 ---')
  try {
    const res: any = await getCalQueryByYYLink({
      infoId: params.value.infoId,
      month: currentMonth.value,
      year: currentYear.value,
      yyLink: props.yyLink
    })

    calendarObj.value = {
      state: res.state,
      msg: res.msg
    }

    if (res.state === 1) {
      console.log(res)
      dateList.value = res.data
    }
  } catch (error) {
    console.error('获取日历数据失败', error)
  }
}

// 选择套餐
const chooseProduct = (item: ProdReplacesItem) => {
  if (detail.value.isStore === 1 && item.stock === 0) return // 如果是门店预约产品，判断售罄不可选
  if (params.value.infoId === item.infoId) return // 点击相同返回

  travelDate.value = []
  difPrice.value = 0
  params.value.infoId = item.infoId
  getCalendarData()
}

// 选择日期回调
const changeDate = (e: any) => {
  difPrice.value = e.chajia
  if (e.date === currentDate.value) {
    return
  }
  if (e.dateObj.startNum && Number(e.dateObj.startNum) > 1) {
    uni.showToast({
      title: `${t('appoint.reset')}${t('appoint.Appointment')}`,
      icon: 'none',
      mask: true,
      duration: 2500
    })
    params.value.num = e.dateObj.startNum
  }
  currentDate.value = e.date
}

// 切换月份
const changeMonth = () => {
  travelDate.value = []
  difPrice.value = 0
  getCalendarData()
}

const prevMonth = () => {
  if (
    currentYear.value === new Date().getFullYear() &&
    currentMonth.value <= new Date().getMonth() + 1
  ) {
    return
  }
  currentMonth.value -= 1
  if (currentMonth.value < 1) {
    currentYear.value -= 1
    currentMonth.value = 12
  }
  changeMonth()
}

const nextMonth = () => {
  currentMonth.value += 1
  if (currentMonth.value > 12) {
    currentYear.value = parseInt(currentYear.value.toString()) + 1
    currentMonth.value = 1
  }
  changeMonth()
}
</script>

<style lang="scss" scoped>
.YY-popup {
  position: fixed;
  height: 70vh;
  left: 50%;
  top: 40%;
  transform: translate(-50%, -40%);
  border-radius: 40rpx;
  background-color: #fff;
  .YY-popup-box {
    position: relative;
    width: 80vw;
    .YY-popup__title {
      font-size: 36rpx;
      font-weight: 600;
      letter-spacing: 3rpx;
      padding: 30rpx 0;
      position: sticky;
      top: 0;
      z-index: 99999;
      background: #ffffff;
      border-radius: 40rpx 40rpx 0 0;
    }
    .YY-popup__expendAllBtn {
      width: 100px;
      height: 20px;
      font-size: 14px;
      color: #fff;
      background-color: #ff8b0e;
      margin: 10px auto;
      text-align: center;
      line-height: 20px;
      border-radius: 18px;
    }
    .YY-popup-content {
      margin: 0 30rpx;
      .sub-title {
        color: #222222;
        font-size: 32rpx;
        font-weight: 600;
        background: url('http://qnimg.zowoyoo.com/img/84826/1683698281158.png')
          no-repeat left center;
        background-size: 6rpx 32rpx;
        padding-left: 20rpx;
      }
      .popup-item {
        margin: 24rpx 0;
        .disabled-bg {
          z-index: 9999;
          width: 100%;
          height: 100%;
          position: absolute;
          top: 0;
          object-fit: contain;
          background: #fff;
        }
        .item {
          position: relative;
          padding: 10px 10px 10px 35px;
          border-bottom: 1px solid #eee;
          margin: 0;
          &:last-child {
            border-bottom: none;
          }
          .i-sel {
            position: absolute;
            left: 5px;
            top: 50%;
            transform: translateY(-50%);
            width: 18px;
            height: 18px;
            background-color: #fff;
            border-radius: 18px;
            border: 1px solid #ccc;
            box-sizing: border-box;
          }
          .i-sel.sel {
            background: url('http://qnimg.zowoyoo.com/img/84826/1683700430760.png')
              no-repeat center center #ff8b0e;
            background-size: 10px 7px;
            border: none;
          }
          .title {
            font-size: 13px;
            font-weight: bold;
            color: #333;
            line-height: 18px;
          }
          &.disabled {
            opacity: 0.6;
            background: #f1f1f1;
            margin: 0;
          }
        }
      }
      .calendar-box {
        padding-top: 5px;
        border-bottom: 1px solid #eee;
        .months {
          border-bottom: 1px solid #eee;
          width: 100%;
          padding: 0 20px 10px 20px;
          box-sizing: border-box;
          display: flex;
          .i-arrow0 {
            display: inline-block;
            background: url('http://qnimg.zowoyoo.com/img/84826/1683712176191.png')
              no-repeat;
            background-size: 100% 100%;
            width: 6.5px;
            margin-left: 2.5px;
          }
          .i-arrow1 {
            display: inline-block;
            background: url('http://qnimg.zowoyoo.com/img/84826/1683712193724.png')
              no-repeat;
            background-size: 100% 100%;
            width: 6.5px;
            margin-left: 2.5px;
          }
          span {
            padding: 5px 0;
            margin: 0 15px;
            color: #000;
            font-weight: bold;
            font-size: 13px;
            position: relative;
            z-index: 9999;
          }
          span.sel::after {
            content: '';
            position: absolute;
            z-index: 9999;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 0;
            border-top: 3px solid #ffcb00;
          }
        }
        .no-date {
          margin: 30px auto 15px auto;
          font-size: 14px;
          color: #f65050;
        }
      }
    }
    .YY-popup-content__tips {
      position: fixed;
      z-index: 1;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      padding: 30rpx 0 50rpx;
      .image {
        width: 150rpx;
        height: 124rpx;
      }
      .text {
        color: #888888;
        font-size: 32rpx;
        margin-top: 30rpx;
      }
    }
  }
  .YY-pupup-colseBtn {
    position: absolute;
    bottom: -100rpx;
    left: 50%;
    transform: translateX(-50%);
    color: #999999;
    border-radius: 50px;
    background: #ffffff;
    padding: 14rpx 40rpx;
  }
}
</style>
