<template>
  <view class="z-set-meal">
    <view class="z-set-meal-title">
      <p>
        <text>{{ title }}</text>
        <i v-if="titleType === 'colours'"></i>
      </p>
    </view>
    <view class="z-set-meal-box">
      <view
        :class="line ? 'z-set-meal-list line' : 'z-set-meal-list'"
        v-for="(item, index) in dataList.slice(0, show ? dataList.length : num)"
        :key="index"
      >
        <view class="meal-list-top">
          <p
            class="meal-list-top-title"
            @click="handleClick(item)"
          >
            {{ item.title }}
          </p>
          <view class="meal-list-tag">
            <up-tag
              class="list-bottom-tag"
              v-for="(tag, i) in item.theme"
              :key="i"
              :text="tag.name"
              :color="tag.textColor || '#fb6046'"
              :circle="true"
              :bgColor="tag.color || '#fff2f0'"
              :borderColor="tag.color || '#fff2f0'"
            ></up-tag>
            <!-- <van-tag
              class="list-bottom-tag"
              v-for="(tag, i) in item.theme"
              :key="i"
              type="primary"
              :color="tag.color || '#fff2f0'"
              :text-color="tag.textColor || '#fb6046'"
            >
              {{ tag.name }}
            </van-tag> -->
          </view>
        </view>
        <view class="meal-list-bottom">
          <p class="meal-list-top-money">
            <text class="marketPrice">
              <i>￥</i>
              <text>{{ item.marketPrice }}</text>
            </text>
            <text
              class="price"
              v-if="item.commission"
            >
              {{ t('zDetailInfo.commission') }}
              <text>￥{{ item.commission }}</text>
            </text>
            <!-- <text class="price" v-if="item.price">
              {{t('zDetailInfo.commission')}}<text>{{￥}}{{ profit(item) }}</text>
            </text> -->
          </p>
          <text
            class="list-bottom-reserve"
            @click="handleClick(item)"
          >
            {{ buttonText }}
          </text>
        </view>
      </view>
    </view>
    <view
      class="z-set-meal-look"
      v-if="dataList.length > num"
    >
      <text @click="show = !show">
        {{ show ? t('zDetailCollapse.hide') : t('zDetailCollapse.more') }}
        <!-- <van-icon name="arrow" /> -->
        <uni-icons
          type="right"
          size="18"
        ></uni-icons>
      </text>
    </view>
  </view>
</template>
<script lang="ts">
import i18n from '@/i18n/index'
const { t } = i18n().global
const defaultTitle = t('zDetailButton.package')
const defaultButtonText = t('zDetailButton.book')
</script>
<script lang="ts" setup>
import { ref } from 'vue'
// import i18n from '@/i18n/index'

// const { t } = i18n().global

interface DataList {
  title: string
  theme: any[]
  marketPrice: number
  price?: number
  commission?: number
}

withDefaults(
  defineProps<{
    title?: string
    titleType?: string
    dataList: DataList[]
    line?: boolean
    num?: number
    buttonText?: string
  }>(),
  {
    title: defaultTitle,
    titleType: 'none',
    dataList: () => [],
    line: false,
    num: 4,
    buttonText: defaultButtonText
  }
)

const emit = defineEmits(['click'])

const show = ref(false)

// const profit = (item: { marketPrice: number; price: number }) => {
//   return computeNumber(item.marketPrice, '-', item.price).result
// }

const handleClick = (item: any) => {
  emit('click', item)
}
</script>

<style lang="scss" scoped>
@import './style/index.scss';
</style>
