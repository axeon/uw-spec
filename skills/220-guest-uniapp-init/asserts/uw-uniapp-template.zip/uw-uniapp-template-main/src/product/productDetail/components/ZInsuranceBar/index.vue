<template>
  <view>
    <view
      class="z-insurance-bar"
      @click="handleClick"
    >
      <i class="z-insurance-licon"></i>
      <view class="z-insurance-text">{{ title }}</view>
      <i class="z-insurance-ricon"></i>
    </view>
    <!-- 保险内容 -->
    <uni-popup
      ref="popup"
      type="right"
      style="width: 100%; height: 100%; padding-top: 0"
    >
      <view style="">
        <!-- <NavBar
        :border="false"
        :statusBar="true"
        navType="title"
        searchType="current"
        leftIcon="left"
        :title="t('zInsuranceBar.title')"
      >
        <template #left>
          <uni-icons
            @click="() => popup.close()"
            type="left"
            size="18"
            color="#222222"
          ></uni-icons>
        </template>
      </NavBar> -->
        <uni-nav-bar
          left-icon="left"
          :title="t('zInsuranceBar.title')"
          :border="false"
        >
          <template #left>
            <uni-icons
              @click="() => popup.close()"
              type="left"
              size="18"
              color="#222222"
            ></uni-icons>
          </template>
        </uni-nav-bar>
      </view>
      <view class="z-insurance-content">
        <p class="z-insurance-name-list">
          1、{{ t('zInsuranceBar.name') }}：
          <text
            class="z-insurance-orange"
            v-for="(item, index) in list"
            :key="index"
            @click="handleShowPop(item)"
          >
            {{ item.title }}
          </text>
        </p>
        <mp-html :content="content"></mp-html>
      </view>
    </uni-popup>

    <!-- 《平安旅行意外伤害保险（B款）》 弹窗 -->
    <uni-popup
      ref="showPop"
      :is-mask-click="true"
    >
      <view class="z-insurance-pop-b">
        <view class="z-pop-b-title">{{ popTitle }}</view>
        <view class="z-pop-b-content">
          <mp-html :content="popContent"></mp-html>
        </view>
      </view>
    </uni-popup>
  </view>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import i18n from '@/i18n/index'
import mpHtml from 'mp-html/dist/uni-app/components/mp-html/mp-html'

const { t } = i18n().global

// 定义 Props 类型
interface Props {
  title: string
  content: string
  list: any[]
}

// 定义 Props
defineProps<Props>()

// 定义 Emits
// const emit = defineEmits(['click'])

// 定义数据
const popup = ref()
const showPop = ref()
const popTitle = ref('')
const popContent = ref('')

// 方法
const handleClick = () => {
  popup.value.open()
}

const handleShowPop = (item: { title: string; content: string }) => {
  showPop.value.open()
  popTitle.value = item.title
  popContent.value = item.content
}
</script>
<style lang="scss" scoped>
@import './style/index.scss';
</style>
<style lang="scss">
:deep(.uni-popup .uni-popup__wrapper.right) {
  padding-top: 0 !important;
}
.z-insurance-pop-b {
  .van-popup__close-icon--top-right {
    top: 8px;
  }
  .van-popup__close-icon {
    font-size: 14px;
  }
}
</style>
