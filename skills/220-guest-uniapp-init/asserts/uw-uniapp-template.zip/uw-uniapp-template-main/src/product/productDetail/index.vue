<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { onLoad, onPageScroll } from '@dcloudio/uni-app'
import ZUp from '@/components/ZUp/index.vue'
import { navToUrl, getProductSingleImg, CalculationPrice } from '@/utils/tool'
import {
  guestProductInfoPriceList,
  guestProductInfoLoad,
  guestProductInfoSpecList,
  guestProductInfoSessionList,
  guestPoiInfoList,
  type ProductInfo,
  type ProductPrice,
  type GuestProductPriceQueryParam,
  type SpecInfo,
  type ProductSession,
  type GuestPoiInfoQueryParam,
  type PoiInfo
} from '@/api/saasMallAppGuestApi'
import dayjs from 'dayjs'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()
const state = reactive({
  id: undefined,
  scrollTop: 0
})
const detailData = ref<ProductInfo>({})

// 获取产品信息
const getProductInfo = async (id: number) => {
  const res = await guestProductInfoLoad({ id })
  try {
    if (res.state === 'success' && res.data) {
      console.log('guestProductInfoLoad', res.data)
      detailData.value = res.data
    } else {
      detailData.value = {}
    }

    // POI列表
    if (detailData.value?.poiIds) {
      getPoiList(detailData.value?.poiIds?.split(',').map(Number))
    }
  } catch (error) {
    console.log('guestProductInfoLoad error', error)
  }
}

// 跳转下单
const handleClick = () => {
  navToUrl(
    `/product/placeOrder/index?productData=${JSON.stringify(detailData.value)}`
  )
}

// 产品价格列表
const priceList = ref<ProductPrice[]>([])
// 获取产品价格列表
const getProductPriceList = async () => {
  try {
    const params: GuestProductPriceQueryParam = {
      ...{
        $pg: 1,
        $rn: 20,
        state: 1,
        priceDateRange: [
          dayjs(travelDate.value).format('YYYY-MM-DD 00:00:00'),
          dayjs(travelDate.value).format('YYYY-MM-DD 23:59:59')
        ]
      },
      productId: state.id
    }
    const res = await guestProductInfoPriceList(params)
    if (res.state === 'success') {
      console.log('guestProductInfoPriceList', res.data)
      priceList.value = res.data?.results || []
    } else {
      priceList.value = []
    }
  } catch (error) {
    console.error('getProductPriceList error', error)
  }
}

// 出发日期
const travelDate = ref<string>(dayjs().format('YYYY-MM-DD'))

const getCurrentDate = () => {
  const today = new Date()
  const year = today.getFullYear()
  const month = String(today.getMonth() + 1).padStart(2, '0')
  const day = String(today.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

const getFormattedDate = (daysOffset: number) => {
  const date = new Date()
  date.setDate(date.getDate() + daysOffset)
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

// 初始化日期标签列表
const initDateTagList = () => {
  const today = getFormattedDate(0)
  const tomorrow = getFormattedDate(1)
  const queryDate = travelDate.value || getCurrentDate()
  return [
    {
      text: t('今日'),
      date: today,
      type: 'date',
      isSelected: queryDate === today
    },
    {
      text: t('明日'),
      date: tomorrow,
      type: 'date',
      isSelected: queryDate === tomorrow
    },
    {
      text: t('选择日期'),
      date: queryDate !== today && queryDate !== tomorrow ? queryDate : '--',
      type: 'more',
      isSelected: queryDate !== today && queryDate !== tomorrow
    }
  ]
}

const dateTagList = ref(initDateTagList())

// 日期选择器
const selectDate = (type: string, index: number) => {
  console.log('selectDate', type, index)
  if (type === 'date') {
    travelDate.value = dateTagList.value[index].date
    getProductPriceList()
  } else if (type === 'more') {
    // 弹窗选择日期
  }
  // if (type === 'more') {
  //   isPickerVisible.value = !isPickerVisible.value
  //   getPoiCalendarPrice(poiCalendarMonth.value || travelDate.value)
  //   // 更新预订展开的初始月份
  //   currentCalendarMonth.value = dayjs(travelDate.value)
  //     .startOf('month')
  //     .format('YYYY-MM-DD')
  // } else {
  //   travelDate.value = dateTagList.value[index].date
  //   updateTagSelection(travelDate.value)
  //   // 点击今日明日更新初始月份
  //   currentCalendarMonth.value = dayjs(travelDate.value)
  //     .startOf('month')
  //     .format('YYYY-MM-DD')
  //   poiCalendarMonth.value = dayjs(travelDate.value)
  //     .startOf('month')
  //     .format('YYYY-MM-DD')
  //   handleDetail()
  // }
}

// 产品场次集合
const sessionList = ref<ProductSession[]>([])
// 获取产品场次
const getProductSessions = async () => {
  const res = await guestProductInfoSessionList({
    productId: state.id!
  })
  if (res.state === 'success') {
    console.log('guestProductInfoSessionList', res.data)
    sessionList.value = res.data?.results || []
    // 初始化场次
    if (sessionList.value.length) {
      getSpecInfos(sessionList.value[0].id)
    }
  } else {
    sessionList.value = []
  }
}

// 产品规格集合
const specInfos = ref<SpecInfo[]>([])
// 获取产品规格
const getSpecInfos = async (sessionId = 0) => {
  const res = await guestProductInfoSpecList({
    productId: state.id!, //
    sessionId, //
    stockType: 3, //1 日历库存  2 非日历库存 3 场次库存
    currency: 'CNY', //货币类型
    date: dayjs().format('YYYY-MM-DD') //
  })
  if (res.state === 'success') {
    console.log('guestProductInfoSpecList', res.data)
    specInfos.value = res.data || []
  } else {
    specInfos.value = []
  }
}

// 切换场次更新规格
// const handleChangeSession = (item: ProductSession) => {
//   console.log('handleChangeSession', item)
// }

const poiList = ref<PoiInfo[]>([])
// 根据poiIds获取POI列表 (景点列表)
const getPoiList = async (poiIds: number[]) => {
  const params: GuestPoiInfoQueryParam = {
    $pg: 1,
    $rn: 9999,
    ids: poiIds
    // poiType: 1  // 产品类型(1:产品,2:场次,3:规格)
  }
  const res = await guestPoiInfoList(params)
  if (res.state === 'success') {
    console.log('guestPoiInfoList', res.data)
    poiList.value = res.data?.results || []
  } else {
    poiList.value = []
  }
}

onLoad((options: any) => {
  console.log('productDetail options', options)
  if (options.id) {
    state.id = options.id || undefined
    getProductInfo(options.id)
    getProductPriceList()
    getProductSessions()
    // getSpecInfos()
  } else {
    console.log('productDetail options error')
  }
})
// 滚动页面
onPageScroll((e) => {
  state.scrollTop = e.scrollTop
})
</script>

<template>
  <view class="product-page">
    <!-- 产品主图 -->
    <div class="h-[400rpx] w-full overflow-hidden flex justify-center">
      <image
        class="w-full"
        :src="getProductSingleImg(detailData.imgMain)"
      />
    </div>

    <div class="bg-white rounded-t-[30rpx] pt-[20rpx]">
      <div class="text-[22px] p-[10px_20px]">{{ detailData.productName }}</div>

      <div class="flex flex-wrap gap-[8rpx] p-[0px_20px]">
        <span
          class="bg-primary-bg border text-primary flex h-[26rpx] items-center rounded-[10rpx] p-[0_10rpx] text-[24rpx] leading-[24rpx]"
          v-for="tag in detailData.tagIds?.split(',')"
          :key="tag"
        >
          {{ tag }}
        </span>
      </div>

      <div class="flex p-[30rpx] gap-[20rpx]">
        <!--一共只有三个日期标签，明天今天，其他-->
        <div
          class="relative flex h-[65rpx] items-center rounded-[20rpx] border-[1px] p-[0_30rpx] text-[26rpx] select-none"
          :class="{
            'border-[#030D18] bg-[#030D18] text-white':
              date.date === travelDate,
            'border-[#f0f0f0] bg-white text-[#030D18]': date.date !== travelDate
          }"
          v-for="(date, index) in dateTagList"
          :key="date.text"
          @click.stop="selectDate(date.type, index)"
        >
          <!--选择日期 -- 触发日期选择器-->
          <template v-if="date.type === 'more'">
            <span class="flex items-center gap-[5px] text-center">
              <!-- 如果用户选择日期则展示用户日期(除今天明天之外)，否则date值为'--' -->
              {{ date.date === '--' ? date.text : date.date }}
              <!-- <SvgIcon
                name="arrowRight"
                class="mt-[2rpx] h-[20px] w-[20px]"
                :color="date.date === travelDate ? '#fff' : '#030D18'"
              /> -->
            </span>
          </template>
          <template v-else>
            {{ date.text }}
          </template>
        </div>
      </div>

      <div class="flex flex-col gap-[10rpx] p-[0_30rpx]">
        <div
          v-for="item in priceList"
          :key="item.id"
          class="border-2 border-[#eeeeee] rounded-2xl p-[10rpx]"
        >
          <p>priceDate: {{ dayjs(item.priceDate).format('YYYY-MM-DD') }}</p>
          <p>priceSale: {{ CalculationPrice(item.priceSale! / 100) }}</p>
        </div>
      </div>

      <div class="">
        <view class="flex flex-col px-4 py-4 gap-[20rpx]">
          <view
            class="bg-white rounded-2xl shadow-md p-4 mb-3 flex items-start"
            v-for="item in poiList"
            :key="item.id"
          >
            <!-- 左侧图标 -->
            <uv-icon
              name="map-pin"
              size="22"
              color="#3b82f6"
              class="mt-1 mr-3"
            />

            <!-- 右侧内容 -->
            <view class="flex-1">
              <text class="text-base font-semibold text-gray-900">
                {{ item.poiName }}
              </text>
              <text class="block text-sm text-gray-500 mt-1">
                {{ item.address }}
              </text>
            </view>
          </view>
        </view>
      </div>

      <button
        class="bottom-box"
        @click="handleClick"
      >
        立即下单
      </button>
    </div>

    <ZUp :scrollTop="state.scrollTop" />
  </view>
</template>

<style lang="scss" scoped>
.product-page {
  width: 100vw;
  overflow: hidden;
  box-sizing: border-box;
  background-color: #f7f7f7;
  // padding-bottom: calc(env(safe-area-inset-bottom) / 2 + 100rpx);
  .border {
    border: 1px solid #000;
  }

  .bottom-box {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100vw;
    height: 100rpx;
    line-height: 100rpx;
    text-align: center;
    background-color: #fff;
    color: #000;
    font-size: 32rpx;
  }
}
</style>
