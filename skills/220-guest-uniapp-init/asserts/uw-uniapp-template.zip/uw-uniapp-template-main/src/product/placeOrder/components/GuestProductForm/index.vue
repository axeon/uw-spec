<script lang="ts" setup>
import type { GuestFormField } from '@/config/EnumExtend'
import { useCommonSelectTypes } from '@/utils/enumeration'
import { findAreaLabelPath } from '@/utils/tool'
import { ref, onMounted } from 'vue'
import areaInfo from '@/utils/areaInfo'
import type { commonType } from '@/api/type/API_TYPE'

const props = withDefaults(
  defineProps<{
    rules: Record<string, any>
    guestFormList: string[]
    idTypeOption: commonType[]
  }>(),
  {
    // num: 1
  }
)
// const emits = defineEmits<{
//   (e: 'click', item: any): void
// }>()

const { genderTypes } = useCommonSelectTypes()

const formGuestModel = defineModel({
  default: {
    guests: [] as Record<GuestFormField, string | number | undefined>[]
  },
  required: true
})

// 地区控件
const isShowCascader = ref(false)
const curCascaderList = ref([])

// 100001300000000000,100001300010000000,100001300010040000
const curCascaderShowList = ref<string>()
// 河北省/唐山市/路北区
const curCascaderShowLabelList = ref<string>()
// 级联选择器确认
const handleCascaderConfirm = (list: string[]) => {
  // console.log('handleCascaderConfirm', list)
  curCascaderShowList.value = list.join()
  const lastCode = list[list.length - 1]
  const areaList = findAreaLabelPath(areaInfo, lastCode)
  // console.log('areaList', areaList) // ['河北省', '唐山市', '路北区']
  curCascaderShowLabelList.value = areaList?.join('/')
}

// 选择证件类型
const handleSelectIdType = (obj: commonType, index: number) => {
  // console.log('handleSelectIdType', obj, index)
  formGuestModel.value.guests[index].idType = obj.value as string
}

onMounted(() => {})

const formGuestRef = ref()

defineExpose({
  setRules: () => formGuestRef.value?.setRules({}),
  validate: () => formGuestRef.value?.validate()
})
</script>

<template>
  <!-- 游客表单 -->
  <up-form
    ref="formGuestRef"
    :model="formGuestModel"
    :rules="props.rules"
    labelWidth="150rpx"
  >
    <div class="flex flex-col gap-2.5">
      <!-- {{ formGuestModel }}
      {{ formGuestRules }} -->
      <div
        v-for="(guest, index) in formGuestModel.guests"
        :key="index"
      >
        <u-title>游客信息 {{ index + 1 }}</u-title>
        <up-form-item
          v-if="guestFormList.includes('name')"
          label="姓名"
          :prop="`guests.${index}.name`"
          :borderBottom="true"
        >
          <up-input
            v-model="guest.name"
            border="none"
            placeholder="请输入姓名"
            clearable
          ></up-input>
        </up-form-item>
        <up-form-item
          v-if="guestFormList.includes('namePinyin')"
          label="姓名拼音"
          :prop="`guests.${index}.namePinyin`"
          :borderBottom="true"
        >
          <up-input
            v-model="guest.namePinyin"
            border="none"
            placeholder="请输入姓名拼音"
            clearable
          ></up-input>
        </up-form-item>
        <up-form-item
          v-if="guestFormList.includes('gender')"
          label="性别"
          :prop="`guests.${index}.gender`"
          :borderBottom="true"
        >
          <up-radio-group v-model="guest.gender">
            <up-radio
              :customStyle="{ marginRight: '16px' }"
              v-for="(item, idx) in genderTypes"
              :key="idx"
              :label="item.label"
              :name="item.value"
            ></up-radio>
          </up-radio-group>
        </up-form-item>
        <up-form-item
          v-if="guestFormList.includes('phoneCN')"
          label="手机号(大陆)"
          :prop="`guests.${index}.phoneCN`"
          :borderBottom="true"
        >
          <up-input
            placeholder="请输入手机号(大陆)"
            border="surround"
            type="number"
            v-model="guest.phoneCN"
            clearable
          ></up-input>
        </up-form-item>
        <up-form-item
          v-if="guestFormList.includes('phone')"
          label="手机号"
          :prop="`guests.${index}.phone`"
          :borderBottom="true"
        >
          <up-input
            placeholder="请输入手机号"
            border="surround"
            type="number"
            v-model="guest.phone"
            clearable
          ></up-input>
        </up-form-item>
        <up-form-item
          v-if="guestFormList.includes('address')"
          label="地址"
          :prop="`guests.${index}.address`"
          :borderBottom="true"
        >
          <div
            class="flex flex-col"
            @click="isShowCascader = true"
          >
            {{ curCascaderShowLabelList ?? '请选择地区' }}
            <up-input
              placeholder="请输入地址"
              v-model="guest.address"
              clearable
            ></up-input>
          </div>
          <up-cascader
            v-model:show="isShowCascader"
            v-model="curCascaderList"
            labelKey="areaName"
            valueKey="areaCode"
            :data="areaInfo"
            @confirm="handleCascaderConfirm"
          ></up-cascader>
        </up-form-item>
        <up-form-item
          v-if="guestFormList.includes('email')"
          label="邮箱"
          :prop="`guests.${index}.email`"
          :borderBottom="true"
        >
          <up-input
            placeholder="请输入邮箱"
            border="surround"
            type="text"
            v-model="guest.email"
            clearable
          ></up-input>
        </up-form-item>
        <template v-if="idTypeOption.length">
          <up-form-item
            label="证件类型"
            :prop="`guests.${index}.idType`"
            :borderBottom="true"
          >
            <up-select
              v-model:current="guest.idType"
              label="请选择证件类型"
              labelName="label"
              keyName="value"
              :showOptionsLabel="
                guest.idType || [0, '0'].includes(guest.idType!) ? true : false
              "
              :options="idTypeOption"
              @select="handleSelectIdType($event, index)"
            ></up-select>
          </up-form-item>
          <up-form-item
            label="证件号码"
            :prop="`guests.${index}.idInfo`"
            :borderBottom="true"
          >
            <up-input
              placeholder="请输入证件号码"
              border="surround"
              type="text"
              v-model="guest.idInfo"
              clearable
            ></up-input>
          </up-form-item>
        </template>
      </div>
    </div>
  </up-form>
</template>

<style lang="scss" scoped></style>
