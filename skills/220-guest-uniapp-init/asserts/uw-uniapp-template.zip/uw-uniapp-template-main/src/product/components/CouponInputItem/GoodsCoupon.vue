<template>
  <view
    class="coupon-input-item-page"
    :class="{ 'goodspopup-coupon': pageType === 'goodspopup' }"
  >
    <u-popup :show="newShowCouponPop">
      <view class="wrapper">
        <view class="title">优惠券</view>
        <view class="tabs">
          <view
            :class="{ active: tabIndex === 0 }"
            @click="onChangeTab(0)"
          >
            可用
          </view>
          <view
            :class="{ active: tabIndex === 1 }"
            @click="onChangeTab(1)"
          >
            不可用
          </view>
        </view>
        <scroll-view
          class="content"
          :scroll-y="true"
          style="height: 590rpx"
        >
          <Card
            v-for="(coupon, index) in receivedListData"
            :key="index"
            :data="coupon"
            :tabIndex="tabIndex"
            :selectList="selectList"
            @select="onSelect"
          />
          <view
            v-if="tabIndex === 1"
            style="height: 30rpx"
          />
          <view
            class="not-use"
            v-if="tabIndex === 0"
            @click="notUse"
          >
            <text>不使用优惠</text>
            <u-icon
              v-if="selectList.length === 0"
              name="checkmark-circle-fill"
              size="40"
              color="#F47F02"
            />
            <view
              v-else
              class="icon item-set-style"
            />
          </view>
        </scroll-view>
        <view class="bottom">
          <view>
            已选{{ selectList.length }}张，共抵扣
            <text class="highlight">{{ selectMoney }}</text>
            {{ currencyCN }}
          </view>
          <button @click="onSelectOk">确认</button>
        </view>
      </view>
    </u-popup>
  </view>
</template>

<script lang="ts" setup>
import { ref, computed, watch, onMounted } from 'vue'
import { receivedList, couponMoney } from '@/api/text'
import Card from './Card.vue'
import { useUserStore } from '@/store/user'

const props = withDefaults(
  defineProps<{
    productId: number
    number: number
    orderData: object
    price: number
    salePrice: number
    pageType: string
    showCouponPop: boolean
  }>(),
  {
    productId: 1,
    number: 1,
    orderData: () => ({}),
    price: 0,
    salePrice: 0,
    pageType: '',
    showCouponPop: false
  }
)

const emit = defineEmits(['update:showCouponPop', 'save'])

const tabIndex = ref(0)
const receivedListData = ref([])
const selectList = ref<any>([])
const selectMoney = ref(0)
const priceAll = ref(0)
const salePriceAll = ref(0)
const isFristShowClick = ref(true)

const userStore = useUserStore()

const currencyCN = computed(() => {
  return userStore.currencyCN
})

const newShowCouponPop = computed({
  get: () => {
    return props.showCouponPop
  },
  set: (value) => {
    emit('update:showCouponPop', value)
  }
})

watch(
  () => props.number,
  (newData, oldData) => {
    if (newData !== oldData && props.salePrice && selectList.value.length > 0) {
      priceAll.value = uni.$u.utils.toFixed(newData * props.price!, 2)
      salePriceAll.value = uni.$u.utils.toFixed(newData * props.salePrice, 2)
      onSelect(selectList.value[0], true)
    }
  }
)

watch(
  () => props.salePrice,
  (newData, oldData) => {
    if (newData !== oldData && props.salePrice && selectList.value.length > 0) {
      priceAll.value = uni.$u.utils.toFixed(props.number * props.price!, 2)
      salePriceAll.value = uni.$u.utils.toFixed(
        props.number * props.salePrice,
        2
      )
      onSelect(selectList.value[0], true)
    }
  }
)

watch(
  () => props.showCouponPop,
  (newValue) => {
    priceAll.value = uni.$u.utils.toFixed(props.number * props.price!, 2)
    salePriceAll.value = uni.$u.utils.toFixed(
      props.number * props.salePrice!,
      2
    )
    if (newValue === true && isFristShowClick.value === true) {
      getReceivedList(0)
      isFristShowClick.value = false
    }
  }
)

// 请求 API 接口数据
// 获取优惠券数据
const getReceivedList = async (params: number) => {
  if (!props.productId) return
  let id = 0
  if (params === 0) id = 1
  const res: any = await receivedList({
    productId: props.productId,
    price: priceAll.value,
    isUseByProd: id,
    salePrice: salePriceAll.value, // 订单总额
    state: 0
  })
  if (res.state !== 1 || res.data.results.length === 0) return
  emit(
    'save',
    [res.data.results[0].receiveId],
    res.data.results[0].couponMoneyByProd
  )
  selectMoney.value = res.data.results[0].couponMoneyByProd
  if (tabIndex.value === 0) {
    selectList.value = [res.data.results[0].receiveId]
  }
  receivedListData.value = res.data.results
}

const initCouponStatus = () => {
  selectList.value = []
  selectMoney.value = 0
}

// 切换tab
const onChangeTab = (id: number) => {
  tabIndex.value = id
  getReceivedList(id)
  initCouponStatus()
}

// 选择优惠券
const onSelect = (id: any, save: boolean) => {
  if (tabIndex.value === 1) return
  couponMoney(id, {
    price: priceAll.value,
    salePrice: salePriceAll.value,
    productId: props.productId
  }).then((res: any) => {
    if (res.state === 1) {
      selectList.value = [id]
      selectMoney.value = res.data
      if (save) {
        emit('save', [id], res.data)
      }
    } else {
      uni.showToast({
        title: res.msg || '请选择其他优惠券',
        duration: 2000
      })
    }
  })
}

// 不选择优惠券
const notUse = () => {
  initCouponStatus()
}

// 确定
const onSelectOk = () => {
  emit('update:showCouponPop', false)
  emit('save', selectList.value, selectMoney.value)
}

onMounted(() => {
  priceAll.value = uni.$u.utils.toFixed(props.number * props.price!, 2)
  salePriceAll.value = uni.$u.utils.toFixed(props.number * props.salePrice!, 2)
  getReceivedList(0)
})
</script>

<style lang="scss" scoped>
.coupon-input-item-page {
  display: flex;
  align-items: center;
  width: 686rpx;
  height: 90rpx;
  padding: 0 15rpx 0 29rpx;
  margin: 0 auto;
  background: #fff;
  border-radius: 10rpx;
  .wrapper {
    display: flex;
    flex-direction: column;
    > .title {
      padding-top: 40rpx;
      text-align: center;
      font-size: 32rpx;
      font-weight: 500;
      color: #000;
    }
    > .tabs {
      display: flex;
      margin-top: 50rpx;
      margin-bottom: 18rpx;
      font-size: 28rpx;
      text-align: center;
      color: #222;
      > view {
        position: relative;
        width: 50%;
        &.active::after {
          position: absolute;
          bottom: -18rpx;
          left: 50%;
          transform: translateX(-50%);
          content: '';
          display: block;
          width: 115rpx;
          height: 5rpx;
          border-radius: 3rpx;
          background: #f47f02;
        }
      }
    }
    .content {
      box-sizing: border-box;
      max-height: 590rpx;
      padding: 0 32rpx;
      overflow: auto;
      background: #f6f6f6;
      &.con-pd {
        padding-bottom: 30rpx;
      }
      .not-use {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        align-items: center;
        height: 159rpx;
        padding-right: 31rpx;
        > text:first-child {
          flex-grow: 1;
          font-size: 26rpx;
          color: #222;
        }
        > .icon {
          flex-shrink: 0;
        }
        .item-set-style {
          display: inline-block;
        }
      }
    }
    > .bottom {
      display: flex;
      justify-content: space-between;
      align-items: center;
      min-height: 90rpx;
      padding: 0 32rpx;
      .highlight {
        color: #f47f02;
      }
      > button {
        width: 190rpx;
        height: 72rpx;
        line-height: 72rpx;
        padding: 0;
        margin: 0;
        font-size: 26rpx;
        color: #fff;
        border-radius: 36rpx;
        background: #f47f02;
        &::after {
          display: none;
        }
      }
    }
  }
  > .title {
    font-size: 28rpx;
    font-weight: 500;
    color: #222;
    display: flex;
    align-items: center;
    .coupon-icon {
      width: 32rpx;
      height: 28rpx;
      margin-right: 10rpx;
    }
  }
  > .tips {
    flex-grow: 1;
    text-align: right;
    font-size: 26rpx;
    color: #999;
  }
  .price-wrapper {
    flex: 1;
    flex-shrink: 0;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    width: 130rpx;
    padding-right: 10rpx;
    > .price {
      font-size: 26rpx;
      color: #f47f02;
    }
  }
}
.goodspopup-coupon {
  padding-left: unset;
}
</style>

<style lang="scss">
.coupon-input-item-page {
  .wraper {
    z-index: 9999;
    .content {
      card {
        box-shadow: 0px 2px 6px 0px rgba(201, 201, 201, 0.3);
      }
    }
  }
  .icon {
    width: 34rpx;
    height: 34rpx;
    border: 1rpx solid #d5d5d5;
    border-radius: 50%;
  }
}
</style>
