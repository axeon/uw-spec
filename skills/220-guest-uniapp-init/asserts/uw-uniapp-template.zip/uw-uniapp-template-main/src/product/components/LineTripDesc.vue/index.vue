<template>
  <div class="line-trip">
    <div class="line-trip-content">
      <div class="line-trip-title space-between flex-align">
        <span>{{ lineProductJourneys.length }}天行程</span>
      </div>
      <div class="line-trip-box">
        <div
          v-for="line in lineProductJourneys"
          :key="line.id"
          class="flex-col line-trip-custom"
        >
          <div class="line-trip-time">
            <span class="line-trip-time-day">D{{ line.seqDay }}</span>
            <span class="line-trip-time-title">{{ line.itTitle }}</span>
          </div>
          <div class="line-trip-traffic">
            <div class="flex-align">
              <span>交通 · {{ line.itTraffic || '无' }}</span>
            </div>
          </div>
          <div class="line-trip-breakfast">
            <div class="flex-align">
              <span>早餐 · {{ line.itBreakfast }}</span>
              <span>午餐 · {{ line.itCentre }}</span>
              <span>晚餐 · {{ line.itSupper }}</span>
            </div>
          </div>
          <div class="line-trip-hotel">
            <div class="flex-align">
              <span>酒店 · {{ line.itHotel || '无' }}</span>
            </div>
          </div>
          <div class="line-trip-hotel">
            <div class="flex-align">
              <span style="line-height: 20px">
                景点 · {{ scenicSpot(line) }}
              </span>
            </div>
          </div>
          <div class="line-trip-view">
            <div class="flex-align">
              <span style="line-height: 20px">
                自费景点 · {{ line.itZfScenic || '无' }}
              </span>
            </div>
          </div>
          <div class="line-trip-rich-content">
            <mp-html
              selectable
              :content="
                replaceSection(processingCharacter(line.itContent) || '')
              "
              error-img="http://qnimg.zowoyoo.com/img/84826/1621847833863.png"
            ></mp-html>
          </div>
        </div>
      </div>
      <div style="height: 10px; background: #f0f0f0"></div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import mpHtml from 'mp-html/dist/uni-app/components/mp-html/mp-html'
import { replaceSection } from '@/utils/tool'

// 定义 props 接口， 增加类型约束
interface LineProductJourney {
  id: any
  seqDay?: number
  itTitle?: string
  itTraffic?: string
  itBreakfast?: string
  itCentre?: string
  itSupper?: string
  itHotel?: string
  itScenic?: string
  afterView?: { name: string }[]
  itZfScenic?: string
  itContent?: string
}

defineProps({
  lineProductJourneys: {
    type: Array as () => LineProductJourney[], // 使用 Array as () => LineProductJourney[] 明确类型
    default: () => [],
    required: true // 推荐加上 required: true
  }
})

// 景点信息处理，使用 computed 优化性能
const scenicSpot = computed(() => (line: LineProductJourney): string => {
  if (!line) {
    return '无'
  }

  if (line.itScenic) {
    return line.itScenic
  }

  if (
    line.afterView &&
    Array.isArray(line.afterView) &&
    line.afterView.length > 0
  ) {
    return line.afterView.map((item) => item.name).join('、')
  }

  return '无'
})

/**
 * HTML 内容字符处理函数
 * @param {string} value 待处理的 HTML 字符串
 * @returns {string} 处理后的 HTML 字符串
 */
const processingCharacter = (value: string | undefined): string | undefined => {
  if (!value) {
    return value
  }

  let processedValue = value.replace(/&lt;/g, '<')
  processedValue = processedValue.replace(/&gt;/g, '>')
  return processedValue
}
</script>

<style lang="scss" scoped>
.line-trip {
  width: 100%;
  background-color: #fff;

  &-title {
    font-family: PingFangSC-Medium, sans-serif;
    font-weight: bold;
    padding: 10px;
    font-size: 16px;
    color: #222;
    border-bottom: 1px solid #e5e5e5;
  }

  &-content {
    width: 100%;
  }

  &-custom {
    padding: 10px;
    margin-bottom: 10px;
    border-bottom: 1px solid #e5e5e5;
  }

  &-time {
    color: #222;
    margin-bottom: 10px;

    &-day {
      font-size: 18px;
      font-weight: bold;
    }

    &-title {
      font-size: 15px;
      margin-left: 10px;
    }
  }

  &-traffic,
  &-breakfast,
  &-hotel,
  &-view {
    position: relative;

    span {
      color: #222;
      font-size: 13px;
      margin-left: 10px;
    }

    .flex-align {
      padding: 10px 0;
    }
  }

  &-traffic,
  &-breakfast,
  &-hotel {
    &::before {
      content: '';
      position: absolute;
      left: 9px;
      top: 1.5rem;
      height: 100%;
      border-left: 1px dotted #000;
      box-sizing: border-box;
    }
  }

  &-rich-content {
    padding: 10px;
  }
}
</style>

<style lang="scss">
.line-trip {
  &-rich-content {
    view {
      max-width: 100%;
    }

    image {
      max-width: 100%;
    }
  }
}
</style>
