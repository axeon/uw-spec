<template>
  <view class="z-detail-info">
    <view class="z-detail-info-title">
      <text
        class="rush"
        v-if="currentTime && treeId === 12 && showSnapTime === true"
      ></text>
      {{ title }}
    </view>
    <view class="z-detail-info-des">
      <view class="info-des-icon">
        <view class="des-icon-item des-icon-choiceness des-icon-tag">
          精选好货
        </view>
        <view
          class="des-icon-item des-icon-refundsuccess des-icon-tag"
          v-for="(item, index) in tagList"
          :key="index"
        >
          {{ item }}
        </view>
      </view>
      <view v-if="treeId === 12 && nums && timeObj.state === 'time-wait'">
        <view class="progress-bar">
          <view class="text">已抢 {{ nums }}</view>
          <view
            class="width"
            :style="{ width: nums }"
          ></view>
          <view class="bg"></view>
        </view>
      </view>
      <view
        class="sold"
        v-if="sold && treeId !== 12"
      >
        {{ soldText }}:{{ sold }}
      </view>
    </view>
    <view
      class="z-detail-info-box"
      :class="{ 'new-z-detail-info-box': isPoiScene || userInfo.isPoi === 1 }"
    >
      <view class="z-detail-info-money">
        <view class="info-money-top">
          <view>
            {{ currency }}
            <!-- 百度小程序是可以在不登录的情况进入系统的，所以要判断没有用户类型的情况 -->
            <text v-if="userInfo.userType === 0 || !userInfo.userType">
              {{ salePrice }}
            </text>
            <text v-else-if="userInfo.userType > 0">{{ price }}</text>
            起
          </view>
          <text
            class="marketPrice new-marketPrice"
            v-if="marketPrice"
          >
            {{ currency }}{{ marketPrice }}
          </text>
        </view>
      </view>
      <view
        class="z-detail-info-time"
        :class="timeObj.state"
        v-if="currentTime && treeId === 12 && showSnapTime === true"
      >
        <view class="info-time-top">{{ timeObj.title }}</view>
        <u-count-down
          v-if="timeObj.time / 1000 > 0"
          :timestamp="timeObj.time / 1000"
          :color="
            timeObj.state === 'time-wait'
              ? 'rgba(254, 50, 33, 1)'
              : 'rgba(28, 134, 107, 1)'
          "
          :font-size="26"
          :height="36"
          :separator-size="24"
          separator-color="#fff"
          bg-color="rgba(255,255,255,.9)"
          separator="zh"
        ></u-count-down>
      </view>
    </view>
    <view
      class="z-detail-info-brokerage"
      @click="clickIntegral"
      v-if="brokerage && userInfo.userType > 0"
    >
      <view class="info-money-bottom">
        <i class="brokerage-icon">推广奖励</i>
        <view class="brokerage">
          <text>佣金</text>
          <text class="brokerage-num">
            {{ currency }}{{ CalculationPrice(brokerage) }}
          </text>
        </view>
        <view
          class="b2bCashback"
          v-if="
            b2bCashback && (userInfo.userType === 3 || userInfo.userType === 8)
              ? Number(b2bCashback)
              : 0
          "
        >
          <text>团返</text>
          <text class="brokerage-num">{{ currency }}{{ b2bCashback }}</text>
        </view>
      </view>
      <u-icon
        name="arrow-right"
        color="#CF7F00"
      ></u-icon>
    </view>
    <slot></slot>
    <view
      v-if="couponInfo.length > 0"
      class="z-detail-voucher"
      @click="onShowCoupon"
    >
      <u-popup
        :show="showCoupon"
        height="auto"
        border-radius="30"
        closeable
      >
        <view class="popup-content">
          <view class="title">
            <text>优惠券</text>
            领取
          </view>
          <scroll-view
            :scroll-y="true"
            style="height: 512rpx"
          >
            <view class="coupons">
              <view
                class="item"
                v-for="localCoupon in localCouponData"
                :key="localCoupon.id"
              >
                <view class="left">
                  <view class="money">
                    <view class="price">
                      <text>{{ currency }}</text>
                      <text>{{ localCoupon.couponMoney }}</text>
                    </view>
                  </view>
                  <view class="content">
                    <view class="title">{{ localCoupon.couponName }}</view>
                    <view class="time">{{ formatData(localCoupon) }}</view>
                  </view>
                </view>
                <view class="right">
                  <button
                    class="btn"
                    :class="{ isReceived: localCoupon.userUnUsedNum > 0 }"
                    @click.stop="
                      onCouponReceive(localCoupon.id, localCoupon.userUnUsedNum)
                    "
                  >
                    {{ localCoupon.userUnUsedNum > 0 ? '已领' : '立即领取' }}
                  </button>
                </view>
              </view>
            </view>
          </scroll-view>
        </view>
      </u-popup>
      <view class="content">
        <text class="receive">领劵</text>
        <view class="vouchers">
          <block
            v-for="(coupon, index) in couponInfo"
            :key="coupon.id"
          >
            <view
              v-if="index < 2"
              class="voucher-item"
            >
              <text>
                {{ couponType(coupon.couponMoney, coupon.couponType) }}
              </text>
            </view>
          </block>
        </view>
        <u-icon
          name="arrow-right"
          color="#D1C09B"
        />
      </view>
    </view>
    <view
      class="z-detail-info-address"
      :class="{
        'poi-z-detail-info-address': isPoiScene || userInfo.isPoi === 1
      }"
      v-if="viewNames.length === 1"
    >
      <view
        class="info-address"
        :style="{ 'margin-top': !areaName ? '10rpx' : 0 }"
      >
        <view class="info-address-left">
          <i></i>
          <view>
            <text
              class="info-viewname-title ellipsis"
              v-if="viewName"
            >
              {{ viewName }}
            </text>
            <view class="info-address-main ellipsis">{{ address }}</view>
          </view>
        </view>
        <view class="info-address-right">
          <view
            class="info-address-map cell"
            v-if="longitude && latitude"
            @click="handleMap({ longitude, latitude, name: areaName, address })"
          >
            <i></i>
            <text>地图</text>
          </view>
          <view
            class="info-address-phone cell"
            v-if="phone"
            @click="handlePhone"
          >
            <i></i>
            <text>电话</text>
          </view>
        </view>
      </view>
    </view>
    <view
      v-else-if="viewNames.length > 1"
      class="z-detail-info-address-another"
    >
      <view
        class="another-title"
        @click="clickAnother"
      >
        <view class="another-title-left">
          适用商户（{{ viewNames.length }}）
        </view>
        <view class="another-title-right">
          查看更多
          <u-icon name="arrow-right"></u-icon>
        </view>
      </view>
      <view class="another-end">{{ viewNames[0].name }}</view>
    </view>
    <u-popup
      v-model="isAnother"
      mode="bottom"
      border-radius="40"
      height="70%"
      closeable
    >
      <view class="popup-content">
        <view class="popup-title">适用商户（{{ viewNames.length }}）</view>
        <view style="height: 80rpx"></view>
        <scroll-view
          :scroll-y="true"
          style="height: 900rpx"
        >
          <view
            class="z-detail-info-address"
            :class="{
              'poi-z-detail-info-address': isPoiScene || userInfo.isPoi === 1
            }"
            v-for="item in viewNames"
            :key="item.name"
          >
            <view class="info-address-title fw">{{ item.name }}</view>
            <view
              class="info-address"
              :style="{ 'margin-top': !areaName ? '10rpx' : 0 }"
            >
              <view
                class="info-address-left"
                :class="{
                  'poi-info-address-left': isPoiScene || userInfo.isPoi === 1
                }"
              >
                <i></i>
                <view class="info-address-main">{{ item.address }}</view>
              </view>
              <view class="info-address-right">
                <view
                  class="info-address-map cell"
                  v-if="item.longitude && item.latitude"
                  @click="handleMap(item)"
                >
                  <i></i>
                  <text>地图</text>
                </view>
                <view
                  class="info-address-phone cell"
                  v-if="item.phone"
                  @click="handlePhone(item.phone)"
                >
                  <i></i>
                  <text>电话</text>
                </view>
              </view>
            </view>
          </view>
        </scroll-view>
        <view></view>
      </view>
    </u-popup>
    <u-popup
      v-model="show"
      mode="bottom"
      border-radius="40"
    >
      <view class="integral-box">
        <view class="title">
          <i>佣金</i>
          <text>奖励</text>
        </view>
        <view class="integral-main">
          <view class="integral-num">
            奖励积分:
            <text>{{ CalculationPrice(brokerage || 0) }}</text>
          </view>
          <view class="integral-rule">
            <view>奖励积分:</view>
            <view>
              普通用户通过你分享的小视频或商品链接进入购买商品，可获得积分（1积分=1{{
                currencyCN
              }}）
            </view>
          </view>
        </view>
        <view class="interim"></view>
        <view
          class="integral-btn"
          @click="show = false"
        >
          取消
        </view>
      </view>
    </u-popup>
  </view>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'
import { formatData } from '@/utils/coupon/tool'
import { bd09togcj02, CalculationPrice } from '@/utils/tool'
import { couponList, couponReceive } from '@/api/text'
import { useUserStore } from '@/store/user'

// 定义props类型
interface Props {
  treeId?: number
  title?: string
  orderStartDate?: number // 产品开售时间
  orderEndDate?: number // 产品结售时间
  currentTime?: number // 服务器当前时间
  sold?: number | string // 已售的数量
  soldText?: string // 已售的文本
  salePrice?: number | string // 零售价
  marketPrice?: number | string // 市场价 传入显示 互斥佣金  权重高于 佣金
  price?: number | string // 分销价
  brokerage?: number // 佣金 传入显示 互斥市场价
  b2bCashback?: number | string // 一级佣金
  progressBar?: number | string // 进度条
  longitude?: number | string // 经度
  latitude?: number | string // 纬度
  areaName?: string // 产品所在地名称
  viewName?: string // 景区名称
  address?: string // 地址
  couponInfo?: any[] // 优惠券信息
  productId?: number | string
  isCancel?: number
  phone?: any[] | string
  dyProductInfo?: object
  appointment?: string // 是否需要预约
  yyUrl?: string
  cancelRule?: any[] // 取消规则
  viewNames?: any[] // 景点名称
}

const props = withDefaults(defineProps<Props>(), {
  title: '',
  soldText: '已售',
  progressBar: 0,
  phone: '',
  appointment: '',
  yyUrl: '',
  cancelRule: () => [],
  viewNames: () => [],
  couponInfo: () => [],
  dyProductInfo: () => ({})
})

// const emit = defineEmits(['finish'])

const store = useUserStore()
const show = ref(false)
const showCoupon = ref(false)
const localCouponData = ref<any[]>([])
const isAnother = ref(false)

// 计算属性
const currency = computed(() => '￥')
const currencyCN = computed(() => '元')
const userInfo = computed(() => store.userInfo as unknown as any)
const scene = computed(() => store.scene)
const isPoiScene = computed(
  () =>
    String(scene.value) === '023005' &&
    process.env.VUE_APP_PLATFORM === 'mp-toutiao'
)

// 进度条显示
const nums = computed(() => {
  if (props.progressBar === 0) return '0'
  if (typeof props.progressBar === 'number') {
    return props.progressBar + '%'
  } else {
    return props.progressBar
  }
})

// 标签列表 - 过滤空值
const tagList = computed(() => {
  const list = props.cancelRule || []
  const arr: any[] = []
  list.forEach((item) => {
    if (item) arr.push(item)
  })
  return arr
})

// 时间状态对象
const timeObj = computed(() => {
  const obj = {
    time: 0,
    title: '',
    state: ''
  }

  // 服务器时间大于产品开售时间
  if (props.currentTime && props.currentTime > (props.orderStartDate || 0)) {
    if (props.currentTime > (props.orderEndDate || 0)) {
      obj.time = 0
      obj.title = '抢购已结束'
      obj.state = 'time-end'
    } else {
      obj.time = (props.orderEndDate || 0) - props.currentTime
      obj.title = '距活动结束'
      obj.state = 'time-wait'
    }
  } else {
    obj.time = (props.orderStartDate || 0) - (props.currentTime || 0)
    obj.title = '距活动开始'
    obj.state = 'time-start'
  }
  return obj
})

// 是否显示倒计时
const showSnapTime = computed(() => {
  // 三天时间，毫秒，超过三天不显示
  const targetTime = 3 * 24 * 60 * 60 * 1000

  if (props.currentTime && props.currentTime > (props.orderStartDate || 0)) {
    if (props.currentTime > (props.orderEndDate || 0)) {
      return true
    } else {
      // 抢购中 - 只显示结束时间
      if ((props.orderEndDate || 0) - props.currentTime > targetTime) {
        return false
      } else {
        return true
      }
    }
  } else {
    if ((props.orderStartDate || 0) - (props.currentTime || 0) > targetTime) {
      return false
    } else {
      return true
    }
  }
})

const clickAnother = () => {
  isAnother.value = true
}

// 领取优惠券
const onCouponReceive = async (id: number, number: number) => {
  if (number > 0) return

  uni.showLoading({ title: '加载中' })
  const res: any = await couponReceive(id)

  if (res.state === 1) {
    await getCoupons()
    uni.hideLoading()
  } else {
    uni.hideLoading()
    uni.showToast({
      icon: 'none',
      title: res.msg,
      duration: 2800
    })
  }
}

// 获取优惠券数据
const getCoupons = async () => {
  const res: any = await couponList({
    productId: props.productId,
    receiveMode: 0 // 只获取用户主动领取的优惠券
  })

  if (res.state !== 1) return
  localCouponData.value = res.data.results
}

// 显示优惠券弹窗
const onShowCoupon = () => {
  showCoupon.value = true
  getCoupons()
}

// 判断优惠券类型
const couponType = (money: any, couponType?: number): string => {
  const couponTypeHash = ['抵扣券', '满减券', '折扣券', '商品兑换券']
  return money + currencyCN.value + couponTypeHash[(couponType as number) - 1]
}

// 地图点击事件
const handleMap = (item?: any) => {
  let obj = {}
  if (item) {
    obj = bd09togcj02(item.longitude, item.latitude)
  } else {
    obj = bd09togcj02(Number(props.longitude), Number(props.latitude))
  }

  uni.openLocation({
    latitude: (obj as any).lat,
    longitude: (obj as any).lng,
    name: item ? item.name : props.areaName,
    address: item ? item.address : props.address
  })
}

// 点击积分
const clickIntegral = () => {
  show.value = true
}

// 打电话
const handlePhone = (val?: any) => {
  if (!val && !props.phone) return false

  let phoneList: string[] = []

  if (val && typeof val !== 'object') {
    phoneList = val.split(/,|，|、/)
  } else {
    phoneList =
      typeof props.phone === 'string'
        ? props.phone.split(/,|，|、/)
        : props.phone
  }

  if (phoneList.length === 1) {
    uni.makePhoneCall({
      phoneNumber: phoneList[0]
    })
    return false
  }

  uni.showActionSheet({
    itemList: phoneList,
    success: function (res: any) {
      console.log('选中了第' + (res.tapIndex + 1) + '个按钮')
      uni.makePhoneCall({
        phoneNumber: phoneList[res.tapIndex]
      })
    }
  })
}
</script>

<style lang="scss" scoped>
.z-detail-info {
  padding: 12 * 2rpx 0;
  background-color: #fff;
  .z-detail-info-title {
    box-sizing: border-box;
    margin-bottom: 24rpx;
    padding: 0 32rpx;
    overflow: hidden;
    color: rgba(34, 34, 34, 1);
    font-weight: bold;
    font-size: 32rpx;
    line-height: 46rpx;
    .rush {
      display: inline-block;
      width: 72rpx;
      height: 34rpx;
      margin-right: 6rpx;
      margin-bottom: 6rpx;
      vertical-align: middle;
      font-size: 0;
      background-image: url('http://qnimg.zowoyoo.com/img/84826/1637727080853.png');
      background-repeat: no-repeat;
      background-position: center;
      background-size: contain;
    }
  }

  .z-detail-info-des {
    display: flex;
    justify-content: space-between;
    padding: 0 32rpx;
    margin-bottom: 20rpx;
    .info-des-icon {
      flex: 1;
      display: flex;
      // flex-direction: column;
      flex-wrap: wrap;
      align-items: center;
      .des-icon-tag {
        display: inline-block;
        color: #f48e84;
        font-size: 20rpx;
        line-height: 27rpx;
        padding: 4rpx 7rpx;
        border-radius: 5rpx 5rpx 5rpx 5rpx;
        border: 1px solid #f48e84;
        margin-right: 12rpx;
      }
    }
  }
  .z-detail-info-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 0 32rpx;
    background: #f9f9f9;
    border-radius: 20rpx;
    overflow: hidden;
    height: 100rpx;
    .z-detail-info-money {
      display: flex;
      flex: 1;
      flex-direction: column;
      padding-left: 20rpx;
      .info-money-top {
        display: flex;
        align-items: baseline;
        font-size: 24rpx;
        view {
          display: flex;
          align-items: baseline;
          color: #fb6046;
          text {
            font-size: 48rpx;
            font-family: DINPro, Arial, sans-serif;
          }
        }
        .marketPrice {
          color: rgba(187, 187, 187, 1);
          font-weight: 400;
          margin-left: 16rpx;
          font-family: DINPro, Arial, sans-serif;
        }
        .new-marketPrice {
          position: relative;
        }
        .new-marketPrice::after {
          position: absolute;
          content: '';
          left: 0;
          right: 0;
          top: 50%;
          transform: translateY(-50%);
          background-color: rgba(187, 187, 187, 1);
          content: '';
          width: 110%;
          height: 1rpx;
        }
      }
    }
    .z-detail-info-time {
      flex-shrink: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100%;
      padding: 0 20rpx;
      background-color: #fff4ec;
      box-sizing: border-box;
      .info-time-toview {
        color: #f47f02;
        font-weight: 400;
        font-size: 24rpx;
        text-align: center;
      }
    }
    .time-end {
      // 抢购结束
      background: linear-gradient(-90deg, #c7ced8, #9faab7);
      font-size: 28rpx;
      .info-time-top {
        color: #fff;
      }
    }
    .time-wait {
      // 抢购中
      background: linear-gradient(-90deg, #fe2221, #fe8621);
      font-size: 24rpx;
      .info-time-top {
        color: rgba(255, 255, 255, 0.7);
        margin-bottom: 4rpx;
      }
      .colon {
        color: #fff;
      }
      .block {
        background-color: rgba(255, 255, 255, 0.9);
        color: rgba(254, 50, 33, 1);
      }
    }
    .time-start {
      // 未开始
      background: linear-gradient(-90deg, #47d5d3, #58e3bd);
      font-size: 24rpx;
      .info-time-top {
        color: rgba(28, 134, 107, 1);
        margin-bottom: 4rpx;
      }
      .colon {
        color: #fff;
      }
      .block {
        background-color: rgba(255, 255, 255, 0.9);
        color: rgba(28, 134, 107, 1);
      }
    }
  }
  .z-detail-info-brokerage {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 65rpx;
    padding: 0 15rpx 0 20rpx;
    margin: 22rpx 32rpx 0;
    background: #fbf7ee;
    border-radius: 20px;
    box-sizing: border-box;
    .info-money-bottom {
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding-right: 6rpx;
      font-weight: 500;
      font-size: 28rpx;
      .brokerage-icon {
        display: inline-flex;
        // vertical-align: baseline;
        align-items: center;
        // justify-content: flex-end;
        min-width: 84rpx;
        height: 38rpx;
        color: #f3edd2;
        font-size: 22rpx;
        font-weight: 400;
        background: url('http://qnimg.zowoyoo.com/img/84826/1625553457851.png')
          no-repeat center left #272526;
        background-size: contain;
        box-sizing: border-box;
        border-radius: 8rpx;
        margin-right: 15rpx;
        padding-left: 40rpx;
        padding-right: 8rpx;
      }
      .brokerage,
      .b2bCashback {
        display: inline-flex;
        vertical-align: baseline;
        align-items: center;
        height: 100%;
        color: #cf7f00;
        font-size: 24rpx;
        font-weight: 300;
        .brokerage-num {
          font-size: 28rpx;
          font-weight: bold;
          margin-left: 12rpx;
        }
      }
      .b2bCashback {
        margin-left: 20rpx;
      }
    }
  }
  .z-detail-info-progress {
    margin-top: 14 * 2rpx;
    padding: 0 16 * 2rpx;
  }
  .info-address-left {
    display: flex;
    align-items: center;
    i {
      width: 40rpx;
      height: 40rpx;
      // background: url('../../../assets/map-icon.png') no-repeat center;
      background-size: contain;
    }
  }
  .z-detail-voucher {
    display: flex;
    padding: 27rpx 32rpx 10rpx 32rpx;
    .popup-content {
      display: flex;
      flex-direction: column;
      align-items: center;
      height: 100%;
      padding-bottom: 75rpx;
      > .title {
        padding: 43rpx 0 48rpx;
        font-size: 32rpx;
        font-weight: 500;
        > text {
          color: #f47f02;
        }
      }
      .coupons {
        > .item:not(:first-child) {
          margin-top: 25rpx;
        }
        > .item {
          display: flex;
          width: 686rpx;
          height: 160rpx;
          margin: 0 auto;
          color: #f47f02;
          border-radius: 10rpx;
          // background: url('../../../assets/voucher/tick-bg.png') no-repeat 0 0;
          background-size: 100%;
          > .left {
            position: relative;
            top: -4rpx;
            flex: 1;
            display: flex;
            align-items: center;
            padding-left: 16rpx;
            .money {
              display: flex;
              flex-direction: column;
              width: 172rpx;
              padding-right: 16rpx;
              .price {
                display: flex;
                justify-content: center;
                align-items: flex-end;
                text:first-child {
                  font-size: 30rpx;
                  font-weight: 500;
                }
                text:last-child {
                  font-size: 68rpx;
                  line-height: 68rpx;
                  font-weight: 800;
                }
              }
            }
            .content {
              display: flex;
              flex-direction: column;
              .title {
                font-size: 30rpx;
                font-weight: 500;
                margin-bottom: 16rpx;
              }
              .time {
                font-size: 24rpx;
                color: #f47f02;
              }
            }
          }
          > .right {
            flex-shrink: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            padding-right: 26rpx;
            > .btn {
              width: 140rpx;
              height: 56rpx;
              line-height: 56rpx;
              padding: 0;
              color: #f47f02;
              font-size: 26rpx;
              font-weight: 500;
              background: #ffeee7;
              border: 1rpx solid #f47f02;
              border-radius: 28rpx;
              &.isReceived {
                color: #fbc796;
                border-color: #fbc796;
              }
              &::after {
                display: none;
              }
            }
          }
        }
      }
    }
    > .content {
      display: flex;
      align-items: center;
      width: 100%;
      padding: 16rpx 15rpx 16rpx 24rpx;
      background: #fbf7ee;
      border-radius: 20rpx;
      > .title {
        font-size: 26rpx;
        font-weight: bold;
        color: #333;
      }
      > .receive {
        padding: 0 10rpx;
        height: 40rpx;
        line-height: 40rpx;
        margin-right: 20rpx;
        font-size: 24rpx;
        color: #fefefe;
        background: #f47f02;
        border-radius: 4rpx;
      }
      > .vouchers {
        flex-grow: 1;
        display: flex;
        align-items: center;
        > .voucher-item {
          position: relative;
          height: 44rpx;
          line-height: 44rpx;
          font-size: 24rpx;
          display: flex;
          &:not(:last-child) {
            margin-right: 15rpx;
          }
          > text {
            flex: 1;
            padding: 0 15rpx;
            color: #f47f02;
            display: block;
            height: 44rpx;
            background: url('http://qnimg.zowoyoo.com/img/84826/1636083927474.png')
              repeat-x;
            background-size: 100% 100%;
          }
          &::before {
            content: '';
            background: url('http://qnimg.zowoyoo.com/img/84826/1636083410424.png')
              no-repeat;
            background-size: 100% 100%;
            width: 8rpx;
            height: 44rpx;
          }
          &::after {
            content: '';
            background: url('http://qnimg.zowoyoo.com/img/84826/1636083872621.png')
              no-repeat;
            background-size: 100% 100%;
            width: 8rpx;
            height: 44rpx;
          }
        }
      }
    }
  }
  .popup-content {
    position: relative;
  }
  .popup-title {
    width: 100%;
    position: absolute;
    top: 0;
    padding: 20rpx 32rpx;
    font-weight: 600;
    font-size: 32rpx;
    border-bottom: 2rpx solid #f6f6f6;
    background-color: #fff;
  }
  .z-detail-info-address {
    padding: 12rpx 32rpx 0;
    .fw {
      font-weight: 700;
    }
    .info-address {
      display: flex;
      justify-content: space-between;
      color: #999;
      .info-address-left {
        flex: 1;
        .info-viewname-title {
          color: #f47f02;
          padding-left: 20rpx;
          padding: 0 20 * 2rpx 0 10 * 2rpx;
        }
        .info-address-main {
          display: flex;
          align-items: center;
          padding: 0 20 * 2rpx 0 10 * 2rpx;
          font-size: 12 * 2rpx;
        }
      }
      .info-address-right {
        display: flex;
        .cell {
          width: 50rpx;
          flex: 1;
          box-sizing: content-box;
          color: #a0a0a0;
          display: flex;
          flex-direction: column;
          flex-shrink: 0;
          align-items: center;
          justify-content: space-between;
          font-size: 20rpx;
        }
        .info-address-map {
          i {
            width: 50rpx;
            height: 50rpx;
            background: url('http://qnimg.zowoyoo.com/img/84826/1625553706592.png')
              no-repeat center;
            background-size: contain;
          }
        }
        .info-address-phone {
          margin-left: 20rpx;
          padding-left: 20rpx;
          border-left: 2rpx solid #f6f6f6;
          i {
            width: 50rpx;
            height: 50rpx;
            background: url('http://qnimg.zowoyoo.com/img/84826/1627033431262.png')
              no-repeat center;
            background-size: contain;
          }
        }
      }
    }
  }
  .z-detail-info-address-another {
    margin: 0 32rpx;
    .another-title {
      display: flex;
      justify-content: space-between;
      align-content: center;
      margin: 20rpx 0;
      .another-title-left {
        font-weight: 700;
        font-size: 30rpx;
      }
      .another-title-right {
        color: #999;
        font-size: 24rpx;
      }
    }
    .another-end {
      font-weight: 700;
      font-size: 28rpx;
    }
  }
  .integral-box {
    .title {
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 32rpx;
      font-weight: 500;
      color: #000000;
      padding: 57rpx 0 61rpx;
      i {
        color: #f47f02;
      }
    }
    .integral-main {
      padding: 0 32rpx;
      .integral-num {
        color: #333;
        font-size: 26rpx;
        font-weight: 400;
        padding-bottom: 30rpx;
        border-bottom: 1rpx solid #f0f0f0;
        text {
          color: #f47f02;
        }
      }
      .integral-rule {
        padding: 36rpx 0 50rpx;
        view {
          font-size: 24rpx;
          font-weight: 400;
          color: #333333;
        }
      }
    }
    .integral-btn {
      height: 194rpx;
      color: #999999;
      text-align: center;
      line-height: 194rpx;
    }
  }
  .progress-bar {
    width: 144rpx;
    position: relative;
    overflow: hidden;
    text-align: center;
    .text {
      font-size: 24rpx;
      color: rgba(102, 102, 102, 0.5);
    }
    .width {
      position: absolute;
      left: 0;
      bottom: 0;
      height: 8rpx;
      border-radius: 8rpx;
      background-color: rgb(251, 96, 70);
    }
    .bg {
      width: 100%;
      height: 8rpx;
      box-sizing: border-box;
      border-radius: 8rpx;
      background-color: rgb(255, 236, 223);
    }
  }
}
</style>
