<template>
  <div class="detail-content">
    <div class="content">
      <div class="title">{{ title }}</div>
      <div
        ref="contentRef"
        class="rich-cont"
      >
        <slot></slot>
      </div>
      <div
        class="flex-center expend sticky"
        v-if="
          (type === 'list' && currentLength > maxLength) ||
          currentHeight > maxHeight
        "
      >
        <span
          class="btn flex-align"
          @click="expendMore"
        >
          {{ !isExpend ? btnText : '收起' }}
          <u-icon
            class="arrow"
            :name="isExpend ? 'arrow-up' : 'arrow-down'"
          />
        </span>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, onUnmounted, nextTick, useSlots } from 'vue'

interface Props {
  type?: string // 'list'代表是数组，根据长度计算，不传默认为富文本内容
  title?: string
  content?: string
  maxHeight?: number // 高度数组长度二选一
  maxLength?: number // 选长度的话，就用插槽自己写数组布局,这里会根据长度控制显隐
  btnText?: string
}

const props = withDefaults(defineProps<Props>(), {
  type: '',
  title: '',
  content: '',
  maxHeight: 300,
  maxLength: 3,
  btnText: '展开更多'
})
const slots = useSlots()
const isExpend = ref(false)
const currentHeight = ref(0)
const currentLength = ref(0)
const maxH = ref(Number(props.maxHeight))
const timer = ref<number | null>(null)
const contentRef = ref<HTMLElement | null>(null)

const initHeight = () => {
  if (!contentRef.value) return

  contentRef.value.style.height =
    props.type === 'list' ? `${maxH.value}px` : `${props.maxHeight}px`
  contentRef.value.style.overflow = 'hidden'
}

const expendMore = () => {
  isExpend.value = !isExpend.value
  if (!contentRef.value) return

  if (isExpend.value) {
    if (props.type === 'list') {
      calHeight()
      return
    }
    contentRef.value.style.height = 'auto'
    contentRef.value.style.overflow = 'visible'
  } else {
    initHeight()
  }
}

// list下重新计算高度
const calHeight = () => {
  if (!contentRef.value) return

  const slotContent = slots.default?.()
  if (!slotContent) return

  currentHeight.value = slotContent.reduce((total, vnode) => {
    if (vnode.el) {
      total += (vnode.el as HTMLElement).offsetHeight
    }
    return total
  }, 0)

  contentRef.value.style.height = `${currentHeight.value}px`
  contentRef.value.style.overflow = 'visible'
}

onMounted(() => {
  nextTick(() => {
    initHeight()
  })
})

onUnmounted(() => {
  if (timer.value) {
    clearTimeout(timer.value)
  }
})
</script>

<style scoped lang="scss">
.detail-content {
  height: 100%;
  background-color: #fff;
}
.content {
  max-width: 100%;
  padding: 0 30rpx 20rpx 30rpx;
  line-height: 40rpx;
  .title {
    margin-bottom: 20rpx;
    font-family: PingFangSC-Medium, sans-serif;
    font-weight: bold;
    padding: 20rpx 0;
    font-size: 32rpx;
    height: 60rpx;
    color: #222;
    border-bottom: 2rpx solid #e5e5e5;
    display: flex;
    align-items: center;
  }
  .btn {
    font-size: 28rpx;
    color: #666;
    border: 2rpx solid #d8d8d9;
    border-radius: 24rpx;
    padding: 10rpx 40rpx;
  }
  .expend {
    width: 100%;
    padding: 40rpx 0;
    text-align: center;
    background-image: linear-gradient(
      -180deg,
      rgba(255, 255, 255, 0) 0%,
      #fff 70%
    );
    &.show-more {
      padding-top: 0;
      background: none;
    }
  }
  .sticky {
    position: sticky;
    bottom: 100rpx;
  }
  .rich-cont {
    width: 100%;
    word-break: break-all;
    // #ifdef H5
    img,
    // #endif
    image {
      width: 100% !important;
    }
  }
}
</style>

<style lang="scss">
.rich-cont {
  width: 100%;
  max-width: 100%;
  word-break: break-all;
  white-space: pre-wrap;
  // #ifdef H5
  img,
  // #endif
  image {
    max-width: 100% !important;
    height: auto !important;
    -webkit-touch-callout: none;
  }
}
</style>
