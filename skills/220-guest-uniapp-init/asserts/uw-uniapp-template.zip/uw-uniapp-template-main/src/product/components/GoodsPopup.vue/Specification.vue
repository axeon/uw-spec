<template>
  <div class="specification">
    <div
      :class="{
        'specification-main': true,
        'specification-show': show
      }"
    >
      <i
        class="specification-cancel"
        @click.stop="setShow(false)"
      ></i>
      <div class="specification-top">
        <img
          class="specification-top-img"
          mode="aspectFill"
          :src="img"
        />
        <div class="specification-top-info">
          <p
            class="price"
            v-if="userType === 0"
          >
            <u>{{ currency }}</u>
            <span v-if="inventory.salePrice">{{ inventory.salePrice }}</span>
            <span v-else>
              {{ minPrice }}
              <span style="font-size: 10px">起</span>
            </span>
          </p>
          <p
            class="price"
            v-else
          >
            <u>{{ currency }}</u>
            <span v-if="inventory.price">{{ inventory.price }}</span>
            <span v-else>
              {{ minMerchPrice }}
              <span style="font-size: 10px">起</span>
            </span>
          </p>
          <p
            class="num"
            v-if="inventory.salePrice"
          >
            库存&nbsp;{{ inventory.num }}
          </p>
          <p class="active-name">{{ activeTitie || '请选择' }}</p>
        </div>
      </div>
      <scroll-view
        scroll-y
        class="specification-content"
      >
        <div class="specification-body">
          <div
            v-for="(item, index) in packageList"
            class="body-item"
            :key="item.packageId"
          >
            <p class="specification-body-title">{{ item.packageName }}</p>
            <div class="specification-body-options">
              <div
                v-for="(option, j) in item.specList"
                :key="j"
                :class="{
                  'body-option': true,
                  'option-active':
                    activeJSON[index] && activeJSON[index].spec
                      ? activeJSON[index].spec === option
                      : false,
                  'no-stash': renderNoStash(option)
                }"
                @click="clickOption(option, item.packageId, index)"
              >
                {{ option }}
              </div>
            </div>
          </div>
        </div>
      </scroll-view>
      <div
        @click="clickBtn"
        :class="{
          'specification-buy-btn': true,
          'no-buy': !btnState.value
        }"
      >
        {{ btnState.value ? btnText : activeTitie ? '无库存' : '请选择' }}
      </div>
    </div>
    <div :class="{ overlay: show }"></div>
  </div>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'
import { useUserStore } from '@/store/user'

const props = withDefaults(
  defineProps<{
    btnText: string
    modelValue: boolean
    img: string
    packageList: any[]
    priceList: any[]
  }>(),
  {
    btnText: '立即预订',
    modelValue: false,
    img: '',
    packageList: () => [],
    priceList: () => []
  }
)
const emit = defineEmits(['update:modelValue', 'clickBuy'])

const userStore = useUserStore()

const activeJSON = ref<any[]>([]) // 用户选中的数据
const specNameList = ref<string[][]>([]) // 总规格处理数据

const show = computed({
  get: () => props.modelValue,
  set: (newValue: boolean) => {
    emit('update:modelValue', newValue)
  }
})

const currency = computed(() => userStore.currencyCN)
const userType = computed(() => 0)

const minPrice = computed(() => {
  const arr = [...props.priceList]
  const minArr = arr.sort((x, y) => {
    return x.salePrice - y.salePrice
  })
  return minArr.length ? minArr[0].salePrice : 0
})

const minMerchPrice = computed(() => {
  const arr = [...props.priceList]
  const minArr = arr.sort((x, y) => {
    return x.price - y.price
  })
  return minArr.length ? minArr[0].price : 0
})

// 用户选中的规格参数文字展示
const activeTitie = computed(() => {
  let info = ''
  activeJSON.value.forEach((item, index) => {
    if (item && item.spec) {
      info += item.spec
      if (activeJSON.value.length - 1 > index) {
        info += '/'
      }
    } else {
      info += ` {请选择${props.packageList[index].packageName}} `
      if (activeJSON.value.length - 1 > index) {
        info += '/'
      }
    }
  })
  return info
})
// // 匹配出用户所选中规格的信息 (包括库存 价格 组合ID)
const inventory = computed(() => {
  let obj: any = {}
  let activeStr = ''
  for (let i = 0, leng = activeJSON.value.length; i < leng; i++) {
    const activeItem = activeJSON.value[i]
    if (!activeItem || !activeItem.spec) {
      activeStr = ''
      break
    } else {
      activeStr += activeItem.spec + '/'
    }
  }

  const priceArr = props.priceList.map((item) => {
    let str = ''
    for (const key in item.specName) {
      str += item.specName[key] + '/'
    }
    return str
  })

  const num = priceArr.indexOf(activeStr)
  if (num !== -1) {
    obj = props.priceList[num]
    return obj
  }

  const str = activeStr
  let reverseArr = str.split('/').reverse()
  reverseArr = reverseArr.filter((e) => e.trim() !== '')
  reverseArr = [reverseArr.join('/')]

  const res = priceArr.indexOf(`${reverseArr}/`)
  if (res !== -1) {
    obj = props.priceList[res]
  }

  return obj
})

// 按钮状态 是否可点击
const btnState = computed(() => {
  return inventory.value?.num || 0
})

const setShow = (val: boolean) => {
  show.value = val
}

const mapStash = () => {
  if (specNameList.value.length === 0) {
    props.priceList.forEach((e) => {
      if (e.num <= 0) {
        specNameList.value.push(Object.values(e.specName))
      }
    })
  }
}

const clickOption = (option: string, packageId: number, index: number) => {
  mapStash()
  if (renderNoStash(option)) return
  if (activeJSON.value[index] && activeJSON.value[index].spec === option) {
    activeJSON.value.splice(index, 1, {}) // use splice to trigger reactivity correctly
    return
  }

  const newActiveJson = [...activeJSON.value]
  newActiveJson[index] = { packageId, spec: option }
  activeJSON.value = newActiveJson
}

const clickBtn = () => {
  if (!btnState.value) {
    uni.showToast({
      title: '请先选择规格',
      icon: 'none',
      duration: 2500,
      mask: true
    })
    return
  }

  const info: any = {
    ...inventory.value,
    spec: ''
  }

  if (!inventory.value?.specName) return

  const packageIdList = Object.keys(inventory.value.specName)
  packageIdList.forEach((item: any, index) => {
    for (let i = 0, leng = props.packageList.length; i < leng; i++) {
      const element = props.packageList[i]
      if (Number(item) === element.packageId) {
        info.spec += `${element.packageName}:${
          inventory.value.specName[Number(item)]
        }`
        if (packageIdList.length - 1 > index) {
          info.spec += ' | '
        }
      }
    }
  })

  setShow(false)
  emit('clickBuy', info)
}

const renderNoStash = (option: string): boolean => {
  let smallArr = activeTitie.value
    ? activeTitie.value.replace(/\{.*?\}/g, '').split('/')
    : []
  smallArr = smallArr.filter((e) => e.replace(/\s*/g, ''))
  return !!specNameList.value.find((arr) =>
    equalArr(arr, [...smallArr, option])
  )
}
// 计算相同数组/或包含 的方法，在此规格逻辑某种特殊情况也相同，例如：[1,3,2] === [1,2,3] ->true  [1.2.3] === [1,2,3,4] -> true
const equalArr = (arr1: string[], arr2: string[]): boolean => {
  if (arr1.length !== arr2.length) {
    if (arr1.length < arr2.length) {
      const res = arr1.every((item) => arr2.includes(item))
      return res
    } else {
      return false
    }
  }

  if (JSON.stringify(arr1) === JSON.stringify(arr2)) {
    return true
  } else {
    const arr2Copy = [...arr2] // Create a copy to avoid modifying the original
    arr1.forEach((e1) => {
      const i = arr2Copy.indexOf(e1)
      if (i > -1) {
        arr2Copy.splice(i, 1)
      }
    })
    return arr2Copy.length === 0
  }
}
</script>

<style lang="scss" scoped>
.fade-enter-active,
.fade-leave-active {
  transition: background-color 0.3s;
}
.fade-enter,
.fade-leave-to {
  background-color: rgba(0, 0, 0, 0) !important;
}
.specification {
  .overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 998;
    background-color: rgba(0, 0, 0, 0.6);
  }
  .specification-main {
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 999;
    transform: translateY(100%);
    transition: transform 0.3s;
    width: 100%;
    max-width: 750rpx;
    // max-height: 85%;
    // min-height: 30%;
    height: 85%;
    background-color: #fff;
    border-radius: 40rpx 40rpx 0px 0px;
    padding: 50rpx 32rpx 0px;
    box-sizing: border-box;
    &.specification-show {
      transform: translateY(0);
    }
    .specification-content {
      position: relative;
      // max-height: 1000rpx;
      padding-top: 50rpx;
      height: calc(100% - 50rpx - 186rpx - 100rpx);
    }
    .specification-cancel {
      position: absolute;
      top: 22rpx;
      right: 32rpx;
      width: 52rpx;
      height: 52rpx;
      background: url('http://qnimg.zowoyoo.com/img/84826/1640746223939.png')
        no-repeat center;
      background-size: contain;
    }
    .specification-top {
      display: flex;
      .specification-top-img {
        // width: 342rpx;
        height: 186rpx;
        width: 186rpx;
        // object-fit: cover;
        // width: 30%;
        margin-right: 32rpx;
      }
      .specification-top-info {
        width: 70%;
        .price {
          color: #f47f02;
          margin-bottom: 24rpx;
          u {
            font-size: 24rpx;
            text-decoration: none;
            margin-right: 8rpx;
            display: inline-block;
          }
          span {
            font-size: 40rpx;
          }
        }
        .num {
          font-size: 24rpx;
          font-weight: 500;
          color: #cccccc;
          margin-bottom: 24rpx;
        }
        .active-name {
          font-size: 28rpx;
          font-weight: 500;
          color: #000000;
        }
      }
    }
    .specification-body {
      // padding-bottom: 92rpx;
      .body-item {
        margin-bottom: 52rpx;
        border-bottom: 2rpx solid #f0f0f3;
        &:nth-last-child(1) {
          border-bottom: none;
          // padding-bottom: 240rpx;
        }
        .specification-body-title {
          font-size: 36rpx;
          font-weight: 500;
          color: #000000;
          padding-bottom: 40rpx;
        }
        .specification-body-options {
          display: flex;
          flex-wrap: wrap;
          .body-option {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 140rpx;
            max-height: 80rpx;
            min-height: 64rpx;
            // line-height: 70rpx;
            font-size: 28rpx;
            font-weight: 500;
            color: #2f2e31;
            background: #f0edf1;
            border-radius: 10rpx;
            padding: 0 16rpx;
            margin-right: 24rpx;
            margin-bottom: 30rpx;
            box-sizing: border-box;
            border: 1rpx solid #f0edf1;
            &.option-active {
              color: #f47f02;
              background: #ffffff;
              border: 1rpx solid #f47f02;
            }
          }
          .no-stash {
            opacity: 0.4;
          }
        }
      }
    }
    .specification-buy-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 32rpx;
      font-weight: 500;
      color: #ffffff;
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100vw;
      max-width: 750rpx;
      height: 100rpx;
      background: linear-gradient(90deg, #ffa000, #eb5a14);
      &.no-buy {
        background: #ccc;
      }
    }
  }
}
</style>
