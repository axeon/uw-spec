<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { onLoad, onPageScroll } from '@dcloudio/uni-app'
import ZUp from '@/components/ZUp/index.vue'

import ZScenicInfo from '@/components/ZScenicInfo/index.vue'
import ZViewList from './components/ZViewList/index.vue'
// import ZParseHtml from '@/components/ZParseHtml/index.vue'
import GbLoading from '@/components/GbLoading/index.vue'

import ZDetailSwiper from './productDetail/components/ZDetailSwiper/index.vue'
import { navToUrl, parseTime } from '@/utils/tool'
import {
  // guestProductInfoList,
  guestProductInfoPriceList,
  guestPoiInfoLoad,
  type ProductInfo
} from '@/api/saasMallAppGuestApi'

const detail = {
  services: [
    { name: '2', value: '停车场' },
    { name: '4', value: '健身中心' },
    { name: '6', value: '游泳池' },
    { name: '10', value: '商务中心' }
  ],
  address: '环市东路367号环市东路367号环市东路367号',
  phone: '020-83333998',
  phone1: '020-83333998,123456789、020-83333998，123456789 123456789',
  longitude: 113.2786,
  latitude: 23.13618
}
const collapseList = [
  {
    infoId: 7584609,
    infoTitle: ' 行政房 双床 无早',
    salePrice: 400.0,
    marketPrice: 999.0,
    treeId: 5,
    infoTitleDesc: '行政房 双床 无早',
    signImg: 'http://qnimg.zowoyoo.com/img/15463/1583230528318.jpg',
    startDay: 0,
    startTime: 1440,
    currentTime: 1592472067798,
    isReserve: 1,
    orderStartDate: null,
    orderEndDate: null,
    validityType: '0',
    validityCon: '',
    isSellOut: 1,
    bedtype: '大床',
    notaddbed: 0,
    internet: '免费',
    orderPolicy: '可当天预订，要求必须1440分钟内完成在线支付。',
    roomNumDesc: '>5间',
    hotelPlans: [
      {
        planId: '',
        planName: '标准价',
        orderPolicy: '可当天预订，要求必须1440分钟内完成在线支付。',
        salePrice: 400.0,
        startDay: 0
      }
    ],
    isJoint: 1,
    joint: null
  },
  {
    infoId: 7613111,
    infoTitle: '  商务行政套房 双床 含双早',
    salePrice: 401.0,
    marketPrice: 999.0,
    treeId: 5,
    infoTitleDesc: '商务行政套房 双床 含双早',
    signImg: 'http://qnimg.zowoyoo.com/img/15463/1583230528318.jpg',
    startDay: 0,
    startTime: 1440,
    currentTime: 1592472067821,
    isReserve: 0,
    orderStartDate: null,
    orderEndDate: null,
    validityType: '0',
    validityCon: '',
    isSellOut: 0,
    bedtype: '',
    notaddbed: 0,
    internet: '免费',
    orderPolicy:
      '可当天预订，下单后需人工确认才有效，要求必须1440分钟内完成在线支付。',
    roomNumDesc: '>5间',
    hotelPlans: [
      {
        planId: '',
        planName: '标准价',
        orderPolicy:
          '可当天预订，下单后需人工确认才有效，要求必须1440分钟内完成在线支付。',
        salePrice: 401.0,
        startDay: 0
      }
    ],
    isJoint: 0,
    joint: null
  },
  {
    infoId: 7873666,
    infoTitle: ' 豪华至尊大床房 无早',
    salePrice: 402.0,
    marketPrice: 999.0,
    treeId: 5,
    infoTitleDesc: '豪华至尊大床房 无早',
    signImg: 'http://qnimg.zowoyoo.com/img/84826/1468313251732.jpg',
    startDay: 0,
    startTime: 1440,
    currentTime: 1592472067830,
    isReserve: 0,
    orderStartDate: null,
    orderEndDate: null,
    validityType: '0',
    validityCon: '2016-04-07,2016-11-30',
    isSellOut: 0,
    bedtype: '双床',
    notaddbed: 0,
    internet: '免费',
    orderPolicy:
      '可当天预订，下单后需人工确认才有效，要求必须1440分钟内完成在线支付。',
    roomNumDesc: '>5间',
    hotelPlans: [
      {
        planId: '',
        planName: '标准价',
        orderPolicy:
          '可当天预订，下单后需人工确认才有效，要求必须1440分钟内完成在线支付。',
        salePrice: 402.0,
        startDay: 0
      },
      {
        planId: '8345950',
        planName: '提前一天',
        orderPolicy: '不含早，连住晚数：不限，预订间数： 不限。',
        salePrice: 292.0,
        startDay: 0
      }
    ],
    isJoint: 0,
    joint: null
  },
  {
    infoId: 24377961,
    infoTitle: ' 单人房',
    salePrice: 888.0,
    marketPrice: 0.0,
    treeId: 5,
    infoTitleDesc: '单人房',
    signImg: 'http://qnimg.zowoyoo.com/img/15463/1583230528318.jpg',
    startDay: 0,
    startTime: 1440,
    currentTime: 1592472067846,
    isReserve: 0,
    orderStartDate: null,
    orderEndDate: null,
    validityType: '0',
    validityCon: '',
    isSellOut: 0,
    bedtype: '单人床',
    notaddbed: 1,
    internet: '免费',
    orderPolicy:
      '可当天预订，下单后需人工确认才有效，要求必须1440分钟内完成在线支付。',
    roomNumDesc: '>5间',
    hotelPlans: [
      {
        planId: '',
        planName: '标准价',
        orderPolicy:
          '可当天预订，下单后需人工确认才有效，要求必须1440分钟内完成在线支付。',
        salePrice: 888.0,
        startDay: 0
      }
    ],
    isJoint: 0,
    joint: null
  },
  {
    infoId: 24377962,
    infoTitle: ' 商务套房',
    salePrice: 999.0,
    marketPrice: 0.0,
    treeId: 5,
    infoTitleDesc: '商务套房',
    signImg: 'http://qnimg.zowoyoo.com/img/15463/1583230528318.jpg',
    startDay: 0,
    startTime: 1440,
    currentTime: 1592472067855,
    isReserve: 0,
    orderStartDate: null,
    orderEndDate: null,
    validityType: '0',
    validityCon: '',
    isSellOut: 0,
    bedtype: '大/双床',
    notaddbed: 1,
    internet: '免费',
    orderPolicy: '可当天预订，要求必须1440分钟内完成在线支付。',
    roomNumDesc: '>5间',
    hotelPlans: [
      {
        planId: '',
        planName: '标准价',
        orderPolicy: '可当天预订，要求必须1440分钟内完成在线支付。',
        salePrice: 999.0,
        startDay: 0
      }
    ],
    isJoint: 0,
    joint: null
  },
  {
    infoId: 24377963,
    infoTitle: ' 大床房',
    salePrice: 1099.0,
    marketPrice: 0.0,
    treeId: 5,
    infoTitleDesc: '大床房',
    signImg: 'http://qnimg.zowoyoo.com/img/15463/1583230528318.jpg',
    startDay: 0,
    startTime: 1440,
    currentTime: 1592472067864,
    isReserve: 0,
    orderStartDate: null,
    orderEndDate: null,
    validityType: '0',
    validityCon: '',
    isSellOut: 0,
    bedtype: '大床',
    notaddbed: 1,
    internet: '免费',
    orderPolicy: '可当天预订，要求必须1440分钟内完成在线支付。',
    roomNumDesc: '>5间',
    hotelPlans: [
      {
        planId: '',
        planName: '标准价',
        orderPolicy: '可当天预订，要求必须1440分钟内完成在线支付。',
        salePrice: 1099.0,
        startDay: 0
      }
    ],
    isJoint: 0,
    joint: null
  },
  {
    infoId: 24377964,
    infoTitle: ' 豪华大床',
    salePrice: 1199.0,
    marketPrice: 0.0,
    treeId: 5,
    infoTitleDesc: '豪华大床',
    signImg: 'http://qnimg.zowoyoo.com/img/15463/1583230528318.jpg',
    startDay: 0,
    startTime: 1440,
    currentTime: 1592472067874,
    isReserve: 0,
    orderStartDate: null,
    orderEndDate: null,
    validityType: '0',
    validityCon: '',
    isSellOut: 0,
    bedtype: '大床',
    notaddbed: 1,
    internet: '免费',
    orderPolicy: '可当天预订，要求必须1440分钟内完成在线支付。',
    roomNumDesc: '>5间',
    hotelPlans: [
      {
        planId: '',
        planName: '标准价',
        orderPolicy: '可当天预订，要求必须1440分钟内完成在线支付。',
        salePrice: 1199.0,
        startDay: 0
      }
    ],
    isJoint: 0,
    joint: null
  }
]
const showLoading = ref(true) // 是否显示加载

const showTimePicker = ref(false)
const state = reactive({
  id: NaN,
  scrollTop: 0
})
const detailData = ref<ProductInfo>({})

const imgList = ref<string[]>([])

const dataParams = ref({
  startDate: parseTime(new Date().getTime() + 24 * 3600 * 1000, '{y}-{m}-{d}'),
  endDate: parseTime(new Date().getTime() + 24 * 3600 * 1000 * 2, '{y}-{m}-{d}')
})

// function handleClickCalander() {
//   showTimePicker.value = true
// }
// function handleGroup(item: any) {
//   uni.showToast({
//     title: '拼团产品ID：' + item,
//     icon: 'none'
//   })
// }
function handleClickMap(item: any) {
  uni.showToast({
    title: 'handleClickMap' + item,
    icon: 'none'
  })
}
// const content = ref(
//   '<p><img src="https://v3.b2b2c.rageframe.com/attachment/images/2023/06/20/image_1687243756_vPMCP8n3.jpg" style=""/></p><p><img src="https://v3.b2b2c.rageframe.com/attachment/images/2023/06/20/image_1687243757_Y1MK6EED.jpg" style=""/></p><p><img src="https://v3.b2b2c.rageframe.com/attachment/images/2023/06/20/image_1687243757_UXSIBR9r.jpg" style=""/></p><p><br/></p>'
// )

const timePickerConfirm = async (dateList: Array<string>) => {
  dataParams.value.startDate = dateList[0]
  dataParams.value.endDate = dateList[dateList.length - 1]
  const res = await guestProductInfoPriceList({
    productId: detailData.value.id,
    priceDateRange: ['2024-12-01 00:00:00', '2024-12-20 00:00:00']
  })

  if (res.state === 'success') {
    showTimePicker.value = false
  }
}
const handleLoad = async (id: number) => {
  showLoading.value = true
  const res = await guestPoiInfoLoad({ poiId: id })
  if (res.state === 'success' && res.data) {
    detailData.value = res.data
    imgList.value = [res.data.imgMain as string]
  }
  showLoading.value = false
  // const res1 = await guestProductInfoList({ poiId: id })
  // if (res.state === 'success' && res.data) {
  //   console.log('res.data', res.data)

  //   detailData.value = res.data
  //   imgList.value = [res.data.imgMain as string]
  // }
}
const handleClick = () => {
  navToUrl(
    `/packages/product/productDetail/index?productData=${JSON.stringify(
      detailData.value
    )}`
  )
  // navToUrl(
  //   `/packages/order/placeOrder/index?productData=${JSON.stringify(
  //     detailData.value
  //   )}`
  // )
}

onLoad((options: any) => {
  const { id } = options
  state.id = id || NaN
  if (state.id) {
    handleLoad(state.id)
  }
})
// 滚动页面
onPageScroll((e) => {
  state.scrollTop = e.scrollTop
})
</script>

<template>
  <GbLoading v-model="showLoading" />
  <view
    class="product-page"
    v-if="!showLoading"
  >
    <ZDetailSwiper :covers="imgList" />
    <ZScenicInfo
      :address="detail.address"
      :phone="detail.phone1"
      :latitude="detail.latitude"
      :longitude="detail.longitude"
      @click-map="handleClickMap"
    />

    <ZViewList
      class="mt10"
      :num="5"
      :show-price="true"
      :data-list="collapseList"
      title="住宿(18)"
      title-type="colours"
      postfix="起"
      @click="handleClick"
    />
    <!-- <view class="parse flex-center m-t-100"></view> -->
    <!-- <ZParseHtml :content="content" /> -->
    <!-- 酒店日历弹出框 -->
    <up-calendar
      :show="showTimePicker"
      mode="range"
      color="#f47f02"
      @close="showTimePicker = false"
      @confirm="timePickerConfirm"
    ></up-calendar>
    <ZUp :scrollTop="state.scrollTop" />
  </view>
</template>

<style lang="scss" scoped>
.product-page {
  width: 100vw;
  overflow: hidden;
  box-sizing: border-box;
  background-color: #f7f7f7;
  // padding-bottom: calc(env(safe-area-inset-bottom) / 2 + 100rpx);

  &__box {
    position: relative;
    border-radius: 10rpx;
    background-color: #ffffff;
  }
}
</style>
