<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { onLoad, onPageScroll, onReachBottom } from '@dcloudio/uni-app'
import ZUp from '@/components/ZUp/index.vue'
import GbLoading from '@/components/GbLoading/index.vue'
import ZProductList from '@/product/components/ZProductList/index.vue'
import {
  guestProductInfoList,
  type ProductInfo,
  type GuestProductInfoQueryParam
} from '@/api/saasMallAppGuestApi'
import { navToUrl } from '@/utils/tool'

const showLoading = ref(true) // 是否显示加载

const state = reactive({
  scrollTop: 0
})
const productParams = reactive<GuestProductInfoQueryParam>({
  $pg: 1,
  $rn: 10,
  $rt: 2,
  $sn: ['id'],
  $st: [2],
  state: 1
})
const productList = ref<ProductInfo[]>([])
const productTotal = ref(0)
// 获取产品列表
const getGuestProductInfoList = async () => {
  showLoading.value = true
  try {
    const res = await guestProductInfoList(productParams)
    showLoading.value = false
    productTotal.value = res.data?.sizeAll || 0
    if (res.state === 'success' && res.data?.results?.length) {
      if (productParams.$pg === 1) {
        productList.value = res.data.results
      } else {
        productList.value = [...productList.value, ...res.data.results]
      }
    } else if (res.state === 'success' && !res.data?.results) {
      console.log('noMore')
    }
  } catch (error) {
    showLoading.value = false
    console.log('error', error)
  }
}

// 点击产品
const handleClick = (item: ProductInfo) => {
  console.log('handleClick', item)
  navToUrl(`/product/productDetail/index?id=${item.id}`)
}

onLoad(() => {
  getGuestProductInfoList()
})
// 滚动页面
onPageScroll((e) => {
  state.scrollTop = e.scrollTop
})

onReachBottom(() => {
  console.log('触底了')
  if (productParams.$pg) {
    productParams.$pg++
    getGuestProductInfoList()
  }
})
</script>

<template>
  <GbLoading v-model="showLoading" />
  <view
    class="product-page"
    v-if="!showLoading"
  >
    <ZProductList
      :data="productList"
      @click="handleClick"
    />
    <ZUp :scrollTop="state.scrollTop" />
  </view>
</template>

<style lang="scss" scoped>
.product-page {
  box-sizing: border-box;
  background-color: #f7f7f7;
  // padding-bottom: calc(env(safe-area-inset-bottom) / 2 + 100rpx);
}
</style>
