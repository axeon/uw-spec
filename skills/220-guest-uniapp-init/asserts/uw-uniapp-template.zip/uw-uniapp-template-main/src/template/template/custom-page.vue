<template>
  <TemplateView
    v-if="pageId"
    :project="project"
    :is-custom-page="true"
    :pageId="pageId"
  ></TemplateView>
</template>

<script lang="ts" setup>
import { ref, computed, onMounted } from 'vue'
import { onLoad, onPageScroll } from '@dcloudio/uni-app'
import TemplateView from '../components/template.vue'
import { useMainStore } from '@/store/main'

const mainStore = useMainStore()

const pageId = ref('')

const project = computed(() => mainStore.customProject)

const page = computed(() => {
  return project.value?.siteConfig?.pages?.find((p: any) => p.home)
})

onLoad((options: any) => {
  if (options.pageId) {
    pageId.value = options.pageId as string
  }
})

onPageScroll((e) => {
  // 发送滚动位置给子组件
  uni.$emit('onPageScroll', e.scrollTop)
})

onMounted(() => {
  // 设置页面标题
  // #ifdef H5
  if (page.value) {
    document.title = page.value.name
  }
  // #endif
})
</script>
