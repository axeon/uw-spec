<template>
  <view class="activity">
    <NavBar
      :border="false"
      :statusBar="navStatusBar"
      navType="search"
      searchType="jump"
      searchPlaceholder="请输入关键字"
    />

    <view class="goods-box flex">
      <view class="goods-list">
        <scroll-view :scroll-y="true">
          <view
            class="goods-li"
            :class="{ active: index == currentIndex }"
            v-for="(tab, index) in beans"
            :key="index"
            @click="changeTab(index)"
          >
            <view
              class="selected"
              :class="{ 'primary-color-bg': index === currentIndex }"
            ></view>
            {{ tab.name }}
          </view>
        </scroll-view>
      </view>
      <view class="goods-grid">
        <scroll-view
          class="goods-content"
          :scroll-y="true"
        >
          <view
            class="goods-item-box flexWrap"
            v-if="true"
          >
            <view
              class="goods-items"
              v-for="(item, index) in beans[currentIndex].child"
              :key="index"
            >
              <img
                class="goods-item-img"
                :src="item.image_url"
                lazy-load
                alt=""
                mode="aspectFill"
              />
              <view class="goods-item-name">{{ item.name }}</view>
            </view>
          </view>
        </scroll-view>
      </view>
    </view>

    <ZUp :scrollTop="scrollTop" />

    <tab-bar
      :project="project"
      :active="tab && tab.jump && tab.jump.id"
    ></tab-bar>
  </view>
</template>
<script lang="ts" setup>
import { ref, computed } from 'vue'
import { useMainStore } from '@/store/main'
import { onLoad, onPageScroll } from '@dcloudio/uni-app'
import ZUp from '@/components/ZUp/index.vue'
import TabBar from '../components/TabBar/index.vue'
import NavBar from '@/components/NavBar/index.vue'

const mainStore = useMainStore()

const scrollTop = ref(0)
const currentIndex = ref(0)

const project = computed(() => mainStore.customProject)
const tab = computed(() => {
  return project.value?.siteConfig?.config?.navigation?.list?.find(
    (item: any) => item.jump.id === 'category'
  )
})

// nav导航栏配置
const navStatusBar = computed(() => {
  let flag = true
  // #ifdef MP-TOUTIAO
  flag = false
  // #endif
  return flag
})

const beans = ref([
  {
    id: 13,
    parent_id: 0,
    name: '女装',
    sort: 90,
    image_id: 'fd1e6aaf5667deab131a31552b8c3b6b',
    image_url:
      'https://qyb.jihainet.com/static/uploads/images/2021/02/20/17450a2f60047123927d1c684bf7e7a9.png',
    child: [
      {
        id: 35,
        parent_id: 13,
        name: '时尚套装',
        sort: 100,
        image_id: '5a7adbceeee96f1583ba64652a7518f1',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614567844603c59a477eaa.jpg',
        child: []
      },
      {
        id: 30,
        parent_id: 13,
        name: '吊带/背心',
        sort: 100,
        image_id: 'cb89f0c25c52219b9afe877e26d62609',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614568050603c5a7259b2a.jpg',
        child: []
      },
      {
        id: 29,
        parent_id: 13,
        name: 'T恤',
        sort: 100,
        image_id: '5f215e97cef148aa2a82a85bfe66d1f2',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614568117603c5ab5d9bb3.jpg',
        child: []
      },
      {
        id: 17,
        parent_id: 13,
        name: '衬衫',
        sort: 100,
        image_id: '9d062281b5c9f7b1e451f35aa51473d3',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/02/20/d1db83a7c389fdffd9cdc4c1cf955feb.png',
        child: []
      },
      {
        id: 31,
        parent_id: 13,
        name: '旗袍',
        sort: 140,
        image_id: '2367d35c73ada1fdc0d4bdf8d2b41a58',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614568559603c5c6f43475.jpg',
        child: []
      },
      {
        id: 33,
        parent_id: 13,
        name: '婚纱',
        sort: 140,
        image_id: 'c395b5f472b77b6e095ca3dcec435fb7',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614568351603c5b9f86091.jpg',
        child: []
      },
      {
        id: 34,
        parent_id: 13,
        name: '汉服',
        sort: 140,
        image_id: 'acf345bda92f1472a52b17143cdd5acf',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614568287603c5b5f6a7a4.jpg',
        child: []
      },
      {
        id: 32,
        parent_id: 13,
        name: '礼服',
        sort: 140,
        image_id: '54bae5c5c9c947fd1ea2dbc9690af3b1',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614568456603c5c0861e98.jpg',
        child: []
      },
      {
        id: 15,
        parent_id: 13,
        name: '连衣裙',
        sort: 200,
        image_id: '613f8c01cbbc18ca155397dd339f3f9e',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614568696603c5cf888f4b.jpg',
        child: []
      },
      {
        id: 14,
        parent_id: 13,
        name: '休闲裤',
        sort: 200,
        image_id: 'd9ffadb97943412ada6446382dfd5552',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614568634603c5cba2b9df.jpg',
        child: []
      },
      {
        id: 28,
        parent_id: 13,
        name: '半身裙',
        sort: 200,
        image_id: '792fefcaaeead5a22035b4aa8189d4f8',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614568814603c5d6ee9452.jpg',
        child: []
      },
      {
        id: 16,
        parent_id: 13,
        name: '打底裤',
        sort: 200,
        image_id: '311373e279290036df9ae758119517f1',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614568778603c5d4a1b16d.jpg',
        child: []
      }
    ]
  },
  {
    id: 18,
    parent_id: 0,
    name: '男装',
    sort: 91,
    image_id: '4638b4ff4309ddd6f035e332d404f794',
    image_url:
      'https://qyb.jihainet.com/static/uploads/images/2021/02/20/b2e6451d7c17970212eab1b6726bcd17.png',
    child: [
      {
        id: 36,
        parent_id: 18,
        name: '衬衫',
        sort: 80,
        image_id: '93322fe4ec999e747af52cf759aaef31',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614568966603c5e0635b0c.jpg',
        child: []
      },
      {
        id: 41,
        parent_id: 18,
        name: 'POLO衫',
        sort: 81,
        image_id: '99af8b12ca797a6ad1c34a0be5e4409a',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614569065603c5e694e531.jpg',
        child: []
      },
      {
        id: 39,
        parent_id: 18,
        name: '羊毛衫',
        sort: 82,
        image_id: '50ba92f90459f65c84d85411a0fac27a',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614569135603c5eaf042f2.jpg',
        child: []
      },
      {
        id: 37,
        parent_id: 18,
        name: '夹克',
        sort: 83,
        image_id: '77c8fef21ba49d58e8dad3f1100bf235',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614569201603c5ef186909.jpg',
        child: []
      },
      {
        id: 21,
        parent_id: 18,
        name: '大衣/风衣',
        sort: 84,
        image_id: '2d36a466cb7c4b46cd6d7c9361ac3905',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614569253603c5f252d057.jpg',
        child: []
      },
      {
        id: 38,
        parent_id: 18,
        name: '长裤',
        sort: 100,
        image_id: '2c94902c8c154b1d54b18f09d6fba3ed',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614569545603c604985f6c.jpg',
        child: []
      },
      {
        id: 20,
        parent_id: 18,
        name: '西服',
        sort: 100,
        image_id: '07b294cba54d61592343e6294c6b05e0',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614569461603c5ff5035b1.jpg',
        child: []
      },
      {
        id: 19,
        parent_id: 18,
        name: '唐装/中山装',
        sort: 100,
        image_id: 'ba3a4674909ed7f5b4f769e0a7fa9dc6',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614569395603c5fb3e5d27.jpg',
        child: []
      },
      {
        id: 40,
        parent_id: 18,
        name: '短裤',
        sort: 100,
        image_id: 'f57dbe6cd120eb189115757973298e33',
        image_url:
          'https://qyb.jihainet.com/static/uploads/images/2021/03/01/1614569310603c5f5e14b5c.jpg',
        child: []
      }
    ]
  },
  {
    id: 20,
    parent_id: 0,
    name: '生活用品',
    sort: 90,
    image_id: 'fd1e6aaf5667deab131a31552b8c3b6b',
    image_url:
      'https://qyb.jihainet.com/static/uploads/images/2021/02/20/17450a2f60047123927d1c684bf7e7a9.png',
    child: []
  }
])

const changeTab = (index: number) => {
  console.log(index)
  currentIndex.value = index
}

onLoad(() => {
  uni.setNavigationBarTitle({
    title: '动态列表'
  })
})

onPageScroll((e: any) => {
  onPageScroll(e)
})
</script>

<style lang="scss" scoped>
.activity {
  height: calc(100% - 50px);
  .goods-box {
    height: 100%;
    overflow: hidden;
  }
  .goods-list {
    overflow: auto;
    height: 100%;
    width: 160rpx;
    background-color: #f8f8f8;
    .goods-li {
      font-size: 24rpx;
      color: #666;
      height: 100rpx;
      line-height: 100rpx;
      text-align: center;
      position: relative;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      &.active {
        background-color: #fff;
      }
    }
    .selected {
      height: 56rpx;
      width: 8rpx;
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
    }
  }
  .goods-grid {
    height: 100%;
    overflow: auto;
    background-color: #fff;
    .goods-content {
      width: 590rpx;
      padding: 20rpx;
      box-sizing: border-box;
      .goods-item-box {
        .goods-items {
          width: 170rpx;
          margin-right: 20rpx;
          margin-bottom: 20rpx;
          &:nth-child(3n) {
            margin-right: 0;
          }
          .goods-item-img {
            width: 170rpx;
            height: 170rpx;
          }
          .goods-item-name {
            text-align: center;
            color: #666;
            font-size: 26rpx;
          }
        }
      }
    }
  }
}
</style>
