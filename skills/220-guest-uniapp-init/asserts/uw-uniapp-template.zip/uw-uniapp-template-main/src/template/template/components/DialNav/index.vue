<!-- 盒子布局 -->

<script lang="ts" setup>
import { onMounted } from 'vue'

const props = withDefaults(
  defineProps<{
    mode: number // 显示模式
    shadow?: boolean // 是否显示阴影
    nameSize?: number | string // 名称大小
    imgSize?: number | string // 图标大小
    marginTopLine?: number | string // 两行之间的距离（仅在8，10中）
    dataList: Array<any> // 数据数组
  }>(),
  {
    mode: 8,
    shadow: false,
    nameSize: '12px',
    imgSize: '30px',
    marginTopLine: 15,
    dataList: () => []
  }
)

const emits = defineEmits<{
  (e: 'click', item: any): void
}>()

const handleClick = (item: any) => {
  console.log('child-click')
  emits('click', item)
}

onMounted(() => {
  // console.log('动态 ---')
})
</script>

<template>
  <view
    class="slot"
    :class="{ shadow }"
  >
    <view class="nav-navigation">
      <!-- 此处插槽用于扩展是否显示标题等 -->
      <slot></slot>
      <view
        class="nav-list"
        v-if="mode == 8 || mode == 4"
      >
        <view
          class="nav-item"
          style="width: 25%"
          :style="[{ marginTop: index > 3 ? marginTopLine : '' }]"
          v-for="(item, index) in dataList"
          :key="index"
          @click="handleClick(item)"
        >
          <view class="list-img">
            <img
              :style="{ width: props.imgSize, height: props.imgSize }"
              :src="item.imgUrl"
              lazy-load
            />
          </view>
          <view
            class="list-text"
            :style="{ fontSize: nameSize }"
          >
            {{ item.name }}
          </view>
        </view>
      </view>
      <view
        class="nav-list"
        v-if="mode == 10"
      >
        <view
          class="nav-item"
          style="width: 20%"
          :style="[{ marginTop: index > 4 ? marginTopLine : '' }]"
          v-for="(item, index) in dataList"
          :key="index"
          @click="handleClick(item)"
        >
          <view class="list-img">
            <img
              :style="{
                width: props.imgSize,
                height: props.imgSize
              }"
              :src="item.imgUrl"
              lazy-load
            />
          </view>
          <view
            class="list-text"
            :style="{ fontSize: nameSize }"
          >
            {{ item.name }}
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<style lang="scss" scoped>
.slot {
  border-radius: 16px;
  background-color: #ffffff;
  overflow: hidden;
  &.shadow {
    box-shadow: 0px 2px 8px 0px rgba(27, 25, 86, 0.06);
  }
  .nav-navigation {
    width: 100%;

    .nav-list {
      display: flex;
      flex-wrap: wrap;
      justify-content: flex-start;
      padding-top: 14px;
      padding-bottom: 16px;

      .nav-item {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;

        .list-img {
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          margin-bottom: 8px;
        }

        .list-text {
          text-align: center;
          font-weight: 400;
          color: #171717;
        }
      }
    }
  }
}
</style>
