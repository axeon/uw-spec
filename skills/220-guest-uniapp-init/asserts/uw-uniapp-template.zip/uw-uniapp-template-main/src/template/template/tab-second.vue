<template>
  <TabIndex :location="2"></TabIndex>
</template>

<script lang="ts" setup>
// import { ref, computed } from 'vue'
// import { useMainStore } from '@/store/main'

import TabIndex from './tab-index.vue'

// const mainStore = useMainStore()

// const pageList = ref([])

// const project = computed(() => mainStore.customProject)
// const location = ref(0) // 假设 location 是一个需要从外部传入或在组件内设置的值

// const tab = computed(() => {
//   return project.value?.siteConfig?.config?.navigation?.list[location.value]
// })

// const page = computed(() => {
//   return project.value?.siteConfig?.pages?.find((p: any) => p.home)
// })
</script>

<style lang="scss" scoped></style>
