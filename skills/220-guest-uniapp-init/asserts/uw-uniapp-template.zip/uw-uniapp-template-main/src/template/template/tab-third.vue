<script lang="ts" setup>
import { ref, onMounted, computed } from 'vue'
import UserInfo from './components/UserInfo/index.vue'
import DialNav from './components/DialNav/index.vue'
import OperateTitle from './components/OperateTitle/index.vue'
import TabBar from '../components/TabBar/index.vue'
import { navToUrl } from '@/utils/tool'

import { useUserStore } from '@/store/user'
import { useMainStore } from '@/store/main'

const userStore = useUserStore()
const mainStore = useMainStore()

const project = computed(() => mainStore.customProject)
const tab = computed(() => {
  return project.value?.siteConfig?.config?.navigation?.list?.find(
    (item: any) => item.jump.id === 'my'
  )
})
// const state = reactive({
//   isShowPopup: true
// })
const imgUrl =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAC5pJREFUeF7tnHlwVeUVwH/nJiQRyWIVpIyC2cRClQrWBS2KVm1VLHVjGBesVccFLDCoM27TdqZOqwUdQbFF2xmwY9W6FKnWtqJ0rAsjoFVEyYaiInvey0Je3nv3dL77kvdI8pZ777uB4PSbyT/J+c453y/fds753hP2YVNVi/aG44nrOLCOBkYDlShliJYC5se0FlRaEMJAE/AJ2BspkPcZXL1OROx95bb0tyHd/vEIioouBvss4HSgIk+bzcAqsF6ls/NZGXrMl3nqy9q9XwCpNpUQti/G0iux+T5Q0E+DiGPxL2xZRpn1rEhlR9B2AgWk29YPoaT4BpC5qH4zaGez/6tlC+gCOiKPyrCxrUHZDgSQ6muFtI2cRVzvBA4NyjmfenZSIL/i4M8WikyO+dSR7JY3IA03nIatjyAcm68zgfZXPsCSm6Ss+o189PoGpKpFhBt+C8wEfOvJx3kXfRVYRFn1PBHpdCHfR8TXwLTj0yoi0aeBCX6M7oc+aygedJmUjGr0atszIG2uPxPhOaDcq7H9LB9CuUgqalZ68cMTIG2uuxSRZUCxFyMDSDaC6pVSUfuMW59cA9Jw/XUgi1HtrzuNW5/zkxOJg94oZTVL3ChyBciZOZb15AEPp5uIgWTb093MpJyAuvaclw7gZZVpokRQzsu1J2UF1HVarT0AN2Q3q8fIhCgeND7b6ZYRUNc9580D6Ch3C6W33BrKqidmuidlBhSqfwiY5dfqAdZvoZTX3JLO57SAnPBB9d8D+IYcNH9FZFK6sKQPICfwDB25dsDFVkEj6a3PxG7lm8f3DnD7AmptmENcF/jyZ+cX6IcrIfQVWBbiJURThdZdEI/mNh3phGaTbEw0E3AxdCScPg0Z9a3c/TNJFMhcGVL9wN5/7gHIyecUF2/ylbIwcP7zJGJZ/hyMtMOe1KCzKmlth7b2PiIOqB/NRGrG+/MBdhKJHLV3PqknoHD9PJT7/WjXVcuQlu1+uoIdg/DO7rmQW4eZPWYWpWlaPBi5eSFIziteejvCrVJWY7IUTktqcdKkLXaj30ygLr8fsXxEIV6WlrOeFHbsAtuZL+khXTQXqfx2btDpJES2UGpVdadvU4BCDZeDPuFPK+iK+d72nG5Dbc0Q9ZBKjkZhVyirm3r21chxk/wOxcybK6S8+k89Z1BL/d+xOde31hXe9nWtGAGHjICmtUhz38KEFhTBmDMS8DasQrqXTGsbtO3pX0AWr0hpzQ+SgBKlmcLP8qo+eACksRgy9bbEIKMR9MUHkPZdyUGrWUbnzkSGjXJ+p2/8Gdm0tmt57QY7e1ks/xlEnM7YSFNScpaYhhpngW1uzv6bW0CqaHsLcsldUFCYsLdrC/rSQwhxHDgTpyPVqZNI/7kE2VoHHREIteT0MQBAgHWLlFct7AJU/4I5IHNazibgBpD5z7c3Q6wTPfxo5OxrU7Pmi09g5WNQdSJy6qWp33/yFqx+LrHEdpn9KnehIhhA/FXKa6aKUw4ON5gzNr+KZy5AZi9pD4MmloczU8aehYx3lnrid59+iIxKnT66tQleeQSxxPXscfTkvUk77jRTVn2oaFv9BGK8m9fsMZ0zAbLjiQtgNJICgQVjJoFVgBx3tnPrTtd049vQHoKGNcjmJojHXbkZECAo5ATRcMM1qD7uyrKXJWbARNogYk6cnncW/d4MZNRY9yajnegjtyAxd5UbveBGZPR33evPJCn6UwPo16jenrc2M4PMsjGD6NyT8W5jROT82fCNEZ5M6qJZiAGeo6nZ5y6Z5/+iuLd+kd8YQM+jOjWX4Zx/f+qermWU+Yab3GvKh0PlBDB3HdNMYDv6pNQS/OyjxNIyS1EsqF+HfPx2TheMgB2NItNuDwrQCwbQe6h5r5Nne6LrXuNSjbNJmx/TVJEZ81OA/nIvmHtR2CzRiJecAPE9HViX3xEUoPdFQ/XmgdJRLseVWcwDIB0+Gpl8NRS4i930o7fg5SU5QRnodmsb1ox7ggEEm0TD9dtRDttXgJw96OK7YXD3YzJ3lnXxHMRZdpmbWV66J4J1dUCAhB0GUAcaQKXUyww69lxknHlw5q7pji9h6T1I1x0qU6+4idHi8SABRURDdVGQrju/O4fTSnkBZKaR2aC7N2mxkMvuTu1BLz8O20xoCMRj0Lw1JxyNxbHbE0FsYDMIjZk9yKTxvM33dIQ8AOrR3cRmeyLI9alQUJf9EtlmEpvuW/fsCRYQLQbQFmC4e1cySPoBZOKqllY0GkOunw+lhzjKdfFsxIQlLpsdi6HtqZxScDOIrwwgUzk93qUvmcW8ADJJL7McOlI3YzVJ97Gnwhcbkbo1rt1JnFztqStDoEuMdeYetALV8117lEFQl87LrsJceTo7YU8EDCCXRbfETSlzflltQeM980PW9Fvzq24kRyJ/M5v0AyCz8wXktb9u3wzPzEeyVDK0chwy5QYYtL+eI+mDouHGa1Hb1VsZrxByyeubLyBvLc8sdtUvYOiRudT039/Fuk60bdN4YjH3iz5Ad/S915BXzYO1vk1FkDlLErHY/mqFhRNMwqyAcMPufI96Xfpzd8MYMxE54ZyEbGcH+vt5iCka9mp6zMnI+dcnf6tP3QeR9sR+U1Ka9V2tTJ6GHD7SnT+ZpVooqz6kO+VqHkj9MC+N869x1V1LhiA3PphMkumXDfD8g0hHIpXhbMpHjEYump3ce3TTeuTZ+fQ+zjMZDOiYf1nKa87rAtRwE+jDrkaYScglIAfCKVORiRemNMWi6IZ3oKMVho3qeQKpjbk46uf1aIZqam+XAgFkHqGXVi9OAGqvO4KofJpIwPhsXgAZE1N/hlTnzrLoi49ir3sdeh3l2bwMAJDNIB0lg2s/T1VWm+tfRTjTJx7wACi5lE6egpxyoZOb7tNam7Ff+gO63l2ibO/+eQNSVkpFjRNN71V6brwC7PRHigtqOv+anPmadGq06CAYcwqUD4XCosTGvXkjuuHdHol+Fy4kRfIGhHWllFc5ZfgUoLq6Yg63mnw/XlhwHaLuqg69B2vCBY3HnZjMTd0rFyxr5gJk6BG5xNL/3Txe2GpXSm2tU4bp+fylue4ORH7lR7O9/Hfw31VOllAKrMQpZe4yvZR1p1qd5HrcxqQp3JZzXPl12AgKZprgwOfzF9U7paL23m5bPQHtrCujUBrAR4axLYy95E5099ae40g6anLQroboX6iwCGvGXcjIY/zq2EFMq+XQ2mQqoe8TvFDDHOeTe36agbTyKfTj1dCaPT3qR33GPkUHIZVjkDOnIcPzSa/LXCnP8gTPOV10fREtxe+h5PHYL9Dh7xtlwgZKI98RGdujOpn+GXBL0+nY8ddcZiT2zQD614piFUyW0spVvc38/yF5goi3h+SJpea8WVyN6sD6LGrQM0nkA0qtEzN9pDz7h1lCDbWg7wCJZPHXr+0GOUnKq+syDS3nZUGb685BZAUw6GvGJ4rqBVJR+49s48oJyFluiRewS/MKZgcWXRvkqu6XrHkDciAlUrOP5vXQc2BAiiPWDVJW9Zgbd1zNoG5FGm6cguqToAe7UT7wZKQNkelSVvWiW988AUost8YTwTYGhrk1MkDktoE1RcqrVnvxxzMgB1JzXTWWPI8OsK+jyHwUfYCtP5aKWhNnemq+ACXvSa16H7Y9sL+awrIWMURu8/vVOb4BJfellsZJzuY90GI3E1uZzbi0ynxy0nfLG1BiNq0vIlxyM+gdvlIlvt1P23EHyL2UdTzcO/D0YyYQQMnZZPJJgwpmgs70m5n0Mwinj8kEIouIxhftnc/xra+rY6CAkqCcr85pugy1f4JwRj9eMG2U1xHrj5RVPu33K3CyQewXQHsbTJSUrAtBLwBOy7eC63xDHrwBsoJB9nJTmsl3luxXQD1gmTJ3qH4cVsEEUJOQOxrVEYgMR23zyq2kS74DsVpQ/QoR82GyjSAbsONrKK95X5wvKNk37X/8B54zpeIlzQAAAABJRU5ErkJggg=='

// 订单导航配置
const orderNavOps = ref([
  {
    name: '待付款',
    imgUrl,
    url: '/pages-mall/pages/order/list?tabIndex=1'
  },
  {
    name: '待发货',
    imgUrl,
    url: '/pages-mall/pages/order/list?tabIndex=2'
  },
  {
    name: '待收货',
    imgUrl,
    url: '/pages-mall/pages/order/list?tabIndex=3'
  },
  {
    name: '退款售后',
    imgUrl,
    url: '/pages-mall/pages/order/list?tabIndex=5'
  }
])

// 其他导航配置
const otherNavOps = ref([
  // {
  //   name: '关于我们',
  //   imgUrl,
  //   url: ''
  // },
  {
    name: '地址管理',
    imgUrl,
    url: '/packages/setting/addressManage'
  },
  {
    name: '我的优惠券',
    imgUrl,
    url: '/packages/coupon/discounts'
  },
  {
    name: '领券中心',
    imgUrl,
    url: '/packages/coupon/center'
  },
  // {
  //   name: '我的收藏',
  //   imgUrl,
  //   url: '/pages-mine/pages/collection'
  // },
  { name: '设置', imgUrl, url: '/packages/setting/index' }
])

const moreClick = () => {
  navToUrl('/template/template/tab-second')
}

onMounted(() => {
  console.log('user-page ---')
  console.log(userStore.loginInfo)
  console.log(userStore.userInfo)
})
</script>

<template>
  <view class="user-page">
    <view class="page">
      <!-- 用户 -->
      <UserInfo></UserInfo>
      <!-- 我的订单 -->
      <view class="order-nav">
        <DialNav
          :mode="4"
          shadow
          :dataList="orderNavOps"
        >
          <OperateTitle
            padding="14px 14px 0 14px"
            isShowMore
            title="我的订单"
            moreLabel="全部订单"
            @clickMore="moreClick"
          ></OperateTitle>
        </DialNav>
      </view>
      <!-- 其他功能 -->
      <view class="other-nav">
        <DialNav
          marginTopLine="10px"
          :mode="8"
          shadow
          :dataList="otherNavOps"
          @click="(item) => navToUrl(item.url)"
        >
          <OperateTitle
            padding="14px 14px 0 14px"
            title="我的社区"
          ></OperateTitle>
        </DialNav>
      </view>
    </view>
    <tab-bar
      :project="project"
      :active="tab?.jump?.id"
    ></tab-bar>
  </view>
</template>

<style lang="scss" scoped>
.user-page {
  // padding-bottom: 100px;
  .user-count,
  .order-nav,
  .other-nav {
    position: relative;
    z-index: 9;
    padding: 0 14px 14px 14px;
  }
}
</style>
