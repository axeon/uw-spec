<template>
  <TemplateView :project="project"></TemplateView>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import TemplateView from '../components/template.vue'
import { onPageScroll } from '@dcloudio/uni-app'
import { useMainStore } from '@/store/main'

const project = computed(() => {
  return useMainStore().customProject
})

onPageScroll((e) => {
  // 发送滚动位置给子组件
  uni.$emit('onPageScroll', e.scrollTop)
})
</script>
