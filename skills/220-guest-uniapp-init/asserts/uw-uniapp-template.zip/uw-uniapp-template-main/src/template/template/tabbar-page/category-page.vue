<template>
  <view class="wrap">
    <!-- 左边分组列表 -->
    <view class="wrap-left">
      <view class="group">
        <view
          v-for="(group, index) in groups"
          :key="index"
          class="group-item"
          :class="[getItemClass(index)]"
          @click="chooseGroup(index)"
        >
          <text>{{ group.name }}</text>
        </view>
      </view>
    </view>

    <!-- 右边容器 -->
    <view class="wrap-right">
      <view class="list">
        <view v-if="activeGroup">
          <!-- 分类列表 -->
          <view v-if="activeGroup.child.length">
            <view class="pl5 pr5">
              <!-- <img
                v-if="isAdvertising"
                class="w-100 mt5"
                :src="item.iamge"
                lazy-load
              /> -->
              <view class="mt15 f14">{{ activeGroup.name }}</view>
            </view>
            <view
              v-for="(type, index) in activeGroup.child"
              :key="index"
              class="list-item"
              @click="toList(type)"
            >
              <img
                class="w70 h70 mb10"
                radius="5"
                :src="type.image"
                lazy-load
              />
              <view class="f13">{{ type.name }}</view>
            </view>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { ref, computed, onMounted } from 'vue'
import { useMainStore } from '@/store/main'

interface Group {
  name: string
  child: Type[]
}

interface Type {
  name: string
  image: string
}

const store = useMainStore()

const active = ref<string>('0')
const activeGroup = ref<Group | null>(null)

const project = computed<any>(() => store.customProject)
// const isAdvertising = computed<boolean>(
//   () => project.value?.categoryTpl?.advertising || false
// )
const groups = computed<Group[]>(() => project.value?.config?.goodsGroups || [])

// 获取商品类型数据
const getData = () => {
  if (groups.value.length > 0) {
    activeGroup.value = groups.value[0]
  }
}

// 选择分组
const chooseGroup = (index: number) => {
  active.value = String(index)
  activeGroup.value = groups.value[index]
}

// 菜单tab高亮样式
const getItemClass = (index: number) => {
  if (active.value === String(index)) return 'group-item-active'
  return ''
}

// 跳转商品列表
const toList = (type: Type) => {
  if (!type) return
  console.log('todo: 跳转商品列表')
}

onMounted(() => {
  getData()
})
</script>

<style lang="scss" scoped>
.wrap {
  // #ifdef H5
  height: calc(100vh - 94px);
  // #endif

  // #ifdef MP
  height: calc(100vh - 50px);
  // #endif
  background: #fff;

  .wrap-left {
    display: inline-block;
    position: relative;
    width: 100px;
    height: 100%; //高度根据需求自行设定
    background: #fafafa;

    .group {
      position: absolute;
      left: 0;
      top: 0;
      right: 0;
      bottom: 0; //left,top,right,bottom都为0，充满真个页面
      overflow-y: auto;
      overflow-x: hidden; //设置Y轴出现滚动条，X轴隐藏

      // 隐藏滚动条
      &::-webkit-scrollbar {
        display: none;
        /* Chrome Safari */
      }

      .group-item {
        padding: 15px 0;
        font-size: 14px;
        text-align: center;
      }

      .group-item-active {
        position: relative;
        color: #c7655a;
        background: #fff;

        &::after {
          content: '';
          position: absolute;
          top: 10px;
          left: 0;
          width: 3px;
          height: 24px;
          background: #c7655a;
        }
      }
    }
  }

  .wrap-right {
    display: inline-block;
    position: relative;
    width: calc(100% - 100px);
    height: 100%; //高度根据需求自行设定

    .list {
      position: absolute;
      left: 0;
      top: 0;
      right: 0;
      bottom: 0; //left,top,right,bottom都为0，充满真个页面
      padding: 6px;
      overflow-y: auto;
      overflow-x: hidden; //设置Y轴出现滚动条，X轴隐藏

      // 隐藏滚动条
      &::-webkit-scrollbar {
        display: none;
        /* Chrome Safari */
      }

      .list-item {
        display: inline-flex;
        flex-direction: column;
        align-items: center;
        width: 33.3%;
        margin-top: 15px;
        color: #828282;
      }
    }
  }
}
</style>
