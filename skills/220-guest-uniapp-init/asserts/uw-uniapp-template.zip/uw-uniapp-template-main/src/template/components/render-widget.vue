<script lang="ts" setup>
import { ref, computed, watch } from 'vue'
import request from '@/api/request'
import { jump } from '@/utils/global'
// import RouteMap from '@/util/RouteMap'
import { navToUrl } from '@/utils/tool'
// import config from '@/config/common'
// import { useUserStore } from '@/store/user'

// const userStore = useUserStore()

const props = defineProps({
  item: {
    type: Object,
    default: () => ({})
  }
})

let list = ref<Record<string, any>[]>([])
let listField = ref({})
let page = ref(0)

// 判断是否广告
const isCustomAdvert = computed(() => {
  return props.item?.options?.isCustomAdvert
})

let currentRequestTask: any = null
const preRequest = (params: any) => {
  let newParams = { ...params, page: page.value }
  uni.showLoading({
    title: '加载中...'
  })

  request({
    url: isCustomAdvert.value ? props.item.url?.advertUrl : props.item.url?.url,
    method: 'GET',
    params: newParams
  })
    .then((res: any) => {
      if (res.state === 'success') {
        if (res.data?.results) {
          list.value = res.data.results
        } else {
          list.value = res.data
        }
        uni.hideLoading()
      }
    })
    .finally(() => {
      // 请求完成后，无论成功还是失败，清除当前请求任务标识
      currentRequestTask = null
    })
}

watch(
  () => props.item,
  (newVal) => {
    // 如果有正在进行的请求，先取消
    if (currentRequestTask) {
      currentRequestTask.abort()
    }

    // 字段替换
    if (newVal?.listField) {
      listField.value = newVal.listField
    }

    // 接口参数
    let params = newVal.params || {}

    // 接口
    if (newVal.url?.url) {
      preRequest(params)
      // uni.showLoading({
      //   title: '加载中...'
      // })
      // request({
      //   url:
      //     config.baseUrl +
      //     (isCustomAdvert.value
      //       ? props.item.url?.advertUrl
      //       : props.item.url?.url),
      //   method: 'POST',
      //   params
      // }).then((res: any) => {
      //   if (res.statusCode === 200) {
      //     if (res.data.data?.results) {
      //       list.value = res.data.data.results
      //     } else {
      //       list.value = res.data.data
      //     }
      //     uni.hideLoading()
      //   }
      // })
    }
  },
  {
    immediate: true
  }
)

const handleJump = (cb?: any, type?: string) => {
  console.log('点击图片', cb)
  if (type === 'productdDetail') {
    // 组件未实现，先写死
    navToUrl(`/packages/product/index?id=${cb.id}`)
  }
  if (type === 'viewDetail') {
    // 组件未实现，先写死
    navToUrl('/packages/view/viewDetail/index?id=58')
  }
  // 自定义跳转
  if (type === 'img' || type === 'cap-cube') {
    jump(cb)
  }
  if (cb.type === 'custom') {
    jump(cb)
  }
}
const moreClick = () => {
  // console.log('moreClick', cb, b, c)
}
// 正在抢购点击跟多
const clickPanicBuying = () => {
  uni.navigateTo({
    url: '/product/shoppingrush/index'
  })
}
//
const handleChangeSecond = () => {
  if (props.item?.params) {
    //   console.log(isCustomAdvert.value)
    //   let params = isCustomAdvert.value
    //     ? {
    //         ...props.item.options.params,
    //         parentCustId:
    //           useUser().userInfo?.parentCustId || useUser().parentCustId
    //       }
    //     : { ...props.item?.params, sort: item.key }
    //   request(params)
  }
}
// 正在抢购换一批
const handlerExchange = () => {
  // page.value++
  // let params = isCustomAdvert.value
  //   ? {
  //       ...props.item.options.params,
  //       parentCustId: useUser().userInfo?.parentCustId || useUser().parentCustId
  //     }
  //   : props.item?.params || {}
  // request(params)
}

const more = () => {
  console.log('more')
}
</script>

<template>
  <view class="render">
    <m-swiper
      v-if="item.component == 'm-swiper'"
      :key="item.id"
      :attrs="item.attrs"
      :styles="item.styles"
      :list="list"
      :pathKey="item.listField.pathKey"
      :imgKey="item.listField.imgKey"
      @jump="(e:any) => handleJump(e)"
    ></m-swiper>

    <m-swiper
      v-if="item.component == 'm-swiper-top'"
      :key="item.id"
      :attrs="item.attrs"
      :styles="item.styles"
      :list="list"
      :pathKey="item.listField.pathKey"
      :imgKey="item.listField.imgKey"
      @jump="(e:any) => handleJump(e, 'productdDetail')"
    ></m-swiper>

    <m-grid-nav
      v-if="item.component == 'm-grid-nav'"
      :key="item.id"
      :data="item"
      :attrs="item.attrs"
      :styles="item.styles"
      :list="list"
      :listField="
        isCustomAdvert ? item.listField.adverts : item.listField.common
      "
      @jump="(e:any) => handleJump(e)"
    ></m-grid-nav>

    <m-count-down
      v-if="item.component == 'm-count-down'"
      :key="item.id"
      :attrs="item.attrs"
      :styles="item.styles"
    ></m-count-down>

    <m-title
      v-if="item.component == 'm-title'"
      :key="item.id"
      :data="item"
      @jump="(e:any) => handleJump(e, 'title')"
    ></m-title>

    <m-img
      v-if="item.component == 'm-img'"
      :key="item.id"
      :styles="item.styles"
      :attrs="item.attrs"
      @jump="(e:any) => handleJump(e, 'img')"
    ></m-img>

    <m-product-list
      v-if="item.component == 'm-product-list'"
      :key="item.id"
      :data="item"
      :listField="listField"
      :list="list"
      @jump="(e:any) => handleJump(e,'productdDetail')"
    ></m-product-list>

    <m-product-list
      v-if="item.component == 'view-list'"
      :key="item.id"
      :data="item"
      :listField="listField"
      :list="list"
      @jump="(e:any) => handleJump(e,'viewDetail')"
    ></m-product-list>

    <m-progress
      v-if="item.component == 'm-progress'"
      :key="item.id"
    ></m-progress>

    <m-empty-divider
      v-if="item.component == 'm-empty-divider'"
      :key="item.id"
      :styles="item.styles"
    ></m-empty-divider>

    <m-cap-cube
      v-if="item.component == 'm-cap-cube'"
      :key="item.id"
      :styles="item.styles"
      :attrs="item.attrs"
      @jump="(e:any) => handleJump(e, 'cap-cube')"
    ></m-cap-cube>

    <m-slide-card
      v-if="item.component == 'm-slide-card'"
      :key="item.id"
      :styles="item.styles"
      :type="item.attrs.typeStyle"
      :listField="listField"
      :list="list"
      @jump="() => handleJump()"
    ></m-slide-card>
    <m-img
      v-if="item.component == 'm-advert'"
      :key="item.id"
      :styles="item.styles"
      :attrs="{
        imagePath:
          list &&
          list[item.attrs.typeStyle] &&
          list[item.attrs.typeStyle].advLogo,
        jumpPath: {
          type: 'link',
          id:
            list &&
            list[item.attrs.typeStyle] &&
            list[item.attrs.typeStyle].advLink
        }
      }"
      @jump="(e:any) => handleJump(e, 'img')"
    ></m-img>

    <m-product
      :key="item.id"
      v-if="item.component == 'hot-sell'"
      type="slide"
      :item="item"
      :list="list"
      :listField="listField"
      @moreClick="moreClick()"
      @jump="() => handleJump()"
    ></m-product>

    <m-product
      :key="item.id"
      v-if="item.component == 'panic-buy'"
      type="product"
      :isExchange="true"
      :item="item"
      :list="list"
      :listField="listField"
      @moreClick="moreClick"
      @second-more-click="clickPanicBuying"
      @jump="() => handleJump()"
      @exchange="handlerExchange"
    ></m-product>

    <m-product
      :key="item.id"
      v-if="item.component == 'choose-carefully'"
      type="product"
      :item="item"
      :list="list"
      :listField="listField"
      @change="handleChangeSecond"
      @moreClick="moreClick()"
      @jump="() => handleJump()"
    ></m-product>

    <m-product
      :key="item.id"
      v-if="item.component == 'hot-views'"
      type="slide"
      :item="item"
      :list="list"
      :listField="listField"
      @more="more"
    ></m-product>

    <m-product
      :key="item.id"
      v-if="item.component == 'hot-hotels'"
      type="product"
      :item="item"
      :list="list"
      :listField="listField"
    ></m-product>

    <m-product
      :key="item.id"
      v-if="item.component == 'hot-lines'"
      type="product"
      :item="item"
      :list="list"
      :listField="listField"
    ></m-product>

    <m-product
      :key="item.id"
      v-if="item.component == 'latest-news'"
      type="product"
      :item="item"
      :list="list"
      :listField="listField"
    ></m-product>
    <m-notice-bar
      v-if="item.component == 'm-notice-bar'"
      :id="'widget' + item.id"
      :key="item.id"
      :attrs="item.attrs"
      :styles="item.styles"
      @jump="(e:any) => handleJump(e,'MnoticeBar')"
    ></m-notice-bar>
  </view>
</template>

<style lang="scss">
.panic-buying-box {
  line-height: 32rpx;
  .exchange {
    display: flex;
    justify-content: center;
    padding: 0 0 30rpx 0;
    background-color: #f6f6f6;
    .icon {
      width: 24rpx;
      height: 28rpx;
      margin-right: 12rpx;
    }
    text {
      color: #666666;
      font-size: 28rpx;
    }
  }
}
</style>
