<template>
  <view
    v-if="page"
    :style="renderBox"
    ref="scroll"
    id="myElement"
    class="page-template"
  >
    <TopBar
      v-if="showNavtop"
      :title="page.name"
      :isTop="false"
      :shadow="true"
    ></TopBar>
    <MSearch
      v-if="page.showTopSearch"
      ref="MSearchRef"
      :isCustomPage="isCustomPage"
    ></MSearch>
    <view
      v-for="item in page.componentList"
      :key="item.id"
    >
      <render
        :item="item"
        :component-msg="componentMsgList"
      ></render>
    </view>
    <!-- <ZUp :scrollTop="scrollTop" /> -->

    <tab-bar
      v-if="isShowBottomBar === 'custom' && !isCustomPage"
      :project="project"
    ></tab-bar>
    <!-- <ZTabbar
      v-if="isShowBottomBar === 'default'"
      name="home"
    /> -->
  </view>
</template>

<script lang="ts" setup>
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import render from '@/components/render-widget.vue'
import { useMainStore, type ProjectInfo } from '@/store/main'
// import { useUserStore } from '@/store/user'
import TabBar from './TabBar/index.vue'
import MSearch from '@/schema/m-search/m-search.vue'
import TopBar from './TabBar/top-bar.vue'
// import ZTabbar from '@/components/ZTabbar'
// import ZUp from '@/components/ZUp'
import {
  guestSiteCmsListInfo,
  type SiteCmsInfo
} from '@/api/saasMallAppGuestApi'

const props = withDefaults(
  defineProps<{
    project: ProjectInfo
    pageId?: string
    isCustomPage?: boolean
  }>(),
  { project: () => ({}), isCustomPage: false, pageId: '' }
)

const mainStore = useMainStore()

const scrollTop = ref(0)

const page = computed(() => {
  const { project, pageId } = props
  const cleanPageId = pageId?.split('?')[0] // 处理可能存在的URL参数
  return project?.siteConfig?.pages?.find((page: any) =>
    cleanPageId ? page.id === cleanPageId : page.home
  )
})

const isShowBottomBar = computed(() => {
  return page.value?.isShowTabbar
})
const showNavtop = computed(() => {
  // eslint-disable-next-line init-declarations
  let res
  res = page.value?.showMpTopNav && !page.value?.showTopSearch
  // #ifdef MP-XHS
  res = props.isCustomPage && page.value?.showMpTopNav
  // #endif
  return res
})
const renderBox = computed(() => {
  let style = ''
  // #ifdef MP-WEIXIN
  style = `position: relative;
      padding-top:${
        page.value?.showMpTopNav && !page.value?.showTopSearch
          ? '0'
          : mainStore.menuButtonInfo.top + mainStore.menuButtonInfo.height + 10
      }px;
        background-color: ${page.value?.backgroundColor};
        background-image: url(${page.value?.backgroundImage});
        background-repeat: no-repeat;
        background-position: ${page.value?.backgroundImagePostion} center;
        background-size: ${page.value?.backgroundImageSize};
        heigth-min: 100vh;
      `
  // #endif

  // #ifndef MP-WEIXIN
  style = `position: relative;padding-top: 0px;
      background-color: ${page.value?.backgroundColor};
        background-image: url(${page.value?.backgroundImage});
        background-repeat: no-repeat;
        background-position: ${page.value?.backgroundImagePostion} center;
        background-size: ${page.value?.backgroundImageSize};
        `
  // #endif
  return style
})

let componentMsgList = ref<SiteCmsInfo[]>([])
// 组件内容数据
const handleContentLoad = () => {
  console.log('page.value', page.value)

  // 过滤列表数据
  let catalogIds = [
    ...new Set(
      page.value.componentList
        .map((item: any) => item.options?.catalogId)
        .filter((id: any) => id !== 0 && id !== undefined && id !== null)
    )
  ]
  if (!catalogIds.length) return
  guestSiteCmsListInfo({
    // componentCode:
    catalogIds: catalogIds as any[]
  })
    .then((res) => {
      if (res.state === 'success') {
        console.log('获取组件内容成功:', res.data)
        componentMsgList.value = res.data || []
      } else {
        uni.showToast({ title: res.msg, icon: 'none', duration: 2000 })
      }
    })
    .catch((err) => {
      console.error('获取组件内容失败:', err)
    })
}

onMounted(() => {
  uni.$on('onPageScroll', (val: any) => {
    scrollTop.value = val
    // console.log("触发了", scrollTop);
    if (val > 150) {
      // this.$refs.MSearchRef && (this.$refs.MSearchRef.scrollFlex = true)
    } else {
      // this.$refs.MSearchRef && (this.$refs.MSearchRef.scrollFlex = false)
    }
  })
  handleContentLoad()
})

onBeforeUnmount(() => {
  uni.$off('onPageScroll')
})
</script>

<style lang="scss" scoped>
.page-template {
  min-height: 100vh;
  padding-bottom: constant(safe-area-inset-bottom); //兼容 IOS<11.2
  padding-bottom: env(safe-area-inset-bottom); //兼容 IOS>11.2
}
.page {
  max-width: 100vw;
  overflow: auto;
}

.home-top-bg {
  position: absolute;
  width: 100%;
  // top: -65px;
  height: 180px;
  filter: blur(10px);
  background-size: 110%;
  z-index: auto;
}
</style>
