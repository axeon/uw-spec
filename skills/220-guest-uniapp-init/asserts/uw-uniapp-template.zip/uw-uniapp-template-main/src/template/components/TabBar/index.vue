<template>
  <view>
    <view
      class="tabbar"
      :style="{
        height: 'calc(50px + env(safe-area-inset-bottom))',
        paddingBottom: 'env(safe-area-inset-bottom)',
        background: navigation && navigation.styles.background
      }"
    >
      <view
        v-for="(item, index) in tabList"
        :key="index"
        class="tabbar-item"
        :style="{
          color:
            item && item.jump && item.jump.id === active
              ? navigation.styles.activeColor || 'rgba(81, 151, 255, 1)'
              : navigation.styles.defaultColor
        }"
        @click="toTab(item)"
      >
        <i
          class="iconfont"
          :class="'icon-' + item.icon"
        />
        <view>{{ item.text }}</view>
      </view>
    </view>
    <view
      style="
        height: calc(50px + env(safe-area-inset-bottom));
        padding-bottom: env(safe-area-inset-bottom);
      "
    ></view>
  </view>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import { useMainStore } from '@/store/main'

import { jump } from '@/utils/global'

const props = defineProps({
  active: {
    type: String,
    default: '000000'
  },
  project: {
    type: Object,
    default: () => ({})
  }
})
const mainStore = useMainStore()

// 导航配置
const navigation = computed(
  () =>
    (mainStore.customProject.siteConfig &&
      mainStore.customProject.siteConfig.config?.navigation) ||
    {}
)

// 导航菜单列表
const tabList = computed(() => {
  return navigation.value?.list || []
})

// 切换tab
const toTab = (item: any) => {
  if (props.active === item.jump.id) return
  jump(item.jump)
}
</script>

<style lang="scss" scoped>
.tabbar {
  position: fixed;
  bottom: 0;
  left: 0;
  display: flex;
  flex-direction: row;
  align-items: center;
  width: 100%;
  height: 50px;
  z-index: 999;
  background-color: rgb(255, 255, 255);
  box-shadow: 0 -1px 8px rgba(0, 0, 0, 0.1);

  .tabbar-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex: 1;
    height: 100%;
    background-size: contain;
    font-size: 12px;
    color: #9b9b9b;

    .tabbar-item-icon {
      font-size: 26px;
      margin-bottom: 3px;
    }

    text {
      font-size: 10px;
    }
  }

  .tabbar-item-active {
    color: cornflowerblue !important;
  }
}
</style>
