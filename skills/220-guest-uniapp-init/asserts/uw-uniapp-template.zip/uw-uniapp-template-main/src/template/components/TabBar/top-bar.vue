<template>
  <view v-if="statusHeight">
    <view
      class="top-bar"
      :class="[shadow ? 'shadow' : '']"
      :style="[barBg]"
    >
      <!-- 状态栏 -->
      <view
        class="w-100"
        :style="{ height: `${navtop + 10}px` }"
      ></view>
      <view class="flex-column col-center">
        <uni-icons
          v-if="!page"
          type="left"
          size="24"
          class="back_icon"
          @click="back"
        ></uni-icons>
        <!-- <u-icon  v-if="!page" name="arrow-left" class="back_icon" size="24" @click="back"></u-icon> -->
        <view
          class="top-bar-content flex-center"
          :style="{
            color: isTop ? '#FFFFFF' : '#000000',
            height: `${navheight + statusHeight}px`
          }"
        >
          {{ title }}
        </view>
      </view>
    </view>

    <!-- 占位符 -->
    <view
      class="w-100"
      :style="{ height: `${navheight + navtop + statusHeight + 10}px` }"
    ></view>
  </view>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import { useMainStore } from '@/store/main'

const props = defineProps({
  title: {
    type: String,
    default: ''
  },
  placeholder: {
    type: Boolean,
    default: true
  },
  isTop: {
    type: Boolean,
    default: true
  },
  background: {
    type: String,
    default: ''
  },
  shadow: {
    type: Boolean,
    default: false
  }
})
const mainStore = useMainStore()
// console.log(mainStore.menuButtonInfo)

const statusHeight = computed(() => mainStore.statusHeight)
const navheight = computed(() => mainStore.menuButtonInfo.height)
const navtop = computed(() => mainStore.menuButtonInfo.top)
const barBg = computed(() => {
  let background = `url("https://qnimg.zowoyoo.com/img/84826/1658735606655.png") no-repeat center / 100% 100%`

  if (props.background) background = props.background

  if (!props.isTop) background = '#FFFFFF'

  return {
    background
  }
})
const page = computed(() => {
  const pages = getCurrentPages()
  return pages.length === 1
})

const back = () => {
  uni.navigateBack({
    delta: 1
  })
}
</script>

<style lang="scss" scoped>
.top-bar {
  position: fixed;
  top: 0;
  width: 100%;
  color: #ffffff;
  background: url('https://qnimg.zowoyoo.com/img/84826/1658735606655.png')
    no-repeat center / 100% 100%;
  z-index: 9999;
  font-size: 16px;
  letter-spacing: 2px;
  // font-weight: bold;

  .top-bar-content {
    width: 100%;
    // height: 44px;
  }
}

.shadow {
  box-shadow: 0 -1px 8px rgba(0, 0, 0, 0.1);
}

.back_icon {
  position: absolute;
  left: 8px;
}
</style>
