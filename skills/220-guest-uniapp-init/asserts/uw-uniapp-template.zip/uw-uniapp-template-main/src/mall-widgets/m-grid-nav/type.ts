export interface Styles {
  pageMargin: number // 左右外边距
  pagePadding: number // 左右内边距
  marginTop: number // 上外边距
  marginBottom: number // 下外边距
  paddingTop: number // 上内边距
  paddingBottom: number // 下内边距
  imgPadding: number // 单项间距
  radiusTop: number // 上圆角
  radiusBottom: number // 下圆角
  itemWidth: number // 单项宽度
  imgWidth: number // 图片宽度
  imgRadius: number // 图片圆角
  fontSize: number // 文本字体
  titleColor: string // 文本颜色
  cmpBackground: string // 组件背景
}
export interface Attrs {
  model: string // 模式选择
  type: string // 显示类型
  max: string // 一行显示数量
  dataList: Array<{
    img: string
    name: string
    url: string
  }>
}
export interface JumpType {
  id?: string
  type?: string
}
