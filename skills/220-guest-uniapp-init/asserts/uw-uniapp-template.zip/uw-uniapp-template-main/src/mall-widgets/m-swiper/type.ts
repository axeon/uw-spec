export interface JumpType {
  id?: string
  type?: string
}
export interface Attrs {
  isAutoplay?: boolean // 是否自动轮播
  autoplay?: number // 自动轮播速度
  circular?: boolean // 是否开启循环播放
  showBgImage?: boolean // 是否显示背景图片
  showHeaderAddress?: boolean // 是否显示头部地址
  dataList?: Record<string, string>[]
}
// 样式控制
export interface Styles {
  marginBottom: number //	下边距
  height: number //	轮播图高度
  width: number //	轮播图宽度
  padding: number //	轮播图内边距
  radius: number //	轮播图圆角
  vertical: boolean //	是否为纵向滚动
  indicatorDots: boolean // 是否显示面板指示点
  indicatorColor: string //	指示器颜色
  indicatorActiveColor: string //	指示器颜色
  backgroundColor: string //	背景颜色
  headerAddressHeight: number // 头部地址高度
  headerAddressPrimaryColor: string // 头部地址主色
}
