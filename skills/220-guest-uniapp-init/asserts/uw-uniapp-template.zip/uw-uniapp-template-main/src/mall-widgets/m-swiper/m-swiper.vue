<script lang="ts" setup>
// 轮播图
import { ref, computed, type StyleValue } from 'vue'
import type { JumpType, Attrs, Styles } from './type'
import mHeaderAddress from '../m-header-address/m-header-address.vue'

const props = withDefaults(
  defineProps<{
    attrs: Partial<Attrs>
    styles: Partial<Styles>
    imgKey: string
    pathKey: string
    list: Array<any>
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({}),
    imgKey: 'img',
    pathKey: 'advLink',
    list: () => []
  }
)
const emit = defineEmits<{
  jump: [item: JumpType]
}>()
const mergedAttrs = computed(() => ({
  isAutoplay: true, // 是否自动轮播
  autoplay: 3000, // 自动轮播速度
  circular: true, // 是否开启循环播放
  showBgImage: true, // 是否显示背景图片
  showHeaderAddress: false, // 是否显示头部地址
  dataList: [],
  ...props.attrs
}))
const mergedStyles = computed(() => ({
  height: 400, //	轮播图高度
  headerAddressHeight: 80, // 头部地址高度
  width: 750, //	轮播图宽度
  padding: 20, //	轮播图内边距
  radius: 20, //	轮播图圆角
  vertical: false, //	是否为纵向滚动
  indicatorDots: true, // 是否显示面板指示点
  indicatorColor: 'rgba(0, 0, 0, .3)', // 指示器颜色
  indicatorActiveColor: '#fff', // 指示器颜色
  backgroundColor: '', // 背景颜色
  headerAddressPrimaryColor: '',
  marginBottom: 0, // 下边距
  ...props.styles
}))

const advertsCurrent = ref(0)

const showBgImageNum = computed(() => {
  let num = 0
  // #ifdef MP-WEIXIN
  num = 0
  // #endif
  // #ifdef MP-XHS
  num = mergedAttrs.value.showBgImage ? 130 : 0
  // #endif
  return num
})
// 轮播图的虚化背景图
const bgImageUrl = computed(() => {
  let str = ''
  if (props.list && props.list[advertsCurrent.value]) {
    str = props.list[advertsCurrent.value][props.imgKey]
  } else if (mergedAttrs.value.dataList && mergedAttrs.value.dataList.length) {
    str = mergedAttrs.value.dataList[advertsCurrent.value].img
  }
  return str
})
// 轮播图数据
const firstNonEmptyArray = computed(
  () => (props.list?.length ? props.list : mergedAttrs.value.dataList) || []
)
const swipeStyle = computed<StyleValue>(() => {
  return {
    // width: mergedStyles.value.width + 'rpx',
    height: mergedStyles.value.height + showBgImageNum.value + 'rpx',
    padding: mergedStyles.value.padding + 'rpx',
    paddingTop: (showBgImageNum.value || mergedStyles.value.padding) + 'rpx',
    boxSizing: 'border-box',
    marginBottom: mergedStyles.value.marginBottom + 'rpx',
    backgroundColor: mergedStyles.value.backgroundColor || 'transparent'
  }
})

const swipeItemStyle = computed<StyleValue>(() => {
  return {
    width: mergedStyles.value.width - mergedStyles.value.padding * 2 + 'rpx',
    height: '100%',
    borderRadius: mergedStyles.value.radius + 'rpx',
    overflow: 'hidden'
  }
})

const hearderAddressStyle = computed<StyleValue>(() => {
  console.log(mergedStyles.value.headerAddressHeight)

  return {
    width: '84vw',
    top: mergedStyles.value.headerAddressHeight * 2 + 'rpx',
    // top: 50*2 + 'rpx',
    position: 'absolute',
    left: '50%',
    translate: '-50% 0'
  }
})

const clickSwipeItem = (item: any) => {
  if (!item) return
  emit('jump', { type: 'link', id: item[props.pathKey] })
}

const handleSwiperChange = (event: any) => {
  const { current } = event.detail
  // console.log(event, current)

  advertsCurrent.value = current
}

// onMounted(() => {
//   const app = createApp({})
// console.log('aa',app);

//   app.use(lazyPlugin, {
//     loading: 'http://qnimg.zowoyoo.com/img/84826/1591081561756.gif',
//     error: 'http://qnimg.zowoyoo.com/img/84826/1591081561591.png'
//   })
// })
</script>

<template>
  <view
    v-if="swipeStyle"
    class="m-swiper__box"
    :style="swipeStyle"
  >
    <view
      v-if="mergedAttrs.showBgImage"
      class="home-top-bg"
      :style="{ backgroundImage: `url(${bgImageUrl})` }"
    ></view>
    <swiper
      :indicator-dots="mergedStyles.indicatorDots"
      :indicator-color="mergedStyles.indicatorColor"
      :indicator-active-color="mergedStyles.indicatorActiveColor"
      :vertical="mergedStyles.vertical"
      :autoplay="mergedAttrs.isAutoplay"
      :interval="mergedAttrs.autoplay"
      :circular="mergedAttrs.circular"
      :style="swipeItemStyle"
      class="m-swiper"
      @change="handleSwiperChange"
    >
      <swiper-item
        v-for="(item, index) in firstNonEmptyArray"
        :key="index"
        class="m-swiper__item"
        @click.stop="clickSwipeItem(item)"
      >
        <img
          class="img"
          mode="aspectFill"
          :src="item[imgKey] || item.img"
          lazy-load
        />
      </swiper-item>
    </swiper>
    <view
      v-if="attrs.showHeaderAddress"
      class="m-swiper__address"
      :style="hearderAddressStyle"
    >
      <m-header-address
        :primaryColor="mergedStyles.headerAddressPrimaryColor"
      />
    </view>
  </view>
</template>

<style lang="scss" scoped>
.m-swiper__box {
  position: relative;
  .home-top-bg {
    position: absolute;
    top: -65px;
    left: 0;
    width: 100%;
    height: 360rpx;
    filter: blur(30rpx);
    background-size: 140%;
    background-position: center bottom;
    overflow: hidden;
  }
  .m-swiper {
    margin: 0 auto;
    box-shadow: 0px 10rpx 20rpx 0px rgba(51, 51, 51, 0.6);
    .m-swiper__item {
      width: 100%;
      height: 100%;
      .img {
        width: 100%;
        height: 100%;
      }
    }
  }
  // .m-swiper__address {
  //   position: absolute;
  //   left: 50%;
  //   translate: -50% 0;
  //   width: 84vw;
  // }
}
</style>
