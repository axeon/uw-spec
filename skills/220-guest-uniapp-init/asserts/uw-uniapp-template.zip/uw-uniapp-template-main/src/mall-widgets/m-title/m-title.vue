<template>
  <!-- 标题 -->
  <view
    class="m-text-title"
    :style="[wrapStyle(styles)]"
  >
    <view
      class="m-text-title-content"
      :class="[
        attrs.model == 'center' ? 'title-mid-model' : 'title-left-model'
      ]"
      :style="[cmpStyle(styles)]"
    >
      <!-- 主标题 -->
      <view
        :class="[attrs.model == 'center' ? 'mb8' : 'mr5']"
        :style="[titleStyle]"
        @click="attrs.jumpPath && jump(attrs.jumpPath)"
      >
        {{ attrs.title || '' }}
      </view>

      <!-- 副标题 -->
      <view
        class="info"
        :style="[subTitleStyle]"
      >
        {{ attrs.info || '' }}
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import { wrapStyle, cmpStyle, unit } from '../utils/registerBaseStyle'

interface Props {
  data: {
    styles?: {
      pagePadding?: number
      cmpUpperPadding?: number
      cmpLowerPadding?: number
      cmpUpperRadius?: number
      cmpLowerRadius?: number
      titleSize?: number
      infoSize?: number
      titleColor?: string
      infoColor?: string
      cmpBackground?: number
      tilteWeight?: number
      infoWeight?: number
      [key: string]: any
    }
    attrs?: {
      title?: string
      model?: 'left' | 'center'
      jumpPath?: any
      info?: string
      [key: string]: any
    }
    [key: string]: any
  }
}

interface Emits {
  (e: 'jump', item: any): void
}

const props = defineProps<Props>()

const emit = defineEmits<Emits>()

const styles = computed(() => {
  return {
    pagePadding: 0, // 左右边距
    cmpUpperPadding: 10, // 上边间距
    cmpLowerPadding: 10, // 下边间距
    cmpUpperRadius: 0, // 上边圆角
    cmpLowerRadius: 0, // 下边圆角
    titleSize: 16, // 标题字体
    infoSize: 12, // 副标题字体
    titleColor: '#333333', // 标题颜色
    infoColor: '#999999', // 副标题颜色
    cmpBackground: 0, // 背景色
    ...props.data.styles
  }
})

const attrs = computed(() => {
  return {
    title: '默认文字',
    model: 'left', // 布局选择
    jumpPath: {}, // 页面跳转
    ...props.data.attrs
  }
})

// 主标题样式
const titleStyle = computed(() => {
  return {
    color: styles.value.titleColor,
    fontSize: unit(styles.value.titleSize),
    fontWeight: styles.value.tilteWeight
  }
})

// 副标题样式
const subTitleStyle = computed(() => {
  return {
    color: styles.value.infoColor,
    fontSize: unit(styles.value.infoSize),
    fontWeight: styles.value.infoWeight
  }
})

// 跳转方法
const jump = (item: any) => {
  emit('jump', item)
}
</script>

<style lang="scss" scoped>
.m-text-title {
  .m-text-title-content {
    padding-top: 10px;
    padding-bottom: 10px;
  }
  .title-left-model {
    display: flex;
    align-items: flex-end;
    padding-left: 10px;
    padding-right: 10px;
  }

  .title-mid-model {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .mb8 {
    margin-bottom: 8px;
  }
  .mr5 {
    margin-right: 5px;
  }
}
</style>
