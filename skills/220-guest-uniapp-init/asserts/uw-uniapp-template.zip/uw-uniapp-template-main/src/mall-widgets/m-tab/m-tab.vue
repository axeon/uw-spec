<template>
  <!-- 未开发 -->
  <view class="m-tab">
    <view
      v-if="type === 'line'"
      class="tabs line-tabs"
    >
      <view
        v-for="(tab, index) in tabList"
        :key="index"
        :class="{ active: active === tab.id }"
        @click="active = tab.id"
      >
        <text>{{ tab.title }}</text>
      </view>
    </view>
    <view
      v-else-if="type === 'cake'"
      class="tabs cake-tabs"
    >
      <view
        v-for="(tab, index) in tabList"
        :key="index"
        :class="{ active: active === tab.id }"
        @click="active = tab.id"
      >
        {{ tab.title }}
      </view>
    </view>
    <view
      v-else-if="type === 'card'"
      class="tabs card-tabs"
    >
      <view
        v-for="(tab, index) in tabList"
        :key="index"
        :class="{ active: active === tab.id }"
        @click="active = tab.id"
      >
        {{ tab.title }}
      </view>
    </view>
  </view>
</template>
<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  type: {
    type: String,
    default: 'line'
  },
  tabList: {
    type: Array<{ title: string; id: number }>,
    required: true,
    default() {
      return []
    }
  },
  value: {
    type: [Number, String],
    default: ''
  }
})

const type = computed(() => {
  return props.type
})

const tabList = computed(() => {
  return props.tabList
})

const active = defineModel()
</script>
<style scoped lang="scss">
.m-tab {
  padding: 16rpx;

  .tabs {
    display: flex;
    overflow-x: auto;

    view {
      cursor: pointer;
      padding: 20rpx 30rpx;
      transition: background-color 0.3s, color 0.3s;
      white-space: nowrap; /* 禁止文本换行，确保文字水平排列 */
    }
  }

  .line-tabs view {
    border-bottom: 6rpx solid transparent;
    color: #747576;
    &.active {
      border-bottom-color: #ff8c00;
      color: #000;
    }
  }

  .cake-tabs {
    view {
      background-color: #f6f6f6;
      border-radius: 30rpx;
      margin-right: 10rpx;

      &.active {
        background-color: #fff4e8;
        color: #ff8c00;
      }
    }
  }

  .card-tabs {
    border: 1rpx solid #ddd;
    border-radius: 5rpx;

    view {
      border-right: 1rpx solid #ddd;
      background-color: #fff;
      &:last-child {
        border-right: none;
      }
      &.active {
        background-color: #ff8c00;
        color: #fff;
      }
    }
  }
}
</style>
