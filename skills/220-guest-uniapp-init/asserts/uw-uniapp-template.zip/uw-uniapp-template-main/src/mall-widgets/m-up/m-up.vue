<template>
  <!-- 回到顶部 -->
  <view>
    <view
      class="m-scroll-top"
      :style="style"
      @click="handleClick"
    >
      <u-icon
        name="arrow-upward"
        :size="mergedStyles.iconSize"
        :color="mergedStyles.iconColor"
      ></u-icon>
    </view>
  </view>
</template>
<script setup lang="ts">
import { computed } from 'vue'
import { unit } from '../utils/registerBaseStyle'
interface Styles {
  radius: number
  iconSize: number
  iconColor: string
  border: string
  backgroundColor: string
}

interface Attrs {
  model: string
  bottom: string
  paddingLeft: string
  paddingRight: string
  scrollTop: number
}
const props = withDefaults(
  defineProps<{
    attrs?: Partial<Attrs>
    styles?: Partial<Styles>
    scrollTop: number
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({}),
    scrollTop: 0
  }
)
const mergedAttrs = computed(() => ({
  model: 'right', // 位置选择
  bottom: 40, // 底部距离
  paddingLeft: 0, // 左边距
  paddingRight: 30, // 右边距
  show: false, // 是否强制显示
  scrollTop: props.scrollTop,
  ...props.attrs
}))
const mergedStyles = computed(() => ({
  radius: 50, // 按钮圆角
  iconSize: 24, // 图标大小
  iconColor: '#333333', // 图标颜色
  border: 'transparent', // 边框颜色
  backgroundColor: '#f1f1f1', // 背景颜色
  ...props.styles
}))

const handleClick = () => {
  uni.pageScrollTo({
    scrollTop: 0
  })
}
const style = computed(() => {
  return {
    opacity:
      mergedAttrs.value.scrollTop >= 200 || mergedAttrs.value.show ? 1 : 0,
    bottom: unit(mergedAttrs.value.bottom),
    marginLeft: unit(mergedAttrs.value.paddingLeft),
    right: unit(mergedAttrs.value.paddingRight),
    backgroundColor: mergedStyles.value.backgroundColor,
    borderColor: mergedStyles.value.border,
    borderRadius: `${mergedStyles.value.radius}%`
  }
})
</script>
<style lang="scss" scoped>
.m-scroll-top {
  position: fixed;
  padding: 15rpx;
  // width: 100rpx;
  // height: 100rpx;
  // background: url('http://qnimg.zowoyoo.com/img/84826/1625553533012.png')
  //   no-repeat center;
  display: flex;
  align-items: center;
  justify-content: center;
  background-size: contain;
  transition: opacity 0.3s;
  border: 1rpx solid transparent;
}
</style>
