/*
 * @Description:
 * @Date: 2024-06-13 14:53:42
 * @LastEditors: niezihao
 * @LastEditTime: 2024-06-28 11:52:19
 * @Author: niezihao
 */

import type { StyleValue, CSSProperties } from 'vue'
// 动态渲染通用样式
export function wrapStyle(target: any): CSSProperties {
  if (!target) return {}

  const result: Partial<Record<keyof CSSProperties, string>> = {}

  const needUnit = ['fontSize', 'width', 'height'] as Array<keyof CSSProperties>

  for (const [key, value] of Object.entries(target)) {
    const keyAsCssProp = key as keyof CSSProperties

    if (needUnit.includes(keyAsCssProp)) {
      result[keyAsCssProp] = unit(value)
      continue
    }

    if (key === 'pagePadding') {
      result.paddingLeft = unit(value)
      result.paddingRight = unit(value)
    }
  }

  return result as CSSProperties
}
export function cmpStyle(target: any) {
  if (!target) {
    return {}
  }

  const result: StyleValue = {}
  for (const [key, value] of Object.entries(target)) {
    // 容器负边距
    if (key === 'negativeMarginBottom') {
      result['paddingBottom'] = unit(value)
      continue
    }

    // 上部内间距
    if (key === 'cmpUpperPadding') {
      result['paddingTop'] = unit(value)
      continue
    }

    // 下部内间距
    if (key === 'cmpLowerPadding') {
      result['paddingBottom'] = unit(value)
      continue
    }

    // 所有圆角
    if (key === 'cmpRadius') {
      result['borderRadius'] = unit(value)
      continue
    }

    // 上部圆角
    if (key === 'cmpUpperRadius') {
      result['borderTopLeftRadius'] = unit(value)
      result['borderTopRightRadius'] = unit(value)
      continue
    }

    // 下部圆角
    if (key === 'cmpLowerRadius') {
      result['borderBottomLeftRadius'] = unit(value)
      result['borderBottomRightRadius'] = unit(value)
      continue
    }

    // 组件背景色
    if (key === 'cmpBackground') {
      result['background'] = value as string
      continue
    }
  }
  return result
}

// 样式单位rpx
export function unit(target: any) {
  return `${Number(target) * 2}rpx`
}
