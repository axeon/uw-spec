<template>
  <view>
    <template v-if="displayList && displayList.length">
      <view
        v-for="(item, index) in displayList"
        :key="index"
        class="m-img-list"
        :style="[wrapStyle(mergedStyles), cmpStyle(mergedStyles)]"
      >
        <view
          class="img"
          :style="[getImgStyle(item)]"
          @click="jump(item)"
        ></view>
        <!-- <image
      class="img"
      mode="widthFix"
      :src="attrs.imagePath || defaultImage"
      :style="[getImgStyle()]"
      @click="jump(attrs.jumpPath)"
    /> -->
        <view
          v-if="item.text"
          class="text"
          :style="[getImgTextStyle()]"
        >
          {{ item.text }}
        </view>
        <view
          v-if="item.btnText"
          class="btn"
          :style="[getImgBtnStyle()]"
        >
          {{ item.btnText }}
        </view>
      </view>
    </template>
    <template v-else>
      <view
        class="m-img-list"
        :style="[wrapStyle(mergedStyles), cmpStyle(mergedStyles)]"
      >
        <image
          class="img"
          mode="widthFix"
          :src="defaultImage"
          :style="[getDefualtImgStyle()]"
        />
      </view>
    </template>
    <view
      class="load-more"
      v-if="attrs.onPullDownRefresh"
    >
      {{ loadMoreText }}
    </view>
    <view
      v-if="attrs.showLoadingButton"
      class="load-more"
    >
      <up-button
        plain
        :text="loadMoreText"
        :loading="loading"
        shape="circle"
        loadingText="加载中..."
        @click="handleLoadMore"
      ></up-button>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { computed, ref, watch } from 'vue'
import { onReachBottom } from '@dcloudio/uni-app'
import { wrapStyle, cmpStyle, unit } from '../utils/registerBaseStyle'
import type { JumpType, DataType, Styles, Attrs } from './type'

const props = withDefaults(
  defineProps<{
    attrs: Partial<Attrs>
    styles: Partial<Styles>
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({})
  }
)
const mergedAttrs = computed(() => ({
  dataList: [],
  currentPage: 1, // 起始分页
  onPullDownRefresh: false, // 开启下拉加载
  showLoadingButton: false, // 开启加载按钮
  pageSizes: 10, // 每页显示数量
  ...props.attrs
}))
const mergedStyles = computed(() => ({
  pagePadding: 0, // 边距
  cmpRadius: 0, // 容器圆角
  imgRadius: 0, // 图片圆角
  imgHeight: 200, // 图片高度
  cmpUpperPadding: 0, //	上边距
  cmpLowerPadding: 0, //	下边距
  fadeOut: '', // 渐变方向
  cmpBackground: '', // 背景色
  imgTextHeight: 20, // 文案高度
  imgTextWidth: 20, // 文案宽度
  imgTextFontSize: 16, // 文案字体大小
  imgTextColor: '', // 文案颜色
  imgTextTop: 20, // 文案距离顶部
  imgTextLeft: 20, // 文案距离左侧
  imgBtnRadius: 5, // 按钮圆角
  imgBtnHeight: 20, // 按钮高度
  imgBtnWidth: 20, // 按钮宽度
  imgBtnFontSize: 16, // 按钮字体大小
  imgBtnColor: '', // 按钮颜色
  imgBtnTop: 40, // 按钮距离顶部
  imgBtnLeft: 50, // 按钮距离左侧
  imgBtnBackground: '', // 按钮背景色
  ...props.styles
}))
const loadedList = ref<DataType[]>([])
const currentPage = ref(mergedAttrs.value.currentPage) // 当前显示的页码
const loading = ref(false) // 按钮加载状态

// 数据变化更新页面
watch(
  () => ({
    refresh: mergedAttrs.value.onPullDownRefresh,
    size: mergedAttrs.value.pageSizes,
    page: mergedAttrs.value.currentPage
  }),
  ({ page, size, refresh }, oldVal) => {
    // 仅在 currentPage 实际变化时更新
    if (page !== oldVal?.page && page !== currentPage.value) {
      currentPage.value = page
    }
    // 如果 pageSize 或 refresh 变化，重置到第一页
    if (size !== oldVal?.size || refresh !== oldVal?.refresh) {
      currentPage.value = 1
    }
  },
  { deep: true, immediate: true }
)
watch(
  () => mergedAttrs.value.dataList,
  (newList) => {
    if (newList?.length) {
      const startIndex = (currentPage.value - 1) * mergedAttrs.value.pageSizes
      const endIndex = currentPage.value * mergedAttrs.value.pageSizes
      loadedList.value = newList.slice(startIndex, endIndex).filter(Boolean)
    } else {
      loadedList.value = []
    }
  },
  { immediate: true }
)

// 展示的列表
const displayList = computed(() => {
  return loadedList.value
})

// 是否还有更多数据可加载
const hasMore = computed(() => {
  const { dataList = [], pageSizes } = mergedAttrs.value
  return currentPage.value * pageSizes < dataList.length
})

// 加载更多文本
const loadMoreText = computed(() => {
  if (!hasMore.value) return '已加载全部'
  return loading.value ? '' : '加载更多'
})

// 加载更多方法
const handleLoadMore = () => {
  if (!hasMore.value || loading.value) return
  loading.value = true

  setTimeout(() => {
    const { dataList = [], pageSizes } = mergedAttrs.value
    const nextPage = currentPage.value + 1
    const startIndex = (nextPage - 1) * pageSizes
    const endIndex = nextPage * pageSizes

    const newItems = dataList.slice(startIndex, endIndex).filter(Boolean)
    if (newItems.length) {
      loadedList.value = [...loadedList.value, ...newItems]
      currentPage.value = nextPage
    }
    loading.value = false
  }, 1000)
}

const emit = defineEmits<{
  jump: [item: JumpType]
}>()
const defaultImage =
  'https://img01.yzcdn.cn/public_files/2019/03/05/2b60ed750a93a1bd6e17fc354c86fa78.png!large.webp'

const backgroundImage = (item: any) => {
  let style = ''
  if (mergedStyles.value.fadeOut) {
    style = `linear-gradient(to ${
      mergedStyles.value.fadeOut
    }, rgba(0, 0, 0, 0), ${
      mergedStyles.value.cmpBackground
        ? mergedStyles.value.cmpBackground
        : 'rgba(255, 255, 255, 1)'
    }), url(${item.imagePath || defaultImage})`
  } else {
    style = `url(${item.imagePath || defaultImage})`
  }
  return style
}
// const backgroundImage = computed(() => {
//   let style = ''
//   if (mergedStyles.value.fadeOut) {
//     style = `linear-gradient(to ${mergedStyles.value.fadeOut}, rgba(0, 0, 0, 0), ${mergedStyles.value.cmpBackground ? mergedStyles.value.cmpBackground : 'rgba(255, 255, 255, 1)'}), url(${mergedAttrs.value.imagePath || defaultImage})`
//   } else {
//     style = `url(${mergedAttrs.value.imagePath || defaultImage})`
//   }
//   return style
// })

const getImgStyle = (item: DataType) => {
  return {
    backgroundImage: backgroundImage(item),
    borderRadius: unit(mergedStyles.value.imgRadius),
    height: unit(mergedStyles.value.imgHeight)
  }
}
const getDefualtImgStyle = () => {
  return {
    borderRadius: unit(mergedStyles.value.imgRadius),
    height: unit(mergedStyles.value.imgHeight)
  }
}
const getImgTextStyle = () => {
  return {
    height: unit(mergedStyles.value.imgTextHeight),
    width: unit(mergedStyles.value.imgTextWidth),
    fontSize: unit(mergedStyles.value.imgTextFontSize),
    color: mergedStyles.value.imgTextColor,
    top: unit(mergedStyles.value.imgTextTop),
    left: unit(mergedStyles.value.imgTextLeft),
    lineHeight: unit(mergedStyles.value.imgTextHeight)
  }
}
const getImgBtnStyle = () => {
  return {
    backgroundColor: mergedStyles.value.imgBtnBackground,
    borderRadius: unit(mergedStyles.value.imgBtnRadius),
    height: unit(mergedStyles.value.imgBtnHeight),
    width: unit(mergedStyles.value.imgBtnWidth),
    fontSize: unit(mergedStyles.value.imgBtnFontSize),
    color: mergedStyles.value.imgBtnColor,
    top: unit(mergedStyles.value.imgBtnTop),
    left: unit(mergedStyles.value.imgBtnLeft),
    lineHeight: unit(mergedStyles.value.imgBtnHeight)
  }
}
const jump = (item: DataType) => {
  if (!item.jumpPath && !item.url) return
  emit('jump', item.jumpPath || { id: item.url, type: 'link' })
}
onReachBottom(() => {
  if (!mergedAttrs.value.onPullDownRefresh) return
  console.log('log输出的内容：m-img-list触底了')
  handleLoadMore()
})
</script>

<style lang="scss" scoped>
.m-img-list {
  position: relative;
}
.img {
  width: 100%;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
}

.text {
  position: absolute;
  text-align: center;
}

.btn {
  position: absolute;
  text-align: center;
}
.load-more {
  margin: 20rpx;
}
</style>
