<script lang="ts" setup>
import { computed } from 'vue'
import { unit } from '../utils/registerBaseStyle'

// 样式配置类型
interface Styles {
  titleSize?: number
  titleColor?: string
  titleWeight?: number
  moreSize?: string
  moreColor?: string
  radius?: number
  backgroundColor?: string
  activeSize?: number
  activeColor?: string
  activeWeight?: number
  inactiveSize?: number
  inactiveColor?: string
  lineColor?: string
}

// 组件属性配置类型
interface Attrs {
  title?: string
  more?: boolean
  moreName?: string
  dataList?: Array<{ name: string; url: string; query: string; more: string }>
}

// 定义组件props，包含attrs和styles两个属性
const props = withDefaults(
  defineProps<{
    attrs?: Partial<Attrs>
    styles?: Partial<Styles>
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({})
  }
)
// 定义组件事件
const emit = defineEmits<{
  moreClick: [] // 点击更多按钮事件
  secondMoreClick: [] // 点击二级更多按钮事件
  change: [item: { name: string; key: string }] // 二级菜单切换事件
  jump: [item: object] // 二级菜单跳转事件
}>()

// 合并后的属性配置
const mergedAttrs = computed(() => ({
  title: '标题', // 标题
  more: true, // 默认显示更多按钮
  moreName: '更多', // 更多按钮文本
  dataList: [], // 二级菜单
  ...props.attrs // 合并传入的属性
}))

// 合并后的样式配置
const mergedStyles = computed(() => ({
  titleSize: 18, // 标题文字大小
  titleColor: '#222', // 标题文字颜色
  titleWeight: 7, // 标题文字粗细
  moreSize: 18, // 更多按钮文字大小
  moreColor: '#222', // 更多按钮文字颜色
  radius: 10, // 整体圆角
  backgroundColor: '#f1f1f1', // 主容器背景色
  // 二级菜单
  activeSize: 17, // 激活文字大小
  activeColor: '#303133', // 激活文字颜色
  activeWeight: 7, // 激活文字粗细
  inactiveSize: 15, // 未激活文字大小
  inactiveColor: '#303133', // 未激活文字颜色
  lineColor: 'red', // 滑块颜色
  lineHeight: 4,
  ...props.styles // 合并传入的样式
}))

// 主容器样式
const mainStyle = computed(() => {
  return {
    backgroundColor: mergedStyles.value.backgroundColor,
    borderRadius: unit(mergedStyles.value.radius)
  }
})
// 二级菜单选择中时的样式
const activeStyle = computed(() => {
  return {
    color: mergedStyles.value.activeColor,
    fontSize: unit(mergedStyles.value.activeSize),
    fontWeight: mergedStyles.value.activeWeight * 100
  }
})
// 二级菜单非选中时的样式
const inactiveStyle = computed(() => {
  return {
    color: mergedStyles.value.inactiveColor,
    fontSize: unit(mergedStyles.value.inactiveSize)
  }
})
// 点击更多按钮处理函数
const handlerTitleClick = () => {
  if (mergedAttrs.value.dataList) {
    const item = mergedAttrs.value.dataList.filter((item) => item.more)
    if (item && item[0].more) {
      const type = item[0].more.includes('/') ? 'link' : 'custom'
      emit('jump', { id: item[0].more, type })
    }
  }
}
const clickTabs = (item: { name: string; url: string; query: string }) => {
  if (item.url) {
    const type = item.url.includes('/') ? 'link' : 'custom'
    emit('jump', { id: item.url, type, query: item.query || '' })
  }
}
</script>

<template>
  <!-- 板块标题容器 -->
  <view
    class="z-title"
    :style="mainStyle"
  >
    <!-- 主标题区域 -->
    <view
      class="z-title-main"
      v-if="mergedAttrs.title"
    >
      <!-- 左侧标题和图标 -->
      <view class="z-title-left">
        <text
          :style="{
            fontSize: mergedStyles.titleSize,
            fontWeight: mergedStyles.titleWeight * 100
          }"
        >
          {{ mergedAttrs.title }}
        </text>
      </view>
      <!-- 右侧更多按钮 -->
      <view
        v-if="mergedAttrs.more"
        class="z-title-right"
        @click="handlerTitleClick"
      >
        <text
          :style="{
            fontSize: mergedStyles.moreSize + 'px'
          }"
        >
          {{ mergedAttrs.moreName }}
        </text>
        <u-icon
          name="arrow-right"
          :size="mergedStyles.moreSize"
        ></u-icon>
      </view>
    </view>

    <!-- 二级标题区域 -->
    <view
      class="z-title-minor"
      v-if="mergedAttrs.dataList.length > 0"
    >
      <u-tabs
        :list="mergedAttrs.dataList"
        :lineColor="mergedStyles.lineColor"
        :lineHeight="mergedStyles.lineHeight"
        :inactiveStyle="inactiveStyle"
        :activeStyle="activeStyle"
        @click="clickTabs"
      ></u-tabs>
    </view>
  </view>
</template>

<style lang="scss" scoped>
/* 主容器样式 */
.z-title {
  padding: 20rpx 32rpx 10rpx;
  /* 主标题区域样式 */
  .z-title-main {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10rpx;

    /* 左侧标题样式 */
    .z-title-left {
      display: flex;
      align-items: center;

      text {
        font-size: 38rpx;
      }
    }

    /* 右侧更多按钮样式 */
    .z-title-right {
      display: flex;
      align-items: center;

      text {
        color: #666;
        font-size: 32rpx;
      }
    }
  }

  /* 二级标题区域样式 */
  .z-title-minor {
    padding-bottom: 10rpx;
  }
}
</style>
