<script lang="ts" setup>
// html - 信息渲染组件
import { computed } from 'vue'
import { unit } from '../utils/registerBaseStyle'
import mpHtml from 'mp-html/dist/uni-app/components/mp-html/mp-html'

interface Styles {
  margin: number // 整体边距
  color: string // 字体颜色
  fontSize: number // 字体大小
  fontWeight: number // 字体粗细
  lineHeight: number // 字体行高
  imgRadius: number // 图片圆角
  imgHeight: number // 图片高度
  imgTop: number // 图片上边距
  imgBottom: number // 图片下边距
  imgRight: number // 图片右边距
  imgLeft: number // 图片左边距
}

interface Attrs {
  dataList: Array<any>
  jumpPath: object
}

const props = withDefaults(
  defineProps<{
    attrs?: Partial<Attrs>
    styles?: Partial<Styles>
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({})
  }
)
const mergedAttrs = computed(() => ({
  dataList: [],
  ...props.attrs
}))

const mergedStyles = computed(() => ({
  margin: 0,
  color: '#000',
  fontSize: 14,
  fontWeight: 4,
  imgRadius: 0,
  imgHeight: 200,
  imgTop: 10,
  imgBottom: 0,
  imgLeft: 0,
  imgRight: 0,
  lineHeight: 20,
  ...props.styles
}))
// const emit = defineEmits<{
//   jump: [item: object]
// }>()

// 整体样式
const containerStyle = computed(() => {
  return {
    margin: unit(mergedStyles.value.margin)
  }
})
// 文字样式
const fontStyle = computed(() => {
  return {
    margin: unit(mergedStyles.value.margin),
    color: mergedStyles.value.color,
    fontSize: unit(mergedStyles.value.fontSize),
    lineHeight: unit(mergedStyles.value.lineHeight),
    fontWeight: (mergedStyles.value.fontWeight || 4) * 100
  }
})
// 图片样式
const imgStyle = computed(() => {
  return {
    borderRadius: unit(mergedStyles.value.imgRadius),
    height: unit(mergedStyles.value.imgHeight),
    marginTop: unit(mergedStyles.value.imgTop),
    marginBottom: unit(mergedStyles.value.imgBottom)
  }
})
// 图片的左右边距使用父元素的padding实现
const imgBoxStyle = computed(() => {
  return {
    paddingLeft: unit(mergedStyles.value.imgLeft),
    paddingRight: unit(mergedStyles.value.imgRight)
  }
})
// 解析dataList数据
const parsedDataList = computed(() => {
  if (!mergedAttrs.value.dataList) return []
  return mergedAttrs.value.dataList.flatMap((item) => {
    if (!item.content) return []

    const content = item.content.trim()

    // 如果是HTML内容，直接返回
    if (content.startsWith('<') && content.endsWith('>')) {
      return [{ ...item, type: 'html' }]
    }

    // 验证是否是纯图片
    const { isValid, urls } = validateImageUrls(content)
    if (isValid) {
      return urls.map((url) => ({ content: url, type: 'image' }))
    }

    // 混合内容（图片和文字）
    const mixedParts = content
      .split(/(https?:\/\/[^\s]+)/)
      .map((part: string) => part.trim())
      .filter((part: string) => part !== '')
    return mixedParts.map((part: string) => {
      if (
        part.match(
          /^https?:\/\/.*\.(?:png|jpg|jpeg|gif|webp|svg|bmp)(?:\?.*)?$/i
        )
      ) {
        return { content: part, type: 'image' }
      } else {
        const cleanedText = part.replace(/\s+/g, ' ')
        return { content: cleanedText, type: 'text' }
      }
    })
  })
})
const validateImageUrls = (str: string) => {
  if (!str || typeof str !== 'string') {
    return { isValid: false, urls: [] }
  }

  // 分割字符串，支持多个连续的分隔符（换行、逗号、分号、空格）
  const urls = str
    .split(/[\n,; ]+/)
    .map((url) => url.trim())
    .filter((url) => url !== '')

  if (urls.length === 0) {
    return { isValid: false, urls: [] }
  }

  const imageRegex =
    /^https?:\/\/.*\.(?:png|jpg|jpeg|gif|webp|svg|bmp)(?:\?.*)?$/i

  const isValid = urls.every((url) => imageRegex.test(url))

  return {
    isValid,
    urls: urls
  }
}
// const handlerClick = (index: number) => {
//   if (!mergedAttrs.value) return

//   if (mergedAttrs.value.dataList) {
//     const url = mergedAttrs.value.dataList[index]?.url
//     const query = mergedAttrs.value.dataList[index]?.query || ''
//     if (url) {
//       const type = url.includes('/') ? 'link' : 'custom'
//       emit('jump', { id: url, type, query })
//     }
//   } else if (mergedAttrs.value.jumpPath) {
//     emit('jump', mergedAttrs.value.jumpPath)
//   }
// }
</script>

<template>
  <view
    class="m-html"
    :style="containerStyle"
  >
    <view
      v-for="(item, index) in parsedDataList"
      :key="index"
    >
      <view
        v-if="item.type === 'image'"
        class="img-box"
        :style="imgBoxStyle"
      >
        <img
          class="img"
          :style="imgStyle"
          :src="item.content"
          alt=""
        />
      </view>
      <mp-html
        v-else-if="item.type === 'html'"
        :content="item.content"
        :style="fontStyle"
      ></mp-html>
      <text
        v-else
        :style="fontStyle"
      >
        {{ item.content }}
      </text>
    </view>
  </view>
</template>

<style lang="scss" scoped>
.m-html {
  min-height: 30px;
  .img-box {
    width: 100vw;
  }
  .img {
    width: 100%;
  }
  image {
    width: 100%;
  }
}
</style>
