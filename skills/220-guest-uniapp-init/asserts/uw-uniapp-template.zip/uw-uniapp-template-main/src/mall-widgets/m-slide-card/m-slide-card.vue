<template>
  <!-- 滑动卡片 -->
  <view
    class="z-slide-card"
    :style="mainStyle"
  >
    <view :class="Number(attrs.type) === 0 ? `z-hot-sell` : 'z-hot-sell-box'">
      <view class="ul">
        <view
          class="li"
          v-for="(item, index) in dataList"
          :key="item.id"
          @click.stop="handlerHostClick(item, index)"
        >
          <view
            class="sell-bg view"
            :style="{ backgroundImage: `url(${item.signImg || item.img})` }"
          >
            <view class="sell-bg-icon i">TOP {{ index + 1 }}</view>
            <view
              class="sell-icon-site"
              v-if="item.areaName && Number(attrs.type) === 0"
            >
              <view class="sell-icon-box">
                <u-icon name="map"></u-icon>
                {{ item.areaName }}
              </view>
            </view>
          </view>
          <view
            v-if="Number(attrs.type) !== 0"
            class="sell-bg-icon-new i"
          >
            TOP {{ index + 1 }}
          </view>
          <view class="sell-title p">
            {{ item.infoTitle || item.title || item.viewName }}
          </view>
          <view class="sell-money view">
            <view class="sell-money-item">
              <view
                class="sell-salePrice p"
                v-if="item.salePrice && Number(attrs.type) === 0"
              >
                <text class="i">￥</text>
                <text class="span">{{ item.salePrice }}</text>
                <text class="text">起</text>
              </view>
              <view
                class="sell-marketPrice p"
                v-if="item.marketPrice && Number(attrs.type) === 0"
              >
                市场价￥{{ item.marketPrice }}
              </view>
            </view>
            <template v-if="Number(attrs.type) === 0">
              <button
                v-if="attrs.userType === 0"
                @click.stop="handlerHostClick(item, index)"
                class="post-video"
              >
                立即预订
              </button>
              <!-- v-if="userType !== 0 && (item.posterImg == '' || item.posterType == '' || item.posterImg == null || item.posterType == null)" -->
              <button
                v-if="
                  attrs.userType !== 0 && (!item.posterImg || !item.posterType)
                "
                class="post-video"
                open-type="share"
                @click.stop
                :data-signimg="item.signImg"
                :data-productno="item.infoId"
                :data-posterimg="item.posterImg"
                :data-postertype="item.posterType"
                :data-infotitle="item.infoTitle"
                :data-infotitledesc="item.infoTitleDesc"
              >
                一键分享
              </button>
              <!-- v-else-if="userType !== 0 && item.posterImg != '' && item.posterType != '' && item.posterImg != null && item.posterType != null" -->
              <button
                v-else-if="
                  attrs.userType !== 0 && item.posterImg && item.posterType
                "
                class="post-video"
                @click.stop="toShowModalX(index)"
                :data-productno="item.infoId"
                :data-videotitle="item.infoTitle"
              >
                一键发圈
              </button>
              <!-- @click.stop="toShowModalX(index)" -->
            </template>
          </view>
          <view
            class="sell-icon-site"
            v-if="item.areaName && Number(attrs.type) === 1"
          >
            <view class="sell-icon-box">
              <u-icon name="map"></u-icon>
              {{ item.areaName }}
            </view>
          </view>
        </view>
        <view
          v-if="Number(attrs.type) !== 1"
          class="last li"
        ></view>
        <view
          v-if="Number(attrs.type) === 1"
          class="last li"
          @click.stop="handleClick"
        >
          <text class="span">查看更多</text>
          <text class="i"></text>
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { computed, withDefaults } from 'vue'
import { unit } from '../utils/registerBaseStyle'

interface Styles {
  cmpBackground: string
  slideCardPaddingTop: string
  slideCardPaddingBottom: string
}

interface Attrs {
  list: any[]
  type: number | string
  infoId: number
  isShowModal: boolean
  posterImg: string
  posterType: string
  infoTitle: string
  infoTitleDesc: string
  userType: number
}
const props = withDefaults(
  defineProps<{
    attrs: Partial<Attrs>
    styles: Partial<Styles>
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({})
  }
)

const emit = defineEmits(['click', 'more', 'jump', 'change'])

const mainStyle = computed(() => {
  return {
    backgroundColor: props.styles.cmpBackground,
    paddingTop: unit(props.styles.slideCardPaddingTop) || 0,
    paddingBottom: unit(props.styles.slideCardPaddingBottom) || 0
  }
})

const dataList = computed(() => {
  let arr = []
  if (!props.attrs.list?.length) return []
  if (Number(props.attrs.type) === 1 && props.attrs.list.length % 2 !== 1) {
    arr = props.attrs.list.slice(0, props.attrs.list.length - 1)
  } else {
    arr = props.attrs.list
  }
  return arr
})

const handlerHostClick = (item: any, index: number) => {
  let jumpData: any = {}
  if (item.url) {
    jumpData = {
      id: item.url,
      type: 'link'
    }
  } else if (item.infoId) {
    jumpData = {
      id: `/pages/productDetail/index?infoId=${
        dataList.value[index].infoId
      }&treeId=${dataList.value[index].treeId || ''}`,
      type: 'link'
    }
  } else {
    jumpData = {
      id: '/pages/product/view/index?viewId=' + dataList.value[index].viewId,
      type: 'link'
    }
  }

  emit('jump', jumpData)
}

const handleClick = () => {
  emit('more')
}

// 显示弹框
const toShowModalX = (index: number) => {
  const item = dataList.value[index]
  const data = {
    isShowModal: true,
    infoId: item.infoId,
    infoTitle: item.infoTitle,
    infoTitleDesc: item.infoTitleDesc,
    signImg: item.signImg
  }
  emit('change', data)
}
</script>

<style lang="scss" scoped>
// 超值热销
.z-slide-card {
  &::-webkit-scrollbar {
    display: none;
  }
  .z-hot-sell {
    width: 100%;
    padding-top: 20rpx;
    padding-bottom: 26rpx;
    overflow-x: scroll;
    overflow-y: hidden;
    -webkit-overflow-scrolling: touch;

    .ul {
      display: flex;
      padding-left: 32rpx;
    }

    .li {
      flex-shrink: 0;
      width: 535rpx;
      padding-bottom: 24rpx;
      margin-right: 22rpx;
      border-radius: 20rpx;
      background-color: #fff;

      .sell-bg {
        width: 100%;
        height: 340rpx;
        margin-bottom: 20rpx;
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        border-radius: 20rpx 20rpx 0 0;
        .sell-bg-icon {
          display: inline-block;
          width: 120rpx;
          height: 40rpx;
          color: #fff;
          font-weight: 600;
          font-size: 24rpx;
          line-height: 40rpx;
          text-align: center;
          background: url('http://qnimg.zowoyoo.com/img/84826/1757405121085.png')
            no-repeat center;
          background-size: cover;
          transform: translate(0, -10rpx);
        }

        .sell-icon-site {
          line-height: 1;
          display: inline-block;
          vertical-align: baseline;
          padding: 4rpx 10rpx;
          background: rgba(0, 0, 0, 0.4);
          border-radius: 16rpx;
          transform: translate(-100rpx, 288rpx);
          color: #fff;
          font-size: 24rpx;
          .sell-icon-box {
            display: flex;
            align-items: center;
          }
        }
      }

      .sell-title {
        margin-bottom: 20rpx;
        padding: 4rpx 20rpx 0;
        overflow: hidden;
        font-weight: 600;
        font-size: 32rpx;
        color: #222222;
        white-space: nowrap;
        text-overflow: ellipsis;
      }

      .sell-money {
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-sizing: border-box;
        padding: 0 20rpx;
        .sell-money-item {
          line-height: 1;
          flex: 2;
          display: flex;
          align-items: baseline;
          justify-content: flex-start;
          .sell-salePrice {
            color: #f47f02;
            font-size: 38rpx;
            margin-right: 36rpx;
            .text {
              margin-left: 6rpx;
              font-size: 24rpx;
              text-decoration: none;
            }
          }
        }
        .money-item-btn {
          flex: 1;
          justify-content: flex-end;
        }

        .sell-marketPrice {
          color: rgba(187, 187, 187, 1);
          font-weight: 400;
          font-size: 20rpx;
          text-decoration: line-through;
        }
      }
    }

    .last {
      width: 1rpx;
    }
  }

  .z-hot-sell-box {
    width: 100%;
    padding: 0 0 32rpx;
    overflow-x: scroll;
    -webkit-overflow-scrolling: touch;

    .ul {
      display: flex;
      flex-direction: column;
      flex-wrap: wrap;
      height: 436rpx;
      padding-left: 32rpx;

      .li {
        position: relative;
        box-sizing: border-box;
        width: 282rpx;
        height: 212rpx;
        margin-right: 10rpx;
        margin-bottom: 10rpx;
        background-size: cover;

        .sell-bg {
          height: 100%;
          background-repeat: no-repeat;
          background-position: center;
          background-size: cover;
        }

        .sell-title {
          position: absolute;
          top: 0rpx;
          padding: 50rpx 0 40rpx;
          width: 100%;
          padding-left: 20rpx;
          overflow: hidden;
          color: #fff;
          font-size: 32rpx;
          white-space: nowrap;
          text-overflow: ellipsis;
          background-image: linear-gradient(rgba(0, 0, 0, 0.8), transparent);
        }
        .sell-bg-icon-new {
          top: 0;
          left: 0;
          position: absolute;
          z-index: 9;
          display: inline-block;
          width: 120rpx;
          height: 40rpx;
          color: #fff;
          font-weight: 600;
          font-size: 24rpx;
          line-height: 40rpx;
          text-align: center;
          background: url('http://qnimg.zowoyoo.com/img/84826/1757405121085.png')
            no-repeat center;
          background-size: cover;
        }

        .sell-icon-site {
          position: absolute;
          bottom: 20rpx;
          left: 20rpx;
          padding: 4rpx 10rpx;
          background: rgba(0, 0, 0, 0.4);
          border-radius: 16rpx;
          color: #fff;
          font-size: 20rpx;
          .sell-icon-box {
            display: flex;
            align-items: center;
          }
        }

        .i {
          display: block;
          width: 120rpx;
          height: 40rpx;
          margin-bottom: 20rpx;
          color: #fff;
          font-weight: 600;
          font-size: 24rpx;
          line-height: 40rpx;
          text-align: center;
          background: url('http://qnimg.zowoyoo.com/img/84826/1757405209800.png')
            no-repeat center;
          background-size: cover;
        }
      }

      .li:first-child {
        width: 434rpx;
        height: 434rpx;
        margin-bottom: 0;
        overflow: hidden;
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        border-radius: 20rpx 0 0 20rpx;
      }

      .li:nth-child(2) {
        width: 342rpx;
      }

      .li:nth-child(3) {
        width: 342rpx;
      }

      .li:nth-child(odd) {
        margin-bottom: 0;
      }

      .li:nth-last-child(2) {
        overflow: hidden;
        border-bottom-right-radius: 20rpx;
      }

      .li:nth-last-child(3) {
        overflow: hidden;
        border-top-right-radius: 20rpx;
      }

      .last {
        z-index: 1;
        display: flex;
        flex: 1;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        width: 84rpx;
        height: 436rpx;
        margin-right: 0;
        margin-left: -20rpx;

        .span {
          margin-bottom: 10rpx;
          color: #bbb;
          writing-mode: vertical-rl;
        }

        .i {
          width: 24rpx;
          height: 24rpx;
          background: url('http://qnimg.zowoyoo.com/img/84826/1757405256787.png')
            no-repeat center;
          background-size: contain;
        }
      }
    }
  }
}

.post-video {
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
  font-size: 20rpx;
  font-weight: bold;
  color: #ffffff;
  height: 54rpx;
  line-height: 54rpx;
  padding: 0 10rpx;
  background: #f47f02;
  border-radius: 60rpx;
  margin: 0;
  white-space: nowrap;
  box-sizing: border-box;
  &::after {
    border: none;
  }
}
</style>
