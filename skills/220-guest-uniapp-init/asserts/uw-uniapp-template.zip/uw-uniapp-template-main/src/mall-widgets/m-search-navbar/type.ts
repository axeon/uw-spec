export interface Attrs {
  leftType: string // 纯洁模式icon 返回文字font 回到首页home 不显示左边none
  centerType: string // 显示标题title 显示搜索框search 不显示none
  fixed: boolean // 固定页面顶部
  border: boolean // 显示下边框
  title: string // 导航栏标题
  bgColor: string // 导航栏背景颜色
  query: string // 参数
  url: string // 跳转链接
}

export interface Styles {
  size: number
}
