<template>
  <view
    class="m-img"
    :style="[wrapStyle(mergedStyles), cmpStyle(mergedStyles)]"
  >
    <view
      class="img"
      :style="[getImgStyle()]"
      @click="mergedAttrs.jumpPath && jump(mergedAttrs.jumpPath)"
    ></view>
    <!-- <image
      class="img"
      mode="widthFix"
      :src="mergedAttrs.imagePath || defaultImage"
      :style="[getImgStyle()]"
      @click="jump(mergedAttrs.jumpPath)"
    /> -->
    <view
      v-if="mergedAttrs.text"
      class="text"
      :style="[getImgTextStyle()]"
    >
      {{ mergedAttrs.text }}
    </view>
    <view
      v-if="mergedAttrs.btnText"
      class="btn"
      :style="[getImgBtnStyle()]"
    >
      {{ mergedAttrs.btnText }}
    </view>
  </view>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import { wrapStyle, cmpStyle, unit } from '../utils/registerBaseStyle'
import type { JumpType, Styles, Attrs } from './type'

const props = withDefaults(
  defineProps<{
    attrs: Partial<Attrs>
    styles: Partial<Styles>
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({})
  }
)
const mergedAttrs = computed(() => ({
  imagePath: '', // 图片路径
  jumpPath: {}, // 跳转路径
  text: '', // 文案
  btnText: '', // 按钮文案
  ...props.attrs
}))
const mergedStyles = computed(() => ({
  pagePadding: 0, // 左右边距
  cmpRadius: 0, // 容器圆角
  imgRadius: 0, // 图片圆角
  imgHeight: 200, // 图片高度
  cmpUpperPadding: 0, //	上边距
  cmpLowerPadding: 0, //	下边距
  cmpBackground: '', // 背景色
  fadeOut: '', // 渐变方向
  imgTextHeight: 20, // 文案高度
  imgTextWidth: 20, // 文案宽度
  imgTextFontSize: 16, // 文案字体大小
  imgTextColor: '', // 文案颜色
  imgTextTop: 20, // 文案距离顶部
  imgTextLeft: 20, // 文案距离左侧
  imgBtnRadius: 5, // 按钮圆角
  imgBtnHeight: 20, // 按钮高度
  imgBtnWidth: 20, // 按钮宽度
  imgBtnFontSize: 16, // 按钮字体大小
  imgBtnTop: 40, // 按钮距离顶部
  imgBtnLeft: 50, // 按钮距离左侧
  imgBtnColor: '', // 按钮颜色
  imgBtnBackground: '', // 按钮背景色
  ...props.styles
}))
setTimeout(() => {
  console.log('log输出的内容：propsprops', mergedStyles.value)
}, 500)
// const emit = defineEmits(['jump'])
const emit = defineEmits<{
  jump: [item: JumpType]
}>()
const defaultImage =
  'https://img01.yzcdn.cn/public_files/2019/03/05/2b60ed750a93a1bd6e17fc354c86fa78.png!large.webp'

const backgroundImage = computed(() => {
  let style = ''
  if (mergedStyles.value.fadeOut) {
    style = `linear-gradient(to ${
      mergedStyles.value.fadeOut
    }, rgba(0, 0, 0, 0), ${
      mergedStyles.value.cmpBackground
        ? mergedStyles.value.cmpBackground
        : 'rgba(255, 255, 255, 1)'
    }), url(${mergedAttrs.value.imagePath || defaultImage})`
  } else {
    style = `url(${mergedAttrs.value.imagePath || defaultImage})`
  }
  return style
})

const getImgStyle = () => {
  return {
    backgroundImage: backgroundImage.value,
    borderRadius: unit(mergedStyles.value.imgRadius),
    height: unit(mergedStyles.value.imgHeight)
  }
}
const getImgTextStyle = () => {
  return {
    height: unit(mergedStyles.value.imgTextHeight),
    width: unit(mergedStyles.value.imgTextWidth),
    fontSize: unit(mergedStyles.value.imgTextFontSize),
    color: mergedStyles.value.imgTextColor,
    top: unit(mergedStyles.value.imgTextTop),
    left: unit(mergedStyles.value.imgTextLeft),
    lineHeight: unit(mergedStyles.value.imgTextHeight)
  }
}
const getImgBtnStyle = () => {
  return {
    backgroundColor: mergedStyles.value.imgBtnBackground,
    borderRadius: unit(mergedStyles.value.imgBtnRadius),
    height: unit(mergedStyles.value.imgBtnHeight),
    width: unit(mergedStyles.value.imgBtnWidth),
    fontSize: unit(mergedStyles.value.imgBtnFontSize),
    color: mergedStyles.value.imgBtnColor,
    top: unit(mergedStyles.value.imgBtnTop),
    left: unit(mergedStyles.value.imgBtnLeft),
    lineHeight: unit(mergedStyles.value.imgBtnHeight)
  }
}
const jump = (item: JumpType) => {
  if (!item) return
  emit('jump', item)
}
</script>

<style lang="scss" scoped>
.m-img {
  position: relative;
}
.img {
  width: 100%;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
}

.text {
  position: absolute;
  text-align: center;
}

.btn {
  position: absolute;
  text-align: center;
}
</style>
