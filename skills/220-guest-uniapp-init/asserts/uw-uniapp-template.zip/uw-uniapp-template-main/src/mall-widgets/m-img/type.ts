/*
 * @Description:
 * @Date: 2024-06-21 11:10:30
 * @LastEditors: niezihao
 * @LastEditTime: 2024-08-16 17:45:52
 * @Author: niezihao
 */
export interface PropsType {
  // 参数
  attrs: {
    imagePath?: string // 图片路径
    jumpPath?: JumpType // 跳转路径
    text?: string // 文案
    btnText?: string // 按钮文案
  }
  // 样式控制
  styles: {
    cmpLowerPadding: number //	下边距
    cmpRadius: number // 容器圆角
    imgRadius: number // 图片圆角
    cmpUpperPadding: number //	上边距
    pagePadding: number // 边距
    cmpBackground: string // 背景色
    imgHeight: number // 图片高度
    fadeOut: string // 渐变
    imgTextHeight: number // 文案高度
    imgTextWidth: number // 文案宽度
    imgTextFontSize: number // 文案字体大小
    imgTextColor: string // 文案颜色
    imgTextTop: number // 文案距离顶部
    imgTextLeft: number // 文案距离左侧
    imgBtnBackground: string // 按钮背景色
    imgBtnRadius: number // 按钮圆角
    imgBtnHeight: number // 按钮高度
    imgBtnWidth: number // 按钮宽度
    imgBtnFontSize: number // 按钮字体大小
    imgBtnColor: string // 按钮颜色
    imgBtnTop: number // 按钮距离顶部
    imgBtnLeft: number // 按钮距离左侧
  }
}

export interface JumpType {
  id?: string
  type?: string
}
export interface Attrs {
  imagePath?: string // 图片路径
  jumpPath?: JumpType // 跳转路径
  text?: string // 文案
  btnText?: string // 按钮文案
}
// 样式控制
export interface Styles {
  cmpLowerPadding: number //	下边距
  cmpRadius: number // 容器圆角
  imgRadius: number // 图片圆角
  cmpUpperPadding: number //	上边距
  pagePadding: number // 边距
  cmpBackground: string // 背景色
  imgHeight: number // 图片高度
  fadeOut: string // 渐变
  imgTextHeight: number // 文案高度
  imgTextWidth: number // 文案宽度
  imgTextFontSize: number // 文案字体大小
  imgTextColor: string // 文案颜色
  imgTextTop: number // 文案距离顶部
  imgTextLeft: number // 文案距离左侧
  imgBtnBackground: string // 按钮背景色
  imgBtnRadius: number // 按钮圆角
  imgBtnHeight: number // 按钮高度
  imgBtnWidth: number // 按钮宽度
  imgBtnFontSize: number // 按钮字体大小
  imgBtnColor: string // 按钮颜色
  imgBtnTop: number // 按钮距离顶部
  imgBtnLeft: number // 按钮距离左侧
}
