<template>
  <view>
    <!-- 商品列表 -->
    <view
      v-if="type === 'product' && list.length > 0"
      class="panic-buying-box"
      :style="contentStyle"
    >
      <m-category-title
        :defaultColor="item.styles?.defaultColor"
        @moreClick="moreClick"
        @second-more-click="secondMoreClick"
        @change="handleChange"
        v-bind="Object.assign({}, item.attrs, item.titleOptions)"
      ></m-category-title>
      <m-product-list
        :data="item"
        :listField="listField"
        :list="list"
        @jump="handleJump"
      ></m-product-list>
      <view
        v-if="isExchange"
        class="exchange"
        :style="{ backgroundColor: item.styles.cmpBackground }"
        @click="handlerExchange"
      >
        <!-- <uni-icons
          class="icon"
          type="refreshempty"
          size="16"
        ></uni-icons> -->
        <view class="icon"></view>
        <text>换一批</text>
      </view>
    </view>
    <!-- 横向滑动块 -->
    <view
      v-if="type === 'slide' && list.length > 0"
      :style="contentStyle"
    >
      <m-category-title
        :defaultColor="item.styles?.defaultColor"
        @moreClick="moreClick"
        @second-more-click="secondMoreClick"
        @change="handleChange"
        v-bind="Object.assign({}, item.attrs, item.titleOptions)"
      ></m-category-title>
      <m-slide-card
        :type="item.attrs?.typeStyle"
        :list="list"
        :styles="item.styles"
        @jump="handleJump"
        @more="handleMore"
      ></m-slide-card>
    </view>
  </view>
</template>

<script setup>
import { computed } from 'vue'
import { unit } from '../utils/registerBaseStyle.ts'

const props = defineProps({
  item: {
    type: Object,
    default: () => ({})
  },
  list: {
    type: Array,
    default: () => []
  },
  listField: {
    type: Object,
    default: () => ({})
  },
  // product slide
  type: {
    type: String,
    default: 'product'
  },
  isExchange: {
    type: Boolean,
    default: false
  }
})

const contentStyle = computed(() => {
  return {
    paddingTop: unit(props.item.styles?.paddingTop),
    paddingBottom: unit(props.item.styles?.paddingBottom),
    backgroundColor: props.item.styles?.productBackgroundColor
  }
})

const emit = defineEmits([
  'jump',
  'moreClick',
  'secondMoreClick',
  'Exchange',
  'change',
  'more'
])

// 查看更多
const moreClick = () => {
  emit('moreClick')
}

// 点击跳转
const handleJump = (e) => {
  emit('jump', e)
}

// 换一批
const handlerExchange = () => {
  emit('exchange')
}

// 二级标题更多
const secondMoreClick = () => {
  emit('secondMoreClick')
}

// 二级标题点击切换
const handleChange = (item) => {
  emit('change', item)
}

// 横向滑动块点击更多
const handleMore = () => {
  emit('more')
}
</script>

<style lang="scss" scoped>
$huanyipi: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAAGsNJREFUeF7tnQuYHFWVx8+pnoREcY1BZUVEMYJB/QAfIA/RABoBeSjusGT63ppJBkHEqCAugqIBBR8IuIQVQZLM1L09QYfloYSIqIigoKLurgRRA+JbMGIE3TyYrmOfbA07xqlHV1d3V1Wf+339zSRzH+f8bv371q2691wESUJACIQSQGEjBIRAOAERiFwdQiCCgAhELg8hIAKRa0AIpCMgI0g6blKqRwiIQHqko8XNdAREIOm4SakeISAC6ZGOFjfTERCBpOMmpXqEgAikRzpa3ExHQASSjpuU6hECIpAe6WhxMx0BEUg6blKqRwiIQHqko8XNdAREIOm4SakeISAC6ZGOFjfTERCBpOMmpXqEgAikRzpa3ExHQASSjltkqf7+/h1nzpw5x3GcOQAwBxHn1Ov1bT/5Q0Q+AGx2HGcz/+QPET35e6VSeXBkZOShNpgmVTZJQATSJLDJ7P39/TNnz5493/f9+Yg4HwBeDAD8kz9PSVnt1GJ/BYD7AGAdIt5HROsqlcp9IpwMyDZRhQgkIayBgYF9K5XKAgB4HQDsDQAvTFg002xE9GdE/CYR3QEAd2/ZsuWe8fHxTZk2IpU9SUAEEnIxsCD6+voOAYDX+L7/GkTcJY/XDSJuCcRyDxHdM3PmzK+sXLny8TzaWkSbRCBTek1rzaPDcY1v5iMAYK8idigA/BoArkfE6z3Pu62gPuTG7J4XiNaahXAcIh5HRAfkpmeyMeQuIrquUqlcPzo6+kA2VfZWLT0pkEWLFj2zr6+PRwr+HNMDXb41GFVWe553Yw/4m5mLPSWQoaGhF9Tr9WEA4M9zMqNYrIpuI6IRa61XLLO7Y21PCEQpxY9ghx3HGSaiuR1CzRPlR4noT4j4KH8mfyciZDsQkW2Z/OwU/D67Q/b9ABFH+vr6RmRSH0681AJxXXdvIpocMZ7ahgvvASJ6wHGc9QDA9/jb/r158+YH0j56HR4enrt169Y9iOhFALAHIvLPbb8HAsraDbabhXLlqlWr/pB15UWvr5QC0VrvjohnBeLoy7CTfgQA30DEtZ7nrc2w3kRVLVmyZJeJiYn9iGjbx3GcV2U4Iq4nokustVckMqZHMpVOIEqpkxDxXADYLYM+/CUA3ElEdwLArdZaHilylQYHB19Zr9dfCQCHA8DxiNjSFwIifo2FYoy5OVeOdsmY0giEH9eyMIhoUYssNwLADUR0o7X2hhbr6mjxgYGBPRzHOR4A3oqI+7XSOCKuCoRybyv1FL1sKQSitT4NAD4EAM9uoUO+DAA3ViqVG0ZGRn7fQj25KFqtVhciIo8oLJhnpTTq8eC2a1nK8oUvVmiB8CTc9/1liPiWlD3xCBFd4fv+DWNjY/+Vso5cF1NKPQcRlwSPtndPY2xjNFpTr9fPrtVqPAfrqVRYgSilqoj4KQD45xQ99hgLAxE/Y4zheUbp09DQEC+5n3yil2YZzcOO45w9Ojq6qvSwpjhYSIForT/W2EPx/hQdtZWF4TjOZzzP+2mK8oUvMjQ0NGuKUF7erEOIeMWmTZvOHh8f/3OzZYuYv1AC4Rd+wahxdLOwiehKALjCWvvfzZYta36t9XsBgD/Nrir4XjCafK2sbCb9KoxAlFL8ZOZiAHh+k51yByJ+rBvvLZq0syvZ+Z1RIBJ+0NFUQsS3eZ53dVOFCpa5EAJRSvFE/MNNsv0LAFxojOHbMUkxBLTWhwVCOapJWOcaYz7aZJnCZM+9QFKKYzwYNX5YmJ7IiaFa62FEPJ+IEm8QQ8TLPc9bmhMXMjUj1wJJIY4/ENFZ1tqeetKS6RUBANVq9SWO43y8ya0A48aYE7K2pdv15VYgWusLAeDsJgDdTkRnWGt/0EQZyRpBIMUX1M3GmDeVCWouBeK67koiWpwUND96dBznjJGREQ6dIylDAq7rHk1EPJq8NEm1vJbL87zXJ8lbhDy5E4hS6mZEPDIJPCKaYGF4nrc8SX7Jk44Av41vxPf6dCP8UNJbqJoxRqVrLV+lciUQpdSNiHhsQkQ/8n3/9FqtVvpn8Ql5tD2bUmoEEQcTNnSxMebMhHlzmy03AtFaXwUAb0tCioi+0tfXd4oEUUtCK9s8SqnPIuIpSWpt7Jw8z1pb6IWOuRCI67r8WJH3cCRJY5s3b148Pj7OgQgkdYGA1voTAPBvSZouuki6LpBgg9PnksBGxCs9z3t7krySp70EXNddQkQrkrRSZJF0VSBKqTcg4k2NN94zE4AuxT1tAj8Lk0UptQAREwWnI6LBIkZS6ZpABgYGXug4zpcRkYMRRKYifwPF+Vb0vzchkg1E9MaivafqmkBc1/08ESV5bFi6l09FF8X29ruuy1Epk2xPvm3z5s1HFGn+2BWBKKXORMSLElwoPzDGcEACSTknoJRajIgrE5i53BjzrgT5cpGl4wIJhuRbASAu+sbPN2zYsNfatWu35IKUGBFLwHXdM4iItyTE3TKfYq3lx/q5Tx0ViNb6qUT0VUSMCxL9JwA41hjD4XYkFYiAUuqTiPi+GJMfR8Q3ep53V95d67RALgOA2GXRiPhmCbKc90sn3D7XdW8iorhFi7caYxbm3cuOCUQp5SLiaByQxll977fW8osoSQUl4Lruno2jJDiMUmQUFUQ8zfO8z+TZzY4IRGvN8ar4yLA9Y2CUck9Bni+AdtmW8MnWz4noYGvt79plR6v1dkoglwDA6THGPliv198wNjb2YKtOSfl8ENBa834e3tcTlS41xpyRD4v/0Yq2C2RwcPDwxhl/X00A4ARjzHiCfJKlQASUUgYRI5e+O47zutHR0W/m0a22C0RrzY90IzfQIOInPM9LE+cqj0zFpikElFIvQkS+vY4K8PclY0zSbQ4d5dtWgWit3wMAl8Z49G1jzMEd9Voa6ygB13WXNo5p4CeYoQkRhz3PS/KisaO2t00gQ0NDe9Trdf7m2DnGo7caY67rqNfSWMcJxO0UJaLvW2tf1XHDYhpsm0ASbqwZM8ZU8wZF7MmegFLqEESMnGcQUe7esLdFIMHRyhyTaocI1JsR8SDP8yR2VfbXYy5rjItUk8dRpF0CSbLj7AJjzAdz2ZNiVFsI9Pf37zhr1iweRUKDZudtFMlcICeeeOIuM2bM4FEh6jCbH1cqlYNGRkb4NCdJPURAKfVORAyNQpO3USRzgSilzkHEC2L6/FRjzGd76LoQVwMCwSjCX6B8cu+0KU+jSKYC4dW6iPhDIoraJXh/pVJ5uQR5613NaK351vojEQLJzROtrAXCIfQvj+n6s40xHKlPUo8SqFaruzqOw6PIM8MQ5GVFd9YC+Q4A7B/R778PRo/CH5LZo9d2Zm67rnsREYUGluNTdj3P47MVu5oyE4hS6iBE/FaMNx83xjQTkLqrcKTx9hHQWr8MAHgUCdtZ+igA7GWMeaR9VsTXnJlAXNe9gIjOiWhyczB63B9vluToBQJaaw8AdISvJxtjEsVMaxevzASiteZjlPeJMPSzxphT2+WI1Fs8AlrrfgD4QsRkfY21tunzKLMkkYlAguO74oJIH2GMuSVL46WuYhMITtzlO4rQcycdx3nZ6Ojoum55molAlFIXI2LUppf7Gns9Ep0v0S0Q0m53CLiuu5yI3hnWOiJ+wPO8uE1XbTM+E4Forflb4MURQ+VF1tpEwY7b5qlUnEsC1Wp1oeM4oXcWiHi353kHdsv4lgUyODi40Pf9uFunBcaY27vlpLSbbwJaaz67fu8IK19ijPlxN7xoWSAJlpZIdMRu9GyB2tRa81v10IWr3Yx+koVArkPEt0TcXn3EWvuhAvWXmNphAtVq9QDHcUKDyBHRtdZafuLV8dSyQLTWD0et3G3cfh1Yq9Xu7rhn0mChCLiu+9OINXwbjDHP6oZDLQlkaGho33q9HrXh6SFjTGTwsG44LW3mj4DW+moAGI64EznUWvuNTlvekkC01nymYGgQYiIatdYOddopaa94BFzXVURkwixHxAs9z/tApz1rSSAJYh6dZIxJdExXpx2X9vJFYGBg4BmVSoXXX4Wle4wx+3Xa6pYEorV+KOotKBHNt9b+pNNOSXvFJKC15ig4rwmzvlKpzI7bR1StVl/iOA4fVT25qpyP+DNpFz2mFkh/f/+zZs2aFbXSUuYfxbxOu2a11pqDB34swoDI9yEDAwP7VioVPjNxznZ1pI69llogAwMDr61UKlEv/0aMMYu7RlsaLhwB13X3JyLeUzRtQsSjPM9bO90fg1gIv4mY5C+z1p7XLJTUAlFKnYKIofvKEfFdnueFbs5v1lDJXzwCfLvDwTl839+Vre/r66uNjIz8LMyTxrqsnRrrsjZECCT0uAStNR+6tP3IMbWqdcYY3oPSVGpFIJ9GxHenUXtTFkrmQhII5gK8lH37RaqfNMacFeaU1voPYVtxiWjaNX1aa37P9uoYUA83AoVExQeeftRKS18pdQsihp4QxC99rLXr09Yv5YpNQGv9RQA4ZjovEPF6PmnM87x/uCXSWvOu1IOmKzfdG3Wl1Agi8qQ8LqUKkJ16BNFa/xIAnhdmlTEmdd1xnsrf803Add3XNw7G4aj+UWkdIrJIeFL9ZIq54P/uUW+CSf2T9SLiMZ7n8ROtplKqiziIbfR4REvrjTFRoX+aMlIyF4uAUupkRLwygdVbAeDdU2OkxYQE+qMxZlskFKXUm4ORKEEzkPro6VQCqVar+zmO890wy4horbX2qCSWS57yEWjy4mUAT54y1Xi3xisvVkXdmQwNDc2v1+s3JjjSD1q9FtMKJHKTC0B6xZbvcuk9j4aGhub4vr+OiHZpwvub+vr6ltTr9X2ibs/41t113RuJKMmBO3wG4sJW5sKpBKKUOhYRWcHTJjmptonLoqRZtdZvb5wNc0WT7v3EcZxh3/fvjCj3SQBItDs16r1JUrvSCuQERPx8RCNdD9eSFIDkax+BpEd/b2cBNWLz/g4Rmxl9/sGJrN7DpRVI5JnnjeG1v1arXds+9FJzUQgEYUYfaJx2O7ODNqeelG9vY1qBxD2lONwY8/UOApGmck5Aa81LRI7ogJnfMcYckFU7qQSitX4XAPx7mBFBBEUOJCdJCDxJQCl1JiJe1E4kWb+gTisQniTxKVLTpnq9/oKxsbFftBOE1F1MAkqpBYj4dy8Hs/Iki0l5JrdYWmsOwhC6MnLGjBn/tHLlyqgXiVkxkXoKSMB13ecSES9FeUVW5hPRe6y1oXc1adtJNYLEhfqZN2/ejGXLlk2kNUrK9QaBuCMQklJAxC82DoM9Lmn+ZvKlFcgZiHhxREM7p93B1Yzxkrf4BFzXPYmIWong/ldjzI7tIpFKIK7rvoOI/iPMqImJib1Wr14txxy0q9dKVm8wL+GADdv2jTSTsp6UZzIHcV13CRGFBmMIzj8PDQTWDADJ2xsEgnnJZQBwfFKPiWjAWrs6af40+dKOIAMN5dbCGiSio621a9IYJGV6m4DWmp+Oxi4lQcSrG/tJOOxUW1MqgWitWeX/GWYZImrP82xbLZfKS0sgmJfwLXzY2/efG2Ne2AkAaQXCS9mjRghe48/DpSQhkIoAz0scx7mUiPadWgERdfSI6LQCOQwAQk+UIqLzrLXLUpGRQkIgIMDL5uv1+ocBYN9gAeMXjTHXdBJQKoEMDg7O830/ar+5Z4xJsk+4k75KW0KgaQKpBMKtaK2fiDjC905jzCFNWyMFhEDOCLQikHunCemyzT1E/K3nec/Nma9ijhBomkBqgSilIg/OSRJHtWlrpYAQ6DCB1ALRWnMMVY6lOm3yff+ltVrtvg77I80JgUwJpBaIUmoxIq4MsyZtHKJMvZPKhECLBFoRyEGIyFHwwpK8C2mxc6R49wmkFkhcoGEistZa3X0XxQIhkJ5AaoFwk1prPhxnz5DmHzHG7JzeNCkpBLpPoFWBfAoA3hsxUd+/Vqt9r/tuigVCIB2BVgUSt+Tk/dba0L3r6UyWUkKgcwRaEkh/f39l1qxZfHDJ00JM/rox5vDOuSMtCYFsCbQkEDZFKTWGiIvCzHriiSd2u+aaa36VrdlSmxDoDIGWBRJ3Vrrv+0O1Wm20M+5IK0IgWwItC8R13T2JKPSoZ0Rc7XneQLZmS21CoDMEWhYIm+m67l1EFBbu8S+IOH+647Y646K0IgTSE8hEIDGnArF1p049RSi9uVJSCHSWQCYCUUrtg4ihsXhbPeWns0ikNSHw/wQyEQhXp7XmQxtfHwZXVvfKZVdEAlkKJDLiOwCcbYz5eBEhic29SyBLgewOAPw0a0YIzm8bYw7uXdTieREJZCaQ4DaLY2WFRsZrzFPe7Hle6NmGRQQoNpebQNYCiTzCFwBuMcZ04pShcveaeNcxApkKhPeINEaQ/4k6/hcRT/Q8L+oA0I45Lw0JgTgCmQqEG1NKLUNEDvYVlm43xiyIM0z+LgTyQKAdAnmO4zj3xIwiQ57nyfqsPFwBYkMkgcwFknAUyfQkUuljIdAuAu0SSOwoQkRLrbWXt8sxqVcIZEGgLQJJOIr8qq+v7+BVq1bJXpEselLqaAuBdgokdhRBxMs9z1vaFs+kUiGQAYG2CSThKAJEtNBay+u4JAmB3BFoq0C01k8FAA4ut0+E57caYxbmjowYJAQ4EHu7KSilqogYeRybTNjb3QtSf1oCbRdIcKs1joj/EmHkr4joMGtt1KE8aX2UckIgNYGOCERr/erGXpE7Iw7cYQe+ZIw5NrUnUlAItIFARwTCdscdl8B5EPETnueFHqnQBv+lSiEQSaBjAhkeHp67detWnrDPj7KIiAattZ70mxDIA4GOCSSYi8RO2AHgjwBwhDHmnjwAEht6m0BHBRLcap0HAB+KwX7H7Nmzj7jqqqv+t7e7R7zvNoGOCyQQyWoAODHG+XFjzAndBiTt9zaBrghk0aJFO/f19a0FgJeLSHr7Asy7910RSDAfOQQRWST8tj0qyUiS96uoxPZ1TSDBrdYwAFydgO/njTFxt2QJqpEsWRPo7+/fcfbs2acS0VEA8F3f95fXarVfZ91Ot+rrqkDYadd1LyCic+IAENEl1trQ06ziysvfsyeglHoFIi4HgIOm1o6Iu5YlFnPXBRKMJDyK8GgSmYhombWWn4JJ6jIB13WPJKLPAcBzpzHlOmPMW7tsYibN50IgwUhyExG9Kc4rEUkcofb/XWs9xOJAxL6Q1h4zxjy9/Za0v4XcCCQYSfjAz1fFuU1E51lrl8Xlk79nT0ApdRYixoWQLU3MgVwJJBDJLwHgeQm69jJjzLsT5JMsGRHQWl8CAKfHVVemL7DcCSQQyRYAmJmgIywRnVar1R6Lyyt/T0/g5JNPfsqmTZt4vpHkpLBzjTEfTd9avkrmUiCBSH4GAC+Kw0VE3weAD1prvxyXV/7ePAGt9e7BfCP2tOIybnzLrUACkXwBAPqTdCsRfcRaG7fGK0lVkicgoLVm9sz0ZTFQJnzfX1yr1SJ3jhYRbK4FEoiEOyjpo92v+r5/bq1Wu7uInZEXmwcHB+f5vs/vppYksGkDIi72PO+mBHkLlyX3AglEEnc4z1TwvAL4g43HjJcWrjdyYLDW+jR+cYuIuyQwh7dILzbG8G7RUqZCCITJu647SEQjTfTC1wHgYmPMzU2U6dmsruseGKxoODohBN6vw+K4N2H+QmYrjECYbrVaXeg4zkUAsHcTtFcEQvlxE2V6JuvSpUt32Lhx4znBqBH24m97Hnwry3OO0qy5CuvwQgmEnQiWyrNIdBNX8UYA+FSlUrl4ZGRkcxPlSp3Vdd3jglFj/6SOEtG1W7ZsWTw+Pv6XpGWKnK9wApmErZQ6ExFZKM2kH/Ijyy1btqwYHx/f2kzBMuXVWh9PRCch4pFN+MVboc83xlzWRJnCZy2sQFq45eKi6xpv61f4vr+il14yuq77ryyMqOO6Q67o8UAcpZ5vTOd7oQUy5ZbrwoSPJLdn8AALZWJiYuXq1asfLvzXXYgDWmsdjBivbdLH3xPR+dbaK5osV5rshRfIZE+4rnu07/vvQ8RmLwKu4jeIeK3v+2vKFEjbdd0lwYhxYIordiwQBx/t3bOpNAKZ7EGt9emIeGbUEXAxvX0vIq4JxHJHka6MBQsW9O26666HIuKhHDUfEV+Zwn4OA8ujRpKdnimqL1aR0gmE8Qfrh3gS/44Wu4PPWlyDiHfNmTPnG8uXL+dFlLlKAwMDz69UKocCwGEA8EYAeHZaA4lo1Pf988fGxh5MW0fZypVSIJOdpJR6AyKeBgDHZdBxvGL4LkT8luM4t46MjHRtOYtSigNesBj4E7t/JoHvYwDgGWNuSZC3p7KUWiBT5id8yzHEL+Qz7N3HiOhbiLgeEXnl8Xrf93+WVYT6I488coe5c+fOcxxnHgDMQ8RtP4nodQDwlAz84HdDnuM43ujoKK+IljQNgZ4QyJQRhYMMsFD487Q2XhG8RukhDqOKiI8S0aOTP4P/2+T7/lzHcZ5BRHMRcdvPyd9ZDESUZNNYGhdY0N7ExIQ3Njb2izQV9FKZnhLIZMcGq1VZJIv4W7kXOhwR7/Z932NxGGP+2gs+Z+FjTwpkEhw/9dltt92OAYBjiIjPJtkpC6g5qoMfKvD5jywKftknqUkCPS2Qqaxc193J930WyTGIyKJJunCvSeRtz76eiL4CALfX6/Xby/wCtO0kO3FGYSecyLoNvgWr1+uHBy8d+cVju+YDWZl+GwCsYVHIsRFZIf2/emQEScCzWq0e4DjO5LsGFkxsQIkE1baShRcOsiBumjlz5tdWrFjxaCuVSdlwAiKQFFeHUmoBAOzOH0R8weTvIVEGU7QQfHsh/paI7ucPIv7E9/37Hce53xjDoZEkdYCACCRDyP39/TN32GGH3R3H4VuyOb7vz+GfiPh0RNz2OxHxz1lEtNFxHH4XsZGI/sz/5k+lUuH/e6Rer9/fSyuNM+yGTKsSgWSKUyorGwERSNl6VPzJlIAIJFOcUlnZCIhAytaj4k+mBEQgmeKUyspGQARSth4VfzIlIALJFKdUVjYCIpCy9aj4kykBEUimOKWyshEQgZStR8WfTAmIQDLFKZWVjYAIpGw9Kv5kSkAEkilOqaxsBEQgZetR8SdTAiKQTHFKZWUjIAIpW4+KP5kSEIFkilMqKxsBEUjZelT8yZSACCRTnFJZ2QiIQMrWo+JPpgT+BlhPGFCZmD9BAAAAAElFTkSuQmCC';
.icon {
  background-image: url($huanyipi);
  background-size: 100% 100%;
}
.panic-buying-box {
  .exchange {
    display: flex;
    justify-content: center;
    padding: 0 0 30rpx 0;
    .icon {
      width: 24rpx;
      height: 28rpx;
      margin-right: 12rpx;
    }
    text {
      color: #666666;
      font-size: 28rpx;
    }
  }
}
</style>
