<script lang="ts" setup>
// 滚动通知
import { computed } from 'vue'

interface Styles {
  color: string
  backgroundColor: string
  fontSize: string | number
  padding: number
}

interface Attrs {
  dataList: Array<{
    url: string
    text: string
    query: string
  }> // 明确为字符串数组
  list: string[]
  type: 'row' | 'column'
  showIcon: boolean // 使用驼峰命名保持一致
  duration: number
  jumpPath: object
}

const props = withDefaults(
  defineProps<{
    attrs?: Partial<Attrs>
    styles?: Partial<Styles>
  }>(),
  {
    attrs: () => ({}),
    styles: () => ({})
  }
)
// 默认值
const mergedAttrs = computed(() => ({
  dataList: [], // 滚动内容
  list: [],
  type: 'row', // 滚动模式 row-横向滚动，column-竖向滚动
  showIcon: true, // 是否显示左侧的音量图标
  duration: 2, // 滚动间隔时间
  jumpPath: {}, // 跳转路径
  ...props.attrs
}))
// 默认值
const mergedStyles = computed(() => ({
  color: '#F47F02', // 文字颜色
  backgroundColor: '#fff8e7', // 背景颜色
  fontSize: 12, // 字体大小
  padding: 0, // 左右的边距
  ...props.styles
}))
const emit = defineEmits<{
  jump: [item: object]
}>()

const noticeText = computed(() => {
  const { dataList, list } = mergedAttrs.value
  // 优先使用 dataList 的 text 字段，否则使用 list
  const contentList = dataList?.length
    ? dataList.map((item) => item.text)
    : list || []
  return contentList
})
const duration = computed(() => {
  return (mergedAttrs.value?.duration || 2) * 1000
})
const handlerClick = (index: number) => {
  if (!mergedAttrs.value) return

  if (mergedAttrs.value.dataList) {
    const url = mergedAttrs.value.dataList[index]?.url
    const query = mergedAttrs.value.dataList[index]?.query || ''
    if (url) {
      const type = url.includes('/') ? 'link' : 'custom'
      emit('jump', { id: url, type, query })
    }
  } else if (mergedAttrs.value.jumpPath) {
    emit('jump', mergedAttrs.value.jumpPath)
  }
}
</script>

<template>
  <view :style="{ padding: `0 ${mergedStyles.padding}px` }">
    <u-notice-bar
      :text="noticeText"
      :step="mergedAttrs.type === 'row'"
      :direction="mergedAttrs.type"
      :color="mergedStyles.color"
      :bg-color="mergedStyles.backgroundColor"
      :font-size="mergedStyles.fontSize"
      :icon="mergedAttrs.showIcon ? 'volume' : ''"
      :duration="duration"
      @click="handlerClick"
    ></u-notice-bar>
  </view>
</template>

<style lang="scss" scoped></style>
