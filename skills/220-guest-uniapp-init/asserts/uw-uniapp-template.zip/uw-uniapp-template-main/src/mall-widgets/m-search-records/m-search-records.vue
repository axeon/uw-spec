<!-- 历史记录&探索发现 -->
<template>
  <view
    class="m-search-records"
    :style="[wrapStyle(styles), cmpStyle(styles)]"
  >
    <view
      v-if="historyData.length > 0"
      class="history taps"
    >
      <view class="title">
        <view>搜索历史</view>
        <icon
          type="clear"
          @click="showDialog"
        ></icon>
      </view>
      <view class="taps-list">
        <view
          v-for="(item, index) in historyData"
          :key="index"
          class="tipsitem"
          @click="clickHistoryItem(item)"
        >
          {{ item }}
        </view>
      </view>
    </view>
    <view class="recommend taps">
      <view class="title">探索·发现</view>
      <view class="taps-list">
        <view
          v-for="(item, index) in list"
          :key="index"
          class="tipsitem"
          @click="clickRecommendItem(item)"
        >
          {{ item.viewName }}
        </view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { PropsType } from './type'
import { wrapStyle, cmpStyle } from '../utils/registerBaseStyle'

const props = withDefaults(defineProps<PropsType>(), {
  attrs: () => ({
    historyData: []
  }),
  styles: () => ({
    cmpRadius: 0, // 容器圆角
    imgRadius: 0, // 图片圆角
    pagePadding: 20, // 左右边距
    cmpUpperPadding: 10, //	上边距
    cmpLowerPadding: 10, //	下边距
    cmpBackground: 'fff' // 背景色
  }),
  listField: () => ({
    viewId: 'viewId',
    viewName: 'viewName'
  })
})

// 查询历史
const historyData = computed(() => {
  return props.attrs.historyData
})
// 探索·发现
// const recommendData = computed(() => {
//   return props.attrs.recommendData
// })

const emit = defineEmits([
  'clickHistoryItem',
  'clickRecommendItem',
  'clearHistoryData'
])

// 点击查询
const clickHistoryItem = (item: string) => {
  emit('clickHistoryItem', item)
}

// 搜索历史&探索·发现点击事件
const clickRecommendItem = (item: Record<string, string>) => {
  emit('clickRecommendItem', item)
}

// 是否清空记录弹窗
const showDialog = () => {
  uni.showModal({
    title: '清空历史',
    content: '是否清空搜索历史？',
    success: (res) => {
      if (res.confirm) {
        emit('clearHistoryData')
      }
    }
  })
}
</script>
<style lang="scss" scoped>
.m-search-records {
  box-sizing: border-box;
  .taps {
    margin-bottom: 40rpx;
  }
  .title {
    color: #999999;
    font-size: 28rpx;
    margin-bottom: 30rpx;
    display: flex;
    justify-content: space-between;
  }
  .taps-list {
    display: flex;
    flex-wrap: wrap;
    .tipsitem {
      padding: 16rpx 20rpx;
      font-size: 24rpx;
      color: #222222;
      background: #f6f6f6;
      border-radius: 10px;
      margin: 0 20rpx 20rpx 0;
    }
  }
}
</style>
