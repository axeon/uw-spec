export interface PropsType {
  // 参数
  attrs: {
    isAutoplay: boolean // 是否自动轮播
    autoplay: number // 自动轮播速度
    circular: boolean // 是否开启循环播放
    showBgImage: boolean // 是否显示背景图片
  }
  // 样式控制
  styles: {
    marginBottom: number //	下边距
    height: number //	轮播图高度
    width: number //	轮播图宽度
    padding: number //	轮播图内边距
    radius: number //	轮播图圆角
    vertical: boolean //	是否为纵向滚动
    indicatorDots: boolean // 是否显示面板指示点
    indicatorColor: string //	指示器颜色
    indicatorActiveColor: string //	指示器颜色
    backgroundColor: string //	背景颜色
  }
  pathKey?: string // 路径跳转链接
  imgKey?: string // 显示的key字段 用来定义list中要显示的那个字段的值
  list: Record<string, string>[]
}

export interface JumpType {
  id?: string
  type?: string
}
