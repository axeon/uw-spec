<template>
  <!-- 分隔组件 -->
  <view :style="[wrapStyle(styles), cmpStyle(styles)]">
    <view
      class="m-empty-divider"
      :style="{ height: styles.height + 'px' }"
    >
      <view
        v-if="styles.model == 'line'"
        class="m-empty-divider-line"
        :style="[getLineStyle()]"
      ></view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { wrapStyle, cmpStyle } from '../utils/registerBaseStyle'
import type { PropsType } from './type'

const props = withDefaults(defineProps<PropsType>(), {
  styles: () => ({
    model: 'line', // 分割模式
    type: 'solid', // 分割线类型
    pagePadding: 0, // 左右边距
    cmpUpperPadding: 0, // 上边距
    cmpLowerPadding: 0, // 下边距
    height: 20, // 高度
    lineColor: '#E5E5E5', // 分割线颜色
    cmpBackground: '' // cmpBackground
  })
})

const getLineStyle = () => {
  return {
    border: `1px ${props.styles.type} ${props.styles.lineColor}`
  }
}
</script>

<style lang="scss" scoped>
.m-empty-divider {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;

  .m-empty-divider-line {
    width: 100%;
  }
}
</style>
