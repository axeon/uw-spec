/*
 * @Description:
 * @Date: 2024-08-22 11:26:15
 * @LastEditors: niezihao
 * @LastEditTime: 2024-08-28 15:45:03
 * @Author: niezihao
 */
export interface PropsType {
  // 参数
  attrs: {
    rowNumber: number // 行数量
    colNumber: number // 列数量
    menusConfg: string[] // 菜单配置数据
  }
  // 样式控制
  styles: {
    RLpadding: number //	边距
    height: number //	高度
    backgroundColor: string //	背景颜色
  }
  // 替换字段
  listField: {
    logo: string
    name: string
  }
  list: Record<string, string>[]
}
