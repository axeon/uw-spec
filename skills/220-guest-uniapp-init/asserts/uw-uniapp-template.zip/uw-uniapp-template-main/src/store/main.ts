// stores/main.ts
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { I18N } from '@/i18n/i18n.type'
import { name, version } from '../../package.json'
import {
  userCommonInfoSaasOssSite,
  userCommonInfoSysOssSite
} from '@/api/saasBaseAppUserApi'
import { setDayjsLocale } from '@/i18n/dayjsLocale'
import {
  userCommonPaymentListConfig,
  type AisLinkerConfigInfo
} from '@/api/saasFinanceAppGuestApi'

export interface SiteConfig {
  pages: Record<string, any>
  config: Record<string, any>
}

export interface ProjectInfo {
  id?: number //站点ID
  saasId?: number //运营商ID
  siteName?: string //站点名
  siteIcon?: string //站点图标
  siteDesc?: string //站点描述
  mchId?: number //归属人
  areaCode?: number //地区编码
  defaultSite?: number //是否默认站点, 0:否 1:是
  rankOrder?: number //用于排序
  servicePhone?: string //客户电话
  siteConfig?: SiteConfig //页面配置
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态 -1:删除 0:停止使用 1:可以使用
}

export const useMainStore = defineStore(
  'main',
  () => {
    const i18n = ref<I18N>('zh-CN')

    const customHeight = '90rpx'
    const customInputHeight = ref({
      height: customHeight,
      'padding-left': '80rpx',
      'border-radius': '20rpx'
    })
    const customButtonHeight = ref({
      height: customHeight,
      'font-weight': 'bold',
      'border-radius': '20rpx'
    })

    const customProject = ref<ProjectInfo>({})

    // Oss 文件存储域名
    const saasDomain = ref<string>('')
    // 系统文件存储域名 (用在后台系统 内部使用 不是给C端人员的)
    const sysDomain = ref<string>('')
    const saasDomainTime = ref<number>(0)
    const sysDomainTime = ref<number>(0)

    const menuButtonInfo = ref({ top: 0, left: 0, width: 0, height: 0 })
    const statusHeight = ref<number>(0)

    // 登录代理
    const loginAgent = `${name}:${version}`

    // 支付配置列表
    const paymentConfigList = ref<AisLinkerConfigInfo[]>([])

    /* ====== getters：用 computed ====== */
    const isRealWeiXin = computed(() => {
      // #ifdef H5
      return /micromessenger/.test(navigator.userAgent.toLowerCase())
      // #endif
      return false
    })

    const curBrownerLang = computed(() => {
      const sys = uni.getSystemInfoSync()
      if (!sys) return 'zh-CN'
      return sys.language?.replace('_', '-') || sys.language || 'zh-CN'
    })

    const DEV = computed(
      () =>
        (typeof window !== 'undefined' &&
          window.location?.href.includes('192.168.88.21')) ||
        import.meta.env.DEV
    )

    const windowWidth = computed(() =>
      typeof window !== 'undefined' && window.innerWidth
        ? window.innerWidth + 'px'
        : '100vw'
    )
    const windowHeight = computed(() =>
      typeof window !== 'undefined' && window.innerHeight
        ? window.innerHeight + 'px'
        : '100vh'
    )

    /* ====== actions：普通函数 ====== */
    function setI18n(lang: I18N) {
      i18n.value = lang
      setDayjsLocale(lang)
    }

    function setCustomProject(project: ProjectInfo) {
      customProject.value = project
    }

    function setMenuButtonInfo(info: typeof menuButtonInfo.value) {
      menuButtonInfo.value = info
    }

    function setStatusHeight(h: number) {
      statusHeight.value = h
    }

    function formatDomain(v: string) {
      const d = v.startsWith('https://') ? v : 'https://' + v
      return d.endsWith('/') ? d : d + '/'
    }

    function setSaasDomain(v: string) {
      const d = formatDomain(v)
      saasDomain.value = d
    }

    function setSysDomain(v: string) {
      const d = formatDomain(v)
      sysDomain.value = d
    }

    function handleGetUploadDomain() {
      const TTL = 30 * 60 * 1000
      const now = Date.now()
      if (
        saasDomain.value &&
        saasDomainTime.value &&
        now - saasDomainTime.value < TTL
      )
        return

      userCommonInfoSaasOssSite({}).then((res) => {
        setSaasDomain(res.data || '')
        saasDomainTime.value = Date.now()
      })
      userCommonInfoSysOssSite({}).then((res) => setSysDomain(res.data || ''))
    }

    // 获取支付配置
    const handleGetPaymentListConfig = () => {
      userCommonPaymentListConfig().then((res) => {
        console.log('支付配置', res)
        if (res.state === 'success' && res.data) {
          paymentConfigList.value = res.data || []
        } else {
          paymentConfigList.value = []
        }
      })
    }

    /* ====== 统一导出 ====== */
    return {
      // state
      i18n,
      customHeight,
      customInputHeight,
      customButtonHeight,
      customProject,
      menuButtonInfo,
      statusHeight,
      saasDomain,
      sysDomain,
      loginAgent,
      saasDomainTime,
      sysDomainTime,
      paymentConfigList,
      // getters
      isRealWeiXin,
      curBrownerLang,
      DEV,
      windowWidth,
      windowHeight,
      // actions
      setI18n,
      setCustomProject,
      setMenuButtonInfo,
      setStatusHeight,
      setSaasDomain,
      setSysDomain,
      handleGetUploadDomain,
      handleGetPaymentListConfig
    }
  },
  {
    unistorage: true // 开启后对 state 的数据读写都将持久化
  }
)
