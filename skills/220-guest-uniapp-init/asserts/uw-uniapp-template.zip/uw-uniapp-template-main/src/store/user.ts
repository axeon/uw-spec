// stores/user.ts
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { guestUserInfoLoad, type GuestInfoExt } from '@/api/saasMallAppGuestApi'
import type { TokenResponse } from '@/api/saasMallAppOpenApi'
import { name, version } from '../../package.json'
import { setAuthToken, getAuthToken } from '@/utils/auth'
import myManifest from '../manifest.json'
import { defaultSiteInfo } from '@/config/initSiteInfo'
import { userLogout } from '@/api/authUwAuthCenterApiUser'

interface SiteInfo {
  siteId: number
  saasId: number
}
interface ManifestEntry {
  appid: string
}

// 定义 myManifest 的类型
interface MyManifest {
  [key: string]: ManifestEntry
}
type Platform = keyof typeof myManifest

export const useUserStore = defineStore(
  'user',
  () => {
    const loginInfo = ref<TokenResponse>({}) // 登录信息
    const userInfo = ref<GuestInfoExt>({}) // 用户信息
    const siteInfo = ref<SiteInfo>(defaultSiteInfo) // 默认站点信息
    const outSideToken = ref<string>(getAuthToken() || '') // 外部传入的token
    const loginAgent = ref<string>(`${name}:${version}`) // 登录代理标识
    const appId = ref<string>('')
    const currencyCN = ref<string>('')
    const openId = ref<string>('')
    const scene = ref<string>('') // 用户进入的场景值
    const dyVideoId = ref<string>('') // 抖音的视频ID

    /* ---------- getters ---------- */
    const saasId = computed(
      () => loginInfo.value?.saasId || siteInfo.value?.saasId
    )

    /** 是否登录：返回 token 或匿名 token */
    const token = computed(
      () =>
        loginInfo.value?.token ||
        `0$1!0@${loginInfo.value?.saasId || siteInfo.value?.saasId}`
    )

    const refreshToken = computed(() => loginInfo.value?.refreshToken || '')

    /* ---------- actions ---------- */
    function setSiteInfo(info: SiteInfo) {
      siteInfo.value = info
    }

    function setAppId(id?: string) {
      if (!id) {
        const platform = process.env.VUE_APP_PLATFORM as Platform
        const typedManifest = myManifest as unknown as MyManifest
        appId.value = typedManifest[platform].appid
      } else {
        appId.value = id
      }
    }

    /** 设置用户进入的场景值 */
    function setScene(s: any) {
      scene.value = s
    }

    /** 设置抖音视频ID */
    function setDyVideoId(id: any) {
      dyVideoId.value = id
    }

    function setOpenId(id: any) {
      openId.value = id
    }

    /** 设置外部 token */
    function setToken(t: any) {
      setAuthToken(t)
      outSideToken.value = t
    }

    /** 设置登录信息 */
    function setLoginInfo(info: TokenResponse) {
      loginInfo.value = info
    }

    /** 更新 token（保留 refreshToken） */
    function setRefreshTokenInfo(info: {
      createAt: number
      expiresIn: number
      token: string
    }) {
      loginInfo.value = { ...loginInfo.value, ...info }
    }

    /** 设置用户信息（可自动拉取） */
    async function setUserInfo(info?: GuestInfoExt) {
      if (info) {
        userInfo.value = info
        return
      }
      try {
        const res = await guestUserInfoLoad()
        if (res.state === 'success') {
          userInfo.value = res.data || {}
        } else {
          uni.showToast({
            icon: 'none',
            duration: 3000,
            mask: true,
            title: res.msg
          })
        }
      } catch (e: any) {
        uni.showToast({
          icon: 'none',
          duration: 3000,
          title: JSON.stringify(e)
        })
      }
    }

    /** 清除登录缓存 */
    function clearLoginCache() {
      loginInfo.value = {}
      userInfo.value = {}
      const keys = ['loginInfo', 'userInfo']
      keys.forEach((k) => uni.removeStorage({ key: k }))
    }

    /** 退出登录 */
    function LogOut() {
      userLogout({ loginAgent: loginAgent.value }).then(() => {
        clearLoginCache()
        uni.reLaunch({ url: '/pages/login/index' })
      })
    }

    /* ================== 统一导出 ================== */
    return {
      /* state */
      loginInfo,
      userInfo,
      siteInfo,
      outSideToken,
      loginAgent,
      appId,
      currencyCN,
      openId,
      scene,
      dyVideoId,
      /* getters */
      saasId,
      token,
      refreshToken,
      /* actions */
      setSiteInfo,
      setAppId,
      setScene,
      setDyVideoId,
      setOpenId,
      setToken,
      setLoginInfo,
      setRefreshTokenInfo,
      setUserInfo,
      clearLoginCache,
      LogOut
    }
  },
  {
    unistorage: true // 开启后对 state 的数据读写都将持久化
  }
)
