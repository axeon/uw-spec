<template>
  <web-view
    :src="src"
    v-if="show"
  ></web-view>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'

const src = ref<string>('')
const show = ref<boolean>(false)

onLoad((query?: Record<string, any>) => {
  const url = query?.url as string | undefined
  const title = query?.title as string | undefined
  src.value = decodeURIComponent(url || '')

  // 这个定时器是为了防止网址显示不出来
  const time = setTimeout(() => {
    show.value = true
    clearTimeout(time)
  }, 100)

  if (title) {
    uni.setNavigationBarTitle({
      title
    })
  }
})
</script>

<style lang="scss" scoped></style>
