<template>
  <!-- <view class="background" :style="{ backgroundColor: bgColor }"></view> -->
  <scroll-view
    scroll-y
    id="content"
    class="content"
    :style="{
      backgroundColor: pageConfig?.backgroundColor,
      backgroundImage: `url(${pageConfig?.backgroundImage})`,
      backgroundRepeat: 'no-repeat',
      backgroundPosition: `${pageConfig?.backgroundImagePostion} center`,
      backgroundSize: pageConfig?.backgroundImageSize
    }"
  >
    <MSearch
      v-if="pageConfig?.showTopSearch"
      style="pointer-events: none"
    ></MSearch>
    <view style="position: relative">
      <!-- <view class="home-top-bg" v-if="pageConfig?.backgroundImage"
        :style="{ backgroundImage: `url(${pageConfig?.backgroundImage})` }">
      </view> -->
      <vuedraggable
        :list="list"
        item-key="index"
        animation="300"
        @end="setList"
      >
        <template #item="{ element }">
          <widget-shape
            v-if="element"
            :widget="element"
          >
            <render-widget
              :item="toRaw(element)"
              :component-msg="componentMsgList"
              @sendError="sendError"
            ></render-widget>
          </widget-shape>
        </template>
      </vuedraggable>
    </view>
  </scroll-view>
</template>

<script setup>
import { ref, provide, onMounted, toRaw } from 'vue'
import vuedraggable from 'vuedraggable'
import WidgetShape from '@/components/widget-shape.vue'
import RenderWidget from '@/components/render-widget.vue'
import MSearch from '@/schema/m-search/m-search.vue'
// import WidgetShape from './components/widget-shape.vue';
// import RenderWidget from './components/render-widget.vue';
// import domtoimage from 'dom-to-image';
// import useProject from '@/store/modules/project';
import { isEqual } from 'lodash-es'
// const projectStore = useProject();
import { useUserStore } from '@/store/user'
import config from '@/config/common'

const { BASEURL } = config
const userStore = useUserStore()

let pageConfig = ref({})
const curWidgetId = ref('')
const insertIndex = ref(-1)
const list = ref([])
const flag = ref(true)
const waiting = ref({
  id: '-1',
  component: 'waiting'
})
provide('curWidgetId', curWidgetId)
provide('setCurWidgetId', setCurWidgetId)

listeningDom()

// 统一接收平台信息，调用对应方法处理
function getMessage() {
  window.addEventListener('message', (e) => {
    if (e.source !== window.parent) return
    // console.log('log输出的内容：111e.data', e.data)
    if (e.data) {
      let { even, params } = e.data
      if (even === 'init') init(params)

      if (even === 'move') moveWaiting(params)

      if (even === 'drop') addWidget(params)

      if (even === 'list') {
        if (list.value.length === params.length) {
          const newlist = list.value
          for (let i = 0; i < params.length; i++) {
            const flag = isEqual(newlist[i], params[i])
            // console.log(flag)
            if (!flag) {
              list.value[i] = params[i]
            }
          }
        } else {
          list.value = params
        }
        // 更新组件数据
        debouncedHandleContentLoad()
      }

      if (even === 'cover') createCover()

      if (even === 'changeCurrWidget') setCurWidgetId(params.id)
    }
  })
}

// 初始化,同步平台商城配置数据
function init(params) {
  // console.log('params', params.project.config.backgroundColor);
  pageConfig.value = params.curPage
  if (
    pageConfig.value.componentList &&
    pageConfig.value.componentList.length > 0 &&
    import.meta.env.DEV &&
    flag.value
  ) {
    flag.value = false
    list.value = pageConfig.value.componentList
    handleContentLoad()
  }
  // bgColor.value = params.project?.config?.backgroundColor;
  // projectStore.setProject(params.project);
}

// 监听dom变化，传输页面高度给平台
function listeningDom() {
  let MutationObserver =
    window.MutationObserver ||
    window.WebKitMutationObserver ||
    window.MozMutationObserver

  new MutationObserver(debounce(messageHeight, 100)).observe(document.body, {
    attributes: true,
    childList: true,
    subtree: true
  })
}

// 获取页面高度
function messageHeight() {
  list.value.forEach((item) => {
    const widgetElement = document.getElementById(`widget${item.id}`)
    if (widgetElement) {
      const { height } = widgetElement.getBoundingClientRect()
      // console.log('Element height (getBoundingClientRect):', height);
      item.height = height
    } else {
      console.warn(`Element with id #widget${item.id} not found.`)
    }
  })
  window.parent.postMessage(
    { type: 'setHeight', params: toRaw(list.value) },
    '*'
  )
}

function useDebounce(fn, delay = 300) {
  let timer = null
  return function (...args) {
    if (timer) {
      clearTimeout(timer)
    }

    timer = setTimeout(() => {
      fn.apply(this, args)
      timer = null
    }, delay)
  }
}
// 防抖
function debounce(fn, wait) {
  let timer = null
  return () => {
    const args = [...arguments]
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      fn.apply(this, args)
    }, wait)
  }
}

// 移动mating
function moveWaiting(params) {
  let haveWaiting = list.value.find((item) => item.component === 'waiting')

  if (params.type === 'widget') {
    let index = list.value.findIndex((item) => item.id === params.id)
    let watingIndex = list.value.findIndex(
      (item) => item.component === 'waiting'
    )

    if (!haveWaiting) {
      // 没有waiting模块,创建waiting
      list.value.splice(params.direction ? index : index + 1, 0, waiting.value)
    } else {
      // 已有waiting模块，移动waiting
      let isWaiting = list.value[index].component === 'waiting'

      // console.log(`index:${index}`);
      // console.log(`isWaiting:${isWaiting}`);

      if (isWaiting) return

      const temp = list.value.splice(watingIndex, 1)
      let cuurIndex = list.value.findIndex((item) => item.id === params.id)
      insertIndex.value = params.direction ? cuurIndex : cuurIndex + 1
      list.value.splice(insertIndex.value, 0, temp[0])
    }
  } else {
    if (!haveWaiting) {
      list.value.push(waiting.value)
    }
  }
}

// 新增物料
function addWidget(params) {
  let watingIndex = list.value.findIndex((item) => item.component === 'waiting')

  if (watingIndex !== -1) {
    list.value.splice(watingIndex, 1, params)
  } else {
    list.value.push(params)
  }

  setList()
}
// 物料列表变更，通知父容器同步更新
function setList() {
  window.parent.postMessage(
    { type: 'setList', params: { list: toRaw(list.value) } },
    '*'
  )
}
// 渲染组件错误
function sendError() {
  window.parent.postMessage({ type: 'sendError' }, '*')
}

// 设置选中物料
function setCurWidgetId(id) {
  curWidgetId.value = id
  window.parent.postMessage({ type: 'setCurrWidget', params: { id } }, '*')
}

// 创建封面base64,并通知父容器
async function createCover() {
  // let node = document.getElementById('content')
  // let base64 = await domtoimage.toPng(node)
  // window.parent.postMessage({ type: 'getCoverBase64', params: { base64 } }, '*')
}

let requestConfig = ref({}) //请求配置
// let componentList = ref([])
let componentMsgList = ref([])

if (
  uni.getLaunchOptionsSync().query.token &&
  uni.getLaunchOptionsSync().query.token !== 'null'
) {
  // 缓存 防止跳往外部token丢失
  userStore.setToken(uni.getLaunchOptionsSync().query.token)
}
if (
  uni.getLaunchOptionsSync().query.requestConfig &&
  uni.getLaunchOptionsSync().query.requestConfig !== 'null'
) {
  requestConfig.value = JSON.parse(
    uni.getLaunchOptionsSync().query.requestConfig
  )
  // 缓存 防止跳往外部token丢失
  if (requestConfig.value.token) {
    userStore.setToken(requestConfig.value.token)
  }
}

// 页面数据初始化
// const handleInit = () => {
//   const host = requestConfig.value?.host
//     ? decodeURIComponent(requestConfig.value.host)
//     : BASEURL
//   const hearders = requestConfig.value.hearder
//     ? requestConfig.value.hearder
//     : 'Authtoken'
//   uni.request({
//     url: host + '/saas-mall-app/guest/site/cms/listCatalog',
//     data: { catalogType: 1 },
//     header: {
//       [hearders]: userStore.outSideToken
//     },
//     success: (res) => {
//       if (res.statusCode === 200) {
//         if (res.data.data?.results) {
//           componentList.value = res.data.data.results
//         } else {
//           componentList.value = res.data.data[0].children
//         }
//         handleContentLoad()
//       }
//     },
//     fail: (err) => {
//       console.error('接口请求出错:', err)
//     },
//     complete: () => {
//       // 请求完成后，无论成功还是失败，清除当前请求任务标识
//       uni.hideLoading()
//     }
//   })
// }
const deduplicateByKey = (arr, key) => {
  const map = new Map()
  return arr.filter((item) => {
    const value = item[key]
    return !map.has(value) && map.set(value, true)
  })
}
const number = ref(0)
// 组件内容数据
const handleContentLoad = () => {
  // 过滤列表数据
  let catalogIds = [
    ...new Set(
      list.value
        .map((item) => item.options?.catalogId)
        .filter((id) => id !== 0 && id !== undefined && id !== null)
    )
  ]
  if (!catalogIds.length) return
  // console.log('log输出的内容：list.value', list.value)
  const host = requestConfig.value?.host
    ? decodeURIComponent(requestConfig.value.host)
    : BASEURL
  const hearders = requestConfig.value.hearder
    ? requestConfig.value.hearder
    : 'Authtoken'
  uni.request({
    url: host + '/saas-mall-app/guest/site/cms/listInfo',
    data: { state: 1, catalogIds: catalogIds },
    header: {
      [hearders]: userStore.outSideToken
    },
    success: (res) => {
      if (res.statusCode === 200) {
        if (res.data.data?.results) {
          componentMsgList.value = res.data.data.results
        } else {
          componentMsgList.value = res.data.data
        }
        // cms组件处理
        if (list.value && list.value.length) {
          const cmsItem = list.value.find((item) => item.component === 'm-cms')
          if (cmsItem && cmsItem.options && cmsItem.options.catalogId) {
            let cmsList = componentMsgList.value[cmsItem.options.catalogId]
            if (!cmsList && number.value !== 1) return
            number.value = 1
            const inx = list.value.indexOf((item) => item.id === cmsItem.id)
            list.value.splice(inx, 1)
            cmsList = deduplicateByKey(cmsList, 'componentCode')
            const serializableList = cmsList.map((item) => {
              return { ...item }
            })
            window.parent.postMessage(
              {
                type: 'setCms',
                params: { list: serializableList }
              },
              '*'
            )
          }
        }
      }
    },
    fail: (err) => {
      console.error('接口请求出错:', err)
    },
    complete: () => {
      // 请求完成后，无论成功还是失败，清除当前请求任务标识
      uni.hideLoading()
    }
  })
}
const debouncedHandleContentLoad = useDebounce(handleContentLoad, 500)
onMounted(() => {
  getMessage()
})
</script>

<style lang="scss" scoped>
.background {
  position: absolute;
  width: 100%;
  // min-height: 667px;
  height: 100vh;
}

.content {
  max-width: 100vw;
  // height: 100vh;
  min-height: 100vh;
  overflow: auto;
  // padding-bottom: 50px;
}

.home-top-bg {
  position: absolute;
  width: 100%;
  top: -65px;
  height: 180px;
  filter: blur(10px);
  background-size: 110%;
}
</style>
