<script lang="ts" setup>
import { onLoad } from '@dcloudio/uni-app'
import { computed } from 'vue'
import { useUserStore } from '@/store/user'
import { formatParam } from '@/utils/tool'
import { defaultSiteInfo } from '@/config/initSiteInfo'

const userStore = useUserStore()
// 定制页面
const configAppid: Record<string, string> = {
  wxc627db84bc3463e9: '/pages/home/defaultHome?' // 测试定制
}

const appId = computed(() => {
  return userStore.appId
})
interface SiteInfo {
  saasId: number
  siteId: number
}

const handleUrl = (options: any) => {
  for (const key in configAppid) {
    if (appId.value === key) {
      uni.redirectTo({
        url: configAppid[key] + formatParam(options),
        fail: () => {
          uni.switchTab({
            url: configAppid[key] + formatParam(options)
          })
        }
      })
      return
    }
  }
}

const hasCustomJson = (options: any) => {
  let siteInfo: SiteInfo | null = defaultSiteInfo
  // 线上预览参数
  if (options.siteInfo) {
    siteInfo = JSON.parse(options.siteInfo) as SiteInfo
  }
  // 没有站点信息(小程序或者本地测试)
  if (!siteInfo || !siteInfo.siteId) {
    // 是小程序 接口查询站点信息(未开发)
    if (process.env.VUE_APP_PLATFORM !== 'h5') {
      // 查询方法

      // 小程序是否跳转自定义页面
      // const isCustomPage = true
      // 没有站点信息，跳转普通页面
      handleUrl(options)
      return
    } else {
      // 本地测试直接使用默认数据
      // if (import.meta.env.DEV) {
      // siteInfo = JSON.parse('{"siteId":20001,"saasId":655370}') as SiteInfo
      // }
    }
  }
  // 有站点信息，保存站点信息，并且跳转自定义页面
  useUserStore().setSiteInfo(siteInfo)
  uni.redirectTo({
    url: '/template/index',
    fail: () => {
      uni.switchTab({
        url: '/template/index'
      })
    }
  })
}
onLoad((options) => {
  console.log('home options', options)
  // http://192.168.88.21:30300/#/saasMallApp/saas/site/info 由该链接 （saas后台项目 配置而来）
  setTimeout(() => {
    hasCustomJson(options)
  }, 0)
})
</script>
<template>
  <view class="index">
    <view class="loading-container flex-center flex-align">
      <image
        src="../../static/images/loading.gif"
        alt="Loading"
      />
    </view>
  </view>
</template>
<style lang="scss" scoped>
.loading-container {
  height: 100vh;
  background: #ffffff;
  image {
    width: 300rpx;
    height: 293rpx;
  }
}
</style>
