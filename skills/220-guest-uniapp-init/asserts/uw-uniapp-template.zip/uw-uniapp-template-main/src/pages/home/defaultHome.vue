<script lang="ts" setup>
// import { ref, onMounted, computed } from 'vue'
import { onLoad } from '@dcloudio/uni-app'

onLoad((option) => {
  console.log('log输出的内容：option', option)
})
</script>

<template>
  <view class="index">默认首页</view>
</template>

<style lang="scss" scoped></style>
