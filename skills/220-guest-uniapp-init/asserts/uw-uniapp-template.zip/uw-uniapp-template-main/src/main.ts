import pinia from '@/store/index'
import { createSSRApp } from 'vue'
import i18n from './i18n'
import App from './App.vue'
import uviewPlus from 'uview-plus'
import lazyPlugin from 'vue3-lazy'
import imgNone from '@/static/images/imgNone2.png'
import loading from '@/static/images/loading.gif'
import '@/styles/tailwind.css'

export function createApp() {
  const app = createSSRApp(App)
  app.use(pinia).use(i18n()).use(uviewPlus)
  app.use(lazyPlugin, {
    loading: loading,
    error: imgNone
  })
  return {
    app,
    pinia // 此处必须将 Pinia 返回
  }
}
