// h5部署环境才需要
/**
 * 1.如果是开发环境，网关：http://192.168.88.21/18000。
 * 2.如果是带非80/443默认端口号，网关：80： http://域名或主机 443： https://域名或主机 其他的端口就去掉默认取80
 * 3.如果使用域名访问， 用string.split('.')取出第一个值  match主机名以(-dev|-test|-beta|-stag|-prod|-stab|-debug)结尾的情况，
 * 网关名为gw$1。如https://root-pc-ui.jtr.com => https://gw.jtr.com；
 * https://root-pc-ui-dev.jtr.com=>https://gw-dev.jtr.com
 * @param hostname window.location.origin
 * @returns 后台接口地址
 */
const getGatewayUrl = () => {
  // 判断是否是IP的正则
  const ipRegex =
    /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
  // 判断是否为开发环境
  const isDevEnvironment = import.meta.env.DEV
  let baseURL = 'http://192.168.88.21:80'
  // 如果是开发环境，返回固定的IP地址作为网关
  if (isDevEnvironment || location.hostname.includes('192.168.88.21')) {
    const isDebug = uni.getStorageSync('isDebug')
    if (isDebug) {
      baseURL = 'http://192.168.88.21:80'
    }
    return baseURL
    // 带端口访问 或 直接IP访问
  } else if (location.port || ipRegex.test(location.hostname)) {
    // 带端口访问, 采用http
    baseURL = `http://${location.host}`
  } else {
    // 域名访问
    // 匹配主机名以(-dev|-test|-beta|-stag|-prod|-stab|-debug)结尾的情况
    const envPattern = /-dev|-test|-beta|-stag|-prod|-stab|-debug$/i
    const matchResult = location.host.match(envPattern)
    const hostEnd = location.host.split('.').slice(1).join('.')
    // 如果匹配成功，生成对应的gw$1网关URL
    if (matchResult) {
      const env = matchResult[0]
      baseURL = `${location.protocol}//gw${env}.${hostEnd}`
    } else {
      baseURL = `${location.protocol}//gw.${hostEnd}`
    }
  }
  return baseURL
}

const config = {
  // rsa 公钥
  PUBLIC_KEY:
    'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlMYtTE8xBlM4AiwedCJRPEdyMaUA6ZnOovripQzVfZKgG/N846T5KbfnJljlz4QkLXjYUSSxu0+TS26koyHV4fA6WqNzKzDXE0wVJI15eIj6KWuJF0gWwdOwUHJRHZHPH46NX5uqcckY7BW8S6rFxX4Ep7xGy0xT/KqqEoteqHRndX/Idpyg8RcglS4vDkXPz/I4C8bxBnbVKkoYH3M1eTcaIPNRfKKCyGEQOYrpG1OVMJ2yW4Kf5bGOtYAP4ds5DzfpaYTSUjPbteHp7ry+Bp06fH3IY3NRuAU69tJpEIZSX4N9nRbfgieFUFRKMq9/XtPSHxm1AjpABNjvZpXBMQIDAQAB',
  // rsa 私钥
  PRIVATE_KEY: '',
  baseUrl: getGatewayUrl(), // Api请求URL
  appNotifyUrl: '', // 支付回调url
  wxMchId: '', // 微信支付商户ID
  BASEURL: getGatewayUrl()
}

export default config
