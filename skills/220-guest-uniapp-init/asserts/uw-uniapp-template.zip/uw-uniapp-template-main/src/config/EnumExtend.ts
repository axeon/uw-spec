/**
 * 产品限制Key枚举
 */
export enum productLimitKeyEnum {
  /**
   * 销售范围
   */
  SaleRangeLimiter = 'SaleRangeLimiter',
  /**
   * 导入全球货仓
   */
  SaleShareTypeLimiter = 'SaleShareTypeLimiter',
  /**
   * 订单确认
   */
  BookConfirmLimiter = 'BookConfirmLimiter',
  /**
   * 游客资料
   * ProofGuestDataTypeLimiter.guestDataType 直接取值即可 不需要取转二进制后的数据
   */
  ProofGuestDataTypeLimiter = 'ProofGuestDataTypeLimiter',
  /**
   * 销售时间
   */
  SaleTimeLimiter = 'SaleTimeLimiter',
  /**
   * 每日售卖时间
   */
  SaleDailyTimeLimiter = 'SaleDailyTimeLimiter',
  /**
   * 最小预定数量
   */
  BookQuantityLimiter = 'BookQuantityLimiter',
  /**
   * 预定时间
   */
  BookTimeLimiter = 'BookTimeLimiter',
  /**
   * 订单自动取消
   */
  BookCancelLimiter = 'BookCancelLimiter',
  /**
   * 最大预定天数
   */
  BookMaxDayLimiter = 'BookMaxDayLimiter',
  /**
   * 联系人资料
   */
  ProofContactDataTypeLimiter = 'ProofContactDataTypeLimiter',
  /**
   * 游客基本信息
   */
  ProofGuestInfoTypeLimiter = 'ProofGuestInfoTypeLimiter',
  /**
   * 游客证件类型
   */
  ProofGuestPapersTypeLimiter = 'ProofGuestPapersTypeLimiter',
  /**
   * 游客游玩日期限购
   */
  GuestTravelDayLimiter = 'GuestTravelDayLimiter',
  /**
   * 游客预定日期限购
   */
  GuestBookDayLimiter = 'GuestBookDayLimiter',
  /**
   * 产品时间段限购
   */
  GuestTimeRangeLimiter = 'GuestTimeRangeLimiter',
  /**
   * 场次限购
   */
  GuestSessionLimiter = 'GuestSessionLimiter',
  /**
   * 身份证限购
   */
  GuestIdAreaLimiter = 'GuestIdAreaLimiter',
  /**
   * 性别限购
   */
  GuestGenderLimiter = 'GuestGenderLimiter',
  /**
   * 年龄限购
   */
  GuestAgeLimiter = 'GuestAgeLimiter'
}

/**
 * 产品限制Value枚举
 */
export enum productLimitValueEnum {
  /**
   * 销售范围
   */
  SaleRangeLimiter = 0,
  /**
   * 导入全球货仓
   */
  SaleShareTypeLimiter = 1,
  /**
   * 订单确认
   */
  BookConfirmLimiter = 2,
  /**
   * 游客资料
   */
  ProofGuestDataTypeLimiter = 3,
  /**
   * 销售时间
   */
  SaleTimeLimiter = 4,
  /**
   * 每日售卖时间
   */
  SaleDailyTimeLimiter = 5,
  /**
   * 最小预定数量
   */
  BookQuantityLimiter = 6,
  /**
   * 预定时间
   */
  BookTimeLimiter = 7,
  /**
   * 订单自动取消
   */
  BookCancelLimiter = 8,
  /**
   * 最大预定天数
   */
  BookMaxDayLimiter = 9,
  /**
   * 联系人资料
   */
  ProofContactDataTypeLimiter = 10,
  /**
   * 游客基本信息
   */
  ProofGuestInfoTypeLimiter = 11,
  /**
   * 游客证件类型
   */
  ProofGuestPapersTypeLimiter = 12,
  /**
   * 游客游玩日期限购
   */
  GuestTravelDayLimiter = 13,
  /**
   * 游客预定日期限购
   */
  GuestBookDayLimiter = 14,
  /**
   * 产品时间段限购
   */
  GuestTimeRangeLimiter = 15,
  /**
   * 场次限购
   */
  GuestSessionLimiter = 16,
  /**
   * 身份证限购
   */
  GuestIdAreaLimiter = 17,
  /**
   * 性别限购
   */
  GuestGenderLimiter = 18,
  /**
   * 年龄限购
   */
  GuestAgeLimiter = 19
}

// 资料凭证
// 联系人资料
export type ContactFormField =
  | 'name'
  | 'namePinyin'
  | 'gender'
  | 'phoneCN'
  | 'phone'
  | 'email'
export const ContactFormFieldArray: ContactFormField[] = [
  'name',
  'namePinyin',
  'gender',
  'phoneCN',
  'phone',
  'email'
]

// 游客资料
export type GuestFormField =
  | 'name'
  | 'namePinyin'
  | 'gender'
  | 'phoneCN'
  | 'phone'
  | 'address'
  | 'email'
  | 'idType'
  | 'idInfo'
export const GuestFormFieldArray: GuestFormField[] = [
  'name',
  'namePinyin',
  'gender',
  'phoneCN',
  'phone',
  'address',
  'email',
  'idType',
  'idInfo'
]

// 支付类型枚举 key对应支付类型 value对应支付方式
export const PAY_TYPE = {
  // WXPAY: 'PC_QRCODE',
  WXPAY: 'H5',
  // ALIPAY: 'PC_QRCODE',
  ALIPAY: 'H5',
  // ALIPAYHK: 'PC_QRCODE',
  ALIPAYHK: 'H5',
  // VISAPAY: 'PC_WEB',
  VISAPAY: 'H5_WEB',
  // MASTERCARDPAY: 'PC_WEB',
  MASTERCARDPAY: 'H5_WEB',
  // UNIONPAY: 'PC_WEB',
  UNIONPAY: 'H5_WEB',
  // CUPPAY: 'PC_WEB'
  CUPPAY: 'H5_WEB'
}
