export enum TypeAddress {
  /**
   * 正常
   */
  NORMAL = 0,
  /**
   * 默认
   */
  DEFAULT = 1
}

export enum TypeTagParent {
  /**
   * 门票
   */
  TICKET = 'TICKET',
  /**
   * 酒店
   */
  HOTEL = 'HOTEL'
}

export enum StateOrder {
  /**
   * 初始状态
   */
  INIT = 0,
  /**
   * 新订单
   */
  ORDER_NEW = 10,
  /**
   * 已审核
   */
  ORDER_AUDIT = 11,
  /**
   * 下单失败
   */
  ORDER_FAIL = 19,
  /**
   * 支付中
   */
  PAY_DOING = 20,
  /**
   * 支付成功
   */
  PAY_SUCCESS = 21,
  /**
   * 支付超时
   */
  PAY_TIMEOUT = 28,
  /**
   * 支付失败
   */
  PAY_FAIL = 29,
  /**
   * 预定中
   */
  ORDER_BOOKING = 30,
  /**
   * 已确认
   */
  ORDER_CONFIRM = 31,
  /**
   * 已拒单
   */
  ORDER_REJECTED = 39,
  /**
   * 取消审核中
   */
  CANCEL_AUDIT_DOING = 40,
  /**
   * 允许取消
   */
  CANCEL_AUDIT_ALLOW = 41,
  /**
   * 已取消
   */
  CANCEL_SUCCESS = 42,
  /**
   * 订单超时取消
   */
  CANCEL_BY_CHANNEL_TIMEOUT = 47,
  /**
   * 取消失败
   */
  CANCEL_FAIL = 49,
  /**
   * 开始退款
   */
  REFUND_DOING = 50,
  /**
   * 退款成功
   */
  REFUND_SUCCESS = 51,
  /**
   * 退款失败
   */
  REFUND_FAIL = 59,
  /**
   * 发货中
   */
  DELIVERY_DOING = 60,
  /**
   * 已发货
   */
  DELIVERY_SUCCESS = 61,
  /**
   * 已签收
   */
  DELIVERY_DONE = 62,
  /**
   * 发货失败
   */
  DELIVERY_FAIL = 69,
  /**
   * 预约中
   */
  APPOINTMENT_DOING = 70,
  /**
   * 预约成功
   */
  APPOINTMENT_SUCCESS = 71,
  /**
   * 订单离线
   */
  OFFLINE = 76,
  /**
   * 预约失败
   */
  APPOINTMENT_FAIL = 79,
  /**
   * 核销中
   */
  SETTLE_DOING = 90,
  /**
   * 核销完毕
   */
  SETTLE_DONE = 91,
  /**
   * 核销失败
   */
  SETTLE_FAIL = 99
}

export enum TypeProduct {
  /**
   * TICKET
   */
  TICKET = 'TICKET',
  /**
   * PACKAGE
   */
  PACKAGE = 'PACKAGE',
  /**
   * TRAVEL
   */
  TRAVEL = 'TRAVEL',
  /**
   * HOTEL
   */
  HOTEL = 'HOTEL'
}

export enum StateGuestAccount {
  /**
   * 正常
   */
  NORMAL = 1,
  /**
   * 冻结
   */
  FROZEN = 0,
  /**
   * 删除
   */
  DELETE = -1
}

export enum TypeGuestData {
  /**
   * 姓名
   */
  CNAME = 1,
  /**
   * 英语名
   */
  FIRSTNAME = 2,
  /**
   * 英语姓
   */
  LASTNAME = 3,
  /**
   * 性别
   */
  GENDER = 4,
  /**
   * 出生日期
   */
  BIRTHDAY = 5,
  /**
   * 出生地(省份)
   */
  BIRTH_PLACE = 6,
  /**
   * 国家/地区
   */
  COUNTRY_OR_DISTRICT = 7,
  /**
   * 身高（cm）
   */
  HEIGHT = 8,
  /**
   * 体重（kg）
   */
  WEIGHT = 9,
  /**
   * 电话
   */
  PHONE = 10,
  /**
   * 联系电话区号
   */
  PHONE_AREA = 11,
  /**
   * 地址
   */
  ADDRESS = 12,
  /**
   * 邮箱
   */
  EMAIL = 13,
  /**
   * 证件签发日期
   */
  ISSUEDATE = 14,
  /**
   * 证件有效期
   */
  VALIDITY = 15
}

export enum TypeLimitUnit {
  /**
   * 次
   */
  GTE = 0,
  /**
   * 张
   */
  LTE = 1
}

export enum SaasMallResponseCode {
  /**
   * 用户名或密码不能为空！
   */
  ACCOUNT_INFO_LOGIN = 'saas.mall.app.account.info.login',
  /**
   * 邮箱为空
   */
  ACCOUNT_INFO_REGISTRY_EMAIL = 'saas.mall.app.account.info.registry.email',
  /**
   * 邮箱验证码为空！
   */
  ACCOUNT_INFO_REGISTRY_CODE = 'saas.mall.app.account.info.registry.code',
  /**
   * 手机号格式不正确！
   */
  ACCOUNT_INFO_REGISTRY_MOBILE = 'saas.mall.app.account.info.registry.mobile',
  /**
   * 注册失败！
   */
  ACCOUNT_INFO_REGISTRY_RESULT_FAIL = 'saas.mall.app.account.info.registry.result.fail',
  /**
   * 此手机号已被绑定,请直接登录！
   */
  ACCOUNT_INFO_REGISTRY_PHONE_CHECK_FAIL = 'saas.mall.app.account.info.registry.phone.check.fail',
  /**
   * 此电子邮箱已被绑定,请直接登录！
   */
  ACCOUNT_INFO_REGISTRY_EMAIL_CHECK_FAIL = 'saas.mall.app.account.info.registry.email.check.fail',
  /**
   * 邮箱和手机号不能都为空！
   */
  ACCOUNT_INFO_REGISTRY_CHECK_FAIL = 'saas.mall.app.account.info.registry.check.fail',
  /**
   * 用户名不正确！
   */
  ACCOUNT_RESET_PASSWORD_USER_NOT_FOUND = 'saas.mall.app.account.reset.password.user.not.found',
  /**
   * 账号已被冻结！
   */
  ACCOUNT_RESET_PASSWORD_ACCOUNT_FROZEN = 'saas.mall.app.account.reset.password.account.frozen',
  /**
   * 与当前使用的密码一致，请重新输入！
   */
  ACCOUNT_RESET_PASSWORD_DUPLICATE_PASSWORD = 'saas.mall.app.account.reset.password.duplicate.password',
  /**
   * 查询用户异常！
   */
  ACCOUNT_INFO_CHANGE_USER = 'saas.mall.app.account.info.change.user',
  /**
   * 密码错误！
   */
  ACCOUNT_INFO_CHANGE_PASSWORD_FAIL = 'saas.mall.app.account.info.change.password.fail',
  /**
   * 账号已注销！
   */
  ACCOUNT_LOGOFF_ACCOUNT_ALREADY_DEACTIVATED = 'saas.mall.app.account.logoff.account.already.deactivated',
  /**
   * 密码错误！
   */
  ACCOUNT_LOGOFF_PASSWORD_ERROR = 'saas.mall.app.account.logoff.password.error',
  /**
   * 用户登录系统错误！
   */
  ACCOUNT_LOGIN_EXCEPTION = 'saas.mall.app.account.login.exception',
  /**
   * 用户未注册！
   */
  ACCOUNT_LOGIN_UNREGISTERED = 'saas.mall.app.account.login.unregistered',
  /**
   * 用户不存在！
   */
  ACCOUNT_LOGIN_UNAVAILABLE = 'saas.mall.app.account.login.unavailable',
  /**
   * 用户名或密码不正确！
   */
  ACCOUNT_LOGIN_INCORRECT = 'saas.mall.app.account.login.incorrect',
  /**
   * 登录API调用异常！
   */
  ACCOUNT_API_ERROR = 'saas.mall.app.account.api.error',
  /**
   * 未找到指定ID的用户信息！
   */
  USER_INFO_NOT_FOUND = 'saas.mall.app.user.info.not.found',
  /**
   * 用户账号存在交易订单，不可删除！
   */
  ACCOUNT_LOGOFF_ERROR = 'saas.mall.app.account.logoff.error',
  /**
   * 产品不存在！
   */
  PRODUCT_NOT_FOUND = 'saas.mall.app.product.not.found',
  /**
   * 产品[%s]日历库存不足！
   */
  PRODUCT_CALENDAR_STOCK_NOT_ENOUGH = 'saas.mall.app.product.calendar.stock.not.enough',
  /**
   * 产品[%s]总库存不足！
   */
  PRODUCT_STOCK_NOT_ENOUGH = 'saas.mall.app.product.stock.not.enough',
  /**
   * 产品[%s]场次库存不足！
   */
  PRODUCT_SESSION_STOCK_NOT_ENOUGH = 'saas.mall.app.product.session.stock.not.enough',
  /**
   * sku类型错误！
   */
  SKU_TYPE_ERROR = 'saas.mall.app.sku.type.error',
  /**
   * 该日期商品不存在！
   */
  PRODUCT_PRICE_NOT_FOUND = 'saas.mall.app.product.price.not.found',
  /**
   * 该订单已存在申请变更！
   */
  ALREADY_EXIST_APPLY_CHANGE = 'saas.mall.app.already.exist.apply.change',
  /**
   * 找不到订单详情！
   */
  ORDER_DETAIL_NOT_FOUND = 'saas.mall.app.order.detail.not.found',
  /**
   * 找不到订单凭证！
   */
  ORDER_CREDENTIAL_NOT_FOUND = 'saas.mall.app.order.credential.not.found',
  /**
   * 退票数量超出限制！
   */
  REFUND_NUM_OVER_LIMIT = 'saas.mall.app.refund.num.over.limit',
  /**
   * 退票数量不正确！
   */
  INVALID_REFUND_QUANTITY = 'saas.mall.app.invalid.refund.quantity',
  /**
   * 该商品不支持退改！
   */
  PRODUCT_NOT_SUPPORT_REFUND_CHANGE = 'saas.mall.app.product.not.support.refund.change',
  /**
   * 该商品不支持改！
   */
  PRODUCT_NOT_SUPPORT_MODIFY = 'saas.mall.app.product.not.support.modify',
  /**
   * 保存订单失败！
   */
  FAILED_TO_SAVE_THE_ORDER = 'saas.mall.app.failed.to.save.the.order',
  /**
   * 订单详情保存出错！
   */
  FAILED_TO_SAVE_THE_ORDER_DETAIL = 'saas.mall.app.failed.to.save.the.order.detail',
  /**
   * 订单游客信息保存失败！
   */
  FAILED_TO_SAVE_THE_ORDER_GUEST = 'saas.mall.app.failed.to.save.the.order.guest',
  /**
   * 退款申请保存失败！
   */
  FAILED_TO_SAVE_THE_ORDER_CHANGE = 'saas.mall.app.failed.to.save.the.order.change',
  /**
   * 商城订单不存在，订单ID: [%s]
   */
  ORDER_NOT_EXIST = 'saas.mall.app.order.not.exist',
  /**
   * 商城订单状态异常，订单ID:[%s]
   */
  ORDER_STATUS_ERROR = 'saas.mall.app.order.status.error',
  /**
   * 参数错误
   */
  PARAMS_ERROR = 'saas.mall.app.params.error',
  /**
   * 预定数量不能小于最小值
   */
  BOOKING_QUANTITY_MIN_LIMIT = 'saas.mall.app.booking.quantity.min.limit',
  /**
   * 预定数量不能大于最大值
   */
  BOOKING_QUANTITY_MAX_LIMIT = 'saas.mall.app.booking.quantity.max.limit',
  /**
   * 游玩日期超过最大可预定天数
   */
  TRAVEL_DATE_OVER_MAX_DAYS = 'saas.mall.app.travel.date.over.max.days',
  /**
   * 年龄必须大于最小值
   */
  AGE_MIN_LIMIT = 'saas.mall.app.age.min.limit',
  /**
   * 年龄必须小于最大值
   */
  AGE_MAX_LIMIT = 'saas.mall.app.age.max.limit',
  /**
   * 身份证超过购买张数
   */
  ID_QUANTITY_LIMIT = 'saas.mall.app.id.quantity.limit',
  /**
   * 身份证超过购买次数
   */
  ID_FREQUENCY_LIMIT = 'saas.mall.app.id.frequency.limit',
  /**
   * 手机超过购买张数
   */
  PHONE_QUANTITY_LIMIT = 'saas.mall.app.phone.quantity.limit',
  /**
   * 手机超过购买次数
   */
  PHONE_FREQUENCY_LIMIT = 'saas.mall.app.phone.frequency.limit',
  /**
   * 用户性别不符合
   */
  USER_GENDER_MISMATCH = 'saas.mall.app.user.gender.mismatch',
  /**
   * 用户不在包含区域中
   */
  USER_NOT_IN_INCLUDED_REGION = 'saas.mall.app.user.not.in.included.region',
  /**
   * 用户在排除区域中
   */
  USER_IN_EXCLUDED_REGION = 'saas.mall.app.user.in.excluded.region',
  /**
   * 超过场次限购数量
   */
  SESSION_QUANTITY_LIMIT = 'saas.mall.app.session.quantity.limit',
  /**
   * 该时间段内，该商品已售完
   */
  TIME_SLOT_SOLD_OUT = 'saas.mall.app.time.slot.sold.out',
  /**
   * 不在每日售卖时间内
   */
  DAILY_SALE_TIME_NOT_IN = 'saas.mall.app.daily.sale.time.not.in',
  /**
   * 不在销售时间范围内
   */
  SALE_PERIOD_NOT_IN = 'saas.mall.app.sale.period.not.in',
  /**
   * 超过当天可预定时间
   */
  DAILY_BOOKING_TIME_OVER = 'saas.mall.app.daily.booking.time.over',
  /**
   * 支付配置ID错误！
   */
  PAYMENT_CONFIG_ID_ERROR = 'saas.mall.app.payment.config.id.error',
  /**
   * 支付金额错误！
   */
  THE_PAYMENT_AMOUNT_ERROR = 'saas.mall.app.the.payment.amount.error',
  /**
   * 货币代码错误！
   */
  CURRENCY_ERROR = 'saas.mall.app.currency.error',
  /**
   * 处理中，请稍等
   */
  UNDER_PROCESSING = 'saas.mall.app.under.processing'
}

export enum AuthErrorType {
  /**
   * 登录类型不合法!
   */
  LOGIN_TYPE_ERROR = 'AUTH-0001',
  /**
   * 用户类型错误!
   */
  USER_TYPE_ERROR = 'AUTH-0002',
  /**
   * 用户名或密码不能为空!
   */
  LOGIN_INFO_LOST = 'AUTH-0003',
  /**
   * 登录标识[%s]未在系统中注册!
   */
  LOGIN_ID_NOT_EXISTS = 'AUTH-0004',
  /**
   * 登录代理信息丢失!
   */
  LOGIN_AGENT_LOST = 'AUTH-0005',
  /**
   * 用户信息不存在!
   */
  USER_NOT_FOUND = 'AUTH-0010',
  /**
   * 用户名或密码错误!
   */
  USER_OR_PASSWORD_ERROR = 'AUTH-0011',
  /**
   * 用户状态错误!
   */
  USER_STATE_ERROR = 'AUTH-0012',
  /**
   * 用户权限加载错误!
   */
  USER_PERM_LOAD_ERROR = 'AUTH-0013',
  /**
   * 用户权限状态错误!
   */
  USER_PERM_STATE_ERROR = 'AUTH-0014',
  /**
   * SAAS权限加载错误!
   */
  SAAS_PERM_LOAD_ERROR = 'AUTH-0015',
  /**
   * SAAS权限状态错误!
   */
  SAAS_PERM_STATE_ERROR = 'AUTH-0016',
  /**
   * 原密码错误!
   */
  OLD_PASSWORD_ERROR = 'AUTH-0020',
  /**
   * 用户重置密码失败!
   */
  RESET_PASSWORD_ERROR = 'AUTH-0021',
  /**
   * API调用失败!
   */
  API_ERROR = 'AUTH-0022'
}

export enum LockStateOrderInfo {
  /**
   * 锁定订单
   */
  LOCKED_ORDER = 0,
  /**
   * 解锁订单
   */
  UNLOCK_ORDER = 1
}

export enum TypeOrderChange {
  /**
   * 退票
   */
  REFUND = 0,
  /**
   * 改签
   */
  RESCHEDULE = 1
}

export enum TypePoi {
  /**
   * 景区
   */
  SCENIC_AREA = 0,
  /**
   * 酒店
   */
  HOTEL = 1
}

export enum TypeGender {
  /**
   * 男
   */
  MALE = 0,
  /**
   * 女
   */
  FEMALE = 1
}

export enum TypeData {}

export enum TypeOrderLog {
  /**
   * 系统备注
   */
  SYSTEM = 0,
  /**
   * 游客备注
   */
  GUEST = 1,
  /**
   * 供应商备注
   */
  SUPPLIER = 2,
  /**
   * 分销商备注
   */
  DISTRIBUTOR = 3,
  /**
   * 运营商备注
   */
  SAAS = 5
}

export enum TypeAuth {
  /**
   * 删除
   */
  DELETE = 0,
  /**
   * 新增
   */
  SAVE = 1,
  /**
   * 变更
   */
  UPDATE = 2
}

export enum TypeIdPrefix {
  /**
   * 包含
   */
  CONTAIN = 0,
  /**
   * 排除
   */
  EXCLUDE = 1
}

export enum TypeSaleShare {
  /**
   * 是
   */
  YES = 0,
  /**
   * 否
   */
  NO = 1
}

export enum TypeCode {
  /**
   * 数字码
   */
  NUMBER = 1,
  /**
   * 二维码
   */
  QR_CODE = 2,
  /**
   * PDF
   */
  PDF = 3,
  /**
   * 字符码
   */
  CHAR = 4,
  /**
   * 组合码
   */
  MIX = 5
}

export enum TypeCancel {
  /**
   * 不允许取消
   */
  NOT_ALLOW = -1,
  /**
   * 随时取消[不支持部分退]
   */
  ALLOW = 1,
  /**
   * 随时取消[支持部分退]
   */
  ALLOW_PART = 2,
  /**
   * 条件取消[不支持部分退]
   */
  CONDITION = 3,
  /**
   * 条件取消[支持部分退]
   */
  CONDITION_PART = 4,
  /**
   * 只允许改
   */
  MODIFY = 5
}

export enum GuestIdType {
  /**
   * 身份证
   */
  ID_CARD = 0,
  /**
   * 护照
   */
  PASSPORT = 1,
  /**
   * 香港身份证
   */
  HK_CARD = 2,
  /**
   * 澳门身份证
   */
  MACAO_CARD = 3,
  /**
   * 台胞证
   */
  TAIWAN_CARD = 4,
  /**
   * 外国人永久居留证
   */
  FOREIGNER_ID_CARD = 5,
  /**
   * 警官证
   */
  POLICE_OFFICER_CARD = 10,
  /**
   * 军官证
   */
  MILITARY_OFFICER_CARD = 11,
  /**
   * 士兵证
   */
  SOLDIER_CARD = 12,
  /**
   * 外交官证
   */
  DIPLOMATIC_CARD = 13
}

export enum TypeSaleRange {
  /**
   * 同行和直客
   */
  CLIENT_WITH_PEER = 0,
  /**
   * 仅对同行
   */
  INDUSTRY_PEER = 1,
  /**
   * 仅对直客
   */
  INDEPENDENT_CLIENT = 2
}

export enum TypeConfirm {
  /**
   * 手动确认
   */
  MANUAL = 0,
  /**
   * 自动确认
   */
  AUTO = 1
}

export enum StateProduct {
  /**
   * 下架
   */
  PUT_ON_SHELF = 0,
  /**
   * 上架
   */
  REMOVE_FROM_SHELF = 1,
  /**
   * 删除
   */
  DELETE = -1
}

export enum StateGuestCoupon {
  /**
   * 待使用
   */
  TO_BE_USED = 0,
  /**
   * 已使用
   */
  USED = 1,
  /**
   * 已过期
   */
  EXPIRED = 2
}

export enum TypeSendCoupon {
  /**
   * 手动
   */
  MANUAL = 0,
  /**
   * 自动
   */
  AUTOMATIC = 1,
  /**
   * 活动
   */
  ACTIVITY = 2
}

export enum StateOrderVoucher {
  /**
   * 删除
   */
  DELETE = -1,
  /**
   * 未使用
   */
  UNUSED = 1,
  /**
   * 使用中
   */
  IN_USE = 2,
  /**
   * 已失效
   */
  INVALID = 3,
  /**
   * 已过期
   */
  EXPIRED = 4,
  /**
   * 核销中
   */
  SETTLE_DOING = 5,
  /**
   * 退款中
   */
  REFUND_DOING = 8
}

export enum TypeFinPay {
  /**
   * 线下支付
   */
  PAYMENT_OFFLINE = 0,
  /**
   * 在线支付
   */
  PAYMENT_ONLINE = 1,
  /**
   * 预存
   */
  BALANCE_DEPOSIT = 10,
  /**
   * 授信
   */
  BALANCE_CREDIT = 11,
  /**
   * 货仓预存
   */
  STORE_DEPOSIT = 20
}

export enum TypeValidityPeriod {
  /**
   * 游玩日期当天有效
   */
  PLAY_DATE_SAME_DAY = 0,
  /**
   * 预订日期延后N天有效
   */
  BOOKING_DATE_PLUS_N_DAYS = 1,
  /**
   * 预订日期截止到指定日期N有效
   */
  BOOKING_DATE_UNTIL_SPECIFIED_DATE = 2,
  /**
   * 游玩日期延后N天有效
   */
  PLAY_DATE_PLUS_N_DAYS = 3,
  /**
   * 游玩日期截止到指定日期N有效
   */
  PLAY_DATE_UNTIL_SPECIFIED_DATE = 4,
  /**
   * 指定日期N~M有效
   */
  SPECIFIED_DATE_RANGE = 5
}

export enum TypeCodeValidate {
  /**
   * 一码一验
   */
  ONE_TO_ONE = 0,
  /**
   * 一码多验
   */
  ONE_TO_MORE = 1
}

export enum TypeDeductStock {
  /**
   * 支付扣减
   */
  PAY_DEDUCT = 1,
  /**
   * 下单扣减
   */
  ORDER_DEDUCT = 2
}

export enum TypeRebate {
  /**
   * 固定金额
   */
  FIXED = 1,
  /**
   * 利润比例
   */
  PROFIT_PERCENT = 2,
  /**
   * 销售额比例
   */
  SALES_PERCENT = 3
}

export enum StateOrderChange {
  /**
   * 审核中
   */
  AUDITING = 0,
  /**
   * 审核通过
   */
  APPROVE = 1,
  /**
   * 审核拒绝
   */
  REJECT = 2
}

export enum TypeIdType {
  /**
   * 身份证
   */
  ID_CARD = 1,
  /**
   * 游客护照
   */
  PASSPORT = 2,
  /**
   * 港澳通行证
   */
  HM_PERMIT = 3,
  /**
   * 台胞证
   */
  TAIWAN_COMPATRIOT = 4,
  /**
   * 台湾通行证
   */
  TAIWAN_PERMIT = 5,
  /**
   * 军官证
   */
  MILITARY_OFFICER = 6,
  /**
   * 警官证
   */
  POLICE_OFFICER = 7,
  /**
   * 驾驶证
   */
  DRIVING_LICENSE = 8,
  /**
   * 海员证
   */
  SEAMAN_CERTIFICATE = 9,
  /**
   * 港澳台居民居住证
   */
  HMT_RESIDENT_PERMIT = 10,
  /**
   * 外国人永久居留身份证
   */
  FOREIGNER_PERMANENT_ID = 11,
  /**
   * 港澳台居民来往内地通行证
   */
  MAINLAND_TRAVEL_PERMIT = 12,
  /**
   * 学生证
   */
  STUDENT_CARD = 13,
  /**
   * 国民身份证（台湾）
   */
  TAIWAN_NATIONAL_ID_CARD = 14,
  /**
   * 香港永久居民身份证
   */
  HONGKONG_PERMANENT_IDENTITY_CARD = 15,
  /**
   * 香港居民身份证
   */
  HONGKONG_IDENTITY_CARD = 16,
  /**
   * 澳门永久居民身份证
   */
  MACAU_ERMANENT_RESIDENT_IDENTITY_CARD = 17,
  /**
   * 澳门居民身份证
   */
  MACAU_RESIDENT_IDENTITY_CARD = 18,
  /**
   * 户口本(儿童请选择此项)
   */
  HOUSEHOLD_REGISTRATION_BOOK = 19,
  /**
   * 台湾居民来往大陆通行证
   */
  TAIWAN_RETURNING_HOME_CARD = 20,
  /**
   * 香港居民往来内地通行证
   */
  HONG_KONG_RESIDENT_PASS = 21,
  /**
   * 入台证
   */
  ENTER_TAIWAN_ID = 22,
  /**
   * 中华人民共和国旅行证
   */
  PEOPLE_S_REPUBLIC_OF_CHINA_TRAVEL_PERMIT = 23,
  /**
   * 回乡证
   */
  HOMETOWN_ID = 24
}

export enum TypeMallVoucher {
  /**
   * 商家短信
   */
  MCH_SMS = 1,
  /**
   * 商家邮件
   */
  MCH_EMAIL = 2,
  /**
   * 商家电子码
   */
  MCH_CODE = 3,
  /**
   * 二维码
   */
  QR_CODE = 4,
  /**
   * 身份证
   */
  ID_CARD = 5,
  /**
   * 商家订单号
   */
  MCH_ORDER_CODE = 6,
  /**
   * 手机号
   */
  PHONE = 7,
  /**
   * 确认单
   */
  CONFIRMED_LIST = 8,
  /**
   * 陪同单
   */
  ACCOMPANYING_ORDER = 9,
  /**
   * 商家电子票
   */
  MCH_TICKET = 10,
  /**
   * 其它
   */
  OTHER = 99
}

export enum LanguageEnums {
  /**
   * 简体中文
   */
  ZH_CN = '简体中文',
  /**
   * 英语
   */
  EN = '英语',
  /**
   * 繁体中文
   */
  ZH_TW = '繁体中文'
}

export enum TypeLangTop10 {
  /**
   * 简体中文
   */
  ZH_HANS = 'zh-CN',
  /**
   * 繁體中文
   */
  ZH_HANT = 'zh-TW',
  /**
   * English
   */
  EN = 'en',
  /**
   * 日本語
   */
  JA = 'ja',
  /**
   * 한국어
   */
  KO = 'ko',
  /**
   * français
   */
  FR = 'fr',
  /**
   * Deutsch
   */
  DE = 'de',
  /**
   * русский
   */
  RU = 'ru',
  /**
   * español
   */
  ES = 'es',
  /**
   * العربية
   */
  AR = 'ar'
}

export enum TypeLangTop50 {
  /**
   * 简体中文
   */
  ZH_HANS = 'zh-CN',
  /**
   * 繁體中文
   */
  ZH_HANT = 'zh-TW',
  /**
   * English
   */
  EN = 'en',
  /**
   * 日本語
   */
  JA = 'ja',
  /**
   * 한국어
   */
  KO = 'ko',
  /**
   * français
   */
  FR = 'fr',
  /**
   * Deutsch
   */
  DE = 'de',
  /**
   * русский
   */
  RU = 'ru',
  /**
   * español
   */
  ES = 'es',
  /**
   * العربية
   */
  AR = 'ar',
  /**
   * português
   */
  PT = 'pt',
  /**
   * italiano
   */
  IT = 'it',
  /**
   * Nederlands
   */
  NL = 'nl',
  /**
   * svenska
   */
  SV = 'sv',
  /**
   * suomi
   */
  FI = 'fi',
  /**
   * dansk
   */
  DA = 'da',
  /**
   * norsk
   */
  NO = 'no',
  /**
   * polski
   */
  PL = 'pl',
  /**
   * Türkçe
   */
  TR = 'tr',
  /**
   * ελληνικά
   */
  EL = 'el',
  /**
   * čeština
   */
  CS = 'cs',
  /**
   * magyar
   */
  HU = 'hu',
  /**
   * română
   */
  RO = 'ro',
  /**
   * български
   */
  BG = 'bg',
  /**
   * українська
   */
  UK = 'uk',
  /**
   * ไทย
   */
  TH = 'th',
  /**
   * Tiếng Việt
   */
  VI = 'vi',
  /**
   * Bahasa Melayu
   */
  MS = 'ms',
  /**
   * Bahasa Indonesia
   */
  ID = 'id',
  /**
   * हिन्दी
   */
  HI = 'hi',
  /**
   * বাংলা
   */
  BN = 'bn',
  /**
   * தமிழ்
   */
  TA = 'ta',
  /**
   * فارسی
   */
  FA = 'fa',
  /**
   * עברית
   */
  HE = 'he',
  /**
   * Hausa
   */
  HA = 'ha',
  /**
   * Kiswahili
   */
  SW = 'sw',
  /**
   * አማርኛ
   */
  AM = 'am',
  /**
   * Yorùbá
   */
  YO = 'yo',
  /**
   * isiZulu
   */
  ZU = 'zu',
  /**
   * isiXhosa
   */
  XH = 'xh',
  /**
   * Soomaali
   */
  SO = 'so',
  /**
   * Tagalog
   */
  TL = 'tl',
  /**
   * සිංහල
   */
  SI = 'si',
  /**
   * ქართული
   */
  KA = 'ka',
  /**
   * հայերեն
   */
  HY = 'hy',
  /**
   * ދިވެހި
   */
  DV = 'dv',
  /**
   * oʻzbek
   */
  UZ = 'uz',
  /**
   * қазақша
   */
  KK = 'kk',
  /**
   * кыргызча
   */
  KY = 'ky'
}

export enum TypeMallForm {
  /**
   * 不需要游玩人信息
   */
  NONE = 0,
  /**
   * 需要填写每个游客的信息
   */
  ONE_TICKET = 1,
  /**
   * 只需要填写一个游客的信息
   */
  ONE_ORDER = 2
}

export enum TypeAgeRange {
  /**
   * 大于等于
   */
  GTE = 0,
  /**
   * 小于等于
   */
  LTE = 1
}

export enum TypeTemplate {
  /**
   * 邮件
   */
  EMAIL = 0,
  /**
   * 电子
   */
  ELECTRONIC = 1,
  /**
   * 出票短信
   */
  ISSUE_SMS = 2,
  /**
   * 预定短信
   */
  BOOK_SMS = 3
}

export enum TypeLimit {
  /**
   * 预订规则
   */
  BOOK_LIMIT = 0,
  /**
   * 限购规则
   */
  PURCHASE_LIMIT = 1,
  /**
   * 销售规则
   */
  SALE_LIMIT = 2,
  /**
   * 资料凭证
   */
  PROOF_LIMIT = 3
}

export enum StateTag {
  /**
   * 申请
   */
  WAIT = 0,
  /**
   * 同意
   */
  PASS = 1,
  /**
   * 拒绝
   */
  REJECT = 2
}

export enum TypeStock {
  /**
   * 总量
   */
  ALL = 0,
  /**
   * 场次库存
   */
  SESSION = 1,
  /**
   * 规格库存
   */
  SPEC = 2,
  /**
   * 日历库存
   */
  DAILY = 3
}

export enum TypeSku {
  /**
   * 产品
   */
  PRODUCT = 1,
  /**
   * 场次
   */
  SESSION = 2,
  /**
   * 规格
   */
  SPEC = 3
}
