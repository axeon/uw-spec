export const defaultSiteInfo = {
  siteId: 20001, // saas配置站点ID
  saasId: 655370 // saas系统ID
}

// 测试demo
defaultSiteInfo.siteId = 20004
defaultSiteInfo.saasId = 8821909
