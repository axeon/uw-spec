<template>
  <view class="render">
    <m-swiper
      v-if="item.component == 'm-swiper'"
      :id="'widget' + item.id"
      :key="item.id"
      :attrs="item.attrs"
      :styles="item.styles"
      :list="list"
      :pathKey="item.listField.pathKey"
      :imgKey="item.listField.imgKey"
      @jump="handleJump"
    ></m-swiper>

    <m-swiper
      v-if="item.component == 'm-swiper-top'"
      :id="'widget' + item.id"
      :key="item.id"
      :attrs="filterListMsg(item.options, 'm-swiper-top')"
      :styles="item.styles"
      :list="list"
      @jump="handleJump"
    ></m-swiper>

    <m-grid-nav
      v-if="item.component == 'm-grid-nav'"
      :id="'widget' + item.id"
      :key="item.id"
      :data="item"
      :attrs="filterListMsg(item.options, 'm-grid-nav')"
      :styles="item.styles"
      :lists="list"
      @jump="handleJump"
    ></m-grid-nav>

    <m-count-down
      v-if="item.component == 'm-count-down'"
      :id="'widget' + item.id"
      :key="item.id"
      :attrs="item.attrs"
      :styles="item.styles"
    ></m-count-down>

    <m-title
      v-if="item.component == 'm-title'"
      :id="'widget' + item.id"
      :key="item.id"
      :data="{
        ...item,
        attrs: filterListMsg(item.options, 'm-title')
      }"
      @jump="handleJump"
    ></m-title>

    <m-img
      v-if="item.component == 'm-img'"
      :id="'widget' + item.id"
      :key="item.id"
      :styles="item.styles"
      :attrs="filterListMsg(item.options, 'm-img')"
      @jump="handleJump"
    ></m-img>

    <m-img-list
      v-if="item.component == 'm-img-list'"
      :id="'widget' + item.id"
      :key="item.id"
      :styles="item.styles"
      :attrs="filterListMsg(item.options, 'm-img-list')"
      @jump="handleJump"
    ></m-img-list>

    <m-product-list
      v-if="item.component == 'm-product-list'"
      :id="'widget' + item.id"
      :key="item.id"
      :lists="list"
      :styles="item.styles"
      :attrs="filterListMsg(item.options, 'm-product-list')"
      @jump="handleJump"
    ></m-product-list>

    <m-product-list
      v-if="item.component == 'view-list'"
      :id="'widget' + item.id"
      :key="item.id"
      :data="item"
      :listField="listField"
      :list="list"
      @jump="handleJump"
    ></m-product-list>

    <m-progress
      v-if="item.component == 'm-progress'"
      :id="'widget' + item.id"
      :key="item.id"
      :styles="item.styles"
      :attrs="item.attrs"
    ></m-progress>

    <m-empty-divider
      v-if="item.component == 'm-empty-divider'"
      :id="'widget' + item.id"
      :key="item.id"
      :styles="item.styles"
    ></m-empty-divider>

    <m-cap-cube
      v-if="item.component == 'm-cap-cube'"
      :id="'widget' + item.id"
      :key="item.id"
      :styles="item.styles"
      :attrs="item.attrs"
      @jump="handleJump"
    ></m-cap-cube>

    <m-slide-card
      v-if="item.component == 'm-slide-card'"
      :id="'widget' + item.id"
      :key="item.id"
      :styles="item.styles"
      :type="item.attrs.typeStyle"
      :listField="listField"
      :list="list"
      @jump="handleJump"
    ></m-slide-card>
    <m-img
      v-if="item.component == 'm-advert'"
      :id="'widget' + item.id"
      :key="item.id"
      :styles="item.styles"
      :attrs="{
        imagePath: list && list[item.attrs.typeStyle]?.advLogo,
        jumpPath: {
          type: 'link',
          id: list && list[item.attrs.typeStyle]?.advLink
        }
      }"
      @jump="handleJump"
    ></m-img>

    <m-product
      :id="'widget' + item.id"
      :key="item.id"
      v-if="item.component == 'hot-sell'"
      type="slide"
      :item="item"
      :list="list"
      :listField="listField"
      @moreClick="moreClick"
      @jump="handleJump"
    ></m-product>

    <m-product
      :id="'widget' + item.id"
      :key="item.id"
      v-if="item.component == 'panic-buy'"
      type="product"
      :isExchange="true"
      :item="item"
      :list="list"
      :listField="listField"
      @moreClick="moreClick"
      @second-more-click="clickPanicBuying"
      @jump="handleJump"
      @exchange="handlerExchange"
    ></m-product>

    <m-product
      :id="'widget' + item.id"
      :key="item.id"
      v-if="item.component == 'choose-carefully'"
      type="product"
      :item="item"
      :list="list"
      :listField="listField"
      @change="handleChangeSecond"
      @moreClick="moreClick(11, '精挑细选')"
      @jump="handleJump"
    ></m-product>

    <m-product
      :id="'widget' + item.id"
      :key="item.id"
      v-if="item.component == 'hot-views'"
      type="slide"
      :item="item"
      :list="list"
      :listField="listField"
      @moreClick="moreClick"
      @jump="handleJump"
      @more="more"
    ></m-product>

    <m-product
      :id="'widget' + item.id"
      :key="item.id"
      v-if="item.component == 'hot-hotels'"
      type="product"
      :item="item"
      :list="list"
      :listField="listField"
      @moreClick="moreClick"
      @jump="handleJump"
    ></m-product>

    <m-product
      :id="'widget' + item.id"
      :key="item.id"
      v-if="item.component == 'hot-lines'"
      type="product"
      :item="item"
      :list="list"
      :listField="listField"
      @moreClick="moreClick"
      @jump="handleJump"
    ></m-product>

    <m-product
      :id="'widget' + item.id"
      :key="item.id"
      v-if="item.component == 'latest-news'"
      type="product"
      :item="item"
      :list="list"
      :listField="listField"
      @moreClick="moreClick"
      @jump="handleJump"
    ></m-product>

    <m-content-search
      v-if="item.component == 'm-content-search'"
      :id="'widget' + item.id"
      :key="item.id"
      :attrs="item.attrs"
      :styles="item.styles"
    ></m-content-search>

    <m-notice-bar
      v-if="item.component == 'm-notice-bar'"
      :id="'widget' + item.id"
      :key="item.id"
      :attrs="filterListMsg(item.options, 'm-notice-bar')"
      :styles="item.styles"
      @jump="handleJump"
    ></m-notice-bar>

    <m-notice-bar
      v-if="item.component == 'm-notice-bar-list'"
      :id="'widget' + item.id"
      :key="item.id"
      :attrs="filterListMsg(item.options, 'm-notice-bar-list')"
      :styles="item.styles"
      @jump="handleJump"
    ></m-notice-bar>

    <m-cms
      v-if="item.component == 'm-cms'"
      :id="'widget' + item.id"
      :key="item.id"
      :attrs="filterListMsg(item.options, 'm-cms')"
    ></m-cms>

    <m-mp-html
      v-if="item.component == 'm-mp-html'"
      :id="'widget' + item.id"
      :key="item.id"
      :attrs="filterListMsg(item.options, 'm-mp-html')"
      :styles="item.styles"
    ></m-mp-html>

    <m-up
      v-if="item.component == 'm-up'"
      :id="'widget' + item.id"
      :key="item.id"
      :scrollTop="scrollTop"
      :attrs="filterListMsg(item.options, 'm-up')"
      :styles="item.styles"
    ></m-up>

    <m-category-title
      v-if="item.component == 'm-category-title'"
      :id="'widget' + item.id"
      :key="item.id"
      :attrs="filterListMsg(item.options, 'm-category-title')"
      :styles="item.styles"
      @jump="handleJump"
    ></m-category-title>

    <m-search-navbar
      v-if="item.component == 'm-search-navbar'"
      :id="'widget' + item.id"
      :key="item.id"
      :attrs="item.attrs"
      :styles="item.styles"
      @jump="handleJump"
    ></m-search-navbar>

    <waiting-cmp
      v-if="item.component == 'waiting'"
      :id="'widget' + item.id"
      :key="item.id"
    ></waiting-cmp>
  </view>
</template>

<script setup>
import { watch, ref, computed } from 'vue'
// import useUser from '@/store/modules/user
import { useUserStore } from '@/store/user'
import { jump } from '@/utils/global'
import config from '@/config/common'
import { onPageScroll } from '@dcloudio/uni-app'
import waitingCmp from './waiting-cmp/index.vue'

const userStore = useUserStore()
const { BASEURL } = config

const props = defineProps({
  item: {
    type: Object,
    default: () => ({})
  },
  // 组件数据
  componentMsg: {
    type: Object,
    default: () => ({})
  },
  // 是否作为CMS页面处理
  cmsPage: {
    type: Boolean,
    default: false
  }
})
const emit = defineEmits(['sendError'])

// 判断是否广告
const isCustomAdvert = computed(() => {
  return props.item?.options?.isCustomAdvert
})
// 列表组件的接口数据
let list = ref([])
let listField = ref({
  // img: 'iconImg',
  // name: 'infoTitle',
  // describe: 'infoTitle',
  // price: 'price',
  // originalPrice: 'marketPrice',
})
let page = ref(0)
let requestConfig = ref({}) //请求配置
const scrollTop = ref(0) // 页面滚动君
if (
  uni.getLaunchOptionsSync().query.token &&
  uni.getLaunchOptionsSync().query.token !== 'null'
) {
  // 缓存 防止跳往外部token丢失
  userStore.setToken(uni.getLaunchOptionsSync().query.token)
}
if (
  uni.getLaunchOptionsSync().query.requestConfig &&
  uni.getLaunchOptionsSync().query.requestConfig !== 'null'
) {
  requestConfig.value = JSON.parse(
    uni.getLaunchOptionsSync().query.requestConfig
  )
  // 缓存 防止跳往外部token丢失
  if (requestConfig.value.token) {
    userStore.setToken(requestConfig.value.token)
  }
}

let currentRequestTask = null

// 列表组件请求数据的方法，目前是pc那边配置好接口api
const request = (params) => {
  let newParams = { ...params, page: page.value }
  uni.showLoading({
    title: '加载中...'
  })
  // list.value = [];

  const host = requestConfig.value?.host
    ? decodeURIComponent(requestConfig.value.host)
    : BASEURL

  const hearders = requestConfig.value.hearder
    ? requestConfig.value.hearder
    : 'Authtoken'

  currentRequestTask = uni.request({
    url:
      host +
      (isCustomAdvert.value ? props.item.url?.advertUrl : props.item.url?.url),
    data: newParams,
    header: {
      [hearders]: userStore.outSideToken
    },
    success: (res) => {
      if (res.statusCode === 200) {
        if (res.data.data?.results) {
          list.value = res.data.data.results
        } else {
          list.value = res.data.data
        }
        uni.hideLoading()
      }
      if (res.statusCode === 401) {
        setTimeout(() => {
          emit('sendError')
        }, 1500)
      }
    },
    fail: (err) => {
      console.error('接口请求出错:', err)
    },
    complete: () => {
      // 请求完成后，无论成功还是失败，清除当前请求任务标识
      currentRequestTask = null
      uni.hideLoading()
    }
  })
}
const debouncedRequest = useDebounce(request, 300)
watch(
  () => props.item,
  (newVal) => {
    // console.log('newVal', newVal)

    // 如果有正在进行的请求，先取消
    if (currentRequestTask) {
      currentRequestTask.abort()
    }

    // 字段替换
    if (newVal?.listField) {
      listField.value = newVal.listField
    }

    // 接口参数
    let params = newVal.params || {}
    if (isCustomAdvert.value) {
      params =
        Object.assign({}, newVal.options.params, {
          parentCustId:
            userStore.userInfo?.parentCustId || userStore.parentCustId
        }) || {}
    }

    // 接口
    if (newVal.url?.url) {
      // request(params)
      debouncedRequest(params)
    }
  },
  {
    immediate: true
  }
)
function useDebounce(fn, delay = 300) {
  let timer = null
  return function (...args) {
    if (timer) {
      clearTimeout(timer)
    }

    timer = setTimeout(() => {
      fn.apply(this, args)
      timer = null
    }, delay)
  }
}

// const groupByCatalogId = (arr) => {
//   return arr.reduce((result, item) => {
//     const catalogId = item.catalogId
//     if (!result[catalogId]) {
//       result[catalogId] = []
//     }
//     result[catalogId].push(item)
//     return result
//   }, {})
// }
// const deduplicateByKey = (arr, key) => {
//   const map = new Map()
//   return arr.filter((item) => {
//     const value = item[key]
//     return !map.has(value) && map.set(value, true)
//   })
// }
// 需要单独处理的组件(多个数据合并)
const codeList = [
  'm-img-list',
  'm-notice-bar-list',
  'm-mp-html',
  'm-swiper-top',
  'm-category-title',
  'm-grid-nav'
]
// attrs字段合并
const filterListMsg = (attrs, code) => {
  let preAttrs = {}
  let dataList = []
  // let cms = {
  //   cmsList: [],
  //   cmsMsg: {}
  // }

  if (attrs && attrs.catalogId && props.componentMsg[attrs.catalogId]) {
    props.componentMsg[attrs.catalogId].forEach((item) => {
      if (item.componentCode === code) {
        // 单独处理 m-img-list 组件
        // if (code === 'm-img-list') {
        //   dataList.push(JSON.parse(item.componentData))
        //   preAttrs.dataList = dataList
        // } else if (code === 'm-notice-bar-list') {
        //   dataList.push(JSON.parse(item.componentData))
        //   preAttrs.dataList = dataList
        // } else if (code === 'm-mp-html') {
        //   dataList.push(JSON.parse(item.componentData))
        //   preAttrs.dataList = dataList
        // } else if (code === 'm-swiper-top') {
        //   dataList.push(JSON.parse(item.componentData))
        //   preAttrs.dataList = dataList
        // } else {
        //   preAttrs = JSON.parse(item.componentData)
        // }
        if (codeList.includes(code)) {
          dataList.push(JSON.parse(item.componentData))
          preAttrs.dataList = dataList
        } else {
          preAttrs = JSON.parse(item.componentData)
        }
      }
    })
    // if (code === 'm-cms' && props.item.component === 'm-cms') {
    //   const arr = props.componentMsg[props.item.options.catalogId]
    //   if (arr && arr.length) {
    //     cms.cmsMsg = groupByCatalogId(arr)

    //     if (props.cmsPage) {
    //       // CMS 页面模式 - 保持原有逻辑
    //       arr.forEach((it) => {
    //         if (it.componentCode !== 'm-cms') {
    //           cms.cmsList.push({
    //             component: it.componentCode,
    //             options: { catalogId: it.catalogId },
    //             id: it.id,
    //             attrs: JSON.parse(it.componentData)
    //           })
    //         }
    //       })
    //       cms.cmsList = deduplicateByKey(cms.cmsList, 'component')
    //     } else {
    //       // 非 CMS 页面模式 - 返回转换后的组件数据
    //       const firstItem = arr.find((item) => item.componentCode !== 'm-cms')
    //       if (firstItem) {
    //         return {
    //           ...props.item,
    //           component: firstItem.componentCode,
    //           attrs: {
    //             ...JSON.parse(firstItem.componentData),
    //             ...props.item.attrs
    //           }
    //         }
    //       }
    //     }
    //   }
    // }
  }
  // console.log('log输出的内容：结果', {
  //   ...props.item.attrs,
  //   ...preAttrs,
  //   ...props.item.options,
  //   ...cms
  // })
  // return { ...props.item.attrs, ...preAttrs, ...props.item.options, ...cms }
  return { ...props.item.attrs, ...preAttrs, ...props.item.options }
}

const handleJump = (cb) => {
  console.log('点击跳转方法', cb)
  jump(cb)
}
const moreClick = (cb, b, c) => {
  console.log('moreClick', cb, b, c)
}
// 正在抢购点击跟多
const clickPanicBuying = () => {
  uni.navigateTo({
    url: '/product/shoppingrush/index'
  })
}
//
const handleChangeSecond = (item) => {
  if (props.item?.params) {
    console.log(isCustomAdvert.value)

    let params = isCustomAdvert.value
      ? {
          ...props.item.options.params,
          parentCustId:
            userStore.userInfo?.parentCustId || userStore.parentCustId
        }
      : { ...props.item?.params, sort: item.key }
    request(params)
  }
}
// 正在抢购换一批
const handlerExchange = () => {
  page.value++
  let params = isCustomAdvert.value
    ? {
        ...props.item.options.params,
        parentCustId: userStore.userInfo?.parentCustId || userStore.parentCustId
      }
    : props.item?.params || {}
  request(params)
}

const more = () => {
  console.log('more')
}
// 滚动页面
onPageScroll((e) => {
  scrollTop.value = e.scrollTop
})
</script>

<style lang="scss">
.panic-buying-box {
  line-height: 32rpx;
  .exchange {
    display: flex;
    justify-content: center;
    padding: 0 0 30rpx 0;
    background-color: #f6f6f6;
    .icon {
      width: 24rpx;
      height: 28rpx;
      /* background: url('@/assets/exchange.png') no-repeat center; */
      /* background-size: contain; */
      margin-right: 12rpx;
    }
    text {
      color: #666666;
      font-size: 28rpx;
    }
  }
}
</style>
