import CryptoJS from 'crypto-js'

/**
 * @word 要加密的内容
 * @keyWord String  服务器随机返回的关键字
 *  */
export function aesEncrypt(word: string, keyWord = 'XwKsGlMcdPMEhR1B') {
  const key = CryptoJS.enc.Utf8.parse(keyWord)
  const srcs = CryptoJS.enc.Utf8.parse(word)
  const encrypted = CryptoJS.AES.encrypt(srcs, key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  })
  return encrypted.toString()
}

/**
 *
 * @param cipherText 要解密的内容
 * @param passphrase 服务器随机返回的关键字
 * @returns
 */
export const aesDecrypt = (
  cipherText: string,
  passphrase = 'XwKsGlMcdPMEhR1B'
) => {
  const keyBytes = CryptoJS.enc.Utf8.parse(passphrase)
  const bytes = CryptoJS.AES.decrypt(cipherText, keyBytes, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  })
  return bytes.toString(CryptoJS.enc.Utf8)
}
