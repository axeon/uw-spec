// 验证类型答案
export interface VERIFY_TYPE {
  answerData: string
  opTime: number
}
