<script lang="ts" setup>
/**
 * VerifySlide
 * @description 滑块
 * */
import { ref, onMounted, computed, getCurrentInstance } from 'vue'
import { useI18n } from 'vue-i18n'
import defaultImg from '../default.jpg'
import type { CaptchaQuestion } from '@/api/authUwAuthCenterApiAuth'

const { t } = useI18n()

const props = withDefaults(
  defineProps<{
    defaultPadding?: number // 默认左右内边距
    defaultImgWeight: number // 接口默认返回宽高 （px）
    defaultImgHeight: number // 接口默认返回宽高 （px）
    imgSize?: Record<string, string>
    blockSize?: Record<string, string>
    barSize?: Record<string, string>
    jigsawPoint: {
      x: number
      y: number
    }
    resPonCaptcha?: CaptchaQuestion
  }>(),
  {
    defaultPadding: 30,
    defaultImgWeight: 360,
    defaultImgHeight: 140,
    imgSize: () => {
      return {
        width: '360px',
        height: '140px'
      }
    },
    blockSize: () => {
      return {
        width: '50px',
        height: '50px'
      }
    },
    barSize: () => {
      return {
        width: '100%',
        height: '40px'
      }
    }
  }
)

const emits = defineEmits<{
  (e: 'refresh'): void
  (e: 'getCaptchaSign', item: { answerData: string; opTime: number }): void
}>()
const instance = getCurrentInstance() // 获取组件实例

// 请求是否通过
const passFlag = ref(false)
const vSpace = ref(5)
const tipWords = ref('')
const moveBlockLeft = ref()
const leftBarWidth = ref()

// 移动中样式
const moveBlockBackgroundColor = ref('')
const leftBarBorderColor = ref('#dddddd')
// 鼠标状态
const status = ref(false)
// 是否验证完成
const isEnd = ref(false)

const explain = computed(() => {
  return t('SwipeTightToCompleteVerify')
})

const startVerifyTime = ref()
const endVerifyTime = ref()

const opTime = computed(() => {
  return endVerifyTime.value - startVerifyTime.value
})

// const oldR = 50 // 默认 360 * 140 尺寸的 小图片半径为50 （宽高默认是100*100）
// 旋转小图片宽高
const smallImgSize = computed(() => {
  let width = 50
  let height = 50
  // 计算小图片的宽高
  const { screenWidth, windowWidth } = uni.getSystemInfoSync()
  // 定义 新宽度 （设备宽度 - 内边距的宽度）
  const padding = Math.floor(
    (windowWidth! / 750) * Number(props.defaultPadding)
  )
  // debugger
  // const newScreenWidth = screenWidth
  const newScreenWidth = screenWidth! - padding * 2
  width = width * (newScreenWidth / props.defaultImgWeight)
  height = width
  // debugger
  return {
    width,
    height
  }
})
// 旋转小图片定位位置
const smallImgPosition = computed(() => {
  const oldX = props.jigsawPoint.x // 后台返回旧X轴
  const oldY = props.jigsawPoint.y // 后台返回旧Y轴

  let newX = 0
  let newY = 0
  // 根据当前设备像素设置新的X、Y坐标位置
  const { screenWidth, windowWidth } = uni.getSystemInfoSync()
  console.log('screenWidth', screenWidth)
  // 定义 新宽度 （设备宽度 - 内边距的宽度）
  const padding = Math.floor(
    (windowWidth! / 750) * Number(props.defaultPadding)
  )
  // debugger
  // const newScreenWidth = screenWidth
  const newScreenWidth = screenWidth! - padding * 2

  const imgSizeHeight = Number(props.imgSize.height.replace('px', ''))
  newX = oldX * (newScreenWidth / props.defaultImgWeight)
  newY = oldY * (imgSizeHeight / props.defaultImgHeight)
  // debugger

  const left = newX
  const top = newY
  return {
    left: left + 'px',
    top: top + 'px'
  }
})

//鼠标按下
const handleTouchStart = (e: any) => {
  startVerifyTime.value = new Date().getTime() //开始滑动的时间
  if (isEnd.value === false) {
    moveBlockBackgroundColor.value = '#0473BD'
    leftBarBorderColor.value = '#337AB7'
    e.stopPropagation()
    status.value = true
  }
}
// 鼠标移动
const handleTouchMove = (e: any) => {
  let query = uni.createSelectorQuery().in(instance)
  let barArea = query.select('.verify-bar-area')
  let bar_area_left = 0
  let barArea_offsetWidth = 0
  barArea
    .boundingClientRect((data: any) => {
      bar_area_left = Math.ceil(data.left)
      barArea_offsetWidth = Math.ceil(data.width)

      if (status.value && isEnd.value === false) {
        let x = 0
        if (!e.touches) {
          //兼容移动端
          x = Math.ceil(e.clientX)
        } else {
          //兼容PC端
          x = Math.ceil(e.touches[0].pageX)
        }
        let move_block_left = x - bar_area_left //小方块相对于父元素的left值
        // debugger
        //图片滑动
        if (
          move_block_left >=
          barArea_offsetWidth -
            parseInt(String(parseInt(props.blockSize.width) / 2)) -
            2
        ) {
          move_block_left =
            barArea_offsetWidth -
            parseInt(String(parseInt(props.blockSize.width) / 2)) -
            2
        }

        if (move_block_left <= 0) {
          move_block_left = parseInt(
            String(parseInt(props.blockSize.width) / 2)
          )
        }

        //拖动后小方块的left值
        moveBlockLeft.value =
          move_block_left -
          parseInt(String(parseInt(props.blockSize.width) / 2)) +
          'px'
        leftBarWidth.value =
          move_block_left -
          parseInt(String(parseInt(props.blockSize.width) / 2)) +
          'px'
      }
    })
    .exec()
}
// 鼠标松开
const handleTouchEnd = () => {
  endVerifyTime.value = new Date().getTime()
  // 判断是否重合
  if (status.value && isEnd.value === false) {
    //图片滑动
    let moveLeftDistance = parseInt(
      (moveBlockLeft.value || '').replace('px', '')
    )
    moveLeftDistance =
      (moveLeftDistance * props.defaultImgWeight) /
      parseInt(props.imgSize.width)
    //   debugger

    const positionObj = {
      x: moveLeftDistance,
      y: props.jigsawPoint.y
    }

    emits('getCaptchaSign', {
      answerData: JSON.stringify(positionObj),
      opTime: opTime.value
    })
    status.value = false
  }
}

/**
 * 成功回调
 */
const verifySuccessCb = () => {
  // debugger
  moveBlockBackgroundColor.value = '#5cb85c'
  leftBarBorderColor.value = '#5cb85c'
  passFlag.value = true
  tipWords.value = `${(
    (endVerifyTime.value - startVerifyTime.value) /
    1000
  ).toFixed(2)}s验证成功`
  setTimeout(() => {
    tipWords.value = ''
    initVerifyData()
  }, 1000)
  // uni.showToast({
  //   icon: 'none',
  //   title: '验证成功'
  // })
}

/**
 * 失败回调
 */
const verifyErrorCb = () => {
  // debugger
  initVerifyData()
  moveBlockBackgroundColor.value = '#d9534f'
  leftBarBorderColor.value = '#d9534f'
  setTimeout(() => {
    emits('refresh')
  }, 2000)
}

/**
 * 恢复初始变量
 */
const initVerifyData = () => {
  isEnd.value = false
  passFlag.value = false
  moveBlockLeft.value = 0
  leftBarWidth.value = 0
  moveBlockBackgroundColor.value = ''
  leftBarBorderColor.value = '#dddddd'
  isEnd.value = false
}

/**
 * 刷新人机验证码
 */
const handleRefresh = () => {
  moveBlockLeft.value = 0
  leftBarWidth.value = 0
  emits('refresh')
}

onMounted(() => {
  // console.log('verifySlider Com ---')
})
defineExpose({
  verifySuccessCb,
  verifyErrorCb,
  initVerifyData
})
</script>

<template>
  <div class="verify-wrapper flex flex-col items-center justify-center">
    <div
      class="verify-img-out"
      :style="{ height: parseInt(imgSize.height) + vSpace + 'px' }"
    >
      <div
        class="verify-img-panel"
        :style="{ width: imgSize.width, height: imgSize.height }"
      >
        <image
          :src="
            props.resPonCaptcha?.mainImageBase64
              ? 'data:image/png;base64,' + props.resPonCaptcha?.mainImageBase64
              : defaultImg
          "
          style="width: 100%; height: 100%; display: block"
        ></image>
        <div
          class="verify-refresh"
          @click="handleRefresh()"
        >
          <span class="iconfont icon-refresh"></span>
        </div>

        <div
          class="verify-sub-block"
          :style="{
            width: smallImgSize.width + 'px',
            height: smallImgSize.height + 'px',
            top: smallImgPosition.top,
            left: leftBarWidth
          }"
        >
          <image
            :src="
              'data:image/png;base64,' + props.resPonCaptcha?.subImageBase64
            "
            style="width: 100%; height: 100%; display: block"
          ></image>
        </div>
        <transition name="tips">
          <span
            v-if="tipWords"
            class="verify-tips"
            :class="passFlag ? 'suc-bg' : 'err-bg'"
          >
            {{ tipWords }}
          </span>
        </transition>
      </div>
    </div>

    <!-- 公共部分 -->
    <div
      v-if="props.resPonCaptcha?.mainImageBase64"
      class="verify-bar-area"
      :style="{
        width: imgSize.width,
        height: '40px',
        'line-height': '40px'
      }"
    >
      <span class="verify-msg flex-center">{{ explain }}</span>
      <div
        class="verify-left-bar"
        :style="{
          width: leftBarWidth ? leftBarWidth : '40px',
          height: '40px',
          'border-color': leftBarBorderColor
        }"
      >
        <div
          class="verify-move-block"
          @touchstart="handleTouchStart"
          @touchmove="handleTouchMove"
          @touchend="handleTouchEnd"
          :style="{
            width: '40px',
            height: '40px',
            'background-color': moveBlockBackgroundColor,
            left: moveBlockLeft
          }"
        >
          <span
            :class="{
              'verify-icon iconfont icon-right': true,
              'icon-check': passFlag
            }"
          ></span>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.verify-wrapper {
  .verify-img-out {
    .verify-img-panel {
      position: relative;
      border-radius: 8rpx;
      overflow: hidden;
      box-sizing: border-box;
      display: block;

      .verify-sub-block {
        position: absolute;
        text-align: center;
      }
    }

    .verify-tips {
      position: absolute;
      left: 0px;
      bottom: 0px;
      width: 100%;
      height: 30px;
      background-color: rgb(231, 27, 27, 0.5);
      line-height: 30px;
      color: #fff;
      font-size: 24rpx;
      padding-left: 10rpx;
      &.suc-bg {
        background-color: rgba(92, 184, 92, 0.5);
        filter: progid:DXImageTransform.Microsoft.gradient(startcolorstr=#7f5CB85C, endcolorstr=#7f5CB85C);
      }
      &.err-bg {
        background-color: rgba(217, 83, 79, 0.5);
        filter: progid:DXImageTransform.Microsoft.gradient(startcolorstr=#7fD9534F, endcolorstr=#7fD9534F);
      }
    }

    .tips-enter,
    .tips-leave-to {
      bottom: -30px;
    }
    .tips-enter-active,
    .tips-leave-active {
      transition: bottom 0.5s;
    }
  }
}
/*滑动验证码*/
.verify-bar-area {
  position: relative;
  text-align: center;
  box-sizing: border-box;
  background: #e6e7eb;
  border-radius: 8rpx;
  .verify-move-block {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 10;
    background: #ffffff;
    box-sizing: border-box;
    box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.2);
  }
  .verify-move-block:hover {
    background-color: #0473bd;
    color: #ffffff;
  }
  .verify-left-bar {
    position: absolute;
    top: 0px;
    left: 0px;
    background: #f0fff0;
    cursor: pointer;
    box-sizing: border-box;
  }
  .verify-msg {
    color: #88949d;
  }
}
</style>
