<script lang="ts" setup></script>

<template>
  <view class="loading">
    <view></view>
    <view></view>
    <view></view>
    <view></view>
    <view></view>
    <view></view>
    <view></view>
    <view></view>
  </view>
</template>

<style lang="scss" scoped>
.loading,
.loading > view {
  position: relative;
  box-sizing: border-box;
}

.loading {
  display: block;
  font-size: 0;
  color: #f47f02;
}

.loading.la-dark {
  color: #ee9a3f;
}

.loading > view {
  display: inline-block;
  float: none;
  background-color: currentColor;
  border: 0 solid currentColor;
}

.loading {
  width: 36rpx;
  height: 36rpx;
}

.loading > view {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 8rpx;
  height: 8rpx;
  margin-top: -4rpx;
  margin-left: -4rpx;
  border-radius: 100%;
  animation: ball-spin-clockwise-fade 1s infinite linear;
}

.loading > view:nth-child(1) {
  top: 5%;
  left: 50%;
  animation-delay: -0.875s;
}

.loading > view:nth-child(2) {
  top: 18.1801948466%;
  left: 81.8198051534%;
  animation-delay: -0.75s;
}

.loading > view:nth-child(3) {
  top: 50%;
  left: 95%;
  animation-delay: -0.625s;
}

.loading > view:nth-child(4) {
  top: 81.8198051534%;
  left: 81.8198051534%;
  animation-delay: -0.5s;
}

.loading > view:nth-child(5) {
  top: 94.9999999966%;
  left: 50.0000000005%;
  animation-delay: -0.375s;
}

.loading > view:nth-child(6) {
  top: 81.8198046966%;
  left: 18.1801949248%;
  animation-delay: -0.25s;
}

.loading > view:nth-child(7) {
  top: 49.9999750815%;
  left: 5.0000051215%;
  animation-delay: -0.125s;
}

.loading > view:nth-child(8) {
  top: 18.179464974%;
  left: 18.1803700518%;
  animation-delay: 0s;
}

.loading.la-sm {
  width: 16rpx;
  height: 16rpx;
}

.loading.la-sm > view {
  width: 4rpx;
  height: 4rpx;
  margin-top: -2rpx;
  margin-left: -2rpx;
}

.loading.la-2x {
  width: 64rpx;
  height: 64rpx;
}

.loading.la-2x > view {
  width: 16rpx;
  height: 16rpx;
  margin-top: -8rpx;
  margin-left: -8rpx;
}

.loading.la-3x {
  width: 96rpx;
  height: 96rpx;
}

.loading.la-3x > view {
  width: 24rpx;
  height: 24rpx;
  margin-top: -12rpx;
  margin-left: -12rpx;
}

@keyframes ball-spin-clockwise-fade {
  50% {
    opacity: 0.25;
    transform: scale(0.5);
  }

  100% {
    opacity: 1;
    transform: scale(1);
  }
}
</style>
