<script lang="ts" setup>
import { ref, onMounted, watch } from 'vue'
import LoopLoading from './components/LoopLoading.vue'

const props = withDefaults(
  defineProps<{
    modelValue: boolean // 是否loading
  }>(),
  {
    modelValue: false
  }
)

const emits = defineEmits<{
  (e: 'update:modelValue', bool: boolean): void
}>()

const isActive = ref(props.modelValue)

watch(
  () => props.modelValue,
  async (value: boolean) => {
    isActive.value = value
    emits('update:modelValue', value)
  }
)

onMounted(() => {
  // console.log('GbLoading Com ---')
})
</script>

<template>
  <view name="fade">
    <view
      class="mask"
      v-show="isActive"
    >
      <view class="spinner flex-col flex-align">
        <h1 class="logo"></h1>
        <LoopLoading class="m-t-32" />
      </view>
    </view>
  </view>
</template>

<style lang="scss" scoped>
.mask {
  touch-action: none; // 禁止拖动、平滑、缩放等等
  width: 100%;
  height: 100vh;
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  z-index: 998;
  background: #fff;
  .spinner {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    .logo {
      width: 160rpx;
      height: 120.52rpx;
    }
  }
}
</style>
