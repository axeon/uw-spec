<template>
  <!-- 弹窗组件 -->
  <view
    class="z-popup"
    @catchtouchmove.stop="handlemove"
    :style="{ zIndex: zIndex }"
  >
    <!-- 遮罩层 -->
    <view
      :class="{
        overlay: overlay,
        show: modelValue
      }"
      @click.stop="handleOverlay"
    ></view>

    <!-- 弹窗内容 -->
    <view
      :class="['z-popup-box', position]"
      :animation="animationOverlay"
    >
      <!-- 关闭按钮 -->
      <view
        class="closeable"
        v-if="closeable"
        @click.stop="handleOverlay"
      >
        <u-icon
          name="close"
          color="#666666"
          size="28"
        ></u-icon>
      </view>

      <!-- 主要内容区域 -->
      <view>
        <view class="book-container">
          <view class="book-desc-title1 flex-center">{{ shareTitle }}</view>
          <view class="item-desc-tip">
            选择图片（{{ imageUrlList.length }}/{{ file.length }}）
          </view>
          <view class="image-box">
            <view class="image-list">
              <checkbox-group @change.stop="checkboxChange">
                <view
                  class="item-image-box"
                  v-for="(item, index) in file"
                  :key="index"
                >
                  <view
                    class="item-checkbox"
                    style="border-radius: 50%"
                  >
                    <checkbox
                      class="select-checkbox"
                      :disabled="index === 0"
                      style="transform: scale(0.9)"
                      :value="item.img_url"
                      :checked="item.checked"
                    />
                  </view>
                  <view @click.stop="toPreview(item.img_url)">
                    <image
                      class="item-image"
                      mode="aspectFill"
                      :src="item.img_url"
                    />
                  </view>
                </view>
              </checkbox-group>
            </view>
          </view>
        </view>

        <!-- 操作按钮区域 -->
        <view class="operate-btn-box">
          <view class="item-desc">{{ issuedNum }}人已发圈</view>
          <view class="btn-box">
            <button
              class="item-btn share-btn"
              open-type="share"
              @click.stop
              :data-productno="infoId"
              :data-infotitle="shareTitle"
              :data-signimg="signImg"
            >
              直接分享
            </button>
            <button
              class="item-btn save-btn"
              @click.stop="toSavaImageAndCopyText"
            >
              一键发圈
            </button>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { ref, computed, watch, onMounted } from 'vue'
import { prodMaterial, materialHandle } from '@/api/text'

// 定义接口
interface FileItem {
  img_url: string
  checked: boolean
}

interface Props {
  // 显示/隐藏
  modelValue?: boolean
  // 遮罩层
  overlay?: boolean
  // 位置 top bottom right left
  position?: string
  // 关闭图标
  closeable?: boolean
  // 是否点击遮罩层后关闭
  closeOnClickOverlay?: boolean
  // 层级
  zIndex?: number
  infoId?: string
  isShowModal?: boolean
  signImg?: string
}

// 定义props
const props = withDefaults(defineProps<Props>(), {
  modelValue: false,
  overlay: true,
  position: 'center',
  closeable: false,
  closeOnClickOverlay: true,
  zIndex: 1999,
  isShowModal: false,
  infoId: '',
  signImg: ''
})

// 定义emit事件
const emit = defineEmits(['update:modelValue', 'closed'])

// 响应式数据
const animationOverlay = ref({})
const shareTitle = ref('')
const issuedNum = ref('')
const imageUrlList = ref<string[]>([])
const file = ref<FileItem[]>([])
const newImageList = ref<string[]>([])
const schedule = ref(false)
const percent = ref(0)

// 计算属性
const directionShow = computed(() => {
  const obj: Record<string, string> = {
    top: 'translateY',
    bottom: 'translateY',
    right: 'translateX',
    left: 'translateX',
    center: ''
  }
  return obj[props.position]
})

const directionHide = computed(() => {
  const obj: Record<string, string> = {
    top: '-100%',
    bottom: '100%',
    right: '100%',
    left: '-100%',
    center: '0, 0'
  }
  return obj[props.position]
})

// 监听modelValue变化
watch(
  () => props.modelValue,
  (newVal, oldVal) => {
    if (newVal !== oldVal && newVal) {
      showAnimation()
      return
    }
    if (newVal !== oldVal && !newVal) {
      hideAnimation()
    }
  }
)

// 显示弹窗
const showModal = async () => {
  imageUrlList.value = []
  uni.showLoading({
    title: '加载中...'
  })

  try {
    // 获取图片列表，文字
    const res: any = await prodMaterial({
      productId: props.infoId,
      isNews: 0
    })

    if (res.state === 1) {
      uni.hideLoading()
      emit('update:modelValue', true)
      issuedNum.value = res.data.issuedNum
      newImageList.value = res.data.imgMaterials
      shareTitle.value =
        res.data.productTitle + ' 预订网址：' + res.data.bookWebsite

      const roots = res.data.imgMaterials.map((item: any, index: number) => {
        return {
          img_url: item,
          checked: index === 0
        }
      })

      file.value = roots
      imageUrlList.value = [res.data.imgMaterials[0]]
    } else {
      uni.showToast({
        title: res.msg,
        icon: 'none',
        mask: true,
        duration: 2500
      })
    }
  } catch (error) {
    console.error('获取素材失败:', error)
    uni.showToast({
      title: '获取素材失败',
      icon: 'none'
    })
  }
}

// 阻止触摸移动事件
const handlemove = () => {
  return true
}

// 点击遮罩层
const handleOverlay = () => {
  if (props.closeOnClickOverlay) {
    emit('update:modelValue', false)
  }
}
type AnimationMethod =
  | 'translateX'
  | 'translateY'
  | 'translateZ'
  | 'scale'
  | 'rotate'
  | 'opacity'
  | 'backgroundColor'
// 显示动画
const showAnimation = () => {
  const animation: any = uni.createAnimation({
    duration: 200,
    timingFunction: 'linear'
  })

  if (directionShow.value) {
    const method = directionShow.value as AnimationMethod
    const animationInstance = animation[method] as (value: number) => any
    animationInstance(0).step()
  }

  animationOverlay.value = animation.export()
}

// 隐藏动画
const hideAnimation = () => {
  const animation: any = uni.createAnimation({
    duration: 200,
    timingFunction: 'linear'
  })

  if (directionShow.value) {
    const method = directionShow.value as AnimationMethod
    const animationInstance = animation[method] as (value: any) => any
    animationInstance(directionHide.value).step()
  }

  animationOverlay.value = animation.export()
  // 抛出隐藏事件
  emit('closed')
}

// 保存图片和复制文本
const toSavaImageAndCopyText = () => {
  emit('update:modelValue', false)

  // 复制文字
  uni.setClipboardData({
    data: shareTitle.value,
    success: () => {
      console.log('复制成功')
    }
  })

  // 转换图片域名并且下载图片
  materialHandle(imageUrlList.value).then((res: any) => {
    if (res.state === 1) {
      getsave(0, imageUrlList.value.length, res.data)
    } else {
      uni.showToast({
        title: res.msg,
        icon: 'none',
        mask: true,
        duration: 2500
      })
    }
  })
}

// 下载图片到本地相册
const getsave = (i: number, length: number, imageList: string[]) => {
  uni.showLoading({
    title: `下载中(${i + 1}/${length})`
  })

  const downloadTask = uni.downloadFile({
    url: imageList[i],
    success: (res) => {
      uni.saveImageToPhotosAlbum({
        filePath: res.tempFilePath as string,
        success: () => {
          if (i + 1 === length) {
            uni.showToast({
              title: '保存成功'
            })
            imageUrlList.value = []
          }
          uni.hideLoading()
          if (++i < length) {
            getsave(i, length, imageList)
          }
        },
        fail: (err: any) => {
          if (
            err.errMsg === 'saveImageToPhotosAlbum:fail:auth denied' ||
            err.errMsg === 'saveImageToPhotosAlbum:fail auth deny' ||
            err.errMsg === 'saveImageToPhotosAlbum:fail authorize no response'
          ) {
            // 需要授权保存相册
            uni.showModal({
              title: '提示',
              content: '需要您授权保存相册',
              showCancel: false,
              success: () => {
                uni.openSetting({
                  success: (settingdata: any) => {
                    if (settingdata.authSetting['scope.writePhotosAlbum']) {
                      uni.showModal({
                        title: '提示',
                        content: '获取权限成功,再次点击图片即可保存',
                        showCancel: false
                      })
                    } else {
                      uni.showModal({
                        title: '提示',
                        content: '获取权限失败，将无法保存到相册哦~',
                        showCancel: false
                      })
                    }
                  }
                })
              }
            })
          } else {
            uni.showToast({
              title: '保存图片失败',
              icon: 'none'
            })
          }
        }
      })
    }
  })

  // 下载进度
  downloadTask.onProgressUpdate((res: any) => {
    console.log(res)
    if (res.progress > 0) {
      schedule.value = true
      percent.value = res.progress
    }
    if (res.progress === 100) {
      schedule.value = false
    }
  })
}

// 图片预览
const toPreview = (imgUrl: string) => {
  uni.previewImage({
    current: imgUrl,
    urls: newImageList.value
  })
}

// 图片选中与取消选中
const checkboxChange = (e: any) => {
  const items = file.value
  const values = e.detail.value
  imageUrlList.value = values
  // 更新选中状态
  for (let i = 1, lenI = items.length; i < lenI; ++i) {
    const item = items[i]
    if (values.includes(item.img_url)) {
      item.checked = true
    } else {
      item.checked = false
    }
  }
}

// 组件创建时调用
onMounted(() => {
  showModal()
})
</script>

<style lang="scss" scoped>
.book-container {
  position: relative;
  margin: 0 auto;
  margin-bottom: 60px;
  max-height: 70vh;
  overflow: auto;
  padding: 0 12px;
  .book-desc-title1 {
    padding: 15rpx 0;
    font-size: 16px;
  }
  .item-desc-tip {
    font-size: 14px;
    line-height: 32rpx;
    color: #707070;
  }
  .image-box {
    width: 100%;
    .item-image-box {
      display: inline-block;
      width: 33.3%;
      box-sizing: border-box;
      padding: 10rpx;
      position: relative;
      .item-image {
        width: 100%;
        height: 150rpx;
      }
      .item-checkbox {
        position: absolute;
        right: 0;
        top: 4px;
      }
    }
  }
}

.operate-btn-box {
  width: 100%;
  box-sizing: border-box;
  padding: 5rpx 20rpx;
  position: absolute;
  bottom: 20rpx;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .item-desc {
    font-size: 14px;
    line-height: 32rpx;
    color: #666666;
  }
  .btn-box {
    display: flex;
    justify-content: space-between;
    align-items: center;
    .item-btn {
      border-radius: 30rpx;
      color: #fff;
      padding: 10rpx 20rpx;
      font-size: 14px;
    }
    .share-btn {
      margin-right: 10rpx;
      background-color: #4c7acc;
    }
    .save-btn {
      background-color: #e66744;
    }
    button {
      line-height: unset;
    }
  }
}

.z-popup {
  .overlay {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 100000;
    transition: 300ms;
    &.show {
      width: 100vw;
      height: 100vh;
      background-color: rgba(0, 0, 0, 0.4);
    }
  }
  .z-popup-box {
    position: fixed;
    z-index: 100001;
    max-height: 80vh;
    border-radius: 25rpx;
    background-color: #fff;
    &.top,
    &.left {
      top: 0;
      left: 0;
    }
    &.top {
      width: 100vw;
      transform: translateY(-100%);
      overflow-y: scroll;
    }
    &.left {
      height: 100vh;
      transform: translateX(-100%);
      overflow-x: scroll;
    }
    &.bottom,
    &.right {
      bottom: 0;
      right: 0;
    }
    &.bottom {
      width: 100vw;
      transform: translateY(100%);
      overflow-y: scroll;
    }
    &.right {
      height: 100vh;
      transform: translateX(100%);
      overflow-x: scroll;
    }
    &.center {
      width: 90vw;
      height: 80vh;
      top: 45%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
    .closeable {
      position: absolute;
      top: 16rpx;
      right: 20rpx;
      z-index: 100002;
    }
  }
}
</style>
