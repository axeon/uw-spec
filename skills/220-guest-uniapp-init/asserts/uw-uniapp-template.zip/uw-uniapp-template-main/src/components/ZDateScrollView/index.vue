<script lang="ts" setup>
import dayjs from 'dayjs'
import { computed, reactive, ref } from 'vue'
import { useI18n } from 'vue-i18n'

const props = withDefaults(
  defineProps<{
    modelValue: string // 当前高亮日期
  }>(),
  {
    modelValue: dayjs().format('YYYY-MM-DD')
  }
)
const emits = defineEmits<{
  (e: 'update:modelValue', date: string): void
  (e: 'change', date: string): void
}>()

const { t } = useI18n()

// const curTravelId = ref<string>('today')
const isShowCalendar = ref<boolean>(false)
// 出发日期
const curTravelDate = computed({
  get() {
    return props.modelValue
  },
  set(val) {
    // console.log('set', val)
    emits('update:modelValue', val)
  }
})

interface DateItem {
  id: string
  title: string
  sub?: string
  value?: string // 传给 dayjs 的字符串
}

const today = dayjs().locale('zh-cn')
const tomorrow = today.add(1, 'day')
const theDayAfterTomorrow = today.add(2, 'day')

/* 静态列表 */
const dateList = reactive<DateItem[]>([
  {
    id: 'today',
    title: '今天',
    // sub: today.format('MM月DD日'),
    value: today.format('YYYY-MM-DD')
  },
  {
    id: 'tomorrow',
    title: '明天',
    // sub: tomorrow.format('MM月DD日'),
    value: tomorrow.format('YYYY-MM-DD')
  },
  {
    id: 'dec3',
    title: theDayAfterTomorrow.format('MM月DD日'),
    value: theDayAfterTomorrow.format('YYYY-MM-DD')
  },
  { id: 'all', title: '所有日期' }
])

/* 点击 item */
function onSelect(item: DateItem) {
  if (item.id === 'all') {
    // 打开日历
    isShowCalendar.value = true
    return
  } else {
    // 点击三日内日期 将all属性date还原为所有日期展示
    const target = dateList.find((i) => i.id === 'all')!
    target.title = t('所有日期')
  }
  // curTravelId.value = item.id
  curTravelDate.value = item.value as string
  emits('change', curTravelDate.value)
}

/* 日历选中回调 */
function onConfirm(e: any) {
  isShowCalendar.value = false
  const date = e[0] // 单选模式直接取第一项
  const target = dateList.find((i) => i.id === 'all')!
  // 是否在今天，明天，后天 三天内
  const findItem = dateList.find((item) => item.value === date)
  if (findItem?.value === date) {
    // curTravelId.value = findItem!.id!
    curTravelDate.value = date
    target.title = t('所有日期')
    emits('change', curTravelDate.value)
    return
  }
  /* 手动把“所有日期”显示成选中的日期 */
  target.title = t('选中日期') + dayjs(date).format('MM月DD日')
  target.value = date
  // if (target.value) curTravelId.value = 'all'
  // console.log('日历选中:', date)
  curTravelDate.value = date
  emits('change', curTravelDate.value)
}
/* 日历自定义样式（可选） */
function formatter(day: any) {
  // console.log('formatter', day)
  // 示例：让今天高亮
  if (dayjs(day.date).format('YYYY-MM-DD') === today.format('YYYY-MM-DD')) {
    day.bottomInfo = '今天'
  }
  return day
}
</script>

<template>
  <!-- 日期选择栏 -->
  <div class="flex gap-2 overflow-x-scroll">
    <div
      v-for="item in dateList"
      :key="item.id"
      class="flex text-nowrap border border-gray-200 rounded-[10rpx] p-[10rpx_20rpx]"
      :class="{
        'text-white bg-[#14293f]': curTravelDate === item.value
      }"
      @click="onSelect(item)"
    >
      {{ item.title }}
      <up-icon
        v-if="item.id === 'all'"
        name="arrow-right"
      ></up-icon>
    </div>
  </div>
  <!-- uview-plus 单选日历 -->
  <up-calendar
    ref="calendarRef"
    mode="single"
    :show="isShowCalendar"
    :formatter="formatter"
    :defaultDate="curTravelDate"
    @confirm="onConfirm"
    @close="isShowCalendar = false"
  />
</template>

<style lang="scss" scoped></style>
