<template>
  <view class="z-calendar">
    <view class="picker-box">
      <view class="picker-box-c">
        <view class="picker-header space-between">
          <view
            class="picker-prev"
            @click="preMon"
          >
            <!-- <van-icon name="arrow-left" /> -->
            <uni-icons
              type="left"
              size="18"
            ></uni-icons>
          </view>
          <view class="picker-year">
            {{ year }}{{ t('zCalendar.year') }} {{ month
            }}{{ t('zCalendar.month') }}
          </view>
          <view
            class="picker-next"
            @click="nextMon"
          >
            <uni-icons
              type="right"
              size="18"
            ></uni-icons>
            <!-- <van-icon name="arrow" /> -->
          </view>
        </view>
        <view class="picker-content">
          <view class="picker-week">
            <view
              class="picker-weekday"
              v-for="week in weekList"
              :key="week"
            >
              {{ week }}
            </view>
          </view>
          <view class="picker-con">
            <!-- 单选 -->
            <template v-if="type === 'selection'">
              <view
                :key="item.id"
                class="picker-day flex-col flex-align flex-center"
                v-for="item in picker"
                :class="[
                  {
                    'is-active':
                      item.monthStatus &&
                      item.dateStatus &&
                      (item.salePrice || isZeroBuy) &&
                      (chooseDate === item.intackDate ||
                        currentDate === item.intackDate)
                  },
                  {
                    'is-active':
                      (chooseDate === item.intackDate ||
                        currentDate === item.intackDate) &&
                      isSearch
                  },
                  { 'is-not-current-mounth': !item.monthStatus },
                  {
                    'is-before-current-date':
                      !item.monthStatus && !item.dateStatus
                  },
                  {
                    'is-not-price':
                      !item.salePrice &&
                      (item.salePrice === undefined || !isZeroBuy)
                  },
                  { 'is-today': today === item.intackDate }
                ]"
                :style="{
                  paddingBottom: mode === 'B2B' ? '0' : '3px',
                  background:
                    item.monthStatus &&
                    item.dateStatus &&
                    item.salePrice &&
                    (chooseDate === item.intackDate ||
                      currentDate === item.intackDate)
                      ? themeColor
                      : ''
                }"
                @click="checkDay(item)"
              >
                <slot :row="item">
                  <template
                    v-if="chooseDateText && chooseDate === item.intackDate"
                  >
                    <text
                      class="unit has-text"
                      :style="{ color: themeColor }"
                    >
                      {{ chooseDateText }}
                    </text>
                  </template>
                  <template v-else>
                    <text
                      class="unit"
                      :class="{ 'green no-num': !item.num }"
                      v-if="
                        item.monthStatus &&
                        item.dateStatus &&
                        (item.salePrice || isZeroBuy)
                      "
                    >
                      <slot
                        name="unit"
                        :row="item"
                      >
                        {{ item.num ? item.num : renderNum(item) }}
                      </slot>
                    </text>
                  </template>
                  <text
                    class="day"
                    v-if="item.monthStatus"
                  >
                    {{ item.dateNum }}
                  </text>
                  <text
                    class="price"
                    v-if="
                      item.monthStatus &&
                      item.dateStatus &&
                      (item.salePrice || isZeroBuy)
                    "
                  >
                    {{
                      item.salePrice > 0 || Number(item.salePrice) === 0
                        ? '￥'
                        : ''
                    }}{{ item.salePrice }}
                  </text>
                  <text
                    class="price dist-price"
                    style="margin-top: 2px"
                    v-if="
                      item.monthStatus &&
                      item.dateStatus &&
                      item.salePrice &&
                      mode === 'B2B'
                    "
                  >
                    ￥{{ item.price }}
                  </text>
                </slot>
              </view>
            </template>
            <!-- 范围 -->
            <template v-if="type === 'range'">
              <view
                :key="item.id"
                class="picker-day flex-col flex-align flex-center"
                v-for="item in picker"
                :class="[
                  {
                    'is-active':
                      item.monthStatus &&
                      (params.startDate === item.intackDate ||
                        params.endDate === item.intackDate) &&
                      isActiveDate(params.startDate, params.endDate)
                  },
                  {
                    'is-continue':
                      params.startDate && params.endDate && showContinue(item)
                  },
                  { 'is-not-current-mounth': !item.monthStatus },
                  {
                    'is-before-current-date':
                      !item.monthStatus && !item.dateStatus
                  },
                  { 'is-not-price': !item.salePrice },
                  { 'is-active-start': params.startDate === item.intackDate },
                  { 'is-active-end': params.endDate === item.intackDate }
                ]"
                :style="{
                  paddingBottom: mode === 'B2B' ? '0' : '3px',
                  background:
                    (item.monthStatus &&
                      (params.startDate === item.intackDate ||
                        params.endDate === item.intackDate) &&
                      isActiveDate(params.startDate, params.endDate)) ||
                    (params.startDate && params.endDate && showContinue(item))
                      ? themeColor
                      : ''
                }"
                @click="checkRangeDay(item)"
              >
                <slot :row="item">
                  <template
                    v-if="
                      item.monthStatus &&
                      (params.startDate === item.intackDate ||
                        params.endDate === item.intackDate) &&
                      isActiveDate(params.startDate, params.endDate)
                    "
                  >
                    <text
                      class="unit has-text"
                      :style="{ color: themeColor }"
                    >
                      {{
                        params.startDate === item.intackDate
                          ? rangeText.stext
                          : params.endDate === item.intackDate
                          ? rangeText.etext
                          : ''
                      }}
                    </text>
                  </template>
                  <template v-else>
                    <text
                      class="unit"
                      :class="{ 'no-num': !item.num }"
                      v-if="
                        item.monthStatus && item.dateStatus && item.salePrice
                      "
                    >
                      <slot
                        name="unit"
                        :row="item"
                      >
                        {{ showContinue(item) ? '连住' : item.num }}
                      </slot>
                    </text>
                  </template>
                  <text
                    class="day"
                    v-if="item.monthStatus"
                  >
                    {{ item.dateNum }}
                  </text>
                  <text
                    class="price"
                    v-if="item.monthStatus && item.dateStatus && item.salePrice"
                  >
                    ￥{{ item.salePrice }}
                  </text>
                  <text
                    class="price dist-price"
                    style="margin-top: 2px"
                    v-if="
                      item.monthStatus &&
                      item.dateStatus &&
                      item.salePrice &&
                      mode === 'B2B'
                    "
                  >
                    ￥{{ item.price }}
                  </text>
                </slot>
              </view>
            </template>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>
<script lang="ts">
import i18n from '@/i18n/index'

const { t } = i18n().global
const go = t('zCalendar.go')
const st = t('zCalendar.st')
const ct = t('zCalendar.ct')
</script>
<script lang="ts" setup>
import { ref, reactive, computed } from 'vue'
import { parseTime } from '@/utils/tool'

const props = withDefaults(
  defineProps<{
    mode?: string
    isSearch?: boolean
    modelValue?: string | object
    type?: string
    fieId?: string
    datePriceList?: any[]
    themeColor?: string
    currentYear?: string | number
    currentMonth?: string | number
    currentDate?: string | string[]
    chooseDateText?: string
    rangeText?: {
      stext: string
      etext: string
    }
    isZeroBuy?: boolean
  }>(),
  {
    mode: 'B2C',
    isSearch: false,
    modelValue: '',
    type: 'selection', // 默认单选， 范围range
    fieId: 'travelDate',
    datePriceList: () => [], // 价格日历
    themeColor: '#fb6046', // 主题颜色
    currentYear: new Date().getFullYear(),
    currentMonth: new Date().getMonth() + 1,
    currentDate: '',
    chooseDateText: () => go,
    // 范围选择对应文字
    rangeText: () => ({
      stext: st,
      etext: ct
    }),
    isZeroBuy: false
  }
)

const emit = defineEmits([
  'changeMonth',
  'changeDate',
  'update:modelValue',
  'select'
])
// 计算今天的日期
const today = computed(() => {
  const date = new Date()
  const day = date.getDate() < 10 ? `0${date.getDate()}` : date.getDate()
  return `${props.currentYear}-${props.currentMonth}-${day}`
})

// 多选状态下的日期
const params = reactive({
  startDate: '',
  endDate: ''
})

// 点击次数
const clickN = ref(0)

// 星期列表
const weekList = computed(() => [
  t('zCalendar.Week7'),
  t('zCalendar.Week1'),
  t('zCalendar.Week2'),
  t('zCalendar.Week3'),
  t('zCalendar.Week4'),
  t('zCalendar.Week5'),
  t('zCalendar.Week6')
])

const year = computed({
  get() {
    return props.currentYear
  },
  set(e) {
    emit('changeMonth', { year: e, month: month.value })
  }
})

const month = computed({
  get() {
    return props.currentMonth
  },
  set(e) {
    let m = e
    let y = year.value
    if (Number(e) > 12) {
      m = 1
      y = Number(y) + 1
    } else if (Number(e) < 1) {
      m = 12
      y = Number(y) - 1
    }
    emit('changeMonth', { year: y, month: m })
  }
})

const chooseDate = computed({
  get() {
    return props.modelValue
  },
  set(val) {
    emit('changeDate', val)
    emit('update:modelValue', val)
  }
})

const picker = computed(() => {
  const dateArr = initCalendar.value.reduce(
    (item: any, { intackDate, ...next }) => {
      const date = props.datePriceList.filter((item1: any) => {
        return item1[props.fieId] === intackDate
      })
      const dateItem = (date.length > 0 ? date[0] : {}) as object

      item.push({ ...next, ...dateItem, intackDate })
      return item
    },
    []
  )

  return dateArr
})
const initCalendar = computed(() => {
  const firstDay = new Date(`${props.currentYear}/${props.currentMonth}/01`)
  const day = firstDay.getDay() // 第一天周几
  const startDate = new Date(firstDay)
  startDate.setDate(firstDay.getDate() - day)
  let item = null
  const tempArr = []
  // eslint-disable-next-line init-declarations
  let tempItem
  for (let i = 0; i < 42; i++) {
    item = new Date(startDate)
    item.setDate(startDate.getDate() + i)
    tempItem = {
      intackDate: parseTime(item, '{y}-{m}-{d}'),
      dateNum: parseTime(item, '{d}'),
      monthStatus: item.getMonth() === Number(props.currentMonth) - 1, // 是否当月
      // dateStatus: item.getDate() >= new Date().getDate() // 是否是今天之后的日期
      dateStatus: calTodayArterDate(parseTime(item, '{y}-{m}-{d}'))
    }
    tempArr.push(tempItem)
  }
  return tempArr
})

// 计算是否是今天之后的日期 是：true
function calTodayArterDate(date: any) {
  const dY = date.split('-')
  const cY = parseTime(new Date().getTime(), '{y}-{m}-{d}').split('-')
  if (dY[0] > cY[0]) {
    return true
  }
  if (dY[0] === cY[0]) {
    if (dY[1] > cY[1]) {
      return true
    }
    if (dY[1] === cY[1]) {
      if (dY[2] >= cY[2]) {
        return true
      }
      return false
    }
    return false
  }
  return false
}

// 切换上月
function preMon() {
  if (
    Number(year.value) === new Date().getFullYear() &&
    Number(month.value) <= new Date().getMonth() + 1 &&
    !props.isSearch
  ) {
    return
  }
  let month1 = Number(month.value)
  month1 -= 1
  month.value = month1
}

// 切换下月
function nextMon() {
  let month1 = Number(month.value)
  month1 += 1
  month.value = month1
}
interface DayItem {
  monthStatus: boolean
  dateStatus: boolean
  intackDate: string
  salePrice?: number | null
  [key: string]: any // 其他可能的属性
}

// 选择日期 - 单选
function checkDay({
  monthStatus,
  dateStatus,
  intackDate,
  salePrice,
  ...day
}: DayItem) {
  const isValidateDate =
    monthStatus &&
    dateStatus &&
    (salePrice || (salePrice !== undefined && props.isZeroBuy)) // 有效日期
  if (
    (props.type === 'selection' && isValidateDate && day.noSale !== 1) ||
    props.isSearch
  ) {
    chooseDate.value = intackDate
    emit('select', {
      ...day,
      salePrice
    })
  }
}

// 选择范围日期 - 范围
function checkRangeDay({ monthStatus, intackDate, ...day }: any) {
  // 选开始日期没有价格的不能选，选结束日期前一天没有价格的不能选，前一天有价格的能选
  if (!params.startDate) {
    if (day && day.salePrice !== 0 && !day.salePrice) return
  }
  if (params.startDate) {
    // 上一次选的开始日期和结束日期数据还存在，所以先清空一下再判断
    if (params.endDate) {
      params.startDate = ''
      params.endDate = ''
    }
    // 两个日期相差大于1，并且候选日期没有价格（为null或者undefined），并且不是0（0元购可以选），禁止选择
    const startEndDay = datedifference(params.startDate, intackDate)
    if (!startEndDay) return
    if (startEndDay < 0 && day && day.salePrice !== 0 && !day.salePrice) return
  }
  const today = parseTime(new Date(), '{y}-{m}-{d}')
  if (
    new Date(intackDate).getTime() < new Date(today).getTime() &&
    !props.isSearch
  ) {
    return
  }
  if (!monthStatus && !props.isSearch) return
  if (day.noSale === 1 && !props.isSearch) return // 停售不能选
  if (clickN.value === 0) {
    params.startDate = intackDate
    clickN.value = 1
  } else if (clickN.value === 1) {
    params.endDate = intackDate
    clickN.value = 2
    if (dateCompare(params.startDate, params.endDate)) {
      const a = params.endDate
      const b = params.startDate
      params.startDate = a
      params.endDate = b
    }
  } else {
    clickN.value = 1
    params.startDate = intackDate
    params.endDate = ''
  }
  emit('update:modelValue', params)
  emit('changeDate', params)

  const startDate = new Date(params.startDate).getTime()
  const endDate = new Date(params.endDate).getTime()
  const selectList = []

  for (let i = 0; i < props.datePriceList.length; i++) {
    const item = props.datePriceList[i] as any
    const time = new Date(item.travelDate).getTime()
    if (endDate) {
      if (time >= startDate && time <= endDate) {
        selectList.push(item)
      }
    } else if (time === startDate) {
      selectList.push(item)
      break
    }
  }
  emit('select', selectList)
}

// 计算两个日期的差 - 存在先选的日期比后选日期大的情况，所以不用绝对值
function datedifference(startDate: any, endDate: any) {
  startDate = Date.parse(startDate)
  endDate = Date.parse(endDate)
  const dateSpan = endDate - startDate
  const day = Math.floor(dateSpan / (24 * 3600 * 1000))
  return day
}

// 比较两日期大小
function dateCompare(sdate: any, edate: any) {
  const s = new Date(sdate).getTime()
  const e = new Date(edate).getTime()
  return s > e
}

// 日期延续
function showContinue({ intackDate }: any) {
  const sDate = new Date(params.startDate).getTime()
  const eDate = new Date(params.endDate).getTime()
  const curDate = new Date(intackDate).getTime()
  if (curDate > sDate && curDate < eDate) {
    return intackDate.split('-')[1] === String(props.currentMonth)
  }
  return false
}

// 验证高亮的时候，不是当月不显示出来
function isActiveDate(sdate: any, edate: any) {
  if (edate && edate.split('-')[1] !== Number(props.currentMonth)) {
    return (
      Number(sdate.split('-')[1]) === Number(props.currentMonth) ||
      Number(edate && edate.split('-')[1]) === Number(props.currentMonth)
    )
  }
  return true
}

// 多产品类目渲染num
function renderNum({ isApply, isHandle, noSale }: any) {
  if (noSale === 1) return '停售'
  if (isHandle === 1) return '可办'
  if (isApply === 1) return '申请'
}
</script>

<style lang="scss" scoped>
@import './style/index.scss';
</style>
