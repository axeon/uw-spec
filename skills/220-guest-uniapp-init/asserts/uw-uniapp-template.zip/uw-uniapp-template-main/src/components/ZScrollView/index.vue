<script setup lang="ts">
import { ref } from 'vue'

const props = withDefaults(
  defineProps<{
    navList: any[] // 导航列表
    type?: 'type-0' | 'type-1' // 自定义样式
    isFixed?: boolean // 是否固定导航栏
    top?: string // 导航栏距离顶部的距离
    itemHeight?: string // item元素的高度
    navMargin?: string // 导航栏的margin
    navPadding?: string // 导航栏的padding
    itemMargin?: string // item元素的margin
    itemPadding?: string // item元素的padding
  }>(),
  {
    navList: () => [],
    type: 'type-0',
    isFixed: false,
    itemHeight: '80rpx'
  }
)

const emits = defineEmits<{
  (e: 'change', item: any): void
}>()
// const handleClick = (item: any) => {
//   emits('click', item)
// }

const scrollLeft = ref(0)
const navCurrent = ref(0)

const navSelect = (e: any, item: any) => {
  // console.log(e)
  navCurrent.value = e.currentTarget.dataset.id
  scrollLeft.value = (e.currentTarget.dataset.id - 1) * 60
  emits('change', item)
}
</script>

<template>
  <view
    class="scroll-view"
    :class="[isFixed ? 'fixed' : '', type]"
    :style="{ padding: navPadding, margin: navMargin, top }"
  >
    <scroll-view
      scroll-x
      class="nav"
      scroll-with-animation
      :scroll-left="scrollLeft"
    >
      <view
        class="nav-item"
        :class="{
          'active primary-color': index == navCurrent
        }"
        :style="{
          height: itemHeight,
          lineHeight: itemHeight,
          padding: itemPadding,
          margin: itemMargin
        }"
        v-for="(item, index) in props.navList"
        :key="index"
        :data-id="index"
        @tap="(e:any) => navSelect(e, item)"
      >
        <text class="title">{{ item.title }}</text>
      </view>
    </scroll-view>
  </view>
</template>

<style scoped lang="scss">
.scroll-view {
  width: 100%;
  overflow: hidden;
  box-sizing: border-box;
  &.fixed {
    // border: 1px solid #000;
    position: fixed;
    top: 44px; // NavBar的默认高度
    z-index: 9;
    background-color: #ffffff;
  }
  &.type-0 {
    .nav {
      white-space: nowrap;
      box-sizing: border-box;
      .nav-item {
        display: inline-block;
        margin: 0 10rpx;
        &.active {
          font-weight: 600;
          border-bottom: 4rpx solid;
        }
      }
    }
  }
  &.type-1 {
    .nav {
      white-space: nowrap;
      box-sizing: border-box;
      &-item {
        display: inline-block;
        margin: 0 10rpx;
        .title {
          border-radius: 30rpx;
          color: #999999;
          background-color: #f2f2f2;
          padding: 4rpx 12rpx;
          box-sizing: border-box;
        }
        &.active {
          font-weight: 600;
          .title {
            color: #f58c1c !important;
            background-color: rgba(245, 140, 28, 0.3) !important;
          }
        }
      }
    }
  }
  // &.type-2 {}
}
</style>
