<template>
  <view
    class="z-up"
    :style="style"
    @click="handleClick"
  ></view>
</template>

<script lang="ts" setup>
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    scrollTop: number
  }>(),
  {
    scrollTop: 0
  }
)

// 计算属性
const style = computed(() => {
  return `opacity: ${props.scrollTop > 300 ? 1 : 0};`
})

// 方法
const handleClick = () => {
  uni.pageScrollTo({
    scrollTop: 0
  })
}
</script>

<style lang="scss" scoped>
.z-up {
  position: fixed;
  width: 100rpx;
  height: 100rpx;
  right: 30rpx;
  bottom: 190rpx;
  background: url('http://qnimg.zowoyoo.com/img/84826/1625553533012.png')
    no-repeat center;
  background-size: contain;
  opacity: 0;
  transition: opacity 0.3s;
}
</style>
