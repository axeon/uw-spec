<!-- 全局顶部导航栏 -->
<script lang="ts" setup>
// const props = withDefaults(
//   defineProps<{
//     num?: number // 数量
//   }>(),
//   {
//     num: 1
//   }
// )
// const emits = defineEmits<{
//   (e: 'click', item: any): void
// }>()
// const handleClick = (item: any) => {
//   emits('click', item)
// }

// const count = ref(5)
</script>

<template>
  <div class="Gb-navbar flex items-center justify-between">
    <div class="logo">
      <up-image
        :show-loading="true"
        src="@/static/images/dummy.png"
        width="170rpx"
        height="64rpx"
      ></up-image>
    </div>
    <div class="flex justify-end gap-[30rpx]">
      <div class="item">
        <div class="icon"></div>
        <div class="text">{{ '简中' }}</div>
      </div>
      <div class="item">
        <div class="icon"></div>
        <div class="text">{{ '订单' }}</div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.Gb-navbar {
  height: 90rpx;
  background: #ffffff;
  box-shadow: 0px 2rpx 20rpx 0px rgba(0, 0, 0, 0.05);

  padding: 0 30rpx;
  .item {
    // @apply border text-2xl; // TODO 不生效
    display: flex;
    gap: 10rpx;

    font-family: Alibaba PuHuiTi 3, Alibaba PuHuiTi 30;
    font-weight: 400;
    font-size: 26rpx;
    color: #14293f;
    .icon {
      width: 40rpx;
      height: 40rpx;
      border: 1px solid #000;
    }
  }
}
</style>
