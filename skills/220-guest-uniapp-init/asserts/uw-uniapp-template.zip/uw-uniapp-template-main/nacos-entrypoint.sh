#!/bin/sh

#配置nginx.conf
cat > /etc/nginx/nginx.conf << EOF
user  nginx;
worker_processes  3;

error_log  /var/log/nginx/error.log notice;
pid        /var/run/nginx.pid;

events {
    worker_connections  1024;
}

http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    sendfile        on;
    #tcp_nopush     on;

    keepalive_timeout  65;

    gzip  on;
    gzip_static on;
    gzip_min_length  1000;
    gzip_buffers     32 8k;
    gzip_http_version 1.1;
    gzip_comp_level 6;
    gzip_types       text/plain text/xml text/css text/javascript application/javascript application/x-javascript application/css application/xml application/json;
    gzip_vary on;

    server {
        listen $APP_PORT;
        location /  {
        expires 365d;
        if ( \$request_uri = "/" ){
            expires 180;
        }
        root   /usr/share/nginx/html;
        index  index.html index.htm;
        }
    }
}

EOF

#设置nacos请求数据
POST_DATA="serviceName="$APP_NAME
POST_DATA=$POST_DATA"&username="$NACOS_USERNAME
POST_DATA=$POST_DATA"&password="$NACOS_PASSWORD
POST_DATA=$POST_DATA"&namespaceId="$NACOS_NAMESPACE
POST_DATA=$POST_DATA"&ip="$APP_HOST
POST_DATA=$POST_DATA"&port="$APP_PORT
POST_DATA=$POST_DATA"&weight=2.0"
POST_DATA=$POST_DATA"&ephemeral=false"

#接受到信号后执行的函数
post_signal()
{
  echo "shutting down..."
  curl -X DELETE http://${NACOS_SERVER}/nacos/v2/ns/instance -d "$POST_DATA"
  sleep 5
  nginx -s quit
}

#监听信号为INT TERM KILL
trap "post_signal" SIGINT SIGTERM SIGKILL

#启动nacos注册
resultCode=`curl -s -S -X POST -d "$POST_DATA" "http://$NACOS_SERVER/nacos/v2/ns/instance"`
echo ${resultCode}

#启动nginx
nginx -g 'daemon off;' &
wait $!
