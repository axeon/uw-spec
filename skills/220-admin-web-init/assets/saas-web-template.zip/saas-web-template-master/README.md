# Vue3 后台管理系统模板 - 项目结构文档

## 一、项目概述

基于 Vue 3 + TypeScript + Vite 构建的企业级后台管理系统模板，支持多租户运营、动态权限管理、多语言国际化等特性。

### 1.1 技术栈

| 技术 | 版本 | 说明 |
|------|------|------|
| Vue | 3.5.16 | 核心框架，使用 Composition API + `<script setup>` |
| TypeScript | 5.7.3 | 开发语言 |
| Vite | 8.0.0-beta.0 | 构建工具 |
| Element Plus | 2.10.2 | UI 组件库 |
| Pinia | 2.3.1 | 状态管理 |
| Vue Router | 4.5.1 | 路由管理 |
| Vue I18n | 9.2.2 | 国际化 |
| Axios | 1.10.0 | HTTP 请求库 |
| Dayjs | 1.11.9 | 日期处理 |
| ECharts | 5.4.2 | 图表库 |
| TinyMCE | 6.7.1 | 富文本编辑器 |
| Sass | 1.79.5 | CSS 预处理器 |

---

## 二、项目目录结构

```
saas-admin-web/
├── .husky/                    # Git hooks 配置
│   ├── _/                     # Husky 内部文件
│   ├── commit-msg             # 提交信息校验钩子
│   └── pre-commit             # 提交前校验钩子
├── .vscode/                   # VSCode 配置
│   ├── extensions.json        # 推荐插件
│   └── settings.json          # 编辑器设置
├── public/                    # 静态资源（不经过构建）
│   ├── tinymce/              # TinyMCE 编辑器静态文件
│   ├── favicon.ico
│   └── systemUpgradeRefresh.js
├── scripts/                   # 构建脚本
│   ├── tinymce-langs/        # TinyMCE 语言包备份
│   └── copy-tinymce.js       # 复制 TinyMCE 脚本
├── src/                       # 源代码目录
│   ├── api/                  # API 接口定义
│   ├── assets/               # 静态资源
│   ├── components/           # 公共组件
│   ├── config/               # 配置文件
│   ├── directives/           # 自定义指令
│   ├── hooks/                # 组合式函数
│   ├── i18n/                 # 国际化配置
│   ├── layout/               # 布局组件
│   ├── pages/                # 页面视图
│   ├── router/               # 路由配置
│   ├── store/                # Pinia 状态管理
│   ├── styles/               # 全局样式
│   ├── utils/                # 工具函数
│   ├── App.vue               # 根组件
│   ├── main.ts               # 应用入口
│   ├── types.ts              # 全局类型定义
│   └── vite-env.d.ts         # Vite 环境类型
├── .eslintrc-auto-import.json # 自动导入 ESLint 配置
├── .gitignore
├── .oxfmtrc.json             # Oxfmt 格式化配置
├── .oxlintrc.json            # Oxlint 代码检查配置
├── auto-imports.d.ts         # 自动导入类型声明
├── commitlint.config.cjs     # Commitlint 配置
├── components.d.ts           # 组件自动导入声明
├── index.html                # HTML 模板
├── package.json              # 项目依赖
├── pnpm-lock.yaml
├── README.md
├── tsconfig.json             # TypeScript 配置
├── tsconfig.node.json        # Node 环境 TS 配置
└── vite.config.ts            # Vite 配置
```

---

## 三、核心配置文件详解

### 3.1 package.json

```json
{
  "name": "my-vue-app",
  "version": "0.0.1",
  "type": "module",
  "scripts": {
    "prepare": "husky install",
    "lint": "oxlint --fix src/",
    "copy:tinymce": "node scripts/copy-tinymce.js",
    "dev": "npm run copy:tinymce && vite --host",
    "build:prod": "npm run copy:tinymce && vite build",
    "build": "npm run copy:tinymce && vue-tsc && vite build",
    "preview": "vite preview"
  }
}
```

**脚本说明：**
- `prepare`: 初始化 Husky
- `lint`: 运行 Oxlint 代码检查并自动修复
- `copy:tinymce`: 复制 TinyMCE 静态资源到 public 目录
- `dev`: 开发模式启动（含 TinyMCE 复制）
- `build:prod`: 生产构建（跳过类型检查）
- `build`: 生产构建（含类型检查）
- `preview`: 预览生产构建

### 3.2 vite.config.ts

```typescript
export default defineConfig({
  base: "./",                          // 相对路径部署
  plugins: [
    VueMacros({...}),                  // Vue 宏支持
    vitePageName(),                    // 自定义页面名称插件
    AutoImport({...}),                 // 自动导入 API
    Components({...}),                 // 自动导入组件
    vitePluginVersionMark({...}),      // 版本标记插件
    compression({...}),                // Gzip 压缩
  ],
  css: {
    preprocessorOptions: {
      scss: { 
        additionalData: `@use "@/layout/config.module.scss" as *;` 
      }
    }
  },
  define: {
    "import.meta.env.VITE_GIT_SHA": JSON.stringify(gitSha),
    __APP_NAME__: JSON.stringify(appName)
  },
  resolve: {
    alias: {
      "@": pathSrc,                    // 路径别名
      "~/": `${pathSrc}/`,
      "vue-i18n": "vue-i18n/dist/vue-i18n.cjs.js"
    }
  },
  build: {
    minify: "terser",
    terserOptions: {
      compress: {
        drop_console: true,            // 移除 console
        drop_debugger: true            // 移除 debugger
      }
    },
    rollupOptions: {
      output: {
        manualChunks(id) {...}        // 代码分割策略
      }
    }
  },
  optimizeDeps: { 
    exclude: ["@jsquash/webp", "@jsquash/jpeg", "@jsquash/png"] 
  },
  worker: { format: "es" }             // WebWorker ES 模块格式
})
```

**关键配置说明：**

| 配置项 | 说明 |
|--------|------|
| `base: "./"` | 使用相对路径，支持任意部署路径 |
| `AutoImport` | 自动导入 Vue、Vue Router、VueUse API |
| `Components` | 自动导入 `src/components` 下的组件 |
| `compression` | 启用 Gzip 压缩，阈值 1KB |
| `manualChunks` | 按 node_modules 包名分割代码 |
| `drop_console` | 生产环境移除 console 语句 |

### 3.3 tsconfig.json

```json
{
  "compilerOptions": {
    "target": "esnext",
    "module": "esnext",
    "moduleResolution": "bundler",
    "strict": true,
    "jsx": "preserve",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "esModuleInterop": true,
    "lib": ["ESNext", "DOM"],
    "skipLibCheck": true,
    "noEmit": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"]
    },
    "types": ["element-plus/global"]
  },
  "include": [
    "src/**/*.ts",
    "src/**/*.d.ts",
    "src/**/*.tsx",
    "src/**/*.vue",
    "./auto-imports.d.ts"
  ],
  "vueCompilerOptions": {
    "plugins": ["vue-macros/volar"]
  }
}
```

### 3.4 Oxlint 配置 (.oxlintrc.json)

**启用插件：** `Oxlint`, `vue`, `typescript`

**核心规则：**

| 规则 | 级别 | 说明 |
|------|------|------|
| `no-var` | error | 禁止使用 var |
| `no-alert` | error | 禁止 alert/confirm/prompt |
| `eqeqeq` | error | 强制使用 === 和 !== |
| `max-params` | error | 限制函数参数最多 5 个 |
| `max-depth` | error | 限制代码嵌套深度最多 7 层 |
| `typescript/no-explicit-any` | warn | 警告使用 any 类型 |
| `typescript/consistent-type-definitions` | error | 强制使用 interface |

### 3.5 Oxfmt 配置 (.oxfmtrc.json)

| 配置项 | 值 | 说明 |
|--------|-----|------|
| `printWidth` | 80 | 每行最大字符数 |
| `tabWidth` | 2 | 缩进空格数 |
| `useTabs` | false | 使用空格缩进 |
| `semi` | false | 不使用分号 |
| `singleQuote` | true | 使用单引号 |
| `trailingComma` | none | 不使用尾随逗号 |
| `arrowParens` | avoid | 箭头函数参数省略括号 |
| `singleAttributePerLine` | true | 每行一个属性 |

### 3.6 Commitlint 配置 (commitlint.config.cjs)

**支持的提交类型：**

| 类型 | 说明 |
|------|------|
| feat | 新功能 |
| fix | 修复 bug |
| docx | 文档变更 |
| style | 代码格式调整 |
| refactor | 代码重构 |
| perf | 性能优化 |
| test | 测试相关 |
| chore | 构建/工具变动 |
| revert | 还原提交 |
| build | 打包 |

---

## 四、源代码目录详解

### 4.1 API 层 (src/api/)

| 文件 | 说明 | 大小 |
|------|------|------|
| `saasBaseAppMchApi.ts` | 商户相关接口 | 8.0KB |
| `saasBaseAppOpenApi.ts` | 开放接口 | 2.0KB |
| `saasBaseAppSaasApi.ts` | 运营商相关接口 | 91.5KB |
| `saasBaseAppUserApi.ts` | 用户相关接口 | 13.2KB |
| `uwAuthCenterAuthApi.ts` | 认证授权接口 | 3.5KB |
| `uwAuthCenterMchApi.ts` | 商户中心接口 | 22.6KB |
| `uwAuthCenterSaasApi.ts` | 运营商中心接口 | 35.2KB |
| `uwAuthCenterUserApi.ts` | 用户中心接口 | 11.3KB |

### 4.2 组件目录 (src/components/)

#### 功能组件

| 组件 | 说明 |
|------|------|
| `Captcha/` | 验证码组件（图片、滑块、点击、旋转等类型） |
| `RichTextEditor/` | 富文本编辑器（TinyMCE 封装） |
| `ECharts/` | 图表封装组件 |
| `UploadFile/` | 文件上传（支持多类型、拖拽） |
| `VideoPlayer/` | 视频播放器 |
| `ExcelPreview/` | Excel 预览 |
| `WordPreview/` | Word 预览 |

#### 业务组件

| 组件 | 说明 |
|------|------|
| `SearchForm/` | 搜索表单（配置化） |
| `DataDiffTable/` | 数据对比表格 |
| `HistoryLog/` | 操作历史日志 |
| `DataHistoryLog/` | 数据历史日志 |
| `CritLog/` | 关键日志 |
| `QueryLog/` | 查询日志 |
| `ParamsConfigTable/` | 参数配置表格 |
| `ParamsConfigTableByAdd/` | 新增参数配置表格 |

#### UI 组件

| 组件 | 说明 |
|------|------|
| `LangSelect/` | 语言选择器 |
| `Icon/` | 图标组件 |
| `MenuIcon/` | 菜单图标 |
| `TitleHeader/` | 标题头部 |
| `ToolTipText/` | 文本提示 |
| `InputNumberRange/` | 数字范围输入 |
| `InputTag/` | 标签输入 |
| `ContextMenu/` | 右键菜单 |
| `GraphicList/` | 图形列表 |
| `PreviewHtml/` | HTML 预览 |
| `PreviewImage/` | 图片预览 |
| `SettingForTheme/` | 主题设置 |
| `SwitchAccounts/` | 账号切换 |
| `Pagination.vue` | 分页组件 |

### 4.3 Hooks 目录 (src/hooks/)

| Hook | 说明 | 大小 |
|------|------|------|
| `useAbnormalMessage.ts` | 异常消息处理 | 1.5KB |
| `useActivated.ts` | 激活状态管理 | 0.5KB |
| `useCountdown.ts` | 倒计时功能 | 2.4KB |
| `useCrud.ts` | CRUD 操作封装 | 16.4KB |
| `useCustomDark.ts` | 暗黑模式 | 0.9KB |
| `useExportExcel.ts` | Excel 导出 | 22.0KB |
| `usePermissionCode.ts` | 权限码处理 | 1.0KB |
| `usePolling.ts` | 轮询功能 | 2.7KB |
| `usePostMessage.ts` | PostMessage 通信 | 0.9KB |
| `usePrompt.ts` | 提示框封装 | 1.4KB |
| `useSimplifyPrompt.ts` | 简化提示 | 1.0KB |
| `useValidate.ts` | 表单验证 | 6.1KB |

### 4.4 国际化 (src/i18n/)

支持 5 种语言：

| 目录 | 语言 | 文件数 |
|------|------|--------|
| `zh-CN/` | 简体中文 | 10 |
| `zh-TW/` | 繁体中文 | 9 |
| `en/` | English | 9 |
| `ja/` | 日本語 | 5 |
| `ko/` | 한국어 | 9 |

### 4.5 布局系统 (src/layout/)

| 文件/目录 | 说明 |
|-----------|------|
| `index.vue` | 布局入口，支持三种布局模式切换 |
| `config.module.scss` | 布局样式变量配置 |
| `default/` | 默认布局（顶部导航 + 侧边菜单） |
| `vertical/` | 垂直布局 |
| `slide/` | 侧边栏布局 |

**布局配置变量：**

```scss
// 侧边栏
$asideWidth: 180px;           // 展开宽度
$asideCollapseWidth: 50px;    // 收起宽度
$asideItemHeight: 50px;       // 菜单项高度
$asideTransitionTime: 0.3s;   // 动画时长

// 顶部
$headerHeight: 50px;          // 顶部高度
$pageTabHeight: 35px;         // 页签高度
```

### 4.6 路由配置 (src/router/)

| 文件 | 说明 |
|------|------|
| `index.ts` | 路由主配置，含权限守卫 |
| `typings.d.ts` | 路由类型定义 |
| `uwAuthCenterRouter.ts` | 权限中心路由 |

**路由守卫功能：**
- Token 刷新处理（refreshToken 参数）
- 登录状态校验
- 动态菜单加载
- 页签管理
- 进度条控制

### 4.7 状态管理 (src/store/)

| 文件 | 说明 |
|------|------|
| `index.ts` | Pinia 实例创建 |
| `main.ts` | 主 Store（690 行，包含完整业务逻辑） |

**Main Store 核心功能：**

```typescript
// 状态
loginInfo          // 登录信息
navIndex          // 顶部导航索引
pageTabs          // 页签数据
appMenu           // 应用菜单
systemDark        // 暗黑模式
systemThemeColors // 主题色
layoutMode        // 布局模式
permissionMap     // 权限映射

// Actions
setAppMenu()      // 设置菜单（含动态路由注册）
setPageTabs()     // 设置页签
Logout()          // 退出登录
handleUserLoadAppMenu()  // 加载用户菜单
handleReloadMenu()       // 刷新 Token
handleReloadAuth()       // 重新加载权限
```

### 4.8 工具函数 (src/utils/)

| 文件 | 说明 |
|------|------|
| `request.ts` | Axios 封装（399 行，含拦截器、错误处理） |
| `tool.ts` | 通用工具函数 |
| `buildTreeMenu.ts` | 菜单树构建 |
| `encryptionAndDecryption.ts` | 加密解密 |
| `enum.ts` | 枚举定义 |
| `getUserTypeApi.ts` | 用户类型 API |
| `idValidate.ts` | ID 验证 |
| `scheduler.ts` | 调度器 |
| `selectOptions.ts` | 选择器选项 |
| `PubSub/` | 发布订阅模式 |

### 4.9 自定义指令 (src/directives/)

| 文件 | 指令名 | 说明 |
|------|--------|------|
| `permission.ts` | `v-permission` | 权限控制指令 |
| `thousandSeparator.ts` | `v-thousand` | 千分位分隔符 |

### 4.10 配置目录 (src/config/)

| 文件 | 说明 |
|------|------|
| `common.ts` | 公共常量配置 |
| `appVersion.ts` | 应用版本信息 |
| `icon.ts` | 图标配置 |

**common.ts 常量：**

```typescript
PUBLIC_KEY              // RSA 公钥
SHOW_SECOND_MENU_ICON   // 是否显示二级菜单图标
HIDE_MENU               // 隐藏菜单路径
ANONYMOUS_TOKEN         // 匿名 Token
REQUEST_WHITE_LIST      // 请求白名单
ANONYMOUS_TOKEN_LIST    // 匿名 Token 接口列表
```

---

## 五、构建与部署

### 5.1 构建脚本 (scripts/copy-tinymce.js)

**功能：** 将 TinyMCE 从 node_modules 复制到 public 目录

**复制内容：**
- icons/ - 图标
- langs/ - 语言包
- models/ - 模型
- plugins/ - 插件
- skins/ - 皮肤
- themes/ - 主题
- tinymce.min.js - 主文件
- tinymce.d.ts - 类型定义

**执行策略：**
- CI/CD 或生产环境：强制复制
- 开发环境：如已存在则跳过

### 5.2 Git Hooks

**pre-commit：**
1. 切换 Node 版本到 22
2. 执行 TypeScript 类型检查
3. 执行 lint-staged（对改动文件进行 lint 和格式化）

**commit-msg：**
- 校验提交信息格式（Conventional Commits）

### 5.3 生产构建优化

| 优化项 | 配置 |
|--------|------|
| 代码压缩 | Terser |
| 移除 console | `drop_console: true` |
| 移除 debugger | `drop_debugger: true` |
| Gzip 压缩 | 阈值 1KB |
| 代码分割 | 按 node_modules 包名分割 |
| 静态资源 | TinyMCE 预复制 |

---

## 六、开发规范

### 6.1 自动导入

**无需手动导入的内容：**

```typescript
// Vue API
ref, reactive, computed, watch, onMounted, ...

// Vue Router API
useRoute, useRouter

// VueUse API
useStorage, useDark, ...

// 组件
// src/components/ 下的组件自动导入，文件夹名即为组件名
```

### 6.2 代码风格

- 使用单引号
- 不使用分号
- 缩进 2 个空格
- 每行最大 80 字符
- 箭头函数省略参数括号
- 每行一个属性（Vue 模板）

### 6.3 提交规范

```bash
# 正确示例
git commit -m 'feat: 新增用户管理模块'
git commit -m 'fix: 修复登录页样式问题'
git commit -m 'refactor: 优化表格组件性能'
```

---

## 七、浏览器兼容性

- Chrome >= 88
- Firefox >= 78
- Safari >= 14
- Edge >= 88

---

## 八、功能模块概览

```
Vue3后台管理系统模板
├── 用户认证管理
│   ├── 登录与会话
│   │   ├── 账号密码登录
│   │   ├── 设备验证码登录
│   │   └── Captcha图形验证
│   ├── 多因素认证
│   │   ├── TOTP密钥绑定
│   │   ├── MFA类型配置
│   │   └── MFA验证流程
│   └── 密码与安全
├── 多租户运营管理
│   ├── 商户全周期管理
│   │   ├── 商户信息维护
│   │   ├── 商户等级配置
│   │   └── 商户资质审核
│   ├── 运营商管理
│   └── 资质与公告
├── 权限策略管理
│   ├── 用户与用户组
│   │   ├── 用户增删改查
│   │   ├── 用户状态管理
│   │   └── 用户权限分配
│   └── 菜单与权限
│       ├── 动态菜单加载
│       └── 权限策略配置
├── 计费与开票服务
│   ├── 订单与支付
│   ├── 发票管理
│   └── 余额与充值
├── 系统审计日志
│   ├── 操作日志
│   ├── 关键日志
│   └── 登录日志
└── 系统配置中心
    ├── 多语言配置
    ├── 主题与布局
    └── 字典与枚举
```

---

*文档生成时间：2026-04-08*
*项目版本：0.0.1*
