/**
 * 复制 tinymce 从 node_modules 到 public 目录
 * 只复制必要的文件：icons, langs, models, plugins, skins, themes, tinymce.min.js, tinymce.d.ts
 */
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const rootDir = path.resolve(__dirname, '..')
const sourceDir = path.join(
  rootDir,
  'node_modules',
  '.pnpm',
  'tinymce@6.8.6',
  'node_modules',
  'tinymce'
)
const targetDir = path.join(rootDir, 'public', 'tinymce')
const langsBackupDir = path.join(rootDir, 'scripts', 'tinymce-langs')

// 需要复制的文件和目录
const itemsToCopy = [
  'icons',
  'langs',
  'models',
  'plugins',
  'skins',
  'themes',
  'tinymce.min.js',
  'tinymce.d.ts'
]

/**
 * 复制文件或目录
 * @param {string} src - 源路径
 * @param {string} dest - 目标路径
 */
function copyRecursive(src, dest) {
  const stats = fs.statSync(src)

  if (stats.isDirectory()) {
    // 创建目标目录
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true })
    }

    // 复制目录内容
    const items = fs.readdirSync(src)
    for (const item of items) {
      const srcPath = path.join(src, item)
      const destPath = path.join(dest, item)
      copyRecursive(srcPath, destPath)
    }
  } else {
    // 复制文件
    fs.copyFileSync(src, dest)
  }
}

/**
 * 删除目录
 * @param {string} dir - 目录路径
 */
function removeDir(dir) {
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true })
  }
}

/**
 * 检查是否需要复制
 * @returns {boolean} - 是否需要复制
 */
function shouldCopy() {
  // 正式环境（CI/CD 或生产构建）强制复制
  if (process.env.CI || process.env.NODE_ENV === 'production') {
    return true
  }

  // 开发环境：如果已存在则不复制
  if (fs.existsSync(targetDir)) {
    console.log('📦 public/tinymce 已存在，跳过复制')
    return false
  }

  return true
}

/**
 * 主函数
 */
function main() {
  console.log('🚀 开始复制 tinymce...')

  // 检查是否需要复制
  if (!shouldCopy()) {
    console.log('✨ 跳过复制')
    process.exit(0)
  }

  // 检查源目录是否存在
  if (!fs.existsSync(sourceDir)) {
    console.error(`❌ 源目录不存在: ${sourceDir}`)
    process.exit(1)
  }

  // 删除旧的 target 目录
  console.log('🗑️  清理旧的 tinymce 目录...')
  removeDir(targetDir)

  // 创建新的 target 目录
  fs.mkdirSync(targetDir, { recursive: true })

  // 复制文件
  console.log('📦 复制必要文件...')
  for (const item of itemsToCopy) {
    const srcPath = path.join(sourceDir, item)
    const destPath = path.join(targetDir, item)

    if (fs.existsSync(srcPath)) {
      copyRecursive(srcPath, destPath)
      console.log(`  ✅ ${item}`)
    } else {
      console.warn(`  ⚠️  跳过不存在: ${item}`)
    }
  }

  // 复制语言包（从备份目录）
  console.log('📦 复制语言包...')
  const targetLangsDir = path.join(targetDir, 'langs')
  if (fs.existsSync(langsBackupDir)) {
    if (!fs.existsSync(targetLangsDir)) {
      fs.mkdirSync(targetLangsDir, { recursive: true })
    }
    const langFiles = fs.readdirSync(langsBackupDir)
    for (const file of langFiles) {
      const srcPath = path.join(langsBackupDir, file)
      const destPath = path.join(targetLangsDir, file)
      fs.copyFileSync(srcPath, destPath)
      console.log(`  ✅ langs/${file}`)
    }
  } else {
    console.warn('  ⚠️  语言包备份目录不存在，跳过语言包复制')
  }

  console.log('✨ tinymce 复制完成！')
}

main()
