import { defineConfig } from "vite";
import path from "path";
import VueMacros from "vue-macros/vite";
import vue from "@vitejs/plugin-vue";
import AutoImport from "unplugin-auto-import/vite";
import Components from "unplugin-vue-components/vite";
import { ElementPlusResolver } from "unplugin-vue-components/resolvers";
import { vitePluginVersionMark } from "vite-plugin-version-mark";
import { compression } from "vite-plugin-compression2";
import vitePageName from "vite-page-name"; // 自定义插件
import { execSync } from "child_process";
import { readFileSync } from "fs";

const pathSrc = path.resolve(__dirname, "src");
// 读取 package.json 中的 name
const pkg = JSON.parse(
  readFileSync(path.resolve(__dirname, "package.json"), "utf-8")
);
const appName = pkg.name;
export default defineConfig({
  base: "./",
  plugins: [
    VueMacros({
      plugins: {
        vue: vue(),
      },
    }),
    vitePageName(),
    AutoImport({
      resolvers: [
        ElementPlusResolver({
          importStyle: "sass",
        }),
      ],
      imports: ["vue", "vue-router", "@vueuse/core"],
      eslintrc: {
        enabled: true, // Default `false`
        filepath: "./.eslintrc-auto-import.json", // Default `./.eslintrc-auto-import.json`
        globalsPropValue: true, // Default `true`, (true | false | 'readonly' | 'readable' | 'writable' | 'writeable')
      },
      dts: true,
    }),
    Components({
      resolvers: [
        ElementPlusResolver({
          importStyle: "sass",
        }),
      ],
    }),
    vitePluginVersionMark({
      ifMeta: true, //  在<head>中添加<meta name=“application-name” content=“{APPNAME_VERSION}： {version}”>
      ifLog: false, // 在控制台中打印信息（默认）true
      ifGlobal: true, // 在窗口中设置一个名为“__${APPNAME}_VERSION__”的变量 APPNAME 是 package.json 中的 name 值的大写
    }),
    compression({
      algorithms: ["gzip"],
      threshold: 1000, // 压缩1kb以上的文件
      skipIfLargerOrEqual: false,
      deleteOriginalAssets: false,
    }),
  ],
  css: {
    preprocessorOptions: {
      // 统一引入该文件，LightningCSS 会有警告
      scss: { additionalData: `@use "@/layout/config.module.scss" as *;` },
    },
  },
  define: {
    "import.meta.env.VITE_GIT_SHA": JSON.stringify(
      (() => {
        try {
          return execSync("git rev-parse --short HEAD").toString().trim();
        } catch {
          return "unknown";
        }
      })()
    ),
    __APP_NAME__: JSON.stringify(appName), // 从 package.json 中读取 name 字段
  },
  resolve: {
    alias: {
      "@": pathSrc,
      "~/": `${pathSrc}/`,
      "vue-i18n": "vue-i18n/dist/vue-i18n.cjs.js",
    },
  },
  build: {
    minify: "terser",
    terserOptions: {
      compress: {
        drop_console: true, // 移除所有console.*
        drop_debugger: true, // 移除debugger
      },
    },
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes(".pnpm")) {
            return null;
          }
          // 判断是否为第三方依赖，将其拆分到 vendor 中
          if (id.includes("node_modules")) {
            return id
              .toString()
              .split("node_modules/")[1]
              .split("/")[0]
              .toString();
          }
        },
      },
    },
  },
  // 禁止 vite 预构建 wasm，避免路径错位
  optimizeDeps: { exclude: ["@jsquash/webp", "@jsquash/jpeg", "@jsquash/png"] },
  // Vite 在 code-splitting（分包） 模式下 不允许 Worker 输出格式为 iife 或 umd
  // 把 WebWorker 文件编译成 ESModule 格式
  worker: { format: "es" },
});
