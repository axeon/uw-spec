<script lang="ts" setup>
import { useMainStore } from '@/store/main'
import { type ComponentInternalInstance } from 'vue'
import { usePrompt } from '@/hooks/usePrompt'
import { useValidate } from '@/hooks/useValidate'
import { useCommonSelectTypes } from '@/utils/selectOptions'
import { useI18n } from 'vue-i18n'
import { saasAccountUserLoad, MscUser } from '@/api/uwAuthCenterSaasApi'
import { ElMessage, ElMessageBox, FormInstance, FormRules } from 'element-plus'
import { useCrud } from '@/hooks/useCrud'
import {
  ResponseData,
  DataList,
  CaptchaQuestion,
  authGenCaptcha
} from '@/api/uwAuthCenterAuthApi'
import {
  userUpdatePassword,
  userUpdateProfile,
  userSendDeviceCode,
  userBindDevice,
  userUnbindDevice,
  MscLoginLogEsQueryParam,
  userListActionLog,
  userListLoginLog,
  MscLoginEsLog,
  userUserTypeConfig,
  userClearTotpSecret,
  type UserTypeConfig
} from '@/api/uwAuthCenterUserApi'
import header1 from '@/assets/headerImg/img1.png'
import header2 from '@/assets/headerImg/img2.png'
import header3 from '@/assets/headerImg/img3.png'
import header4 from '@/assets/headerImg/img4.png'
import header5 from '@/assets/headerImg/img5.png'
import header6 from '@/assets/headerImg/img6.png'
import header7 from '@/assets/headerImg/img7.png'
import header8 from '@/assets/headerImg/img8.png'
import header9 from '@/assets/headerImg/img9.png'
import header10 from '@/assets/headerImg/img10.png'
import header11 from '@/assets/headerImg/img11.png'
import header12 from '@/assets/headerImg/img12.png'
import header13 from '@/assets/headerImg/img13.png'
import header14 from '@/assets/headerImg/img14.png'
import header15 from '@/assets/headerImg/img15.png'
import header16 from '@/assets/headerImg/img16.png'
import {
  type SaasInfo,
  type SaasMchInfo,
  saasPartnerMchInfoLoad
} from '@/api/saasBaseAppSaasApi'
import { userCommonInfoMyMchInfo } from '@/api/saasBaseAppUserApi'
import { watchAtMost } from '@vueuse/core'
import { rsaEncrypt } from '@/utils/encryptionAndDecryption'

// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance
const { dayjs, formatDate, useActivated } = proxy as any
const { t, locale } = useI18n()
const mainStore = useMainStore()
const { validateIdCard } = useValidate()
const route = useRoute()

const {
  userTypes,
  handleTypeForLabel,
  loginTypes,
  loginResultTypes,
  commonTypes,
  organizationalTypes,
  payTypes,
  currencyTypes,
  loginDeviceTypes
} = useCommonSelectTypes()

const userInfo = computed(() => {
  return mainStore.userInfo
})

const activeName = ref('first')
const switchError = ref(false) //是否仅显示失败信息

// 用户头像
const userIconImg = computed(() => {
  const index = mainStore.userInfo.userIcon
    ? Number(mainStore.userInfo.userIcon)
    : 0
  return headerImgList[index]
})

// 使用时间
const getDays = (val: string) => {
  const lastDate = Number(val) || 0
  const now = new Date().getTime()
  return ((now - lastDate) / 1000 / 3600 / 24).toFixed(0)
}

//信息列表
const infoList = computed(() => {
  return [
    {
      name: 'linkPhone',
      value:
        userInfo.value.mobile && userInfo.value.mobile.includes('!')
          ? userInfo.value.mobile.slice(1)
          : '',
      icon: 'phone',
      loginType: 23,
      content: t('myPhone')
    },
    {
      name: 'linkEmail',
      value:
        userInfo.value.email && userInfo.value.email.includes('!')
          ? userInfo.value.email.slice(1)
          : '',
      icon: 'email1',
      loginType: 22,
      content: t('myEmail')
    },
    {
      name: 'idCard',
      value: userInfo.value.idInfo ? userInfo.value.idInfo : '',
      icon: 'idcard',
      userName: userInfo.value.realName,
      content: t('idNumber')
    },
    {
      name: 'password',
      value: '**********',
      icon: 'key1',
      loginDate: getDays(userInfo.value.lastPasswdDate as string),
      content: t('login.passWord')
    }
  ]
})

// 用户资料
const popoverData = ref({})
// popover 显示
const handlePopoverShow = (item: MscLoginEsLog) => {
  const info = mainStore.saasUserInfo[item.userId as number]
  if (info && Object.keys(info).length) {
    popoverData.value = info
  } else {
    saasAccountUserLoad({
      id: item.userId as number
    })
      .then(res => {
        if (res.state === 'success') {
          popoverData.value = res.data || {}
        } else {
          popoverData.value = {}
        }
        mainStore.setSaasUserInfo(item.userId as number, popoverData.value)
      })
      .catch(() => {
        popoverData.value = {}
      })
  }
}

const {
  tableConfig, // 表格相关配置属性
  handleList // 列表请求函数
} = useCrud<MscLoginEsLog, MscLoginLogEsQueryParam>({
  // 列表请求接口
  listFn: (): Promise<ResponseData<DataList<MscLoginEsLog>>> => {
    if (activeName.value === 'first') {
      return userListLoginLog({
        ...tableConfig.queryParams,
        responseState: switchError.value ? 'error' : 'success',
        $sn: undefined,
        $st: undefined
      })
    }
    return userListActionLog({
      ...tableConfig.queryParams,
      responseState: switchError.value ? 'error' : 'success',
      $sn: undefined,
      $st: undefined
    })
  }
})

const handleTabChange = () => {
  handleList()
}

// 头像列表
const headerImgList = [
  header1,
  header2,
  header3,
  header4,
  header5,
  header6,
  header7,
  header8,
  header9,
  header10,
  header11,
  header12,
  header13,
  header14,
  header15,
  header16
]
// 修改头像弹窗
const dialogShow = ref(false)
// 蒙层显示
const overlayVisible = ref(false)
const handleResetDialog = () => {
  dialogShow.value = false
}

const chooseImg = ref('')
const dialogLoading = ref(false)

// 选择
const handleChoose = (val: number) => {
  chooseImg.value = String(val)
}
// 被选择的样式
const getChooseClass = (val: number) => {
  if (String(val) === chooseImg.value) {
    return 'chooseClass'
  }
  return 'unChooseClass'
}
const handleSubmitDialog = () => {
  // 设置系统信息头像
  dialogLoading.value = true
  userUpdateProfile({ ...userInfo.value, userIcon: chooseImg.value })
    .then(res => {
      dialogLoading.value = false
      ElMessage({
        message:
          res.state === 'success'
            ? t('avatarChangeSuccess')
            : t('avatarChangeFail'),
        type: res.state === 'success' ? 'success' : 'error'
      })
      if (res.state === 'success' && res.data) {
        mainStore.setUserInfo(res.data)
        dialogShow.value = false
      }
    })
    .catch(e => {
      ElMessage.error(e)
    })
    .finally(() => {
      dialogLoading.value = false
    })
}

// 当前用户信息类型
const activeInfo = ref('login')
const userInfoTabs = ref([
  { name: 'login', title: '账户信息' },
  { name: 'saas', title: '系统信息' },
  { name: 'mch', title: '商户信息' }
])

// 运营商Id
const operatorId = computed(() => userInfo.value.saasId)
// 运营商资料
const operatorInfo = ref<SaasInfo>({})

// 获取我的运营商
const getOperatorInfo = () => {
  // 加载运营商信息
  operatorInfo.value = mainStore.saasInfo
}

// 获取我的商户信息
const mySaasInfo = ref<SaasMchInfo>({})
const getMySaasInfo = () => {
  const request =
    mainStore.loginInfo.userType === 300
      ? saasPartnerMchInfoLoad({ id: mainStore.userInfo.id! })
      : userCommonInfoMyMchInfo()
  request
    .then(res => {
      mySaasInfo.value = res.data || {}
    })
    .catch(() => {
      mySaasInfo.value = {}
    })
}
const mchId = computed(() => userInfo.value.mchId)
// -----------------修改信息------------------
// 修改信息
const formData = ref<MscUser>({})
const editDialogShow = ref(false)
const handleResetEditDialog = () => {
  editDialogShow.value = false
}

// 修改类型 //password:密码 info:其余信息 idInfo:身份证
const editType = ref('password')
const editFormRef = ref<FormInstance>()
const handleEdit = (name: string) => {
  if (name === 'idCard') {
    editType.value = 'idInfo'
    editDialogShow.value = true
  } else if (name === 'password') {
    editType.value = 'password'
    editDialogShow.value = true
    handleLoadUserConfig()
  } else if (name === 'linkPhone') {
    bindInfoForm.value.loginType = 23
    showBindInfoDialog.value = true
  } else if (name === 'linkEmail') {
    bindInfoForm.value.loginType = 22
    showBindInfoDialog.value = true
  } else {
    editType.value = 'info'
    editDialogShow.value = true
  }
}

// 修改密码表单ref
const updatePassWordFormRef = ref<FormInstance>()
// 修改密码
const updatePassWordForm = reactive({
  oldPassword: '',
  newPassword: '',
  repeatNewPassword: ''
})

// 修改密码校验
const passwordRules = computed<FormRules>(() => {
  return {
    oldPassword: [
      {
        required: true,
        message: t('pleaseInput') + t('user.oldPassword')
      }
    ],
    newPassword: [
      {
        required: true,
        message: t('pleaseInput') + t('user.newPassword')
      },
      {
        validator: (rule: any, value: any, callback: any) => {
          if (
            /^(?=.*[A-Za-z])(?=.*\d)[\w!@#$%^&*\-+=(){}[\]|\\:;"'<>,.?/`~]{8,72}$/.test(
              value
            )
          ) {
            if (
              updatePassWordForm.oldPassword === updatePassWordForm.newPassword
            ) {
              callback(t('updatePasswordTip'))
            } else {
              callback()
            }
          } else {
            callback(new Error(t('passwordFormat')))
          }
        }
      }
    ],
    repeatNewPassword: [
      {
        required: true,
        message: t('user.realRepeatNewPassword')
      },
      {
        validator: (rule: any, value: any, callback: any) => {
          if (value !== updatePassWordForm.newPassword) {
            callback(new Error(t('user.passwordError')))
          } else {
            callback()
          }
        }
      }
    ]
  }
})

// 修改信息表单校验
const formInfoRules = computed<FormRules>(() => {
  return {
    nickName: [
      {
        required: editType.value === 'idInfo' ? false : true,
        message: t('pleaseInput') + t('nickName')
      }
    ],
    realName: [
      {
        required: editType.value === 'idInfo' ? true : false,
        message: t('pleaseInput') + t('realName')
      }
    ],
    idInfo: [
      {
        required: editType.value === 'idInfo' ? true : false,
        message: t('pleaseInput') + t('idNumber'),
        validator: validateIdCard()
      }
    ]
  }
})

// 点击保存修改密码
const handleSaveUpdatePassword = () => {
  updatePassWordFormRef.value?.validate(valid => {
    if (valid) {
      ElMessageBox.confirm(t('confirmEditPassword'), t('tip'), {
        confirmButtonText: t('confirm'),
        cancelButtonText: t('cancel'),
        type: 'warning'
      }).then(() => {
        dialogLoading.value = true
        userUpdatePassword({
          oldPassword: rsaEncrypt(updatePassWordForm.oldPassword) as string, //用户原密码
          newPassword: rsaEncrypt(updatePassWordForm.newPassword) as string //用户新密码
        })
          .then(res => {
            dialogLoading.value = false
            if (res.state === 'success') {
              ElMessage.success(t('passwordResetSuccess') + t('goToLoginPage'))
              sessionStorage.clear()
              if (location.pathname !== '/') {
                location.href = `${location.pathname}#/login?fullPath=${route.fullPath}`
              } else {
                location.href = `/#/login?fullPath=${route.fullPath}`
              }
            } else {
              if (res.code === 'auth.center.passwd.complexity.error') {
                if (passwordConfig.value) {
                  const msg = handlePasswordTip()
                  ElMessage.error(msg || res.msg)
                } else {
                  ElMessage.error(res.msg)
                }
              } else {
                ElMessage.error(res.msg)
              }
            }
          })
          .catch(e => {
            ElMessage.error(e)
          })
          .finally(() => {
            dialogLoading.value = false
          })
      })
    }
  })
}

// 密码配置要求
const passwordConfig = computed(() => {
  return userTypeConfig.value.passwordConfig?.name || ''
})

const userTypeConfig = ref<UserTypeConfig>({})
// 获取用户类型配置
const handleLoadUserConfig = () => {
  userUserTypeConfig()
    .then(res => {
      userTypeConfig.value = res.data || {}
    })
    .catch(() => {
      userTypeConfig.value = {}
    })
}

// 处理密码提示
const handlePasswordTip = () => {
  if (passwordConfig.value === 'ULTIMATE') {
    return t('ULTIMATEPasswordRule')
  } else if (passwordConfig.value === 'EXTREME') {
    return t('EXTREMEPasswordRule')
  } else if (passwordConfig.value === 'STRICT') {
    return t('STRICTPasswordRule')
  } else if (passwordConfig.value === 'STANDARD') {
    return t('STANDARDPasswordRule')
  } else if (passwordConfig.value === 'NORMAL') {
    return t('passwordFormat')
  }
}

// 修改自身信息
const handleSaveInfo = () => {
  if (!editFormRef.value) return
  editFormRef.value?.validate(valid => {
    if (valid) {
      ElMessageBox.confirm(t('confirmEditInfo'), t('tip'), {
        confirmButtonText: t('confirm'),
        cancelButtonText: t('cancel'),
        type: 'warning'
      }).then(() => {
        dialogLoading.value = true
        userUpdateProfile(formData.value)
          .then(res => {
            dialogLoading.value = false
            ElMessage({
              message:
                res.state === 'success'
                  ? t('infoEditSuccess')
                  : t('infoEditFail'),
              type: res.state === 'success' ? 'success' : 'error'
            })
            if (res.state === 'success' && res.data) {
              mainStore.setUserInfo(res.data)
              editDialogShow.value = false
            }
          })
          .catch(e => {
            ElMessage.error(e)
          })
          .finally(() => {
            dialogLoading.value = false
          })
      })
    }
  })
}

// 保存修改信息
const handleSubmitInfo = () => {
  if (editType.value === 'password') {
    // 修改密码
    handleSaveUpdatePassword()
  } else {
    // 修改其他信息
    handleSaveInfo()
  }
}

// --------------------------------邮箱、手机号认证--------------------------------
// 前往校验手机号
const handleValidatePhone = () => {
  bindInfoForm.value.loginType = 23
  showBindInfoDialog.value = true
}
// 前往校验邮箱
const handleValidateEmail = () => {
  bindInfoForm.value.loginType = 22
  showBindInfoDialog.value = true
}

const countNum = ref<number>(60) //倒计时计数
const showGetCode = ref(true) //获取验证码按钮
const showBindInfoDialog = ref(false)
const formRef = ref()

const bindInfoForm = ref<{
  loginType: number //23:手机号验证码 22:Email验证码
  loginId?: string
  password?: string
  verifyCode?: string
  imgCode?: string
}>({
  loginType: 23,
  loginId: undefined,
  password: undefined,
  verifyCode: undefined
})

// 校验参数
const validateParams = ref<CaptchaQuestion>({})
// 加密的签名
const validateSign = ref('')
// 是否显示校验
const showCaptcha = ref(false)
// 校验ref元素
const captchaRef = ref()

let timer: any = null
const resetBindInfoDialog = () => {
  bindInfoForm.value = {
    loginType: 23
  }
  clearInterval(timer)
  // 清空校验
  formRef.value?.clearValidate()
}

// 发送验证码
const toSendVerifyCode = () => {
  if (bindInfoForm.value.loginId) {
    dialogLoading.value = true
    userSendDeviceCode({
      mfaType: bindInfoForm.value.loginType,
      deviceId: bindInfoForm.value.loginId,
      captchaId: validateParams.value.captchaId || '',
      captchaSign: validateParams.value.captchaId ? validateSign.value : ''
    })
      .then(res => {
        if (res.state === 'success') {
          showGetCode.value = false
          timer = setInterval(() => {
            if (countNum.value > 0) {
              countNum.value = countNum.value - 1
            } else {
              countNum.value = 60
              clearInterval(timer)
              showGetCode.value = true
            }
          }, 1000)
          ElMessage.success(
            bindInfoForm.value.loginType === 23
              ? t('smsCodeIsSend')
              : t('emailCodeIsSend')
          )
        } else {
          if (String(res.code).includes('auth.center.captcha.verify')) {
            // 验证码错误重新刷新
            captchaRef.value?.validateError()
            setTimeout(() => {
              handleRefreshCode()
            }, 1500)
          } else {
            ElMessage.error(res.msg)
            showCaptcha.value = false
            dialogLoading.value = false
          }
        }
      })
      .catch(e => {
        console.log(e)
      })
  }
}

//绑定相关信息
const toBindLogin = (formEl: FormInstance) => {
  if (!formEl) return
  formEl.validate(valid => {
    if (valid) {
      dialogLoading.value = true
      const obj = JSON.parse(JSON.stringify(bindInfoForm.value))
      userBindDevice({
        mfaType: obj.loginType,
        deviceId: obj.loginId ? obj.loginId : '',
        password: obj.password ? (rsaEncrypt(obj.password) as string) : '',
        deviceCode: obj.verifyCode ? obj.verifyCode : ''
      })
        .then(async res => {
          if (res.state === 'success') {
            ElMessage.success(t('bindInfoSuccess'))
            mainStore.handleUserProfile()
            showBindInfoDialog.value = false
          } else {
            ElMessage.error(res.msg)
          }
        })
        .catch(e => {
          console.log(e)
        })
        .finally(() => {
          dialogLoading.value = false
        })
    }
  })
}

// 获取验证码是否禁用
const disabledGetCodeBtn = computed(() => {
  const reg =
    bindInfoForm.value.loginType === 23
      ? /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/
      : /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
  if (bindInfoForm.value && bindInfoForm.value.loginId) {
    if (reg.test(bindInfoForm.value.loginId)) {
      return false
    }
    return true
  }
  return true
})

// 生成Captcha
const getGenCaptcha = () => {
  dialogLoading.value = true
  authGenCaptcha({
    captchaId: validateParams.value.captchaId || ''
  })
    .then(res => {
      if (res.state === 'success') {
        validateParams.value = {}
        showCaptcha.value = false
        // 直接获取设备码
        toSendVerifyCode()
      } else if (res.state === 'error' && res.msg) {
        validateParams.value = {}
        showCaptcha.value = false
      } else if (res.data && res.data.captchaId) {
        validateParams.value = { ...res.data }
        showCaptcha.value = true
      }
    })
    .finally(() => {
      dialogLoading.value = false
    })
}

// 邮箱手机号认证
const rules = reactive<FormRules>({
  password: [
    {
      required: true,
      message: t('pleaseInput') + t('login.passWord'),
      trigger: 'blur'
    }
  ],
  verifyCode: [
    {
      required: true,
      message: t('pleaseInputValidateCode'),
      trigger: 'blur'
    }
  ]
})

// 刷新验证
const handleRefreshCode = () => {
  authGenCaptcha({
    captchaId: validateParams.value.captchaId || ''
  }).then(res => {
    if (res.state === 'success') {
      validateParams.value = {}
      showCaptcha.value = false
      // 直接获取设备码
      toSendVerifyCode()
    } else if (res.state === 'error' && res.msg) {
      validateParams.value = {}
      showCaptcha.value = false
    } else if (res.data && res.data.captchaId) {
      validateParams.value = { ...res.data }
      showCaptcha.value = true
    }
  })
}

// 点击验证
const handleValidate = (val: string) => {
  dialogLoading.value = true
  validateSign.value = val
  userSendDeviceCode({
    mfaType: bindInfoForm.value.loginType,
    deviceId: bindInfoForm.value.loginId!,
    captchaId: validateParams.value.captchaId || '',
    captchaSign: validateParams.value.captchaId ? validateSign.value : ''
  })
    .then(res => {
      if (res.state === 'success') {
        captchaRef.value?.validateSuccess()
        showGetCode.value = false
        dialogLoading.value = false
        timer = setInterval(() => {
          if (countNum.value > 0) {
            countNum.value = countNum.value - 1
          } else {
            countNum.value = 60
            clearInterval(timer)
            showGetCode.value = true
          }
        }, 1000)
      } else {
        if (String(res.code).includes('auth.center.captcha.verify')) {
          // 验证码错误重新刷新
          captchaRef.value?.validateError()
          setTimeout(() => {
            handleRefreshCode()
          }, 1500)
        } else {
          ElMessage.error(res.msg)
          showCaptcha.value = false
          dialogLoading.value = false
        }
      }
    })
    .catch(() => {
      dialogLoading.value = false
    })
}

// 解绑
const handleUnbind = (val?: string, loginType?: number) => {
  if (val) {
    usePrompt({
      title: t('tip'),
      message: t('pleaseInput') + t('password'),
      confirmButtonText: t('confirm'),
      cancelButtonText: t('cancel'),
      type: 'warning',
      showInput: true,
      confirmCallBack(remark) {
        dialogLoading.value = true
        userUnbindDevice({
          mfaType: loginType as number,
          password: rsaEncrypt(remark!) as string
        })
          .then(res => {
            if (res.state === 'success') {
              ElMessage.success(t('unBindSuccess'))
              // 获取当前用户信息
              mainStore.handleUserProfile()
            } else {
              ElMessage.error(res.msg)
            }
          })
          .catch(e => {
            ElMessage.error(e)
          })
          .finally(() => {
            dialogLoading.value = false
          })
      }
    })
  }
}

// 信息隐藏处理
const handleHideInfo = (
  str: string,
  firstLength: number,
  lastLength: number
) => {
  const len = str.length - firstLength - lastLength
  let xing = ''
  for (let i = 0; i < len; i++) {
    xing += '*'
  }
  return (
    str.substring(0, firstLength) +
    xing +
    str.substring(str.length - lastLength)
  )
}

// 清除MFA密钥
const handleClearMFAValidate = () => {
  ElMessageBox.prompt(t('pleaseInput') + t('login.passWord'), t('tip'), {
    confirmButtonText: t('confirm'),
    cancelButtonText: t('cancel'),
    type: 'warning',
    inputValidator: (value: string) => {
      if (value) {
        return true
      }
      return false
    },
    inputErrorMessage: t('pleaseInput') + t('login.passWord'),
    inputType: 'text'
  }).then(({ value }) => {
    userClearTotpSecret({
      password: rsaEncrypt(value) as string
    }).then(res => {
      if (res.state === 'success') {
        ElMessage.success(t('clearMFAValidateSuccess'))
        sessionStorage.clear()
        if (location.pathname !== '/') {
          location.href = `${location.pathname}#/login?fullPath=${route.fullPath}`
        } else {
          location.href = `/#/login?fullPath=${route.fullPath}`
        }
      } else {
        ElMessage.error(res.msg)
      }
    })
  })
}

const watchCountNumHandler = watch(
  () => showBindInfoDialog.value,
  val => {
    if (val) {
      // 清空倒计时
      countNum.value = 60
      showGetCode.value = true
    }
  }
)

const watchHandler = watch(
  () => editDialogShow.value,
  val => {
    if (val) formData.value = { ...userInfo.value }
  }
)

// 有商户id就请求
watchAtMost(
  () => mchId.value,
  val => {
    if (val) {
      getMySaasInfo()
    }
  }, // 最多触发3次
  {
    count: 5, // 触发次数
    immediate: true
  }
)

// 有运营商id就请求
watchAtMost(
  () => operatorId.value,
  val => {
    if (val) {
      getOperatorInfo()
    }
  }, // 最多触发3次
  {
    count: 5, // 触发次数
    immediate: true
  }
)

const watchListHandler = watch(
  () => switchError.value,
  () => {
    handleList()
  }
)

useActivated(() => {
  handleList()
})

onUnmounted(() => {
  watchCountNumHandler()
  watchHandler()
  watchHandler()
  watchListHandler()
})
</script>

<template>
  <div class="box">
    <div class="box-left h100">
      <el-card class="left-top">
        <div class="top-item">
          <div
            v-for="(item, index) in infoList"
            :key="index"
          >
            <div
              class="item"
              :class="
                item.name === 'password' && Number(item.loginDate) > 90
                  ? 'pastDueClass'
                  : ''
              "
            >
              <div>
                <el-icon size="80">
                  <i
                    class="iconfont"
                    :class="item.icon"
                    style="font-size: 60px"
                  ></i>
                </el-icon>
              </div>
              <div class="flex-col">
                <p class="item-title">{{ item.content }}</p>
                <div class="item-content">
                  <template
                    v-if="
                      item.name === 'linkPhone' || item.name === 'linkEmail'
                    "
                  >
                    <div
                      v-if="item.value"
                      style="line-height: 50px"
                      class="space-around"
                    >
                      <span class="item-content-value">
                        {{ handleHideInfo(item.value, 3, 4) }}
                      </span>
                      <el-link
                        underline="never"
                        @click="handleUnbind(item.value, item.loginType)"
                        type="primary"
                      >
                        {{ t('unBind') }}
                      </el-link>
                    </div>
                    <div
                      v-else
                      style="line-height: 50px"
                    >
                      <el-text type="danger">{{ t('noBind') }}</el-text>
                    </div>
                  </template>
                  <div
                    v-else-if="item.name === 'idCard'"
                    style="height: 30px; padding: 10px 0px"
                    class="flx-col space-between"
                  >
                    <div>{{ item.userName }}</div>
                    <div>
                      {{ item.value ? handleHideInfo(item.value, 3, 4) : '--' }}
                    </div>
                  </div>
                  <div
                    v-else-if="item.name === 'password'"
                    style="height: 30px; padding: 10px 0px"
                    class="flex-col space-between"
                  >
                    <div>{{ item.value }}</div>
                    <div>
                      <span>{{ t('used') }}</span>
                      &nbsp;{{ item.loginDate }}&nbsp;
                      <span>{{ t('day') }}</span>
                    </div>
                  </div>
                </div>
                <div>
                  <el-link
                    v-if="
                      item.value ||
                      item.name === 'idCard' ||
                      item.name === 'password'
                    "
                    underline="never"
                    type="primary"
                    @click="handleEdit(item.name)"
                  >
                    {{ t('edit') }}
                    <el-icon><ArrowRight /></el-icon>
                  </el-link>
                  <el-link
                    v-else
                    underline="never"
                    type="primary"
                    @click="
                      item.name === 'linkPhone'
                        ? handleValidatePhone()
                        : handleValidateEmail()
                    "
                  >
                    {{ t('bind') }}
                    <el-icon><ArrowRight /></el-icon>
                  </el-link>
                  <el-link
                    underline="never"
                    type="primary"
                    v-if="item.name === 'password'"
                    class="margin-left-10"
                    @click="handleClearMFAValidate"
                  >
                    {{ t('clearMFAValidate') }}
                  </el-link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </el-card>
      <el-card class="left-bottom">
        <div>
          <el-tabs
            v-model="activeName"
            class="demo-tabs"
            @tab-change="handleTabChange"
          >
            <el-tab-pane
              :label="t('loginLog')"
              name="first"
            ></el-tab-pane>
            <el-tab-pane
              :label="t('sensitiveOperation')"
              name="second"
            ></el-tab-pane>
          </el-tabs>
          <el-table
            v-if="activeName === 'first'"
            :style="{ width: '100%' }"
            height="100%"
            :header-cell-style="{
              backgroundColor: 'var(--el-color-info-light-9)'
            }"
            :data="tableConfig.dataList"
            v-loading="tableConfig.tableLoading"
            class="tableClass"
          >
            <el-table-column
              prop="loginId"
              :label="t('loginId')"
              align="center"
              width="150"
            >
              <template #default="{ row }">
                <p>{{ row.loginId }}</p>
                <p>
                  {{ handleTypeForLabel(row.loginType, loginTypes) }}
                </p>
              </template>
            </el-table-column>
            <el-table-column
              prop="userName"
              :label="t('loginInfo')"
              minWidth="150"
              align="center"
            >
              <template #default="{ row }">
                <p>{{ row.userName }}</p>
                <p>{{ row.userIp }}</p>
              </template>
            </el-table-column>
            <el-table-column
              :label="t('uwAuthCenter.MscLoginESLog.loginType')"
              width="150"
              align="center"
            >
              <template #default="scope">
                <div>
                  {{ handleTypeForLabel(scope.row.loginType, loginTypes) }}
                </div>
                <div v-if="scope.row.saasId">
                  {{ `saasId:${scope.row.saasId}` }}
                </div>
              </template>
            </el-table-column>
            <el-table-column
              :label="t('loginAgent')"
              align="center"
              width="200"
            >
              <template v-slot="{ row }">
                <div v-if="row.loginAgent">
                  {{ row.loginAgent.split('/')[0] }}
                </div>
                <div v-if="row.loginAgent">
                  {{ row.loginAgent.split('/')[1] }}
                </div>
              </template>
            </el-table-column>
            <el-table-column
              :label="t('appHostInfo')"
              width="200"
              align="center"
            >
              <template #default="scope">
                <div>{{ scope.row.appInfo }}</div>
                <div>{{ scope.row.appHost }}</div>
              </template>
            </el-table-column>
            <el-table-column
              prop="clientType"
              :label="t('uwAuthCenter.MscLoginESLog.clientType')"
              width="120"
              align="center"
            >
              <template #default="scope">
                <el-tooltip
                  effect="dark"
                  :content="scope.row.clientAgent ? scope.row.clientAgent : ''"
                  :disabled="!scope.row.clientAgent"
                  placement="top"
                >
                  <el-link
                    underline="never"
                    :type="scope.row.clientAgent ? 'success' : 'info'"
                  >
                    {{
                      handleTypeForLabel(scope.row.clientType, loginDeviceTypes)
                    }}
                  </el-link>
                </el-tooltip>
              </template>
            </el-table-column>
            <el-table-column
              :label="t('uwAuthCenter.MscLoginESLog.loginResult')"
              min-width="250"
              align="center"
            >
              <template #default="{ row }">
                <div>
                  <el-link
                    underline="never"
                    :type="
                      row.responseState === 'success' ? 'success' : 'danger'
                    "
                  >
                    {{
                      handleTypeForLabel(row.responseState, loginResultTypes)
                    }}
                  </el-link>
                  <span>{{ `(${row.responseMillis}ms)` }}</span>
                </div>
                <div v-if="row.responseState !== 'success'">
                  {{ row.responseMsg }}
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="loginDate"
              :label="t('uwAuthCenter.MscLoginESLog.loginDate')"
              width="180"
              align="center"
            >
              <template #default="scope">
                <span>
                  {{ formatDate(scope.row.loginDate) }}
                </span>
              </template>
            </el-table-column>
          </el-table>
          <el-table
            v-else
            :style="{ width: '100%' }"
            height="100%"
            :header-cell-style="{
              backgroundColor: 'var(--el-color-info-light-9)'
            }"
            :data="tableConfig.dataList"
            v-loading="tableConfig.tableLoading"
            class="tableClass"
          >
            <el-table-column
              prop="userInfo"
              :label="t('uwAuthCenter.MscActionESLog.userName')"
              align="center"
              width="220"
            >
              <template #default="{ row }">
                <p>
                  {{ row.userName }}({{
                    handleTypeForLabel(row.userType, userTypes)
                  }})
                </p>
                <p>{{ row.userIp }}</p>
              </template>
            </el-table-column>
            <el-table-column
              prop="apiName"
              :label="t('businessInfo')"
              width="350"
              align="center"
            >
              <template #default="scope">
                <div class="flex-col flex-align">
                  <el-tooltip
                    effect="dark"
                    placement="top"
                    :disabled="!scope.row.bizType"
                  >
                    <template #content>
                      <p>
                        {{ scope.row.bizType }}
                        <span v-if="scope.row.bizId || scope.row.bizId === 0">
                          :{{ scope.row.bizId }}
                        </span>
                      </p>
                    </template>
                    <el-text :type="scope.row.bizType ? 'primary' : ''">
                      <div>{{ scope.row.apiName }}</div>
                    </el-text>
                  </el-tooltip>
                  <p>{{ scope.row.apiUri }}</p>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="requestInfo"
              :label="t('requestAndResponse')"
              align="left"
              header-align="center"
              width="300"
            >
              <template #default="scope">
                <div style="display: flex">
                  <el-tooltip
                    effect="dark"
                    placement="left"
                    :disabled="!scope.row.requestBody"
                  >
                    <template #content>
                      <div style="width: 500px">
                        {{ scope.row.requestBody ? scope.row.requestBody : '' }}
                      </div>
                    </template>
                    <el-text type="success">
                      <div class="textAlignLeft">{{ t('requestInfo') }}</div>
                    </el-text>
                  </el-tooltip>
                  &nbsp;&nbsp;
                  <span>
                    {{ formatDate(scope.row.requestDate) }}
                  </span>
                </div>
                <div style="display: flex">
                  <el-tooltip
                    effect="dark"
                    placement="top"
                    :disabled="!scope.row.responseBody"
                  >
                    <template #content>
                      <div style="width: 500px">
                        {{
                          scope.row.responseBody ? scope.row.responseBody : ''
                        }}
                      </div>
                    </template>

                    <el-text :type="scope.row.responseBody ? 'success' : ''">
                      <div>
                        <span>{{ t('returnContent') }}</span>
                      </div>
                    </el-text>
                  </el-tooltip>
                  &nbsp;&nbsp;
                  <span>{{ t('timeConsuming') }}</span>
                  <span>({{ scope.row.responseMillis }}ms)</span>
                </div>
                <div v-if="scope.row.exception">
                  <el-tooltip
                    effect="dark"
                    :content="scope.row.exception ? scope.row.exception : ''"
                    :disabled="!scope.row.exception"
                    teleported
                    :offset="20"
                  >
                    <el-text type="danger">
                      <span>{{ t('errorInfo') }}</span>
                    </el-text>
                  </el-tooltip>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="responseMsg"
              :label="t('uwAuthCenter.MscActionESLog.log')"
              align="center"
              min-width="250"
            ></el-table-column>
            <el-table-column
              prop="statusCode"
              :label="t('state')"
              align="center"
              width="70"
              fixed="right"
            >
              <template #default="scope">
                <el-text
                  :type="scope.row.statusCode === 200 ? 'success' : 'danger'"
                >
                  {{ scope.row.statusCode === 200 ? t('success') : t('error') }}
                </el-text>
              </template>
            </el-table-column>
          </el-table>
          <Pagination
            v-model:page-size="tableConfig.queryParams.$rn"
            :page-sizes="[10, 50, 100, 200, 300, 400]"
            @page-size-change="handleList"
            :total="tableConfig.sizeAll"
            v-model:current-page="tableConfig.queryParams.$pg"
            @current-change="handleList"
            class="flex_col_bottom"
          />

          <el-switch
            v-model="switchError"
            :inactive-text="t('onlyShowErrorInfo')"
            class="switchBtn"
          />
        </div>
      </el-card>
    </div>
    <div class="box-right">
      <el-card class="box-right-content">
        <div class="right-tab">
          <ul>
            <template
              v-for="item in userInfoTabs"
              :key="item.name"
            >
              <li
                :class="item.name === activeInfo ? 'activeTab' : ''"
                @click="activeInfo = item.name"
                class="cursor-p"
                v-show="item.name !== 'mch' || mchId"
              >
                {{ item.title }}
              </li>
            </template>
          </ul>
        </div>
        <div style="padding: 20px">
          <template v-if="activeInfo === 'login'">
            <div>
              <div
                class="image-container"
                @mouseover="overlayVisible = true"
                @mouseleave="overlayVisible = false"
              >
                <el-image
                  :src="userIconImg || header1"
                  class="userIcon"
                />
                <div
                  class="overlay"
                  v-if="overlayVisible"
                  @click="dialogShow = true"
                >
                  <el-text type="primary">{{ t('avatarEdit') }}</el-text>
                </div>
              </div>
              <h3>
                Hi，{{ userInfo.nickName }}
                <el-icon
                  class="editIcon"
                  @click="handleEdit('info')"
                >
                  <Edit />
                </el-icon>
              </h3>
              <span>
                {{ userInfo.remark ? userInfo.remark : '--' }}
              </span>
            </div>
            <div class="right-userInfo">
              <div>
                <span class="title">{{ t('loginAccount') }}</span>
                <span>{{ userInfo.username }}</span>
              </div>
              <div>
                <span>{{ t('onGroupName') }}</span>
                <span>
                  {{ userInfo.groupName ? userInfo.groupName : '--' }}
                </span>
              </div>
              <div>
                <span>{{ t('userType') }}</span>
                <span>
                  {{
                    handleTypeForLabel(userInfo.userType as number, userTypes)
                  }}
                </span>
              </div>
              <div>
                <span>{{ t('logonCount') }}</span>
                <span>
                  {{ userInfo.logonCount }}
                </span>
              </div>
              <div>
                <span>{{ t('lastLogonDate') }}</span>
                <div class="flex-start flex-col textAlignLeft">
                  <span style="margin-bottom: 10px">
                    {{ userInfo.lastLogonIp }}
                  </span>
                  <span>
                    {{ formatDate(userInfo.lastLogonDate) }}
                  </span>
                </div>
              </div>
              <div>
                <span>{{ t('lastModify') }}</span>
                <span class="textAlignLeft">
                  {{ formatDate(userInfo.modifyDate) }}
                </span>
              </div>
              <div>
                <span>{{ t('state') }}</span>
                <el-text :type="userInfo.state === 1 ? 'success' : 'danger'">
                  {{
                    handleTypeForLabel(userInfo.state as number, commonTypes)
                  }}
                </el-text>
              </div>
            </div>
            <div class="right-date">
              <span>{{ t('hasRegister') }}</span>
              <span>{{ getDays(userInfo.createDate as string) }}</span>
              <span>{{ t('day') }}</span>
              {{ formatDate(userInfo.createDate) }}）
            </div>
          </template>
          <template v-else-if="activeInfo === 'saas'">
            <div>
              <h3>Hi，{{ operatorInfo.saasName }}</h3>
              <p class="idStyle">ID:{{ operatorInfo.id }}</p>
              <p class="font14">{{ operatorInfo.orgAddress }}</p>
            </div>
            <div class="right-operatorInfo font14">
              <div>
                <span>{{ t('organizationalType') }}</span>
                <span>
                  {{
                    handleTypeForLabel(
                      operatorInfo.orgType!,
                      organizationalTypes
                    )
                  }}
                </span>
              </div>
              <div>
                <span>{{ t('paymentType') }}</span>
                <span>
                  {{ handleTypeForLabel(operatorInfo.serviceType!, payTypes) }}
                </span>
              </div>
              <div>
                <span>{{ t('contacts') }}</span>
                <div class="flex-col flex-start textAlignLeft">
                  <p>
                    {{ operatorInfo.contactName }}&nbsp;&nbsp;{{
                      operatorInfo.contactMobile
                        ? operatorInfo.contactMobile?.includes('!')
                          ? handleHideInfo(
                              operatorInfo.contactMobile.slice(1),
                              3,
                              4
                            )
                          : handleHideInfo(operatorInfo.contactMobile, 3, 4)
                        : '--'
                    }}
                  </p>
                  <p>{{ operatorInfo.contactEmail }}</p>
                </div>
              </div>
              <div>
                <span>{{ t('quotationCurrency') }}</span>
                <span>
                  {{
                    handleTypeForLabel(
                      operatorInfo.saasCurrency!,
                      currencyTypes
                    )
                  }}
                </span>
              </div>
              <div>
                <span>{{ t('personInCharge') }}</span>
                <div class="flex-col flex-start">
                  <p v-if="operatorInfo.bdInfo">
                    <span>{{ t('attractInvestment') }}</span>
                    &nbsp;-&nbsp;{{ operatorInfo.bdInfo }}
                  </p>
                  <p v-if="operatorInfo.opInfo">
                    <span>{{ t('service') }}</span>
                    &nbsp;-&nbsp;{{ operatorInfo.opInfo }}
                  </p>
                </div>
              </div>
              <div>
                <span>{{ t('status') }}</span>
                <el-text
                  :type="operatorInfo.state === 1 ? 'success' : 'danger'"
                >
                  {{ handleTypeForLabel(operatorInfo.state!, commonTypes) }}
                </el-text>
              </div>
            </div>
            <div class="right-date">
              <span>{{ t('createdOn') }}</span>
              <span>{{ formatDate(operatorInfo.createDate) }}</span>
            </div>
          </template>
          <template v-else>
            <div>
              <h3>Hi，{{ mySaasInfo.mchName }}</h3>
              <div class="flex-center">
                <span class="subheading">
                  {{
                    mySaasInfo.mchType === 1 ? t('supplier') : t('distributor')
                  }}
                </span>
              </div>
              <p class="idStyle">ID:{{ mySaasInfo.saasId }}</p>
              <p>
                {{ mySaasInfo.contactAddress }}
              </p>
            </div>
            <div class="right-operatorInfo font14">
              <div>
                <span>{{ t('contacts') }}</span>
                <div class="flex-col flex-start">
                  <p>
                    {{ mySaasInfo.contactName }}&nbsp;&nbsp;{{
                      mySaasInfo.contactMobile
                    }}
                  </p>
                  <p>{{ mySaasInfo.contactEmail }}</p>
                </div>
              </div>
              <div>
                <span>{{ t('quotationCurrency') }}</span>
                <span>
                  {{
                    handleTypeForLabel(mySaasInfo.mchCurrency!, currencyTypes)
                  }}
                </span>
              </div>
              <div>
                <span>{{ t('performance') }}</span>
                <div class="flex-col flex-start textAlignLeft">
                  <p>
                    <span style="display: inline-block; width: 80px">
                      {{ t('orderNum') }}
                    </span>
                    {{ mySaasInfo.statsOrder }}
                  </p>
                  <p>
                    <span style="display: inline-block; width: 80px">
                      {{ t('orderAmount') }}
                    </span>
                    {{ mySaasInfo.statsMoney }}
                  </p>
                  <p>
                    <span style="display: inline-block; width: 80px">
                      {{ t('statsProduct') }}
                    </span>
                    {{ mySaasInfo.statsProduct }}
                  </p>
                </div>
              </div>
              <div>
                <span>{{ t('desc') }}</span>
                <span>
                  {{ mySaasInfo.mchDesc ? mySaasInfo.mchDesc : '--' }}
                </span>
              </div>
              <div>
                <span>{{ t('status') }}</span>
                <el-text :type="mySaasInfo.state === 1 ? 'success' : 'danger'">
                  {{ handleTypeForLabel(mySaasInfo.state!, commonTypes) }}
                </el-text>
              </div>
            </div>
            <div class="right-date">
              <span>{{ t('createdOn') }}</span>
              <span>
                {{ dayjs(operatorInfo.createDate).format('YYYY-MM-DD') }}
              </span>
            </div>
          </template>
        </div>
      </el-card>
    </div>
  </div>
  <!-- 修改头像 -->
  <el-dialog
    v-model="dialogShow"
    :title="t('avatarEdit')"
    destroy-on-close
    @close="handleResetDialog"
    draggable
    :close-on-click-modal="false"
    width="1000px"
  >
    <div
      style="flex-wrap: wrap; width: 748px; margin: auto"
      class="space-between"
    >
      <template
        v-for="(item, index) in headerImgList"
        :key="index"
      >
        <el-image
          :src="item"
          class="imgItem"
          :class="getChooseClass(index)"
          @click="handleChoose(index)"
        />
      </template>
    </div>
    <template #footer>
      <el-button
        @click="dialogShow = false"
        icon="Close"
      >
        {{ t('cancel') }}
      </el-button>
      <el-button
        type="primary"
        @click="handleSubmitDialog"
        :loading="dialogLoading"
        icon="Check"
      >
        {{ t('edit') }}
      </el-button>
    </template>
  </el-dialog>
  <!-- 修改账号信息 -->
  <el-dialog
    v-model="editDialogShow"
    :title="editType === 'password' ? t('editPassword') : t('editUserInfo')"
    destroy-on-close
    @close="handleResetEditDialog"
    draggable
    :close-on-click-modal="false"
    width="480px"
    class="dialogClass"
  >
    <div class="padding-top-10">
      <template v-if="editType === 'password'">
        <el-form
          :model="updatePassWordForm"
          label-width="auto"
          :rules="passwordRules"
          ref="updatePassWordFormRef"
        >
          <el-row
            type="flex"
            justify="center"
          >
            <el-col :span="20">
              <el-form-item
                :label="t('user.oldPassword')"
                prop="oldPassword"
              >
                <el-input
                  v-model="updatePassWordForm.oldPassword"
                  type="password"
                  show-password
                  clearable
                />
              </el-form-item>
            </el-col>
            <el-col :span="20">
              <el-form-item
                :label="t('user.newPassword')"
                prop="newPassword"
              >
                <el-input
                  v-model="updatePassWordForm.newPassword"
                  type="password"
                  show-password
                  clearable
                />
              </el-form-item>
            </el-col>
            <el-col :span="20">
              <el-form-item
                :label="t('user.repeatNewPassword')"
                prop="repeatNewPassword"
              >
                <el-input
                  v-model="updatePassWordForm.repeatNewPassword"
                  type="password"
                  show-password
                  clearable
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </template>
      <template v-else>
        <el-form
          :model="formData"
          :label-width="editType === 'idInfo' ? '100px' : '60px'"
          label-position="right"
          :rules="formInfoRules"
          ref="editFormRef"
        >
          <template v-if="editType === 'idInfo'">
            <el-row>
              <el-col :span="22">
                <el-form-item
                  :label="t('realName')"
                  prop="realName"
                >
                  <el-input v-model="formData.realName" />
                </el-form-item>
              </el-col>
              <el-col :span="22">
                <el-form-item
                  :label="t('idNumber')"
                  prop="idInfo"
                >
                  <el-input v-model="formData.idInfo" />
                </el-form-item>
              </el-col>
            </el-row>
          </template>
          <template v-else>
            <el-row>
              <el-col :span="22">
                <el-form-item
                  :label="t('nickName')"
                  prop="nickName"
                >
                  <el-input v-model="formData.nickName" />
                </el-form-item>
              </el-col>
              <el-col :span="22">
                <el-form-item :label="t('remark')">
                  <el-input
                    type="textarea"
                    v-model="formData.remark"
                    :autosize="{ minRows: 3 }"
                    :placeholder="t('pleaseInput') + t('remark')"
                    clearable
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
          </template>
        </el-form>
      </template>
    </div>
    <template #footer>
      <el-button
        @click="editDialogShow = false"
        icon="Close"
      >
        {{ t('cancel') }}
      </el-button>
      <el-button
        type="primary"
        @click="handleSubmitInfo"
        :loading="dialogLoading"
        icon="Check"
      >
        {{ t('edit') }}
      </el-button>
    </template>
  </el-dialog>

  <!-- 邮箱、手机验证 -->
  <el-dialog
    v-model="showBindInfoDialog"
    :title="
      bindInfoForm.loginType === 23
        ? t('certifiedPhoneNumber')
        : t('certifiedEmail')
    "
    @close="resetBindInfoDialog"
    draggable
    width="480px"
    class="dialogClass"
    :close-on-click-modal="false"
  >
    <el-form
      ref="formRef"
      :model="bindInfoForm"
      label-width="0"
      label-position="right"
      :rules="rules"
      :validate-on-rule-change="false"
      class="padding-top-15"
      v-show="!showCaptcha"
    >
      <el-row
        type="flex"
        justify="center"
      >
        <el-col :span="20">
          <el-form-item
            :rules="[
              {
                required: true,
                message:
                  bindInfoForm.loginType === 23
                    ? t('validPhoneFormat') + t('pleReInput')
                    : t('uwAuthCenterExtend.MscUserRegister.validEmail') +
                      t('pleReInput'),
                pattern:
                  bindInfoForm.loginType === 23
                    ? /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/
                    : /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/,
                trigger: 'blur'
              }
            ]"
          >
            <el-input
              v-model="bindInfoForm.loginId"
              :placeholder="
                bindInfoForm.loginType === 23
                  ? t('pleaseInput') + t('user.mobile')
                  : t('pleaseInput') + t('user.email')
              "
              style="width: 100%; flex: 1"
            ></el-input>
            <el-button
              type="success"
              round
              :disabled="disabledGetCodeBtn"
              @click="getGenCaptcha"
              v-if="showGetCode"
              class="margin-left-5"
            >
              {{ t('getValidateCode') }}
            </el-button>
            <el-button
              type="success"
              round
              :disabled="true"
              v-else
            >
              {{ `${t('getValidateCode')}(${countNum})s` }}
            </el-button>
          </el-form-item>
        </el-col>
        <el-col :span="20">
          <el-form-item prop="verifyCode">
            <el-input
              v-model="bindInfoForm.verifyCode"
              :placeholder="t('pleaseInput') + t('validateCode')"
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="20">
          <el-form-item prop="password">
            <el-input
              v-model="bindInfoForm.password"
              type="password"
              show-password
              autocomplete="new-password"
              :placeholder="t('pleaseInput') + t('login.passWord')"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <template #footer>
      <el-button
        @click="showBindInfoDialog = false"
        icon="Close"
        v-show="!showCaptcha"
      >
        {{ t('cancel') }}
      </el-button>
      <el-button
        type="primary"
        @click="toBindLogin(formRef)"
        :loading="dialogLoading"
        :disabled="
          disabledGetCodeBtn ||
          !bindInfoForm.verifyCode ||
          !bindInfoForm.password
        "
        icon="Check"
        v-show="!showCaptcha"
      >
        {{ t('bind') }}
      </el-button>
    </template>
    <!-- 校验窗口 -->
    <Captcha
      ref="captchaRef"
      v-model:show="showCaptcha"
      :data="validateParams"
      @refresh="handleRefreshCode"
      @validate="handleValidate"
    ></Captcha>
  </el-dialog>
</template>

<style scoped lang="scss">
.textAlignLeft {
  text-align: left;
}
.font14 {
  font-size: 14px;
}
.box {
  box-sizing: border-box;
  display: flex;
  padding: 10px 10px 0px 20px;
  height: 100%;

  .h100 {
    height: 100%;
  }

  .box-left {
    width: calc(100% - 350px);
    margin-right: 20px;
    min-width: 630px;

    .left-top {
      height: 180px;
      overflow-x: auto;
      padding-top: 10px;
      padding-bottom: 10px;

      :deep(.el-card__body) {
        display: flex;
        width: calc(100% - 40px);
      }

      .top-item {
        display: flex;
        justify-content: space-around;
        flex-wrap: nowrap;
        width: 100%;

        .item {
          position: relative;
          display: flex;
          align-items: center;
          background: var(--el-main-container-background);
          height: 130px;
          width: 246px;
          border-radius: 10px;
          margin-right: 20px;

          .iconfont {
            color: #c2ccd6;
          }

          .item-title {
            font-weight: bold;
            color: var(--el-text-color-regular);
            font-size: 16px;
          }

          .item-content {
            height: 50px;
            color: var(--el-text-color-regular);
            font-size: 14px;

            .item-content-value {
              display: inline-block;
              width: 125px;
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
              font-size: 14px;
            }
          }
        }

        .pastDueClass {
          border: 1px solid var(--el-color-primary);
        }
        .overClass {
          position: absolute;
          height: 100%;
          width: 100%;
          background-color: rgba(128, 128, 128, 0);
          cursor: pointer;
        }
        .pastTipClass {
          position: absolute;
          top: 0px;
          width: 100%;
          background-color: var(--el-color-primary);
          text-align: center;
          border-radius: 11px 11px 0px 0px;
          color: #fff;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          font-size: 14px;
        }
      }
      .top-item > div:last-child {
        margin-right: -20px;
      }
    }
    .left-bottom {
      margin-top: 20px;
      min-height: 300px;
      height: calc(100% - 240px);
      position: relative;
      display: flex !important;

      :deep(.el-card__body) {
        width: 100%;
      }
      :deep(.el-card__body) > div {
        display: flex;
        flex-direction: column;
        height: 100%;
        width: calc(100% - 40px);
      }

      .switchBtn {
        position: absolute;
        right: 25px;
        top: 25px;
      }

      .demo-tabs {
        flex: none;
      }

      .tableClass {
        flex: 1;
        overflow-x: auto;
        overflow-y: auto;
      }
    }
  }
  .box-right {
    width: 320px;
    min-width: 320px;
    height: calc(100% - 20px);
    min-height: 520px;
    position: relative;

    :deep(.el-card__body) {
      padding-right: 0px;
    }

    .box-right-content {
      color: var(--el-text-color-regular);
      width: 100%;
      height: 100%;
      text-align: center;
      overflow-y: auto;
      margin-right: 10px;

      .right-tab {
        position: absolute;
        margin-top: -16px;
        top: 0px;
        right: -1px;

        li {
          list-style: none;
          width: 20px;
          border: 1px solid var(--el-border-color);
          color: var(--el-text-color-regular);
          padding: 5px;
          border-radius: 8px 0px 0px 8px;
          background-color: var(--el-bg-color);
          font-size: 14px;
          transition: all 0.2s;

          &:first-child {
            border-top: 0px;
            border-bottom: 0px;
          }
          &:last-child {
            border-top: 0px;
          }
        }
        .activeTab {
          background-color: var(--el-color-primary);
          color: #fff;
          font-size: 14px;
        }
      }
      .userInfoTabs {
        position: absolute;
        top: 0px;
        right: 0px;
        width: 20px;
      }

      .userIcon {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        border: 1px solid gray;
      }
      .image-container {
        position: relative;

        .overlay {
          position: absolute;
          top: 1px;
          left: calc(50% - 50px);
          width: 100px;
          height: 100px;
          line-height: 100%;
          border-radius: 50%;
          text-align: center;
          background-color: rgba(163, 159, 159, 0.8);
          display: flex;
          justify-content: center;
          align-items: center;

          &:hover {
            cursor: pointer;
          }
        }
      }

      .subheading {
        display: inline-block;
        font-weight: normal;
        line-height: 30px;
        margin-bottom: 10px;
      }

      .right-userInfo {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        height: 380px;
        padding: 30px 0 20px;
        color: var(--el-text-color-regular);
        font-size: 14px;

        div {
          display: flex;
          justify-content: flex-start;
          span {
            &:first-child {
              display: inline-block;
              text-align: left;
              width: 82px;
            }
          }
        }
      }
      .right-operatorInfo {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        height: 320px;
        padding: 30px 0 40px;
        color: var(--el-text-color-regular);

        div {
          display: flex;
          justify-content: flex-start;
          span {
            &:first-child {
              display: inline-block;
              text-align: left;
              width: 82px;
            }
          }
        }
      }

      .right-date {
        position: absolute;
        width: 100%;
        background-color: var(--el-bg-color);
        bottom: -1px;
        left: 1px;
        text-align: center;
        height: 40px;
        line-height: 40px;
        font-size: 14px;
      }
    }
  }
}
.iconfont {
  border-radius: 50%;
}
.chooseClass {
  border: 1px solid var(--el-color-danger);
}
.unChooseClass {
  border: 1px solid var(--el-bg-color);
}
.imgItem {
  width: 100px;
  height: 100px;
  padding: 25px;
}
.editIcon {
  font-size: 16px;
  cursor: pointer;
  color: var(--el-color-primary);
}

.idStyle {
  color: var(--el-color-primary);
  position: absolute;
  top: 14px;
  left: 14px;
}
</style>
