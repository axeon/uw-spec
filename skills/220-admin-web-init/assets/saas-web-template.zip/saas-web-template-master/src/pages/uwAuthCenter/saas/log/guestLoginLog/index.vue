<script setup lang="ts">
import { type ComponentInternalInstance } from "vue";
import { SearchFormType } from "@/components/SearchForm/type";
import {
  saasLogGuestLoginLogList,
  type MscLoginEsLog,
  type MscLoginLogEsQueryParam,
} from "@/api/uwAuthCenterSaasApi";
import { ResponseData, DataList } from "@/api/uwAuthCenterAuthApi";
import { useI18n } from "vue-i18n";
import { useCrud } from "@/hooks/useCrud";
import { useCommonSelectTypes } from "@/utils/selectOptions";

const {
  userTypes,
  handleTypeForLabel,
  loginTypes,
  loginResultTypes,
  loginDeviceTypes,
  getAllUserTypes,
} = useCommonSelectTypes();

// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance;
const { formatDate, useActivated } = proxy as any;
const { t } = useI18n();

interface formParamsType extends MscLoginLogEsQueryParam {
  dateTimeRange?: Array<string>;
}

const {
  tableConfig, // 表格相关配置属性
  handleList, // 列表请求函数
} = useCrud<MscLoginEsLog, formParamsType>(
  {
    // 列表请求接口
    listFn: (): Promise<ResponseData<DataList<MscLoginEsLog>>> => {
      return saasLogGuestLoginLogList(tableConfig.queryParams);
    },
  },
  {
    isCombinedFetch: true,
  }
);

// 搜索表单 结构组成数据
const searchList = computed<SearchFormType[]>(() => {
  return [
    {
      field: "userId",
      componentType: "input",
      formItem: {
        label: t("uwAuthCenter.MscUser.id"),
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "userName",
      componentType: "input",
      formItem: {
        label: t("loginName"),
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "realName",
      componentType: "input",
      formItem: {
        label: "真实姓名",
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "userType",
      componentType: "select",
      formItem: {
        label: "用户类型",
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseSelect"),
      clearable: true,
      options: getAllUserTypes.value,
    },
    {
      field: "userIp",
      componentType: "input",
      formItem: {
        label: t("userIp"),
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "mchId",
      componentType: "input",
      formItem: {
        label: "商户ID",
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "appInfo",
      componentType: "input",
      formItem: {
        label: t("appInfo"),
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput") + t("appInfo"),
      clearable: true,
    },
    {
      field: "appHost",
      componentType: "input",
      formItem: {
        label: "应用主机",
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput") + t("appIP"),
      clearable: true,
    },
    {
      field: "loginAgent",
      componentType: "input",
      formItem: {
        label: "登录代理",
        labelWidth: "70",
      },
      formItemWidth: 280,
      placeholder: t("pleaseInput") + t("appIP"),
      clearable: true,
    },
    {
      field: "responseState",
      componentType: "select",
      formItem: {
        label: t("uwAuthCenterExtend.MscLoginLogQueryParam.loginResult"),
        labelWidth: "70",
      },
      formItemWidth: 280,
      options: loginResultTypes.value,
      placeholder: t("pleaseInput"),
      clearable: true,
    },
    {
      field: "loginDateRange",
      componentType: "datePicker",
      formItem: {
        label: t("uwAuthCenter.MscLoginESLog.loginDate"),
        labelWidth: "70",
      },
      componentWidth: 380,
      clearable: true,
      type: "datetimerange",
      startPlaceholder: t("startDate"),
      endPlaceholder: t("endDate"),
      defaultTime: [
        new Date(2000, 1, 1, 0, 0, 0),
        new Date(2000, 2, 1, 23, 59, 59),
      ],
      valueFormat: "YYYY-MM-DD HH:mm:ss",
    },
  ];
});

useActivated(() => {
  handleList();
});
</script>

<template>
  <div class="flex_col">
    <div class="flex_col_header">
      <SearchForm
        v-model="tableConfig.queryParams"
        :bnt-loading="tableConfig.tableLoading"
        :list="searchList"
        @change="handleList"
        @search="handleList"
      />
    </div>
    <el-table
      border
      :style="{ width: '100%' }"
      :header-cell-style="{
        backgroundColor: 'var(--el-color-info-light-9)',
      }"
      :data="tableConfig.dataList"
      v-loading="tableConfig.tableLoading"
      class="flex_col_body"
    >
      <el-table-column
        label="登录标识"
        align="center"
        minWidth="150"
        fixed="left"
      >
        <template #default="{ row }">
          <div>{{ row.loginId }}</div>
          <div>
            {{ handleTypeForLabel(row.userType, userTypes) }}
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="userName"
        :label="t('loginInfo')"
        width="150"
        align="center"
      >
        <template #default="{ row }">
          <el-text :type="row.responseState !== 'success' ? '' : 'primary'">
            {{ row.userName }}
          </el-text>
          <p>{{ row.userIp }}</p>
        </template>
      </el-table-column>
      <el-table-column
        :label="t('uwAuthCenter.MscLoginESLog.loginType')"
        width="150"
        align="center"
      >
        <template #default="scope">
          <div>{{ handleTypeForLabel(scope.row.loginType, loginTypes) }}</div>
          <div v-if="scope.row.saasId">{{ `saasId:${scope.row.saasId}` }}</div>
        </template>
      </el-table-column>
      <el-table-column label="登录代理" align="center" width="200">
        <template v-slot="{ row }">
          <div v-if="row.loginAgent">{{ row.loginAgent.split("/")[0] }}</div>
          <div v-if="row.loginAgent">{{ row.loginAgent.split("/")[1] }}</div>
        </template>
      </el-table-column>
      <el-table-column label="Auth主机信息" width="200" align="center">
        <template #default="scope">
          <div>{{ scope.row.appInfo }}</div>
          <div>{{ scope.row.appHost }}</div>
        </template>
      </el-table-column>
      <el-table-column
        prop="clientType"
        :label="t('uwAuthCenter.MscLoginESLog.clientType')"
        width="120"
        align="center"
      >
        <template #default="scope">
          <el-tooltip
            effect="dark"
            :content="scope.row.clientAgent ? scope.row.clientAgent : ''"
            :disabled="!scope.row.clientAgent"
            placement="top"
          >
            <el-link
              underline="never"
              :type="scope.row.clientAgent ? 'success' : 'info'"
            >
              {{ handleTypeForLabel(scope.row.clientType, loginDeviceTypes) }}
            </el-link>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column
        :label="t('uwAuthCenter.MscLoginESLog.loginResult')"
        min-width="250"
        align="center"
      >
        <template #default="{ row }">
          <div>
            <el-link
              underline="never"
              :type="row.responseState === 'success' ? 'success' : 'danger'"
            >
              {{ handleTypeForLabel(row.responseState, loginResultTypes) }}
            </el-link>
            <span>{{ `(${row.responseMillis}ms)` }}</span>
          </div>
          <div v-if="row.responseState !== 'success'">
            {{ row.responseMsg }}
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="loginDate"
        :label="t('uwAuthCenter.MscLoginESLog.loginDate')"
        width="180"
        align="center"
      >
        <template #default="scope">
          <span>
            {{ formatDate(scope.row.loginDate) }}
          </span>
        </template>
      </el-table-column>
    </el-table>
    <Pagination
      v-model:page-size="tableConfig.queryParams.$rn"
      @page-size-change="handleList"
      :total="tableConfig.sizeAll"
      v-model:current-page="tableConfig.queryParams.$pg"
      @current-change="handleList"
      class="flex_col_bottom"
    />
  </div>
</template>

<style lang="scss" scoped></style>
