<script setup lang="ts">
import { type ComponentInternalInstance } from "vue";
import { SearchFormType } from "@/components/SearchForm/type";
import {
  saasAccountUserLoad,
  saasLogCritLogList,
  SysCritLog,
  type SysCritLogQueryParam,
} from "@/api/uwAuthCenterSaasApi";
import { useCommonSelectTypes } from "@/utils/selectOptions";
import { useI18n } from "vue-i18n";
import { useMainStore } from "@/store/main";
import { ResponseData, DataList } from "@/api/uwAuthCenterAuthApi";
import { useCrud } from "@/hooks/useCrud";

const { t } = useI18n();
const { userTypes } = useCommonSelectTypes();
// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance;
const { dayjs, useActivated } = proxy as any;
const mainStore = useMainStore();

const {
  tableConfig, // 表格相关配置属性
  handleList, // 列表请求函数
} = useCrud<SysCritLog, SysCritLogQueryParam>(
  {
    // 列表请求接口
    listFn: (): Promise<ResponseData<DataList<SysCritLog>>> => {
      const obj = JSON.parse(JSON.stringify(tableConfig.queryParams));
      obj.$sn = "id";
      return saasLogCritLogList(obj);
    },
  },
  {
    isCombinedFetch: true,
  }
);

// 搜索表单 结构组成数据
const searchList = computed<SearchFormType[]>(() => {
  return [
    {
      field: "userName",
      formItem: {
        label: t("uwAuthCenter.MscUser.username"),
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "input",
      placeholder: t("pleaseInput") + t("uwAuthCenter.MscUser.username"),
    },
    {
      field: "realName",
      formItem: {
        label: t("user.realName"),
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "input",
      placeholder: t("pleaseInput") + t("user.realName"),
    },
    {
      field: "userType",
      formItem: {
        label: t("uwAuthCenter.MscUser.userType"),
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "select",
      options: userTypes.value,
      placeholder: t("pleaseSelect") + t("uwAuthCenter.MscUser.userType"),
    },
    {
      field: "userIp",
      formItem: {
        label: "用户IP",
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "input",
      placeholder: t("pleaseInput") + "用户IP",
    },
    {
      field: "apiUri",
      formItem: {
        label: "请求URL",
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "input",
      placeholder: t("pleaseInput") + "请求URL",
    },
    {
      field: "appInfo",
      formItem: {
        label: t("uwAuthCenter.MscCritLogQueryParam.appInfo"),
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "input",
      placeholder:
        t("pleaseInput") + t("uwAuthCenter.MscCritLogQueryParam.appInfo"),
      value: "",
    },
    {
      field: "appHost",
      formItem: {
        label: t("uwAuthCenter.MscCritLogQueryParam.appHost"),
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "input",
      placeholder:
        t("pleaseInput") + t("uwAuthCenter.MscCritLogQueryParam.appHost"),
    },
  ];
});

// 用户资料
const showUserInfoCard = ref(false);
const handleDetailUserInfo = () => {
  showUserInfoCard.value = true;
};

// 用户资料
const popoverData = ref({});
// popover 显示
const handlePopoverShow = (item: SysCritLog) => {
  const info = mainStore.saasUserInfo[item.userId as number];
  if (info && Object.keys(info).length) {
    popoverData.value = info;
  } else {
    saasAccountUserLoad({
      id: item.userId as number,
    })
      .then((res) => {
        if (res.state === "success") {
          popoverData.value = res.data || {};
        } else {
          popoverData.value = {};
        }
        mainStore.setSaasUserInfo(item.userId as number, popoverData.value);
      })
      .catch(() => {
        popoverData.value = {};
      });
  }
};

const showLog = ref(false);
const logContent = ref("");
const handleShowDetail = (data: string) => {
  showLog.value = true;
  logContent.value = data;
};

useActivated(() => {
  handleList();
});
</script>

<template>
  <div class="flex_col">
    <div class="flex_col_header">
      <SearchForm
        v-model="tableConfig.queryParams"
        :bnt-loading="tableConfig.tableLoading"
        :list="searchList"
        @change="handleList"
        @search="handleList"
      ></SearchForm>
    </div>
    <el-table
      border
      :style="{ width: '100%' }"
      :header-cell-style="{
        backgroundColor: 'var(--el-color-info-light-9)',
      }"
      :data="tableConfig.dataList"
      v-loading="tableConfig.tableLoading"
      class="flex_col_body"
      stripe
    >
      <el-table-column
        prop="id"
        label="ID"
        align="center"
        width="90"
        fixed="left"
      ></el-table-column>
      <el-table-column
        prop="userInfo"
        label="用户信息"
        align="center"
        width="140"
      >
        <template #default="{ row }">
          <p>{{ row.userName }}</p>
          <p>{{ row.userIp ? row.userIp : "" }}</p>
        </template>
      </el-table-column>
      <el-table-column
        prop="bizType"
        :label="t('uwAuthCenter.MscCritLogQueryParam.objectType')"
        align="center"
        minWidth="120"
      ></el-table-column>
      <el-table-column
        prop="apiUri"
        label="请求URL"
        align="center"
        minWidth="180"
      ></el-table-column>
      <el-table-column
        prop="apiName"
        :label="t('uwAuthCenter.MscActionESLog.info')"
        align="center"
        minWidth="100"
      ></el-table-column>
      <el-table-column
        prop="requestInfo"
        label="请求信息"
        align="center"
        minWidth="180"
      >
        <template #default="scope">
          <div class="textAlignLeft">
            <el-link
              type="primary"
              @click="handleShowDetail(scope.row.requestBody)"
              underline="never"
            >
              请求参数
            </el-link>
          </div>
          <div class="textAlignLeft">
            <span>请求时间：</span>
            <span>
              {{
                scope.row.requestDate
                  ? dayjs(scope.row.requestDate).format("YYYY-MM-DD HH:mm:ss")
                  : ""
              }}
            </span>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="responseInfo"
        label="响应信息"
        align="center"
        minWidth="150"
      >
        <template #default="scope">
          <div class="textAlignLeft">
            <el-link
              type="primary"
              @click="handleShowDetail(scope.row.responseBody)"
              underline="never"
            >
              响应信息
            </el-link>
          </div>
          <div class="textAlignLeft">
            <span>响应毫秒：</span>
            <span>
              {{
                scope.row.responseMillis
                  ? scope.row.responseMillis + "(ms)"
                  : ""
              }}
            </span>
          </div>
          <div class="textAlignLeft">
            <span>响应状态码：</span>
            <el-text
              :type="scope.row.statusCode === 200 ? 'success' : 'danger'"
            >
              {{ scope.row.statusCode ? scope.row.statusCode : "" }}
            </el-text>
          </div>
          <div v-if="scope.row.exception" class="textAlignLeft">
            <span>异常信息：</span>
            <el-tooltip
              effect="dark"
              :content="scope.row.exception ? scope.row.exception : ''"
              placement="top-start"
            >
              <span>{{ scope.row.exception ? scope.row.exception : "" }}</span>
            </el-tooltip>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="appInfo"
        label="应用信息"
        align="center"
        minWidth="150"
      >
        <template #default="scope">
          <p>{{ scope.row.appInfo ? scope.row.appInfo : "" }}</p>
          <p>{{ scope.row.appHost ? scope.row.appHost : "" }}</p>
        </template>
      </el-table-column>
      <el-table-column
        prop="bizLog"
        label="日志"
        align="center"
        minWidth="150"
      ></el-table-column>
    </el-table>
    <Pagination
      v-model:page-size="tableConfig.queryParams.$rn"
      @page-size-change="handleList"
      :total="tableConfig.sizeAll"
      v-model:current-page="tableConfig.queryParams.$pg"
      @current-change="handleList"
      class="flex_col_bottom"
    />
  </div>

  <QueryLog v-model="showLog" :content="logContent"></QueryLog>
</template>

<style lang="scss" scoped>
.textAlignLeft {
  text-align: left;
}
</style>
