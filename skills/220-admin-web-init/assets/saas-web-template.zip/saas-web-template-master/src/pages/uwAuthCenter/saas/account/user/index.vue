<script setup lang="ts">
import { type ComponentInternalInstance } from "vue";
import {
  ElMessage,
  FormRules,
  type ElTree,
  type FormInstance,
  type TabPaneName,
} from "element-plus";
import { SearchFormType } from "@/components/SearchForm/type";
import {
  saasAccountUserUpdate,
  saasAccountUserUpdatePerm,
  saasAccountUserResetPassword,
  saasAccountUserDisable,
  saasAccountUserSave,
  saasAccountUserLoadPerm,
  saasAccountUserList,
  saasAccountUserDelete,
  saasAccountGroupList,
  saasAccountUserEnable,
  saasAccountUserLoadPermMenu,
  saasAccountUserUserTypeConfig,
  type UserTypeConfig,
  type MscUserInfo,
  type PermVo,
  type MscUserQueryParam,
  type MscUserPerm,
} from "@/api/uwAuthCenterSaasApi";
import { useSimplifyPrompt } from "@/hooks/useSimplifyPrompt";
import { usePermissionCode } from "@/hooks/usePermissionCode";
import { useValidate } from "@/hooks/useValidate";
import { useCommonSelectTypes } from "@/utils/selectOptions";
import { useI18n } from "vue-i18n";
import { commonType } from "@/types";
import { rsaEncrypt } from "@/utils/encryptionAndDecryption";
import { ResponseData, DataList } from "@/api/uwAuthCenterAuthApi";
import { useCrud } from "@/hooks/useCrud";
import { useMainStore } from "@/store/main";
// 头像图片
import header1 from "@/assets/headerImg/img1.png";
import header2 from "@/assets/headerImg/img2.png";
import header3 from "@/assets/headerImg/img3.png";
import header4 from "@/assets/headerImg/img4.png";
import header5 from "@/assets/headerImg/img5.png";
import header6 from "@/assets/headerImg/img6.png";
import header7 from "@/assets/headerImg/img7.png";
import header8 from "@/assets/headerImg/img8.png";
import header9 from "@/assets/headerImg/img9.png";
import header10 from "@/assets/headerImg/img10.png";
import header11 from "@/assets/headerImg/img11.png";
import header12 from "@/assets/headerImg/img12.png";
import header13 from "@/assets/headerImg/img13.png";
import header14 from "@/assets/headerImg/img14.png";
import header15 from "@/assets/headerImg/img15.png";
import header16 from "@/assets/headerImg/img16.png";
import { handleBuildPermTreeMenu } from "@/utils/buildTreeMenu";

interface MscMenu {
  id?: number | string; //id
  permCode?: string; //权限菜单URI
  permName?: string; //权限菜单名称
  permRank?: number;
  label?: string;
  children?: MscMenu[];
  permVoList?: PermVo[];
  disabled?: boolean;
}

interface newMscUserInfo extends MscUserInfo {
  password?: string;
  operatorAuth?: string;
  repeatPassword?: string;
  userPerm?: string;
  lastLogonType?: number; //最后登录类型
}

// 删除接口参数类型
interface deleteParamsType {
  id: number;
  remark: string; // 备注
}

const { t } = useI18n();
// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance;
const { useActivated, formatDate } = proxy as any;
const { validateIdCard, validateEmail } = useValidate();
const mainStore = useMainStore();
const treeRef = ref<InstanceType<typeof ElTree>>();
const { commonTypes, handleTypeForLabel, genderTypes, loginTypes, idTypes } =
  useCommonSelectTypes();
const mscMenu = ref<MscMenu[]>();
const userAuth = ref<MscUserPerm>();
const authShow = ref(false);
const userAuthInfo = ref<MscUserPerm>();
const userType = computed(() => mainStore.userInfo.userType);
const {
  tableConfig, // 表格相关配置属性
  handleList, // 列表请求函数
  handleDelete, //删除函数
  dialogConfig, // 弹窗相关配置属性
  dialogFormRef, // 弹窗表单ref
  handleUpdate,
  handleOpenUpdateDialog, // 打开编辑弹窗
} = useCrud<newMscUserInfo, MscUserQueryParam>(
  {
    // 列表请求接口
    listFn: (): Promise<ResponseData<DataList<newMscUserInfo>>> => {
      tableConfig.queryParams.$sn = ["id"];
      tableConfig.queryParams.groupId = currentGroupId.value;
      tableConfig.queryParams.userType = userType.value;
      tableConfig.queryParams.stateGte = 0;
      return saasAccountUserList(tableConfig.queryParams);
    },
    // 修改请求接口
    updateFn: (remark?: string): Promise<ResponseData<newMscUserInfo>> => {
      return saasAccountUserUpdate(dialogConfig.dialogFormData, {
        remark: remark || "",
      });
    },
    openUpdateDialogCallback: () => {
      if (dialogConfig.dialogFormData.mobile?.includes("!")) {
        dialogConfig.dialogFormData.mobile =
          dialogConfig.dialogFormData.mobile.slice(1);
        isBindPhone.value = true;
      } else {
        isBindPhone.value = false;
      }
      if (dialogConfig.dialogFormData.email?.includes("!")) {
        dialogConfig.dialogFormData.email =
          dialogConfig.dialogFormData.email.slice(1);
        isBindEmail.value = true;
      } else {
        isBindEmail.value = false;
      }
    },
    updateSuccessCallback: (data) => {
      if (mainStore.userInfo.id === data.id) {
        mainStore.handleUserProfile();
      }
    },
    deleteFn: (params: deleteParamsType) =>
      saasAccountUserDelete({ ...params, loginAgent: mainStore.loginAgent }),
  },
  {
    openUpdateRemark: true,
    openDeleteRemark: true,
  }
);

// 重置密码弹框
const resetPasswordShow = ref(false);
// 重置密码数据
const resetPasswordFrom = ref<{
  id?: number;
  password: string;
  repeatPassword: string;
}>({
  id: undefined,
  password: "",
  repeatPassword: "",
});
const resetPasswordRef = ref<FormInstance>();
// 是否绑定手机号
const isBindPhone = ref(false);
// 是否绑定邮箱
const isBindEmail = ref(false);
const resetLoading = ref(false);

// 选中的值
const defaultCheckedKeys = computed(() => {
  if (!userAuth.value) return [];
  const arr: number[] = [];
  const list = (userAuth.value.userPerm || "")
    .split(",")
    .map(Number) as number[];
  mscMenu.value?.forEach((item) => {
    if (item.permVoList) {
      const ls = item.permVoList;
      ls.forEach((itemC) => {
        for (let i = 0; i < list.length; i++) {
          const el = list[i];
          if (
            el === itemC.id &&
            itemC.permCode &&
            (itemC.permCode.includes(":") ||
              itemC.permCode.includes("dashboard"))
          ) {
            arr.push(el);
          }
        }
      });
    }
  });
  return arr;
});

// 搜索表单 结构组成数据
const searchList = computed<SearchFormType[]>(() => {
  return [
    {
      field: "username",
      formItem: {
        label: "登录账号",
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "input",
      placeholder: t("pleaseInput") + "登录账号",
      value: "",
    },
    {
      field: "mobile",
      formItem: {
        label: t("uwAuthCenter.MscUserQueryParam.mobile"),
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "input",
      placeholder: t("pleaseInput") + t("uwAuthCenter.MscUserInfo.mobile"),
    },

    {
      field: "state",
      formItem: {
        label: t("uwAuthCenter.MscUserQueryParam.state"),
        labelWidth: "90",
      },
      formItemWidth: 280,
      clearable: true,
      componentType: "select",
      options: commonTypes.value,
      placeholder: t("pleaseSelect") + t("uwAuthCenter.MscUserInfo.state"),
    },
  ];
});

// 新增/修改 表单校验
const dialogListRules = computed<FormRules>(() => {
  return {
    username: [
      {
        required: true,
        message: t("pleaseInput") + t("login.userName"),
      },
    ],
    realName: [
      {
        required: true,
        message:
          t("pleaseInput") + t("uwAuthCenterExtend.MscUserInfo.realName"),
      },
    ],
    password: [
      { required: dialogConfig.dialogType === 0, message: t("pleaseInput") },
      {
        validator: (rule: any, value: any, callback: any) => {
          if (dialogConfig.dialogType === 0) {
            if (
              /^(?=.*[A-Za-z])(?=.*\d)[\w!@#$%^&*\-+=(){}[\]|\\:;"'<>,.?/`~]{8,72}$/.test(
                value
              )
            ) {
              callback();
            } else {
              callback(new Error(t("passwordFormat")));
            }
          } else {
            callback();
          }
        },
      },
    ],
    repeatPassword: [
      { required: dialogConfig.dialogType === 0, message: t("pleaseInput") },
      {
        validator: (rule: any, value: any, callback: any) => {
          if (dialogConfig.dialogType === 0) {
            if (value === dialogConfig.dialogFormData.password) {
              callback();
            } else {
              callback(new Error("密码不一致"));
            }
          } else {
            callback();
          }
        },
      },
    ],
    mobile: [
      {
        validator: (rule: any, value: any, callback: any) => {
          if (value) {
            let reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
            if (reg.test(value)) {
              callback();
            } else {
              callback(
                new Error(t("uwAuthCenterExtend.MscUserInfo.validateMobile"))
              );
            }
          } else {
            callback();
          }
        },
      },
    ],
    groupId: [
      {
        required: true,
        message: t("pleaseSelect"),
      },
    ],
    operatorAuth: [
      {
        required: dialogConfig.dialogType === 0,
        message: t("pleaseSelect"),
      },
    ],
    userType: [
      {
        required: true,
        message: t("pleaseSelect"),
      },
    ],
    idInfo: [
      {
        validator: validateIdCard(false),
      },
    ],
    email: [
      {
        validator: validateEmail(false),
      },
    ],
  };
});

// 用户所属组
const activeIndex = ref(0);
const groupList = ref<commonType[]>([]);
const groupRemoteMethod = (isFirst = false) => {
  tableConfig.tableLoading = true;
  saasAccountGroupList({
    $pg: 1,
    $rn: 9999,
    state: 1,
    userType: mainStore.loginInfo.userType,
  })
    .then((res) => {
      if (res.state === "success" && res.data?.results) {
        groupList.value = res.data.results.map((item) => {
          return {
            label: item.groupName as string,
            value: item.id as number,
          };
        });
        if (isFirst) {
          currentGroupId.value = 0;
          activeIndex.value = 0;
        }
      } else {
        groupList.value = [];
      }
      tableConfig.tableLoading = false;
      groupList.value.unshift({
        label: "管理员",
        value: 0,
      });
    })
    .catch(() => {
      tableConfig.tableLoading = false;
    })
    .finally(() => {
      handleList();
    });
};

// 重置 dialogForm 数据
const resetDialogForm = () => {
  dialogConfig.dialogFormData = {};
  mscMenu.value = [];
  userAuth.value = {};
};

// 上传数据处理
const handleData = () => {
  const obj = JSON.parse(JSON.stringify(dialogConfig.dialogFormData));
  delete obj.operatorAuth;
  const list = treeRefOnDialog.value!.getCheckedKeys(false);
  const list2 = treeRefOnDialog.value!.getHalfCheckedKeys();
  const userPerm = list2.concat(list).filter((item: number | string) => {
    return typeof item === "number";
  });
  obj.userPerm = userPerm.join();
  obj.userType = userType.value;
  return obj;
};

// 权限菜单
const treeRefOnDialog = ref();

// 重置密码
const resetPasswords = (row: MscUserInfo) => {
  resetPasswordFrom.value.id = row.id as number;
  resetPasswordShow.value = true;
};

const resetPasswordForm = () => {
  resetPasswordFrom.value.id = undefined;
  resetPasswordFrom.value.password = "";
  resetPasswordFrom.value.repeatPassword = "";
};

// 重置密码 表单校验
const resetPasswordRules: FormRules = {
  password: [
    { required: true, message: t("pleaseInput") },
    {
      validator: (rule: any, value: any, callback: any) => {
        if (
          /^(?=.*[A-Za-z])(?=.*\d)[\w!@#$%^&*\-+=(){}[\]|\\:;"'<>,.?/`~]{8,72}$/.test(
            value
          )
        ) {
          callback();
        } else {
          callback(new Error(t("passwordFormat")));
        }
      },
    },
  ],
  repeatPassword: [
    { required: true, message: t("pleaseInput") },
    {
      validator: (rule: any, value: any, callback: any) => {
        if (value === resetPasswordFrom.value.password) {
          callback();
        } else {
          callback(new Error("密码不一致，请重新输入"));
        }
      },
    },
  ],
};

// 重置密码
const handleResetPassword = () => {
  resetPasswordRef.value?.validate((valid) => {
    if (valid) {
      useSimplifyPrompt({
        message: t("pleaseInput") + t("resetPasswordExplain"),
        confirmCallBack(remark) {
          if (!resetPasswordFrom.value.id) return;
          resetLoading.value = true;
          saasAccountUserResetPassword({
            password: rsaEncrypt(resetPasswordFrom.value.password) as string,
            id: resetPasswordFrom.value.id,
            remark: remark!,
            loginAgent: mainStore.loginAgent,
          })
            .then((res) => {
              if (res.state === "success") {
                resetPasswordShow.value = false;
                ElMessage.success("重置密码成功");
              } else {
                if (res.code === "auth.center.passwd.complexity.error") {
                  if (passwordConfig.value) {
                    const msg = handlePasswordTip();
                    ElMessage.error(msg || res.msg);
                  } else {
                    ElMessage.error(res.msg);
                  }
                } else {
                  ElMessage.error(res.msg);
                }
              }
              resetLoading.value = false;
            })
            .catch(() => {
              resetLoading.value = false;
            });
        },
      });
    }
  });
};

// 请求获取权限
const handleAuth = (row: MscUserInfo) => {
  if (!row.id) return;
  authType.value = 2;
  userAuthInfo.value = row;
  handleUserAuth(row.id);
  saasAccountUserLoadPermMenu({
    groupId: row.groupId as number,
  }).then((res) => {
    if (res.state === "success" && res.data) {
      const list = res.data.map((item) => {
        const childrenArray = handleBuildPermTreeMenu(item.permVoList || []);
        const obj = {
          ...item,
          label: item.appLabel,
          children: childrenArray,
          id: `app-${item.id}`,
          disabled: !item.permVoList || childrenArray.length === 0,
        };
        return obj;
      });
      mscMenu.value = list;
      authShow.value = true;
    }
  });
};

// 获取用户所拥有的权限
const handleUserAuth = (id: number) => {
  saasAccountUserLoadPerm({ id }).then((res) => {
    if (res.state === "success" && res.data) {
      userAuth.value = res.data;
      if (authType.value === 1) {
        dialogConfig.dialogFormData.operatorAuth = res.data.userPerm;
      }
    }
  });
};

// 功能分流
const handleCommand = (val: string, row: MscUserInfo) => {
  if (val === "1") handleOpenUpdateDialog(row);
  if (val === "2") handleAuth(row);
  if (val === "3") handleRootAccountUserLock(row);
  if (val === "4") resetPasswords(row);
  if (val === "5") handleDelete({ id: row.id!, remark: "" });
  if (val === "6") handleUnlockUser(row);
};

// 解禁用户
const handleUnlockUser = (row: MscUserInfo) => {
  useSimplifyPrompt({
    message: t("pleaseInput") + "解除禁用说明",
    confirmCallBack: (remark) => {
      saasAccountUserEnable({
        id: row.id!,
        remark: remark || "",
      })
        .then((res) => {
          if (res.state === "success") {
            ElMessage.success("解除禁用成功");
            handleList();
          } else {
            ElMessage.success(res.msg);
          }
          tableConfig.tableLoading = false;
        })
        .catch(() => {
          tableConfig.tableLoading = false;
        });
    },
  });
};

// 锁定用户
const handleRootAccountUserLock = (row: MscUserInfo) => {
  useSimplifyPrompt({
    message: t("pleaseInput") + "禁用用户说明",
    confirmCallBack: (remark) => {
      tableConfig.tableLoading = true;
      saasAccountUserDisable({
        id: row.id!,
        remark: remark || "",
        loginAgent: mainStore.loginAgent,
      })
        .then((res) => {
          if (res.state === "success") {
            ElMessage.success(t("disableSuccess"));
            handleList();
          } else {
            ElMessage.success(res.msg);
          }
          tableConfig.tableLoading = false;
        })
        .catch(() => {
          tableConfig.tableLoading = false;
        });
    },
  });
};

const handleSubmitDialog = () => {
  dialogFormRef.value?.validate((valid) => {
    if (valid) {
      if (dialogConfig.dialogType === 0) {
        handleAddFn();
      } else {
        // 变更
        handleUpdate();
      }
    }
  });
};

// 新增请求
const handleAddFn = () => {
  const obj = handleData();
  obj.password = rsaEncrypt(obj.password);
  dialogConfig.dialogLoading = true;
  saasAccountUserSave(obj)
    .then((res) => {
      if (res.state === "success") {
        handleList();
        ElMessage.success(t("add") + t("success"));
        dialogConfig.dialogShow = false;
      } else {
        if (res.code === "auth.center.passwd.complexity.error") {
          if (passwordConfig.value) {
            const msg = handlePasswordTip();
            ElMessage.error(msg || res.msg);
          } else {
            ElMessage.error(res.msg);
          }
        } else {
          ElMessage.error(res.msg);
        }
      }
      dialogConfig.dialogLoading = false;
    })
    .catch(() => {
      dialogConfig.dialogLoading = false;
    });
};

// 授权界面，点击授权
const clickAuthSave = () => {
  const list = treeRef.value!.getCheckedKeys(false);
  const list2 = treeRef.value!.getHalfCheckedKeys();
  const userPerm = list2.concat(list).filter((item: number | string) => {
    return typeof item === "number";
  });

  useSimplifyPrompt({
    message: t("pleaseInput") + t("editExplain"),
    confirmCallBack(remark) {
      // 单独修改授权
      saasAccountUserUpdatePerm({
        id: userAuthInfo.value!.id!,
        userPerm: userPerm.join(),
        userConfig: userAuth.value!.userConfig ?? "",
        remark: remark!,
      }).then((res) => {
        if (res.state === "success") {
          ElMessage.success(res.msg);
          authShow.value = false;
          if (mainStore.userInfo.id === userAuthInfo.value?.id) {
            mainStore.handleReloadAuth();
          }
        } else {
          ElMessage.error(res.msg);
        }
      });
    },
  });
};

const authType = ref<0 | 1 | 2>(0); // 0 新增时修改权限  1 编辑时修改权限  2 单独修改权限
// 选中组，获取用户组权限
const handleChangeForGroup = (val: number) => {
  saasAccountUserLoadPermMenu({
    groupId: val,
  }).then((res) => {
    if (res.state === "success" && res.data) {
      const list = res.data.map((item) => {
        const childrenArray = handleBuildPermTreeMenu(item.permVoList || []);
        const obj = {
          ...item,
          label: item.appLabel,
          children: childrenArray,
          id: `app-${item.id}`,
          disabled: !item.permVoList || childrenArray.length === 0,
        };
        return obj;
      });
      mscMenu.value = list;
    }
  });
};

// 获取用户组权限
const getGroupInfo = (val: number) => {
  handleChangeForGroup(val);
};

// 标签选中
const currentGroupId = ref();
const handleTabChange = (pane: TabPaneName) => {
  const groupId = groupList.value[pane as number]?.value;
  currentGroupId.value = groupId;
  handleList();
};

// 修改头像弹窗
const dialogShow = ref(false);
// 蒙层显示
const overlayVisible = ref(false);
// 头像列表
const headerImgList = [
  header1,
  header2,
  header3,
  header4,
  header5,
  header6,
  header7,
  header8,
  header9,
  header10,
  header11,
  header12,
  header13,
  header14,
  header15,
  header16,
];
// 选择
const handleChoose = (index: number) => {
  dialogConfig.dialogFormData.userIcon = index + "";
  dialogShow.value = false;
};

// 用户头像回显
const userIcon = computed(() => {
  if (
    dialogConfig.dialogFormData.userIcon &&
    headerImgList[Number(dialogConfig.dialogFormData.userIcon)]
  ) {
    return headerImgList[Number(dialogConfig.dialogFormData.userIcon)];
  }
  return header1;
});

// 打开新增弹窗
const handleAdd = () => {
  dialogConfig.dialogType = 0;
  dialogConfig.dialogShow = true;
  nextTick(() => {
    getGroupInfo(currentGroupId.value);
    dialogConfig.dialogFormData.groupId = currentGroupId.value;
    if (
      dialogConfig.dialogFormData.groupId ||
      dialogConfig.dialogFormData.groupId === 0
    ) {
      // 请求菜单
      getGroupInfo(dialogConfig.dialogFormData.groupId);
    }
    isBindPhone.value = false;
    isBindEmail.value = false;
    handleLoadUserConfig();
  });
};

// 密码配置要求
const passwordConfig = computed(() => {
  return userTypeConfig.value.passwordConfig?.name || "";
});

const userTypeConfig = ref<UserTypeConfig>({});
// 获取用户类型配置
const handleLoadUserConfig = () => {
  saasAccountUserUserTypeConfig({
    userType: 200,
  })
    .then((res) => {
      userTypeConfig.value = res.data || {};
    })
    .catch(() => {
      userTypeConfig.value = {};
    });
};

// 处理密码提示
const handlePasswordTip = () => {
  if (passwordConfig.value === "ULTIMATE") {
    return t("ULTIMATEPasswordRule");
  } else if (passwordConfig.value === "EXTREME") {
    return t("EXTREMEPasswordRule");
  } else if (passwordConfig.value === "STRICT") {
    return t("STRICTPasswordRule");
  } else if (passwordConfig.value === "STANDARD") {
    return t("STANDARDPasswordRule");
  } else if (passwordConfig.value === "NORMAL") {
    return t("passwordFormat");
  }
};

//  新增、编辑
const statusList = computed<commonType[]>(() => {
  return [
    {
      label: "是否管理员",
      value: dialogConfig.dialogFormData.isMaster === 1 ? "是" : "否",
    },
    {
      label: "登录次数",
      value: dialogConfig.dialogFormData.logonCount,
    },

    {
      label: "最后登录IP",
      value: dialogConfig.dialogFormData.lastLogonIp,
    },
    {
      label: "最后登录时间",
      value: formatDate(Number(dialogConfig.dialogFormData.lastLogonDate)),
    },
    {
      label: "最后登录类型",
      value: handleTypeForLabel(
        dialogConfig.dialogFormData.lastLogonType!,
        loginTypes.value
      ),
    },
    {
      label: "最后修改密码时间",
      value: formatDate(Number(dialogConfig.dialogFormData.lastPasswdDate)),
    },
  ];
});

useActivated(() => {
  groupRemoteMethod(true);
});
</script>

<template>
  <div class="flex_col">
    <div class="flex_col_header">
      <SearchForm
        v-model="tableConfig.queryParams"
        :bnt-loading="tableConfig.tableLoading"
        :list="searchList"
        @change="handleList"
        @search="handleList"
      >
        <template #right>
          <el-button
            class="margin-left-10"
            type="primary"
            size="small"
            @click="handleAdd"
            icon="Plus"
            v-permission="usePermissionCode('save')"
            round
          >
            {{ t("add") }}
          </el-button>
        </template>
      </SearchForm>
    </div>
    <div class="flex_col_body">
      <div style="display: flex">
        <div style="width: 180px">
          <el-tabs
            tab-position="left"
            v-model="activeIndex"
            @tab-change="handleTabChange"
          >
            <el-tab-pane
              :label="item.label"
              v-for="(item, index) in groupList"
              :name="index"
              :key="item.value"
            ></el-tab-pane>
          </el-tabs>
        </div>
        <div style="width: calc(100% - 180px)">
          <el-table
            border
            :style="{ width: '100%' }"
            :header-cell-style="{
              backgroundColor: 'var(--el-color-info-light-9)',
            }"
            :data="tableConfig.dataList"
            v-loading="tableConfig.tableLoading"
            stripe
          >
            <el-table-column
              prop="id"
              label="ID"
              width="80"
              align="center"
              fixed="left"
            ></el-table-column>
            <el-table-column
              prop="username"
              label="登录账号"
              width="140"
              align="center"
            >
              <template v-slot="{ row }">
                <span>{{ row.username }}</span>
                <el-text v-if="row.isMaster" type="success"> (管理员) </el-text>
              </template>
            </el-table-column>
            <el-table-column
              prop="realName"
              label="用户姓名"
              width="140"
              align="center"
            >
              <template v-slot="{ row }">
                <span>{{ row.realName }}</span>
                <el-text v-if="row.isUserActive" type="success">
                  (在线)
                </el-text>
              </template>
            </el-table-column>
            <el-table-column label="性别" width="70" align="center">
              <template v-slot="{ row }">
                <span>{{ handleTypeForLabel(row.gender, genderTypes) }}</span>
              </template>
            </el-table-column>
            <el-table-column
              :label="t('uwAuthCenter.MscUserInfo.mobile')"
              width="120"
              align="center"
            >
              <template v-slot="{ row }">
                <span>
                  {{
                    row.mobile?.includes("!") ? row.mobile.slice(1) : row.mobile
                  }}
                </span>
              </template>
            </el-table-column>
            <el-table-column
              :label="t('uwAuthCenter.MscUserInfo.email')"
              width="180"
              align="center"
            >
              <template v-slot="{ row }">
                <span>
                  {{
                    row.email?.includes("!") ? row.email.slice(1) : row.email
                  }}
                </span>
              </template>
            </el-table-column>
            <el-table-column
              label="登录次数"
              width="90"
              align="center"
              prop="logonCount"
            ></el-table-column>
            <el-table-column
              label="最后登录IP"
              width="200"
              align="center"
              prop="lastLogonIp"
            >
              <template v-slot="{ row }">
                <span>{{ row.lastLogonIp }}</span>
                <el-text v-if="row.isUserLogon" type="success">
                  (已登录)
                </el-text>
              </template>
            </el-table-column>
            <el-table-column
              label="最后登录/最后修改密码时间"
              width="220"
              align="center"
            >
              <template #default="scope">
                <div>
                  {{ formatDate(scope.row.lastLogonDate) }}
                </div>
                <div>
                  {{ formatDate(scope.row.lastPasswdDate) }}
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="createDate"
              :label="t('createDate') + '/修改时间'"
              width="200"
              align="center"
            >
              <template #default="scope">
                <div>
                  {{ formatDate(scope.row.createDate) }}
                </div>
                <div>
                  {{ formatDate(scope.row.modifyDate) }}
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="state"
              :label="t('uwAuthCenter.MscUserGroup.state')"
              width="70"
              align="center"
              fixed="right"
            >
              <template #default="scope">
                <el-text
                  :type="scope.row.state === 1 ? 'success' : 'danger'"
                  underline="never"
                >
                  {{ handleTypeForLabel(scope.row.state, commonTypes) }}
                </el-text>
              </template>
            </el-table-column>
            <el-table-column
              :label="t('operation')"
              align="center"
              width="180"
              fixed="right"
            >
              <template #default="scope">
                <div class="flex-start">
                  <el-button-group v-if="scope.row.state !== -1">
                    <el-tooltip
                      :content="t('edit')"
                      placement="top"
                      :enterable="false"
                    >
                      <el-button
                        type="primary"
                        icon="Edit"
                        size="small"
                        v-permission="usePermissionCode('update')"
                        @click.stop="handleCommand('1', scope.row)"
                      ></el-button>
                    </el-tooltip>
                    <el-tooltip
                      :content="t('auth')"
                      placement="top"
                      :enterable="false"
                    >
                      <el-button
                        type="success"
                        icon="Open"
                        size="small"
                        v-permission="usePermissionCode('updatePerm')"
                        @click.stop="handleCommand('2', scope.row)"
                      ></el-button>
                    </el-tooltip>
                    <template
                      v-if="scope.row.state === 0 && scope.row.isMaster !== 1"
                    >
                      <el-tooltip
                        :content="t('delete')"
                        placement="top"
                        :enterable="false"
                      >
                        <el-button
                          type="danger"
                          icon="Delete"
                          size="small"
                          v-permission="usePermissionCode('delete')"
                          @click.stop="handleCommand('5', scope.row)"
                        ></el-button>
                      </el-tooltip>
                    </template>
                    <template
                      v-if="scope.row.state === 1 && scope.row.isMaster !== 1"
                    >
                      <el-tooltip
                        :content="t('disabled')"
                        placement="top"
                        :enterable="false"
                      >
                        <el-button
                          type="info"
                          size="small"
                          v-permission="usePermissionCode('disable')"
                          @click.stop="handleCommand('3', scope.row)"
                        >
                          <i class="iconfont jinyong"></i>
                        </el-button>
                      </el-tooltip>
                    </template>
                    <template v-if="scope.row.state === 0">
                      <el-tooltip
                        content="启用"
                        placement="top"
                        :enterable="false"
                      >
                        <el-button
                          type="success"
                          size="small"
                          @click.stop="handleCommand('6', scope.row)"
                          v-permission="usePermissionCode('enable')"
                        >
                          <i class="iconfont qiyong"></i>
                        </el-button>
                      </el-tooltip>
                    </template>
                    <el-tooltip
                      :content="t('reset') + t('login.passWord')"
                      placement="top"
                      :enterable="false"
                    >
                      <el-button
                        type="success"
                        icon="Refresh"
                        size="small"
                        v-permission="usePermissionCode('resetPassword')"
                        @click.stop="handleCommand('4', scope.row)"
                      ></el-button>
                    </el-tooltip>
                  </el-button-group>
                </div>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <Pagination
      class="flex_col_bottom"
      v-model:page-size="tableConfig.queryParams.$rn"
      @pageSizeChange="handleList"
      :total="tableConfig.sizeAll"
      v-model:current-page="tableConfig.queryParams.$pg"
      @current-change="handleList"
    />
  </div>

  <!-- 新增、修改 -->
  <div class="operation-dialog">
    <el-dialog
      v-model="dialogConfig.dialogShow"
      :title="
        dialogConfig.dialogType === 0
          ? t('add')
          : t('edit') + `#${dialogConfig.dialogFormData.id}`
      "
      destroy-on-close
      :width="dialogConfig.dialogType === 0 ? '1250px' : '900px'"
      draggable
      @close="resetDialogForm"
    >
      <el-row :gutter="10">
        <el-col :span="dialogConfig.dialogType === 0 ? 10 : 24">
          <titleHeader title="用户信息" class="margin-top-15" />
          <div v-loading="dialogConfig.dialogLoading">
            <el-form
              ref="dialogFormRef"
              :model="dialogConfig.dialogFormData"
              :rules="dialogListRules"
              label-width="140px"
            >
              <el-row :gutter="10">
                <el-col :span="dialogConfig.dialogType === 0 ? 16 : 14">
                  <el-row>
                    <el-col :span="24">
                      <el-form-item label="所属部门" prop="groupId">
                        <el-select
                          v-model="dialogConfig.dialogFormData.groupId"
                          :placeholder="t('pleaseSelect') + '所属部门'"
                          filterable
                          :style="{ width: '100%' }"
                          @change="handleChangeForGroup"
                          :clearable="false"
                        >
                          <el-option
                            v-for="item in groupList"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"
                          />
                        </el-select>
                      </el-form-item>
                    </el-col>
                    <el-col :span="24">
                      <el-form-item label="登录账号" prop="username">
                        <el-input
                          v-model="dialogConfig.dialogFormData.username"
                          :placeholder="
                            t('pleaseInput') +
                            t('uwAuthCenter.MscUserInfo.username')
                          "
                          clearable
                          autocomplete="off"
                          :disabled="dialogConfig.dialogType === 1"
                        />
                      </el-form-item>
                    </el-col>
                  </el-row>
                </el-col>
                <el-col :span="dialogConfig.dialogType === 0 ? 8 : 6">
                  <el-row>
                    <el-col>
                      <div class="flex-center flex-align">
                        <div
                          class="image-container flex-center"
                          @mouseover="overlayVisible = true"
                          @mouseleave="overlayVisible = false"
                        >
                          <img :src="userIcon" class="userIcon" />
                          <div
                            class="overlay"
                            @click="dialogShow = true"
                            v-show="overlayVisible"
                          >
                            <el-text type="primary">修改头像</el-text>
                          </div>
                        </div>
                      </div>
                    </el-col>
                  </el-row>
                </el-col>
              </el-row>
              <el-row>
                <el-col
                  :span="dialogConfig.dialogType === 0 ? 24 : 20"
                  v-show="dialogConfig.dialogType === 0"
                >
                  <el-form-item label="登录密码" prop="password">
                    <el-input
                      v-model="dialogConfig.dialogFormData.password"
                      :placeholder="t('pleaseInput') + '登录密码'"
                      clearable
                      type="password"
                      autocomplete="new-password"
                      show-password
                    />
                  </el-form-item>
                </el-col>
                <el-col
                  :span="dialogConfig.dialogType === 0 ? 24 : 20"
                  v-show="dialogConfig.dialogType === 0"
                >
                  <el-form-item label="确认密码" prop="repeatPassword">
                    <el-input
                      v-model="dialogConfig.dialogFormData.repeatPassword"
                      :placeholder="
                        t('pleaseInput') + t('sure') + t('login.passWord')
                      "
                      clearable
                      type="password"
                      autocomplete="new-password"
                      show-password
                    />
                  </el-form-item>
                </el-col>
                <el-col :span="dialogConfig.dialogType === 0 ? 24 : 20">
                  <el-form-item label="用户姓名" prop="realName">
                    <el-input
                      v-model="dialogConfig.dialogFormData.realName"
                      :placeholder="t('pleaseInput') + '用户姓名'"
                      clearable
                    />
                  </el-form-item>
                </el-col>
                <el-col :span="dialogConfig.dialogType === 0 ? 24 : 20">
                  <el-form-item label="用户昵称" prop="nickName">
                    <el-input
                      v-model="dialogConfig.dialogFormData.nickName"
                      :placeholder="t('pleaseInput') + '用户昵称'"
                      clearable
                    />
                  </el-form-item>
                </el-col>
                <el-col :span="dialogConfig.dialogType === 0 ? 24 : 20">
                  <el-form-item label="用户性别" prop="gender">
                    <el-radio-group
                      v-model="dialogConfig.dialogFormData.gender"
                    >
                      <el-radio
                        v-for="item in genderTypes"
                        :key="item.value"
                        :value="item.value"
                      >
                        {{ item.label }}
                      </el-radio>
                    </el-radio-group>
                  </el-form-item>
                </el-col>
                <el-col :span="dialogConfig.dialogType === 0 ? 24 : 20">
                  <el-form-item label="证件类型" prop="idType">
                    <el-select
                      v-model="dialogConfig.dialogFormData.idType"
                      :placeholder="t('pleaseSelect') + '证件类型'"
                      clearable
                    >
                      <el-option
                        v-for="item in idTypes"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span="dialogConfig.dialogType === 0 ? 24 : 20">
                  <el-form-item label="证件号码" prop="idInfo">
                    <el-input
                      v-model="dialogConfig.dialogFormData.idInfo"
                      :placeholder="t('pleaseInput') + '证件号码'"
                      clearable
                    />
                  </el-form-item>
                </el-col>
                <el-col :span="dialogConfig.dialogType === 0 ? 24 : 20">
                  <el-form-item
                    :label="t('uwAuthCenter.MscUserInfo.mobile')"
                    prop="mobile"
                  >
                    <el-input
                      v-model="dialogConfig.dialogFormData.mobile"
                      :placeholder="
                        t('pleaseInput') + t('uwAuthCenter.MscUserInfo.mobile')
                      "
                      clearable
                      :disabled="dialogConfig.dialogType === 1 && isBindPhone"
                      :style="{
                        width:
                          dialogConfig.dialogType === 1 && isBindPhone
                            ? '95%'
                            : '100%',
                      }"
                    />
                    <el-tooltip
                      effect="dark"
                      content="手机号已被绑定认证，若想修改请登录对应账号进行修改"
                      placement="top-start"
                      v-if="dialogConfig.dialogType === 1 && isBindPhone"
                    >
                      <el-icon
                        color="var(--el-color-success)"
                        class="padding-left-5"
                      >
                        <SuccessFilled />
                      </el-icon>
                    </el-tooltip>
                  </el-form-item>
                </el-col>
                <el-col :span="dialogConfig.dialogType === 0 ? 24 : 20">
                  <el-form-item
                    :label="t('uwAuthCenter.MscUserInfo.email')"
                    prop="email"
                  >
                    <el-input
                      v-model="dialogConfig.dialogFormData.email"
                      :placeholder="
                        t('pleaseInput') + t('uwAuthCenter.MscUserInfo.email')
                      "
                      clearable
                      :disabled="dialogConfig.dialogType === 1 && isBindEmail"
                      :style="{
                        width:
                          dialogConfig.dialogType === 1 && isBindEmail
                            ? '95%'
                            : '100%',
                      }"
                    />
                    <el-tooltip
                      effect="dark"
                      content="邮箱已被绑定认证，若想修改请登录对应账号进行修改"
                      placement="top-start"
                      v-if="dialogConfig.dialogType === 1 && isBindEmail"
                    >
                      <el-icon
                        color="var(--el-color-success)"
                        class="padding-left-5"
                      >
                        <SuccessFilled />
                      </el-icon>
                    </el-tooltip>
                  </el-form-item>
                </el-col>
                <el-col :span="dialogConfig.dialogType === 0 ? 24 : 20">
                  <el-form-item label="备注" prop="remark">
                    <el-input
                      v-model="dialogConfig.dialogFormData.remark"
                      :placeholder="t('pleaseInput') + '备注'"
                      clearable
                      type="textarea"
                      :rows="5"
                    />
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>
        </el-col>
        <el-col :span="14" v-show="dialogConfig.dialogType === 0">
          <titleHeader title="权限信息" class="margin-top-15" />
          <div style="height: 600px; overflow: auto">
            <el-tree
              class="user-tree"
              :data="mscMenu"
              show-checkbox
              node-key="id"
              ref="treeRefOnDialog"
              :default-checked-keys="defaultCheckedKeys"
              :props="{
                children: 'children',
                label: 'label',
              }"
            ></el-tree>
          </div>
        </el-col>
      </el-row>
      <titleHeader
        title="登录信息"
        class="margin-top-15"
        v-if="dialogConfig.dialogType === 1"
      />
      <el-row v-if="dialogConfig.dialogType === 1">
        <el-col :span="20">
          <el-descriptions
            title=""
            :column="2"
            border
            style="margin-left: 60px"
          >
            <el-descriptions-item
              v-for="(item, index) in statusList"
              :label="item.label"
              :key="index"
            >
              {{ item.value }}
            </el-descriptions-item>
          </el-descriptions>
        </el-col>
      </el-row>
      <template #footer>
        <el-button @click="dialogConfig.dialogShow = false" icon="Close">
          {{ t("cancel") }}
        </el-button>
        <el-button
          type="primary"
          @click="handleSubmitDialog"
          :loading="dialogConfig.dialogLoading"
          icon="Check"
        >
          {{ dialogConfig.dialogType === 0 ? t("add") : t("edit") }}
        </el-button>
      </template>
    </el-dialog>
  </div>

  <!-- 重置密码 -->
  <el-dialog
    v-model="resetPasswordShow"
    :title="t('reset') + t('login.passWord')"
    destroy-on-close
    @close="resetPasswordForm"
    width="500px"
  >
    <div class="padding-top-15">
      <el-form
        ref="resetPasswordRef"
        :model="resetPasswordFrom"
        :rules="resetPasswordRules"
        label-width="90px"
      >
        <el-row>
          <el-col :span="20">
            <el-form-item label="密码" prop="password">
              <el-input
                v-model="resetPasswordFrom.password"
                placeholder="请输入密码"
                clearable
                type="password"
                autocomplete="new-password"
                show-password
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="20">
            <el-form-item label="确认密码" prop="repeatPassword">
              <el-input
                v-model="resetPasswordFrom.repeatPassword"
                placeholder="请输入确认密码"
                clearable
                type="password"
                autocomplete="new-password"
                show-password
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <template #footer>
      <el-button @click="resetPasswordShow = false" icon="Close">
        {{ t("cancel") }}
      </el-button>
      <el-button
        type="primary"
        @click="handleResetPassword"
        :loading="resetLoading"
        icon="Check"
      >
        {{ t("reset") + t("login.passWord") }}
      </el-button>
    </template>
  </el-dialog>

  <!-- 授权 -->
  <div class="auth-dialog">
    <el-dialog v-model="authShow" title="用户授权" destroy-on-close>
      <el-tree
        class="user-tree"
        :data="mscMenu"
        show-checkbox
        node-key="id"
        ref="treeRef"
        :default-checked-keys="defaultCheckedKeys"
        :props="{
          children: 'children',
          label: 'label',
        }"
      ></el-tree>
      <template #footer>
        <el-button @click="authShow = false" icon="Close">
          {{ t("cancel") }}
        </el-button>
        <el-button type="primary" @click="clickAuthSave" icon="Check">
          {{ t("confirm") }}
        </el-button>
      </template>
    </el-dialog>
  </div>

  <!-- 修改头像 -->
  <el-dialog
    v-model="dialogShow"
    title="修改头像"
    destroy-on-close
    draggable
    :close-on-click-modal="false"
    width="1000px"
  >
    <div
      style="
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        width: 748px;
        margin: auto;
      "
    >
      <template v-for="(item, index) in headerImgList" :key="index">
        <el-image
          :src="item"
          style="width: 100px; height: 100px; padding: 25px"
          :class="{
            chooseClass: String(index) === dialogConfig.dialogFormData.userIcon,
          }"
          @click="handleChoose(index)"
        />
      </template>
    </div>
  </el-dialog>
</template>

<style lang="scss" scoped>
.operation-dialog {
  :deep(.el-dialog__body) {
    height: 550px;
    overflow: auto;
  }
}
.auth-dialog {
  :deep(.el-dialog__body) {
    height: 550px;
    overflow: auto;
  }
}

.image-container {
  position: relative;
  width: 100px;
  height: 100px;

  .userIcon {
    width: 100px;
    height: 100px;
    border-radius: 50%;
  }

  .overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100px;
    height: 100px;
    line-height: 100%;
    border-radius: 50%;
    text-align: center;
    background-color: rgba(163, 159, 159, 0.8);
    display: flex;
    justify-content: center;
    align-items: center;

    &:hover {
      cursor: pointer;
    }
  }
}

.chooseClass {
  border: 1px solid red;
}
</style>
