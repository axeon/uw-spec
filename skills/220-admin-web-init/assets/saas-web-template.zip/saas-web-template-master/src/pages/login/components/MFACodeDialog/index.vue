<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { ElMessage, FormInstance } from 'element-plus'
import {
  userIssueTotpSecret,
  userBindTotpSecret,
  type TotpSecretData
} from '@/api/uwAuthCenterUserApi'
import { useCountdown } from '@/hooks/useCountdown'
import { useMainStore } from '@/store/main'
import CreatedQRCode from '../CreatedQRCode/index.vue'

const { t } = useI18n()
const props = defineProps<{
  modelValue: boolean
}>()

// 是否显示
const isShow = useModel(props, 'modelValue')
const mainStore = useMainStore()
const loading = ref(false)
// 图片二维码
const secretData = ref<TotpSecretData>({
  qr: ''
})

// 获取密钥
const getSecret = async () => {
  try {
    loading.value = true
    const res = await userIssueTotpSecret()
    if (res.state === 'success') {
      secretData.value = res.data || {}
    } else {
      ElMessage.error(res.msg)
    }
    loading.value = false
  } catch (error) {
    console.log(error)
    secretData.value = {}
    loading.value = false
  }
}

// 绑定MFA
const handleBindMFA = () => {
  formDataRef.value?.validate(valid => {
    if (valid) {
      loading.value = true
      userBindTotpSecret({
        totpSecret: secretData.value.secret!,
        totpCode: formData.value.totpCode!
      })
        .then(res => {
          if (res.state === 'success') {
            ElMessage.success(t('MFABindSuccessTip'))
            isShow.value = false
          } else {
            ElMessage.error(res.msg)
          }
          loading.value = false
        })
        .catch(() => {
          loading.value = false
        })
    }
  })
}

// 关闭的回调
const closeCallback = () => {
  mainStore.setLoginInfo({})
  formDataRef.value?.resetFields()
  stop()
}

// 校验表单
const formData = ref<{
  totpCode?: string
}>({})
const formDataRef = ref<FormInstance>()

// 倒计时
const { start, currentTime, stop } = useCountdown({
  onEnd() {
    if (isShow.value) {
      //  倒计时完成后提示过期之后跳回登录界面
      ElMessage.warning(t('tempTokenExpired'))
      isShow.value = false
    }
  }
})

// 展示的倒计时时间 HH:mm:ss
const displayTime = computed(() => {
  if (currentTime.value) {
    const hours = Math.floor(currentTime.value / 3600)
    const minutes = Math.floor((currentTime.value % 3600) / 60)
    const seconds = Math.floor(currentTime.value % 60)
    return `${hours.toString().padStart(2, '0')}:${minutes
      .toString()
      .padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
  }
  return '00:00:00'
})

defineExpose({
  getSecret,
  start
})
</script>

<template>
  <div>
    <el-dialog
      v-model="isShow"
      :title="t('MFAInit')"
      @close="closeCallback"
      width="450px"
      draggable
      :close-on-click-modal="false"
    >
      <div
        class="flex-center flex-align flex-col"
        v-loading="loading"
      >
        <h3 class="title">{{ t('MFACodeDesc') + '&nbsp;' + displayTime }}</h3>
        <CreatedQRCode
          :url="secretData.qr!"
          :width="200"
          :height="200"
        ></CreatedQRCode>
        <el-form
          :model="formData"
          label-width="auto"
          ref="formDataRef"
          style="width: 250px"
        >
          <el-row
            type="flex"
            justify="center"
          >
            <el-col :span="24">
              <el-form-item
                label=""
                prop="totpCode"
                :rules="[
                  {
                    required: true,
                    message: t('pleaseInputMFACode'),
                    trigger: 'blur'
                  }
                ]"
                label-width="0"
              >
                <el-input
                  v-model="formData.totpCode"
                  clearable
                  :placeholder="t('pleaseInputMFACode')"
                >
                  <template #append>
                    <el-button
                      icon="Check"
                      type="success"
                      @click="handleBindMFA"
                    >
                      {{ t('bind') }}
                    </el-button>
                  </template>
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
    </el-dialog>
  </div>
</template>

<style scoped lang="scss">
.title {
  color: var(--el-text-color-primary);
}

.countdown {
  font-size: 16px;
  font-weight: bold;
  color: var(--el-text-color-primary);
}

:deep(.el-input-group__append) {
  color: var(--el-color-primary);
}
</style>
