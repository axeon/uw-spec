<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { type FormInstance } from 'element-plus'
import { useMainStore } from '@/store/main'
import { type TokenResponse } from '@/api/uwAuthCenterAuthApi'

const { t } = useI18n()
const props = defineProps<{
  modelValue: boolean
  userInfoList: TokenResponse[]
}>()

const emits = defineEmits<{
  (e: 'continueLogin', val: TokenResponse): void
}>()

// 是否显示
const isShow = useModel(props, 'modelValue')
const mainStore = useMainStore()
const loading = ref(false)

// 关闭的回调
const closeCallback = () => {
  formDataRef.value?.resetFields()
  mainStore.setLoginInfo({})
}

// 修改密码
const formData = ref<{
  userId?: string // 用户ID
}>({})
// 表单
const formDataRef = ref<FormInstance>()

// 提交
const handleSubmit = () => {
  formDataRef.value?.validate(valid => {
    if (valid) {
      const userInfo = props.userInfoList.find(
        item => item.userId === formData.value.userId
      )
      if (userInfo) {
        emits('continueLogin', userInfo)
      }
    }
  })
}
</script>

<template>
  <div>
    <el-dialog
      v-model="isShow"
      :title="t('userSelect')"
      @close="closeCallback"
      width="450px"
      draggable
      :close-on-click-modal="false"
    >
      <div
        class="padding-top-30 padding-right-10 padding-left-10"
        v-loading="loading"
      >
        <el-form
          :model="formData"
          label-width="0"
          ref="formDataRef"
        >
          <el-row
            type="flex"
            justify="center"
          >
            <el-col :span="24">
              <el-form-item
                label=""
                prop="userId"
                :rules="[
                  {
                    required: true,
                    message: t('pleaseSelect'),
                    trigger: 'change'
                  }
                ]"
              >
                <el-select
                  v-model="formData.userId"
                  :placeholder="t('pleaseSelect') + t('login.userName')"
                  size="large"
                >
                  <el-option
                    v-for="item in userInfoList"
                    :key="item.userId!"
                    :label="item.userName"
                    :value="item.userId!"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <template #footer>
        <el-button
          @click="isShow = false"
          icon="Close"
        >
          {{ t('cancel') }}
        </el-button>
        <el-button
          type="primary"
          @click="handleSubmit"
          icon="Check"
        >
          {{ t('confirm') }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped lang="scss"></style>
