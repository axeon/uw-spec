import type { RouteRecordRaw } from 'vue-router'
const RouterList: RouteRecordRaw[] = [
  {
    path: '/uwAuthCenter/saas/log/loginLog',
    name: 'uwAuthCenter.saasLogLoginLog',
    component: () => import('@/pages/uwAuthCenter/saas/log/loginLog/index.vue'),
    meta: {
      title: '登录日志查询'
    }
  },
  {
    path: '/uwAuthCenter/saas/log/guestLoginLog',
    name: 'uwAuthCenter.saasGuestLogLoginLog',
    component: () =>
      import('@/pages/uwAuthCenter/saas/log/guestLoginLog/index.vue'),
    meta: {
      title: '客户登录日志查询'
    }
  },
  {
    path: '/uwAuthCenter/saas/log/actionLog',
    name: 'uwAuthCenter.saasLogActionLog',
    component: () =>
      import('@/pages/uwAuthCenter/saas/log/actionLog/index.vue'),
    meta: {
      title: '操作日志查询'
    }
  },
  {
    path: '/uwAuthCenter/saas/log/critLog',
    name: 'uwAuthCenter.saasLogCritLog',
    component: () => import('@/pages/uwAuthCenter/saas/log/critLog/index.vue'),
    meta: {
      title: '关键日志查询'
    }
  },
  {
    path: '/uwAuthCenter/saas/account/user',
    name: 'uwAuthCenter.saasAccountUser',
    component: () => import('@/pages/uwAuthCenter/saas/account/user/index.vue'),
    meta: {
      title: '用户管理'
    }
  },
  {
    path: '/uwAuthCenter/saas/account/group',
    name: 'uwAuthCenter.saasAccountGroup',
    component: () =>
      import('@/pages/uwAuthCenter/saas/account/group/index.vue'),
    meta: {
      title: '用户组管理'
    }
  },
  {
    path: '/userInfo',
    component: () => import('@/pages/userInfo/index.vue'),
    name: 'userInfo', // 唯一值
    meta: {
      title: '用户资料',
      isOwnHand: true
    }
  }
]

export default RouterList
