import 'vue-router'

declare module 'vue-router' {
  interface RouteMeta {
    // 路由title
    title?: string
    // 路由 icon
    icon?: string
    // 路由权限ID
    id?: number
    // 权限
    auth?: string | string[]
    // 当前路由是否缓存
    keepAlive?: boolean
    // 是否是手动添加页面，无需权限限制,默认false
    isOwnHand?: boolean
    // 是否是显示在侧边栏菜单，默认false, 仅对于手动添加的路由有效，二者需一起使用
    isShowInSlideMenu?: boolean
    // 是否是首页, 默认false, 需满足children 只有一个且一个侧边栏只允许一个首页，即自身的情况才会去除一级，直接二级展示
    isHomePage?: boolean
    // 动态路由匹配路径, 该项存在值说明该路由是动态路由,仅对于手动添加的路由有效，二者需一起使用
    dynamicRoute?: string
    // 展示背景色  默认展示背景色即true
    displayBackgroundColor?: boolean
    // 是否只显示内容，不显示头部、侧边栏菜单、页签、面包屑， 默认都是false
    onlyShowContent?: boolean
  }
  interface RouteLocationMatched {
    path: string
    meta: RouteMeta
  }
}
