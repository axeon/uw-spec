<script setup lang="ts">
import { useMainStore } from '@/store/main'
import { ElLoading, ElMessage } from 'element-plus'
import { TokenResponse } from '@/api/uwAuthCenterAuthApi'

const props = defineProps<{
  show: boolean
}>()

const mainStore = useMainStore()
// 用户信息
const userInfo = computed(() => mainStore.userInfo)
const currentAccountName = computed(() => {
  return userInfo.value.realName?.charAt(0).toLocaleUpperCase()
})

// 其余用户
const otherAccount = computed(() => mainStore.otherAccountsLoginInfo)

const emits = defineEmits<{
  (e: 'update:show', val: boolean): void
}>()

// 是否显示
const isShow = computed({
  get() {
    return props.show
  },
  set(val) {
    emits('update:show', val)
  }
})

// 切换账号
const handleSwitchAccount = (item: TokenResponse) => {
  // 非300 312 313账号直接外跳
  // 重刷token
  const currentAppName = mainStore.loadAppMenu[mainStore.navIndex]?.appName
  const loadingInstance = ElLoading.service({ fullscreen: true })
  // 之前的登录信息
  const prevLoginInfo = mainStore.loginInfo
  mainStore
    .handleReloadMenu(item.refreshToken)
    .then((res: TokenResponse) => {
      // 依据拿取到的信息重新设置
      changeOtherAccountsLoginInfo(prevLoginInfo, res)
      // 重新获取用户资料
      mainStore.handleUserProfile()
      // 重新获取菜单
      mainStore.handleUserLoadAppMenu().then(menu => {
        // 重新设置菜单
        mainStore.setAppMenu(menu).then(() => {
          // 顶部导航处理保持
          const targetIndex = menu.findIndex(
            item => item.appName === currentAppName
          )
          if (targetIndex > -1) {
            mainStore.setNavIndex(targetIndex)
          }
        })
      })
      setTimeout(() => {
        loadingInstance.close()
        isShow.value = false
        ElMessage.success('账号切换成功')
      }, 1500)
    })
    .catch(() => {
      setTimeout(() => {
        loadingInstance.close()
        isShow.value = false
        ElMessage.success('账号切换成功')
      }, 1500)
    })
}

// 其他用户登录信息切换
const changeOtherAccountsLoginInfo = (
  prevLoginInfo: TokenResponse,
  currentLoginInfo: TokenResponse
) => {
  const data = mainStore.otherAccountsLoginInfo
  if (data.length) {
    // 剔除当前登录的
    const noCurrentLogin = data.filter(
      item => item.userId !== currentLoginInfo.userId
    )
    // 将之前的添加进去
    noCurrentLogin.push(prevLoginInfo)
    // 重新设置
    mainStore.setOtherAccountsLoginInfo(noCurrentLogin)
  }
}

// 非saas账号跳转对应的
// const handleOpenOtherSystem = () => {}
</script>

<template>
  <div class="switch-account">
    <el-dialog
      v-model="isShow"
      title="账号切换"
      width="500"
      draggable
    >
      <TitleHeader title="当前账号" />
      <div class="flex-center margin-top-10">
        <div class="avatar-wrapper">
          <span>{{ currentAccountName }}</span>
        </div>
      </div>
      <div class="flex-center margin-top-10">
        <el-text>{{ userInfo.realName }}</el-text>
      </div>
      <el-divider />
      <TitleHeader title="其他账号" />
      <div class="other-accounts-wrapper">
        <div
          class="other-account-item"
          v-for="item in otherAccount"
          :key="item.userId"
          @click="handleSwitchAccount(item)"
        >
          <div class="content flex-start">
            <div class="avatar-wrapper">
              <span>{{ item.realName?.charAt(0).toLocaleUpperCase() }}</span>
            </div>
            <div class="avatar-name">
              <el-text>{{ item.realName }}</el-text>
            </div>
          </div>
          <div class="icon">
            <el-icon><ArrowRight /></el-icon>
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<style scoped lang="scss">
.switch-account {
  :deep(.el-dialog__body) {
    .avatar-wrapper {
      height: 60px;
      width: 60px;
      margin: 5px 0;
      background: var(--el-color-primary);
      line-height: 60px;
      text-align: center;
      border-radius: 50%;
      color: #fff;
      font-size: 30px;
    }
    .other-accounts-wrapper {
      width: 100%;
      padding-top: 5px;
      .other-account-item {
        line-height: 60px;
        display: flex;
        align-items: center;
        cursor: pointer;
        border-radius: 8px;
        margin-bottom: 5px 0;
        .content {
          flex: 1;
          padding: 0 5px;
          height: 60px;
          align-items: center;
          .avatar-wrapper {
            height: 40px;
            width: 40px;
            background: #46d6d2;
            line-height: 40px;
            text-align: center;
            border-radius: 50%;
            color: #fff;
            font-size: 14px;
          }
          .avatar-name {
            margin-left: 25px;
          }
        }
        .icon {
          width: 50px;
        }
        &:hover {
          background: var(--el-main-container-background);
        }
      }
    }
  }
}

:deep(.title-content) {
  padding-left: 0 !important;
}
</style>
