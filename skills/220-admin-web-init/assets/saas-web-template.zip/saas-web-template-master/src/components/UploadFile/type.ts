import { type UploadUserFile, type UploadFile } from 'element-plus'

// 文件上传传入的props
export interface uploadFileProps {
  uploadParams?: uploadParamsType // 文件上传附带参数
  autoUpload?: boolean // 是否自动上传
  needCompress?: boolean // 是否需要压缩
  fileListForShow: UploadUserFile[] // 上传展示的文件
  fileListForUpload: uploadFileUrl[] // 真正上传保存到的文件，后端需要上传的是http链接
  listType?: 'text' | 'picture-card' // UI展示类型，目前只支持text 、picture-card   默认picture-card
  multiple?: boolean // 是否多选
  accept?: string // 接收上传的文件格式
  drag?: boolean // 是否可以拖拽
  limit?: number // 限制数
  itemWidth?: string | number // 照片项宽度
  itemHeight?: string | number // 照片项高度
  disabled?: boolean // 是否禁用
  accessType?: 0 | 1 // 访问类型。0，公共文件；1.隐私文件
  expireDate?: string // 文件过期时间
  ossSite?: 'saasOssSite' | 'sysDomain'
  uploadMethod?: (
    val: UploadUserFile | UploadFile
  ) => Promise<handleUploadResponse<uploadFileUrl>> // 手动上传时的方法
}

// 文件真正上传保存的格式
export interface uploadFileUrl {
  id?: number // 上传记录的ID
  blobUrl?: string // 文件上传后的blob 链接
  realUrl?: string // 文件上传后的key
}

// 手动上传方法返回格式
export interface handleUploadResponse<T> {
  state: 'success' | 'error'
  data?: T
}

// 组件暴漏方法
export interface uploadFileExposeMethods {
  // 清除组件相关缓冲，相当于重置
  clearFiles: () => void
  //  更新文件上传的refID  需要在点击保存后调用, 新增时需要传入对应的id, 编辑可不传，不熟悉的保险起见都传
  handleUpdateRefId: (refId?: number) => void
  // 解除文件引用 文件若没有引用，后台会自动删除
  handleUnLinkFile: () => void
  // 将需要上传的文件数组转换成json格式的map，用于保存提交   保存格式 "{id: key}"-JSON  id是文件id, key为后端返回路径，不包含域名
  fileListToJsonMap: () => string
}

// 上传附带的参数
export interface uploadParamsType {
  objectType?: string // 关联的表名
  objectId?: string | number // 关联表的id
}

// 文件上传获取token格式
export interface uploadFileTokenType {
  refType: string // 关联的表名
  refId: string // 关联表的id
  fileName: string // 文件名
  fileSize: number // 文件大小
  accessType?: number // 访问类型。0，公共文件；1.隐私文件
  expireDate?: string // 文件过期时间
}
