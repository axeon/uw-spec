/********************************************************************
 *  模块：图片压缩（Web Worker + jsquash）
 *  目标：在不阻塞主线程的情况下进行图片重编码（webp/jpeg/png），
 *       尽可能降低内存拷贝与峰值，避免内存泄漏。
 *
 *  关键设计：
 *  - Transferable：主线程 → Worker 传输 ArrayBuffer 使用 Comlink.transfer，
 *    Worker → 主线程返回结果同样 transfer，确保零拷贝、内存占用低。
 *  - 单 Worker 复用：默认只 new 一次，空闲 30s 自动回收，避免常驻内存。
 *  - 轻量并发控制：全局信号量限制 convert 并发，降低同时 arrayBuffer() 的峰值。
 *  - 降级策略：压缩失败时回退为原图，保证功能稳定。
 *  - 压缩判定：默认仅处理 [100KB, 10MB] 且 type 以 image/ 开头的文件。
 *******************************************************************/
import * as Comlink from 'comlink'
import { reactive } from 'vue'
import type { Remote } from 'comlink'
import { type UploadRawFile } from 'element-plus'
type OutTypes = 'webp' | 'jpeg' | 'png'
type WorkerApi = typeof import('../workers/imageConvert.worker').api
export interface CompressResult {
  file: File
  originalSize: string
  compressedSize: string
  compressionRate: string
  timeSpent: string
}

let worker: Worker | null = null
let remoteApi: Remote<WorkerApi> | null = null
let idleTimer: number | null = null

/* ---------- 工具 ---------- */
const renameExt = (n: string, ext: string) => n.replace(/\.[^.]+$/, `.${ext}`)
const fmtBytes = (b: number, d = 2) => {
  const u = ['B', 'KB', 'MB', 'GB'],
    p = Math.floor(Math.log(b) / Math.log(1024))
  return `${(b / 1024 ** p).toFixed(d)} ${u[p]}`
}

/* ---------- 组装结果 ---------- */
function buildResult(
  file: UploadRawFile,
  origSize: number,
  start: number,
  compSize = origSize
): CompressResult {
  const rate = ((1 - compSize / origSize) * 100).toFixed(2)
  const time = ((performance.now() - start) / 1000).toFixed(2)
  return {
    file,
    originalSize: fmtBytes(origSize),
    compressedSize: fmtBytes(compSize),
    compressionRate: `${rate}%`,
    timeSpent: `${time}s`
  }
}

/* ---------- 轻量并发控制（全局信号量） ---------- */
let maxConcurrent = 2
let runningCount = 0
const waitQueue: Array<() => void> = []

async function acquire() {
  if (runningCount < maxConcurrent) {
    runningCount++
    return
  }
  await new Promise<void>(resolve => {
    waitQueue.push(() => {
      runningCount++
      resolve()
    })
  })
}

function release() {
  runningCount = Math.max(0, runningCount - 1)
  const next = waitQueue.shift()
  if (next) next()
}

export function setImageConvertConcurrency(n: number) {
  maxConcurrent = Math.max(1, Math.floor(n || 1))
}

/* ---------- 按文件 uid 追踪进度和状态 ---------- */
const fileProgress = reactive(
  new Map<number, { loading: boolean; progress: number }>()
)

// 获取指定文件的进度状态（响应式）
export function getFileProgress(uid: number) {
  return fileProgress.get(uid) || { loading: false, progress: 0 }
}

// 设置指定文件的进度状态
function setFileProgress(uid: number, loading: boolean, progress = 0) {
  fileProgress.set(uid, { loading, progress })
}

// 清理指定文件的进度状态
function clearFileProgress(uid: number) {
  fileProgress.delete(uid)
}

/* ---------- 创建worker实例 ---------- */
async function getApi() {
  if (!worker) {
    // 1. 同一时刻可排队多个任务（Worker 内部是单线程顺序执行）
    // 2. 默认只 new 一次 Worker，
    //    后续所有 convert() 都复用同一个 Worker 实例，
    //    直到你手动 worker.terminate() 或页面卸载。
    worker = new Worker(
      new URL('../workers/imageConvert.worker.ts', import.meta.url),
      { type: 'module' }
    )
    // 错误兜底，防止静默失败导致资源悬挂
    worker.onerror = e => {
      console.warn('[image-convert-worker] onerror', e?.message || e)
    }
    worker.onmessageerror = e => {
      console.warn('[image-convert-worker] onmessageerror', e)
    }
    // Comlink.wrap(...) 把 Worker 暴露的对象包装成 Promise 代理，可直接 await 调用
    remoteApi = Comlink.wrap(worker)
  }
  return remoteApi!
}

/* ---------- 主入口 ---------- */
export function useImageConvert() {
  async function convert(
    origSize: UploadRawFile,
    outType: OutTypes,
    quality = 75
  ) {
    const uid = origSize.uid
    if (!uid) throw new Error('文件缺少 uid')

    // 设置该文件的独立状态
    setFileProgress(uid, true, 0)

    // 轻量进度条：仅用于给用户"在处理"的反馈（非真实压缩比例）
    const duration = 2500
    const start = performance.now()
    const tick = () => {
      const p = Math.min((performance.now() - start) / duration, 0.95)
      setFileProgress(uid, true, p) // 同时更新文件独立进度
      if (p < 0.95) requestAnimationFrame(tick)
    }
    requestAnimationFrame(tick)

    try {
      // 控制并发，避免一次性多图导致 arrayBuffer 暴涨
      await acquire()
      const api = await getApi()
      // 使用 Transferable 直接转移 ArrayBuffer 所有权，避免主线程复制造成内存峰值
      const buf = await origSize.arrayBuffer()
      const res = await api.convert(
        Comlink.transfer(buf, [buf]),
        outType,
        quality
      ) // res.data 是 ArrayBuffer（已从 worker 转移）
      if (!res.ok || !res.data) throw new Error('转换失败，数据为空')
      // 完成状态
      setFileProgress(uid, true, 1)

      const compressRaw = new File(
        [new Blob([res.data], { type: `image/${outType}` })],
        renameExt(origSize.name, outType),
        {
          type: `image/${outType}`,
          lastModified: Date.now()
        }
      ) as UploadRawFile

      // 取原图的uid，是el组件的唯一值
      compressRaw.uid = origSize.uid

      // 压缩成功，输出结果
      console.log(
        'buildResult',
        buildResult(compressRaw, origSize.size, start, compressRaw.size)
      )

      return compressRaw
    } catch (err: any) {
      console.warn('压缩失败，已降级为原图', err)
      return origSize // 降级
    } finally {
      release()
      // 清理该文件的独立状态
      clearFileProgress(uid)

      // 若一段时间无任务，自动关闭 worker，避免内存常驻
      if (idleTimer) {
        clearTimeout(idleTimer)
      }
      idleTimer = window.setTimeout(() => {
        shutdown()
      }, 30_000)
    }
  }

  return { convert }
}

/* 关闭worker接口, 避免内存泄漏 */
export function shutdown() {
  if (worker) {
    try {
      // 释放 comlink 代理
      remoteApi?.[Comlink.releaseProxy]?.()
    } catch (err) {
      console.log('err释放comlink', err)
    }
    worker.terminate() // 释放线程
    worker = null
    remoteApi = null
  }
  if (idleTimer) {
    clearTimeout(idleTimer)
    idleTimer = null
  }
}
// 压缩条件：
// - 仅支持 webp / png / jpeg
// - 大小范围 [minKB, maxMB]
export const shouldCompress = (f: File, minKB = 100, maxMB = 15): boolean => {
  const allowTypes = new Set([
    'image/webp',
    'image/png',
    'image/jpeg',
    'image/jpg'
  ])
  const inSizeRange = f.size > minKB * 1024 && f.size <= maxMB * 1024 * 1024
  return allowTypes.has(f.type) && inSizeRange
}
