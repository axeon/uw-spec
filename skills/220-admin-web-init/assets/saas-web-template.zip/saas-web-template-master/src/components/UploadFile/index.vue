<script setup lang="ts">
import {
  type UploadUserFile,
  type UploadFile,
  type UploadInstance,
  type UploadRawFile,
  ElMessage
} from 'element-plus'
import { useI18n } from 'vue-i18n'
import PDFImage from './images/pdfPicture.jpg'
import XlxImage from './images/xlxPicture.jpg'
import docImage from './images/docPicture.jpg'
import {
  uploadFileProps,
  uploadFileUrl,
  uploadFileTokenType,
  uploadFileExposeMethods
} from './type'
import axios from 'axios'
import {
  saasCommonOssGenUploadParam,
  saasCommonOssUploadSuccess,
  saasCommonOssUpdateRefId,
  saasCommonOssUnlink
} from '@/api/saasBaseAppSaasApi'
import {
  mchCommonOssGenUploadParam,
  mchCommonOssUnlink,
  mchCommonOssUpdateRefId,
  mchCommonOssUploadSuccess
} from '@/api/saasBaseAppMchApi'
import { useMainStore } from '@/store/main'
import { getUserTypeApi } from '@/utils/getUserTypeApi'
import {
  useImageConvert,
  shutdown,
  shouldCompress,
  getFileProgress
} from './composables/useImageConvert'
import { getLowerExtName } from '@/utils/tool'

const props = withDefaults(defineProps<uploadFileProps>(), {
  autoUpload: true,
  needCompress: true,
  itemWidth: '128px',
  itemHeight: '128px',
  listType: 'picture-card',
  disabled: false,
  accessType: 0,
  ossSite: 'saasOssSite'
})
const emits = defineEmits<{
  (e: 'update:fileListForShow', val: UploadUserFile[]): void
  (e: 'update:fileListForUpload', val: uploadFileUrl[]): void
  (e: 'deleteFile', val: string): void
}>()

// 图片子线程压缩（单个 Worker 复用）
const { convert: compressImage } = useImageConvert()

// 上传进度条状态管理
const uploadProgress = ref<Map<number, number>>(new Map())

// 获取指定文件的上传进度
const getUploadProgress = (uid: number): number => {
  return uploadProgress.value.get(uid) || 0
}
// 获取指定文件的压缩进度状态
const getCompressProgress = (uid: number) => getFileProgress(uid)

// 当前域名
const domain = computed(() => {
  return props.ossSite === 'saasOssSite'
    ? mainStore.saasDomain
    : mainStore.sysDomain
})

// 图片预览组件
const PreviewImage = defineAsyncComponent(
  () => import('@/components/PreviewImage/index.vue')
)

// 视频预览组件
const VideoPlayer = defineAsyncComponent(
  () => import('@/components/VideoPlayer/index.vue')
)

// excel预览组件
const ExcelPreview = defineAsyncComponent(
  () => import('@/components/ExcelPreview/index.vue')
)

// word预览组件
const WordPreview = defineAsyncComponent(
  () => import('@/components/WordPreview/index.vue')
)

const { t } = useI18n()
const mainStore = useMainStore()
const UploadFileRef = ref<UploadInstance>()
// 图片、或者文件列表
const fileList = computed<UploadUserFile[]>({
  get() {
    return props.fileListForShow || []
  },
  set(val) {
    emits('update:fileListForShow', val)
  }
})

// 真正需要上传的文件
const realUploadFileList = computed({
  get() {
    return props.fileListForUpload || []
  },
  set(val) {
    emits('update:fileListForUpload', val)
  }
})

// 过渡
const loading = ref(false)
// 当前正在上传或者删除的图片uid 用于图片批量上传时区分展示loading的
const currentOperatorUuids = ref<number[]>([])
// 点击进行查看
const handleFilePreview = (file: UploadFile) => {
  if (file.url) {
    const fileType = whichType(file)
    switch (fileType) {
      case 'image':
        handleImgPreview(file)
        break
      case 'video':
        handleVideoPreview(file)
        break
      case 'pdf':
        handlePdfPreview(file)
        break
      case 'excel':
        handleExcelPreview(file)
        break
      case 'word':
        handleWordPreview(file)
        break
    }
  }
}

// 预览图片显示
const isPreviewImage = ref(false)
// 预览图片地址
const PreviewImageUrls = ref<Array<string>>([])
const initIndex = ref(0)
// 图片预览
const handleImgPreview = (file: UploadFile) => {
  // 过滤出所有的图片
  const allImages = fileList.value.filter(item => whichType(item) === 'image')
  const targetIndex = allImages.findIndex(item => item.url === file.url)
  if (targetIndex > -1) {
    initIndex.value = targetIndex
  } else {
    initIndex.value = 0
  }
  const allUrl = allImages.map(item => {
    if (item.url?.includes('blob')) {
      return item.url
    } else if (item.url?.startsWith('http')) {
      return item.url
    }
    return domain.value + item.url
  })
  PreviewImageUrls.value = (allUrl as string[]) || []
  nextTick(() => {
    isPreviewImage.value = true
  })
}
// 显示视频预览组件
const showVideoPlayer = ref(false)
// 视频预览地址
const videoSrc = ref('')
// 视频预览
const handleVideoPreview = (file: UploadFile) => {
  const target = fileList.value.find(item => item.url === file.url)
  if (target) {
    if (target.url?.startsWith('http') || target.url?.includes('blob')) {
      videoSrc.value = target.url
    } else videoSrc.value = domain.value + target.url
    nextTick(() => {
      showVideoPlayer.value = true
    })
  }
}

// 显示excel预览组件
const showExcelPreview = ref(false)
// 视频预览地址
const excelSrc = ref('')
// excel预览
const handleExcelPreview = (file: UploadFile) => {
  if (file.url) {
    const lastIndex = file.name.lastIndexOf('.')
    //  文件后缀带.
    const fileExtend = file.name.slice(lastIndex)
    if (fileExtend === '.xls') {
      ElMessage.warning(
        'xls文件不支持在线预览, 2s后将自动下载此文件，请本地进行预览'
      )
      setTimeout(() => {
        window.open(file.url)
      }, 2000)
    } else {
      const target = fileList.value.find(item => item.url === file.url)
      if (target) {
        excelSrc.value = target.url?.includes('blob')
          ? target.url
          : domain.value + target.url
        nextTick(() => {
          showExcelPreview.value = true
        })
      }
    }
  }
}

// 显示word预览组件
const showWordPreview = ref(false)
// 视频预览地址
const wordSrc = ref('')
// word预览
const handleWordPreview = (file: UploadFile) => {
  if (file.url) {
    const lastIndex = file.name.lastIndexOf('.')
    //  文件后缀带.
    const fileExtend = file.name.slice(lastIndex)
    if (fileExtend === '.doc') {
      ElMessage.warning(
        'doc文件不支持在线预览, 2s后将自动下载此文件，请本地进行预览'
      )
      setTimeout(() => {
        window.open(file.url)
      }, 2000)
    } else {
      const target = fileList.value.find(item => item.url === file.url)
      if (target) {
        wordSrc.value = target.url?.includes('blob')
          ? target.url
          : domain.value + target.url
        nextTick(() => {
          showWordPreview.value = true
        })
      }
    }
  }
}

// pdf预览
const handlePdfPreview = (file: UploadFile) => {
  window.open(file.url)
}

// 需要调用接口删除的文件
const unLinkFiles = ref<UploadFile[]>([])
// 需要更新ref的文件
const updateRefFiles = ref<uploadFileUrl[]>([])

//  删除
// 清除变量中的相关缓存
const handleRemove = (file: UploadFile) => {
  // 清除进度记录
  if (file.uid) {
    uploadProgress.value.delete(file.uid)
  }
  // 清除UI
  fileList.value = fileList.value.filter(item => item.uid !== file.uid)
  // 清除真正的数据
  realUploadFileList.value = realUploadFileList.value.filter(
    item => item.realUrl !== file.url && item.blobUrl !== file.url
  )
  // 清除需要引用的数据
  updateRefFiles.value = updateRefFiles.value.filter(
    item => item.realUrl !== file.url && item.blobUrl !== file.url
  )
  // 对于已经上传的文件点击删除存储到解除引用的变量中d
  if (file.url && !file.url?.includes('blob') && !file.url?.startsWith('http'))
    unLinkFiles.value.push(file)

  // 执行删除文件的方法回调
  emits('deleteFile', file.url as string)
}

//  清除数据
const clearFiles = () => {
  // 清除所有进度记录
  uploadProgress.value.clear()
  // 清除文件数据
  UploadFileRef.value && UploadFileRef.value.clearFiles()
  // 清除相关缓存数据
  unLinkFiles.value = []
  fileList.value = []
  realUploadFileList.value = []
  updateRefFiles.value = []
}

//  文件改变时，清除非接受的格式文件
const handleChange = (file: UploadFile) => {
  if (props.accept) {
    const formatKeys = props.accept.split(',')
    // 处理文件名，将后缀转换为小写
    const lowerFile = getLowerExtName(file.name)
    file.name = lowerFile.lowerName
    // accept中存在
    if (!formatKeys.includes(lowerFile.ext)) {
      ElMessage.warning(file.name + '文件格式不支持')
      nextTick(() => {
        handleRemove(file)
      })
    } else {
      // 进行上传
      if (props.autoUpload) {
        if (props.listType === 'text') {
          // 文本UI展示方式，需要对rawFile增加blob url链接
          file.url = handleCreateBlobUrl(file.raw!, file.raw!.type)
        }
        // 自动上传
        autoUploadMethod(file)
      } else {
        if (props.uploadMethod) {
          // 手动上传
          props.uploadMethod(file).then(res => {
            if (res.state === 'success') {
              realUploadFileList.value.push(res.data as uploadFileUrl)
              updateRefFiles.value.push(res.data as uploadFileUrl)
            }
          })
        } else {
          ElMessage.error('无上传方法！')
        }
      }
    }
  }
}

// 创建blob链接 用于组件卸载时 释放内存
const blobUrls = new Set<string>()

const handleCreateBlobUrl = (raw: UploadRawFile, type: string): string => {
  const url = URL.createObjectURL(new Blob([raw!], { type: type }))
  blobUrls.add(url)
  return url
}

// 自动上传的方法
const autoUploadMethod = async (file: UploadUserFile | UploadFile) => {
  // 1. 先让浏览器渲染 loading
  if (file.uid) currentOperatorUuids.value.push(file.uid!)
  loading.value = true

  // 2. 再开始压缩（异步，不阻塞）

  /* 2-1 压缩（仅图片且 needCompress 为 true 时） */
  const rawFile = file.raw as UploadRawFile
  let compressRawFile = rawFile
  if (props.needCompress && rawFile && shouldCompress(rawFile)) {
    compressRawFile = (await compressImage(
      rawFile,
      'webp',
      80
    )) as UploadRawFile

    // 创建压缩后的Blob URL并更新到file对象
    if (compressRawFile !== rawFile && props.listType === 'picture-card') {
      const compressBlobUrl = handleCreateBlobUrl(
        compressRawFile,
        compressRawFile.type
      )
      // 更新file对象的url为压缩后的图片url
      file.url = compressBlobUrl
    }
  } else {
    if (!props.needCompress) {
      console.log('needCompress 为 false，跳过压缩', file.name)
    } else {
      console.log('不符合压缩条件，回落原图', file.name)
    }
  }

  /* 2-2 上传压缩后的文件 */
  /* ===== 1. 取令牌 ===== */
  const params: uploadFileTokenType = {
    fileName: compressRawFile.name,
    fileSize: compressRawFile.size as number,
    refId: String(props.uploadParams?.objectId),
    refType: props.uploadParams?.objectType as string,
    accessType: props.accessType,
    expireDate: props.expireDate || undefined
  }
  const request = getUserTypeApi({
    300: () => saasCommonOssGenUploadParam(params),
    310: () => mchCommonOssGenUploadParam(params),
    0: () => saasCommonOssGenUploadParam(params)
  })
  /* ===== 2. 只在 then 里加压缩入口 ===== */
  request().then((res: any) => {
    if (res.state === 'success' && res.data && res.data?.key) {
      const formData = new FormData()
      formData.append('policy', res.data.uploadParam!.policy)
      formData.append(
        'x-amz-algorithm',
        res.data.uploadParam!['x-amz-algorithm']
      )
      formData.append(
        'x-amz-credential',
        res.data.uploadParam!['x-amz-credential']
      )
      formData.append('x-amz-date', res.data.uploadParam!['x-amz-date'])
      formData.append(
        'x-amz-signature',
        res.data.uploadParam!['x-amz-signature']
      )
      formData.append('key', res.data.key)
      // 获取文件格式类型
      formData.append('Content-Type', compressRawFile.type) // ← 这里换成压缩后的文件类型
      // 文件内容放到顺序后面否则会请求失败
      formData.append('file', compressRawFile) // ← 这里换成压缩后的文件
      // 上传至七牛云
      axios({
        url: 'https://' + res.data.ossHost,
        method: 'POST',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        },
        // 添加上传进度监控
        onUploadProgress: progressEvent => {
          if (progressEvent.total && progressEvent.loaded) {
            const percentComplete =
              (progressEvent.loaded / progressEvent.total) * 100
            if (file.uid) {
              uploadProgress.value.set(file.uid, Math.round(percentComplete))
            }
          }
        }
      })
        .then(uploadRes => {
          if (uploadRes.status === 204) {
            realUploadFileList.value.push({
              id: res.data!.id,
              realUrl: res.data!.key,
              blobUrl: file.url
            })
            // 添加上传的引用文件
            updateRefFiles.value.push({
              id: res.data!.id,
              realUrl: res.data!.key,
              blobUrl: file.url
            })
            const uploadSuccessParams = {
              id: res.data!.id!,
              filePath: res.data!.key!
            }
            const request = getUserTypeApi({
              300: () => saasCommonOssUploadSuccess(uploadSuccessParams),
              310: () => mchCommonOssUploadSuccess(uploadSuccessParams),
              0: () => saasCommonOssUploadSuccess(uploadSuccessParams)
            })
            // 调用文件上传成功的请求
            request()
          } else {
            // 清除上传进度
            if (file.uid) {
              uploadProgress.value.delete(file.uid)
            }
            ElMessage.error(`${file.name}${t('failToUpload')}`)
          }
          loading.value = false
          // 清除上传进度
          if (file.uid) {
            uploadProgress.value.delete(file.uid)
          }
          console.log('上传成功', file.name)
          if (file.uid) {
            currentOperatorUuids.value = currentOperatorUuids.value.filter(
              uid => uid !== file.uid
            )
          }
        })
        .catch(() => {
          ElMessage.error(`${file.name}${t('failToUpload')}`)
          loading.value = false
          if (file.uid) {
            currentOperatorUuids.value = currentOperatorUuids.value.filter(
              uid => uid !== file.uid
            )
          }
        })
    } else {
      ElMessage.error(`${file.name}${t('getTokenFail')},${t('failToUpload')}`)
    }
  })
}

// 图片
const imageKeys = toRaw([
  '.jpeg',
  '.jpg',
  '.png',
  '.gif',
  '.jpe',
  '.jpe2',
  '.webp' // 新增的格式
])
// 视频
const videoKeys = toRaw([
  '.avi',
  '.wmv',
  '.mpg',
  '.mov',
  '.rm',
  '.ram',
  '.swf',
  '.flv',
  '.mp4'
])
const docKeys = toRaw(['.doc', '.docx'])
const excelKeys = toRaw(['.xls', '.xlsx'])
const pdfKeys = toRaw(['.pdf'])

// 处理文件上传回显的照片
const handleFileUrl = (file: UploadFile): string => {
  // 图片、视频是需要展示的
  // excel、pdf等展示固定图片不需要做判断
  if (['image', 'video'].includes(whichType(file))) {
    const url = file.url
    if (url?.includes('blob')) {
      return url
    } else if (url?.includes('http') || url?.includes('https')) {
      return url
    }
    return domain.value + file.url
  }
  // 未知
  return ''
}

//  类型判断
const whichType = (file: UploadFile | UploadUserFile): string => {
  const lastIndex = file.name.lastIndexOf('.')
  //  文件后缀带.
  const fileExtend = file.name.slice(lastIndex)
  if (imageKeys.includes(fileExtend)) {
    return 'image'
  } else if (videoKeys.includes(fileExtend)) {
    // 视频
    return 'video'
  } else if (docKeys.includes(fileExtend)) {
    // word文档
    return 'word'
  } else if (excelKeys.includes(fileExtend)) {
    // excel
    return 'excel'
  } else if (pdfKeys.includes(fileExtend)) {
    // pdf
    return 'pdf'
  }
  // 未知
  return ''
}

//  展示项的宽度
const listItemWidth = computed(() => {
  if (typeof props.itemWidth === 'string') {
    return props.itemWidth
  }
  return props.itemWidth + 'px'
})

//  展示项的高度
const listItemHeight = computed(() => {
  if (typeof props.itemHeight === 'string') {
    return props.itemHeight
  }
  return props.itemHeight + 'px'
})

// 当前所有上传成功的url数组 真实url
const uploadSuccessArrayForRealUrl = computed(() => {
  return realUploadFileList.value.map(item => item.realUrl)
})

// 当前所有上传成功的url数组 真实url
const uploadSuccessArrayForBlobUrl = computed(() => {
  const data: string[] = []
  realUploadFileList.value.forEach(item => {
    if (item.blobUrl) {
      data.push(item.blobUrl)
    }
  })
  return data
})

// 超出文件上传限制
const handleExceed = () => {
  ElMessage.warning(`文件最大上传次数为：${props.limit}`)
}

/**
 * 更新文件上传的refID  需要在点击保存后调用
 * @param refId 关联表的ID
 */
const handleUpdateRefId = (refId?: number) => {
  if (updateRefFiles.value.length) {
    updateRefFiles.value.forEach(async item => {
      const url = item.realUrl!.replace(`${domain.value}`, '')
      const params = {
        refId: refId ? String(refId) : String(props.uploadParams!.objectId!),
        id: item.id!,
        filePath: url
      }
      const request = getUserTypeApi({
        300: () => saasCommonOssUpdateRefId(params),
        310: () => mchCommonOssUpdateRefId(params),
        0: () => saasCommonOssUpdateRefId(params)
      })
      await request()
    })
  }
}

const saasId = computed(() => {
  return mainStore.loginInfo.saasId || 0
})
/**
 * 解除文件引用
 * @param refId 关联表的ID
 */
const handleUnLinkFile = () => {
  if (unLinkFiles.value.length) {
    unLinkFiles.value.forEach(async item => {
      const url = item.url!.replace(`${domain.value}`, '')
      // 兼容旧saas那边同步过来的图片 旧saas的无需解绑
      if (url.startsWith(`${saasId.value}/`)) {
        const lastIndex = url.lastIndexOf('/')
        const id = Number(
          url
            .slice(lastIndex + 1)
            .split('.')[0]
            .split('_')[1]
        )
        const params = {
          filePath: url,
          id
        }
        const request = getUserTypeApi({
          300: () => saasCommonOssUnlink(params),
          310: () => mchCommonOssUnlink(params),
          0: () => saasCommonOssUnlink(params)
        })
        await request()
      }
    })
  }
}

/**
 * 将需要上传的文件数组转换成json格式的map，用于保存提交
 */
const fileListToJsonMap = (): string => {
  if (realUploadFileList.value?.length) {
    const obj: Record<number, string> = {}
    realUploadFileList.value.forEach(item => {
      obj[item.id as number] = item.realUrl!
    })
    return JSON.stringify(obj)
  }
  return ''
}

// 是否显示上传框
const showNone = computed(() => {
  if (props.disabled) {
    return 'none'
  } else if (props.limit && fileList.value.length >= props.limit) {
    return 'none'
  }
  return 'flex'
})

// 当前鼠标移上去的路径
const currentMouseOverFileUrl = ref('')
// 文件展示UI方式  鼠标移入
const handleMouseOver = (file: UploadFile | UploadUserFile) => {
  if (props.disabled) {
    return
  }
  currentMouseOverFileUrl.value = file.url || ''
}
// 文件展示UI方式  鼠标移出
const handleMouseLeave = () => {
  if (props.disabled) {
    return
  }
  currentMouseOverFileUrl.value = ''
}

/* 组件卸载时清理 */
onUnmounted(() => {
  // 清除所有进度记录
  uploadProgress.value.clear()
  // 清理blobUrl
  blobUrls.forEach(u => URL.revokeObjectURL(u))
  blobUrls.clear()
  // 关闭worker
  if (props.needCompress) {
    shutdown()
  }
})

onMounted(() => {
  unLinkFiles.value = []
  updateRefFiles.value = []
})

onActivated(() => {
  unLinkFiles.value = []
  updateRefFiles.value = []
})

defineExpose<uploadFileExposeMethods>({
  clearFiles, // 清除文件的方法
  handleUpdateRefId, // 更新文件上传的refID
  handleUnLinkFile, // 解除链接文件
  fileListToJsonMap // 将需要上传的文件数组转换成json格式的map，用于保存提交
})
</script>

<template>
  <div class="upload-wrapper">
    <el-upload
      v-model:file-list="fileList"
      action="#"
      :list-type="listType"
      :auto-upload="false"
      :multiple="props.multiple"
      :accept="props.accept"
      :drag="props.drag"
      :limit="props.limit"
      ref="UploadFileRef"
      :on-change="handleChange"
      :on-exceed="handleExceed"
      :disabled="props.disabled"
      :on-remove="handleRemove"
      :on-preview="handleFilePreview"
    >
      <el-icon v-if="listType === 'picture-card'">
        <Plus />
      </el-icon>
      <slot v-else></slot>
      <template #file="{ file }">
        <!-- 去掉全局的loading，防止批量上传的时候loading统一开关 -->
        <!--通过维护currentOperatorUuids在同一个调用周期里 "push 一次、finally 里删除一次" 来控制各自loading的展示 -->
        <!-- 同时支持压缩进度显示：getCompressProgress(file.uid!) 可获取 { loading, progress } -->
        <div
          class="show-image-wrapper"
          style="position: relative"
          v-loading="
            currentOperatorUuids.includes(file.uid!) &&
            !getCompressProgress(file.uid!).progress &&
            !getUploadProgress(file.uid!)
          "
        >
          <!-- 压缩进度条遮罩层 -->
          <div
            class="progress-overlay flex-center flex-algin"
            v-if="
              props.needCompress &&
              currentOperatorUuids.includes(file.uid!) &&
              getCompressProgress(file.uid!).progress > 0
            "
          >
            <!-- 压缩进度条 -->
            <el-progress
              :percentage="
                Math.round(getCompressProgress(file.uid!).progress * 100)
              "
              :stroke-width="3"
            >
              <div class="progress-text flex-align-end">
                压缩中...{{
                  Math.round(getCompressProgress(file.uid!).progress * 100)
                }}%
              </div>
            </el-progress>
          </div>
          <!-- 上传进度条遮罩层 -->
          <div
            class="progress-overlay flex-center flex-algin"
            v-else-if="
              currentOperatorUuids.includes(file.uid!) &&
              getUploadProgress(file.uid!) > 0
            "
          >
            <!-- 上传进度条 -->
            <el-progress
              :percentage="getUploadProgress(file.uid!)"
              :stroke-width="3"
            >
              <div class="progress-text flex-align-end">
                上传中...{{ getUploadProgress(file.uid!) }}%
              </div>
            </el-progress>
          </div>
          <template v-if="listType === 'picture-card'">
            <!-- 预览内容区 -->
            <div class="preview-content">
              <img
                class="el-upload-list__item-thumbnail"
                :src="handleFileUrl(file)"
                alt=""
                v-if="whichType(file) === 'image'"
              />
              <video
                :src="handleFileUrl(file)"
                v-else-if="whichType(file) === 'video'"
              ></video>
              <img
                class="el-upload-list__item-thumbnail"
                :src="PDFImage"
                v-else-if="whichType(file) === 'pdf'"
              />
              <img
                class="el-upload-list__item-thumbnail"
                :src="XlxImage"
                v-else-if="whichType(file) === 'excel'"
              />
              <img
                class="el-upload-list__item-thumbnail"
                :src="docImage"
                v-else-if="whichType(file) === 'word'"
              />
              <!-- 上传成功、失败提示角标 -->
              <div
                class="upload-tip"
                :style="{
                  background:
                    uploadSuccessArrayForRealUrl?.includes(file.url!) ||
                    uploadSuccessArrayForBlobUrl?.includes(file.url!)
                      ? 'var(--el-color-success)'
                      : 'var(--el-color-danger)'
                }"
              >
                <el-icon
                  color="var(--el-bg-color)"
                  v-if="
                    uploadSuccessArrayForRealUrl?.includes(file.url!) ||
                    uploadSuccessArrayForBlobUrl?.includes(file.url!)
                  "
                >
                  <Check />
                </el-icon>
                <el-icon
                  color="var(--el-bg-color)"
                  v-else
                >
                  <Close />
                </el-icon>
              </div>

              <!-- 操作图标（放大/删除） -->
              <span class="el-upload-list__item-actions">
                <span
                  class="el-upload-list__item-preview"
                  @click="handleFilePreview(file)"
                >
                  <!-- v-if="
                    !['video', 'word', 'excel', 'pdf'].includes(whichType(file))
                  " -->
                  <el-icon>
                    <ZoomIn />
                  </el-icon>
                </span>
                <span
                  class="el-upload-list__item-delete"
                  @click="handleRemove(file)"
                  v-if="!props.disabled"
                >
                  <el-icon>
                    <Delete />
                  </el-icon>
                </span>
              </span>
            </div>
            <!-- 底部按钮区 -->
            <div class="set-main-btn-area">
              <slot
                name="btns"
                :file="file"
              ></slot>
            </div>
          </template>
          <template v-else>
            <div class="file-text-item flex-start flex-align">
              <el-icon class="margin-right-5"><Document /></el-icon>
              <div
                class="fileName ellipsis cursor-p"
                @click="handleFilePreview(file)"
              >
                {{ file.name }}
              </div>
              <div
                class="feedback-icon"
                @mouseover="handleMouseOver(file)"
                @mouseleave="handleMouseLeave"
              >
                <template
                  v-if="
                    currentMouseOverFileUrl &&
                    currentMouseOverFileUrl === file.url
                  "
                >
                  <el-icon
                    color="var(--el-color-danger)"
                    class="cursor-p"
                    @click="handleRemove(file)"
                    v-if="!disabled"
                  >
                    <DeleteFilled />
                  </el-icon>
                </template>
                <template v-else>
                  <el-icon
                    color="var(--el-color-success)"
                    v-if="
                      uploadSuccessArrayForRealUrl?.includes(file.url!) ||
                      uploadSuccessArrayForBlobUrl?.includes(file.url!)
                    "
                  >
                    <CircleCheck />
                  </el-icon>
                  <el-icon
                    color="var(--el-color-danger)"
                    v-else
                  >
                    <CircleClose />
                  </el-icon>
                </template>
              </div>
            </div>
          </template>
        </div>
      </template>
    </el-upload>
    <!-- 底部提示语 -->
    <div class="tip">
      <slot name="tip"></slot>
    </div>
    <!-- 图片预览组件 -->
    <PreviewImage
      v-model:show="isPreviewImage"
      :url="PreviewImageUrls"
      :initial-index="initIndex"
      style="z-index: 9999 !important"
    />
    <!-- 视频预览组件 -->
    <VideoPlayer
      v-model:show="showVideoPlayer"
      :src="videoSrc"
    />
    <!-- Excel预览组件 -->
    <ExcelPreview
      v-model="showExcelPreview"
      :src="excelSrc"
    />
    <!-- word预览组件 -->
    <WordPreview
      v-model="showWordPreview"
      :src="wordSrc"
    />
  </div>
</template>

<style lang="scss" scoped>
// 预览内容区
.preview-content {
  flex: 1;
  position: relative; /* 用于状态角标定位 */
  overflow: hidden; /* 防止内容溢出 */
  width: 100%;
  flex-shrink: 0;
}
.upload-wrapper {
  width: 100%;

  :deep(.el-upload-list__item-thumbnail) {
    object-fit: fill;
  }

  :deep(.el-upload--picture-card) {
    width: v-bind(listItemWidth);
    height: v-bind(listItemHeight);
    display: v-bind(showNone);
    line-height: v-bind(listItemHeight);
    align-items: center;
    justify-content: center;
  }

  :deep(.el-upload-list--picture-card) {
    .el-upload-list__item {
      width: v-bind(listItemWidth);
      height: v-bind(listItemHeight);
      .show-image-wrapper {
        position: relative;
        width: 100%;
        display: flex;
        flex-direction: column;
        .upload-tip {
          position: absolute;
          top: -5%;
          right: -20%;
          width: 50%;
          height: 20px;
          background: var(--el-color-success);
          transform: rotate(45deg);
          display: flex;
          justify-content: center;
          align-items: end;
          .el-icon {
            transform: rotate(-45deg);
          }
        }
      }
    }
  }

  .file-text-item {
    width: 100%;
    height: 32px;
    padding-left: 5px;
    .fileName {
      flex: 1;
    }
    .feedback-icon {
      width: 32px;
      height: 32px;
    }
  }

  :deep(.tip) {
    color: #8a8a8a;
    text-align: center;
  }
  :deep(.el-upload--picture-card) {
    margin-bottom: 8px !important;
  }
  // 进度条
  .progress-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 1000;
    .progress-text {
      width: 100%;
      padding-top: 8px;
      color: #fff;
      font-size: calc(v-bind(listItemWidth) / 9);
      text-align: end;
    }

    .el-progress--line {
      max-width: calc(100% - 10px);
    }
  }
}
</style>
