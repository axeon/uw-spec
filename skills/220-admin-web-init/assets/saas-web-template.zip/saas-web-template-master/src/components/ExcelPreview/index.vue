<template>
  <div :class="{ excelPreview: !dialogExpand?.fullscreen }">
    <el-dialog
      v-model="isShow"
      :title="title"
      :width="dialogWidth"
      draggable
      v-bind="dialogExpand"
      :close-on-click-modal="false"
      @close="closePreview"
    >
      <div
        :style="{ height: contentHeight }"
        v-loading="loading"
        ref="excelDom"
      ></div>
    </el-dialog>
  </div>
</template>

<script lang="ts" setup>
import { excelProps } from './type'
import { ElMessage } from 'element-plus'
import Spreadsheet from 'x-data-spreadsheet'
import 'x-data-spreadsheet/dist/xspreadsheet.css'
import * as ExcelJS from 'exceljs'

const props = withDefaults(defineProps<excelProps>(), {
  title: 'Excel文档预览',
  width: 1000,
  height: 650,
  dialogExpand: () => ({}),
  renderedHandler: () => {
    console.log('渲染成功')
  },
  errorHandler: () => {
    ElMessage.error('Excel文档渲染异常')
  }
})

const emits = defineEmits<{
  (e: 'update:modelValue', val: boolean): void
}>()

// 是否展示
const isShow = computed({
  get() {
    return props.modelValue
  },
  set(val) {
    emits('update:modelValue', val)
  }
})

// excel高度
const contentHeight = computed(() => {
  if (props.dialogExpand?.fullscreen) {
    return '93vh'
  }
  if (typeof props.height === 'number') {
    return props.height + 'px'
  }
  return props.height
})

// 弹窗宽度
const dialogWidth = computed(() => {
  if (typeof props.width === 'number') {
    return props.width + 'px'
  }
  return props.width
})

// dom元素
const excelDom = ref<HTMLElement>()
// 展示excel的实例
let spreadsheetInstance: Spreadsheet | null = null
// 解析excel的实例
const workbookInstance = ref<ExcelJS.Workbook>()
// loading效果
const loading = ref(false)

// 获取文件流，解析数据，进行展示
const loadExcel = () => {
  // 使用fetch获取文件流
  fetch(props.src)
    .then(response => {
      if (!response.ok) {
        // 给出提示，渲染异常
        props.errorHandler()
      }
      return response.blob() // 将响应转换为Blob对象
    })
    .then(blob => {
      // 如果需要读取文件内容（例如使用FileReader）
      const reader = new FileReader()
      reader.onload = async function (e) {
        try {
          const file = e.target?.result
          if (!file) return
          workbookInstance.value = new ExcelJS.Workbook()
          await workbookInstance.value.xlsx.load(file as ArrayBuffer)
          const sheetData = workbookInstance.value.worksheets.map(sheet => {
            const rows: any[] = []
            sheet.eachRow(row => {
              const rowData: any[] = []
              row.eachCell(cell => {
                rowData.push(cell.text)
              })
              rows.push(rowData)
            })
            // todo 表头合并异常 暂时找不到解决办法以后有机会再处理吧
            return {
              name: sheet.name,
              rows: rows.map(row => ({
                cells: row.map((cell: string) => ({
                  text: cell
                }))
              }))
            }
          })
          // 初始化 x-data-spreadsheet
          spreadsheetInstance = new Spreadsheet(excelDom.value as HTMLElement, {
            mode: 'read',
            showToolbar: false,
            showGrid: true,
            view: {
              width: () => props.width,
              height: () => props.height
            }
          })
          // 加载数据并渲染
          spreadsheetInstance.loadData(sheetData)
          // 渲染完成执行回调
          props.renderedHandler()
        } catch (error) {
          // 给出提示，渲染异常
          props.errorHandler()
          console.error(error)
        } finally {
          loading.value = false
        }
      }
      reader.readAsArrayBuffer(blob) // 读取为ArrayBuffer
    })
    .catch(() => {
      props.errorHandler()
      loading.value = false
    })
}

// 销毁各项实例
const destroy = () => {
  if (spreadsheetInstance) {
    spreadsheetInstance = null
  }
  if (workbookInstance.value) {
    workbookInstance.value = undefined
  }
  if (excelDom.value) {
    excelDom.value.innerHTML = ''
  }
  timer.value && clearTimeout(timer.value)
}

// 关闭预览窗口
const closePreview = () => {
  destroy()
}

// 定时器ID
const timer = ref()
const stopWatch = watch(
  () => isShow.value,
  val => {
    if (val) {
      loading.value = true
      nextTick(() => {
        timer.value = setTimeout(() => {
          loadExcel()
        }, 1000)
      })
    }
  },
  {
    immediate: true
  }
)

onUnmounted(() => {
  destroy()
  stopWatch()
})
</script>

<style scoped lang="scss">
.excelPreview {
  :deep(.el-dialog__body) {
    height: 650px;
    overflow: hidden auto;
  }
}
</style>
