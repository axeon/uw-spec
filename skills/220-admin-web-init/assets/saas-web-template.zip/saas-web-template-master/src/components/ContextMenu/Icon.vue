<script lang="ts" setup>
import * as ElementPlusIconsVue from '@element-plus/icons-vue'

const props = withDefaults(
  defineProps<{
    iconName: string
    size?: number
  }>(),
  {
    iconName: '',
    size: 14
  }
)

const render = () => {
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  const icon = ElementPlusIconsVue[props.iconName]
  if (icon) {
    return h(icon)
  }
  return h('i', {
    class: ['iconfont', props.iconName],
    style: {
      'font-size': 'inherit'
    }
  })
}
</script>

<template>
  <div class="menu-icon">
    <el-icon :size="props.size">
      <render></render>
    </el-icon>
  </div>
</template>

<style lang="scss" scoped>
.menu-icon {
  flex-shrink: 0;
  display: inline-flex;
  // width: 50px;
  align-items: center;
  justify-content: center;
}
</style>
