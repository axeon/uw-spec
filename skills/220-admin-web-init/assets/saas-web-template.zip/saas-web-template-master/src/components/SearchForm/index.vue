<script lang="ts" setup>
import { Search, ArrowDown, ArrowUp } from '@element-plus/icons-vue'
import { SearchFormProps, SearchFormType } from './type'
import { OptionType } from 'element-plus/es/components/select-v2/src/select.types'
import { useMainStore } from '@/store/main'
import {
  FormInstance,
  ElScrollbar,
  type CascaderOption,
  CascaderProps,
  ElCascader
} from 'element-plus'
import { watchDebounced } from '@vueuse/core'

//  搜索框tag类型
interface tagListType {
  name: string
  field: string
  label?: string | string | Array<number | string>
  value: string | number | Array<number | string>
}

const InputNumberRange = defineAsyncComponent(
  () => import('@/components/InputNumberRange/index.vue')
)

const props = withDefaults(defineProps<SearchFormProps>(), {
  modelValue: () => ({}),
  formAttributes: () => ({
    size: 'default',
    inline: true
  }),
  type: 'search',
  list: () => [],
  bntLoading: false
})

const emits = defineEmits<{
  (e: 'change'): void
  (e: 'search'): void
}>()

const mainStore = useMainStore()
const conditionList = ref<tagListType[]>([])
const timeOut = ref(0)
const formEl = ref<FormInstance>()
// 控制整体数量是否显示
const show = ref(false)
// 是否显示搜索输入，控制单行是否显示
const showSearchInput = ref(false)

const filterList = computed(() => {
  // type 为 form 的时候 不做过滤
  if (show.value || props.type === 'form') return props.list
  // type 为search，计算一行显示的个数
  return props.list.slice(0, singleLineDisplays.value)
})

// 表单值
const formData = computed(() => {
  return props.modelValue || {}
})

const tagList = computed(() => {
  return conditionList.value.filter(item => {
    return item.value !== '' && item.value !== undefined && item.value !== null
  })
})

// 级联选择的ref
const cascaderRef = ref<InstanceType<typeof ElCascader>[]>([])

// 关闭标签
const closeTag = (item: tagListType) => {
  formData.value[item.field] = undefined
  change()
}

// 点击搜索
const clickSearch = () => {
  if (formEl.value) {
    formEl.value.validate(valid => {
      if (valid) {
        emits('search')
      }
    })
  } else {
    emits('search')
  }
}

//  是否存在默认值
const hasDefaultValue = ref<boolean>(false)

// 判断值是否数组，且数组都为空值
const arrayValueIsNull = (data: number | string | any[]): boolean => {
  if (!data) return false
  if (!Array.isArray(data)) return true
  return data.some(item =>
    item || item === 0
      ? true
      : !isNaN(item) && item !== undefined && item !== null
  )
}

// ── 辅助：构建组合组件 tag（如 selectAndDatePicker）──
const buildCombinationTag = (
  item: SearchFormType,
  key: string,
  arr: tagListType[]
) => {
  // 去重：存在相同 field 则先删除
  const targetIndex = arr.findIndex(target => target.field === item.field)
  if (targetIndex > -1) {
    arr.splice(0, targetIndex)
  }

  const val = formData.value[key]
  const combinationVal = formData.value[item.combinationField as string]

  if (item.options?.length && item.combinationOptions?.length) {
    // 有 options + combinationOptions：取 option label，combinationOption 找不到时才 push
    item.options.forEach(el => {
      if (el.value !== val) return
      const labelTarget = item.combinationOptions?.find(
        o => o.value === combinationVal
      )
      if (!labelTarget) {
        arr.push({
          name: item.combinationField || '',
          field: item.field,
          label: el.label,
          value: val
        })
      }
    })
  } else {
    // 仅有 combinationOptions：用 combinationOption label 作为 name
    const labelTarget = item.combinationOptions?.find(
      o => o.value === combinationVal
    )
    arr.push({
      name: labelTarget?.label || item.combinationField || '',
      field: item.field,
      value: val
    })
  }
}

// ── 辅助：构建单一组件 tag ──
const buildSingleTag = (
  item: SearchFormType,
  key: string,
  itemIndex: number,
  cascaderIndexArray: number[],
  arr: tagListType[]
) => {
  const val = formData.value[key]

  // 有 options（select / radio 等）
  if (item.options?.length) {
    if (item.expand?.multiple) {
      // 多选
      arr.push(handleSelectMultiple(item.options, val, item))
    } else {
      // 单选
      const matched = item.options.find(el => el.value === val)
      if (matched) {
        arr.push({
          name: item.formItem?.label || item.field,
          field: item.field,
          label: matched.label,
          value: val
        })
      }
    }
    return
  }

  // 级联选择器
  if (item.componentType === 'cascader') {
    if (item.cascaderOptions?.length) {
      // 静态级联数据
      if (val && Array.isArray(val)) {
        const label: string[] = []
        ;(val as Array<string | number>).forEach(el => {
          const target = findVal(
            item.cascaderOptions as CascaderOption[],
            el,
            item?.expand?.props || {
              value: 'value',
              label: 'label',
              children: 'children'
            }
          )
          if (target) label.push(target[0])
        })
        arr.push({
          name: item.formItem?.label || item.field,
          field: item.field,
          label,
          value: val
        })
      }
    } else {
      // 动态级联数据：通过 ref 取 presentText
      const cascaderRefIndex = cascaderIndexArray.findIndex(
        idx => idx === itemIndex
      )
      if (cascaderRefIndex > -1) {
        arr.push({
          name: item.formItem?.label || item.field,
          field: item.field,
          value: val,
          label: cascaderRef.value[cascaderRefIndex]?.presentText
        })
      }
    }
    return
  }

  // 其他普通组件
  arr.push({
    name: item.formItem?.label || item.field,
    field: item.field,
    value: val
  })
}

// 处理搜索框展示的条件
const handleCondition = () => {
  if (props.type === 'form') return // 表单类型不处理

  const arr: tagListType[] = []
  const list: SearchFormType[] = hasDefaultValue.value
    ? props.list
    : filterList.value

  // 提前计算级联选择器在 list 中的索引
  const cascaderIndexArray: number[] = list.reduce<number[]>(
    (acc, item, index) => {
      if (item.componentType === 'cascader') acc.push(index)
      return acc
    },
    []
  )

  // 组合组件类型集合
  const combinationComponentsType = new Set(['selectAndDatePicker'])

  for (const key in formData.value) {
    if (!Object.hasOwn(formData.value, key)) continue
    if (
      formData.value[key] === undefined ||
      (!arrayValueIsNull(formData.value[key]) && formData.value[key] !== 0)
    ) {
      continue
    }

    const itemIndex = list.findIndex(item => item.field === key)
    if (itemIndex === -1) continue
    const item = list[itemIndex]

    // ── 组合组件 ──
    if (
      combinationComponentsType.has(item.componentType) &&
      item.combinationField &&
      formData.value[item.combinationField] !== undefined
    ) {
      buildCombinationTag(item, key, arr)
      continue
    }

    // ── 单一组件 ──
    buildSingleTag(item, key, itemIndex, cascaderIndexArray, arr)
  }

  conditionList.value = arr
  handleScroll()
}

// 处理下拉框多选情况 单一组件情况
const handleSelectMultiple = (
  options: Array<{ value?: string | number; label?: string }>,
  val: Array<string | number>,
  item: SearchFormType
): tagListType => {
  const data: Array<string | number> = []
  const labelData: Array<string | number> = []
  const returnData: tagListType = {
    name: '',
    field: '',
    label: '',
    value: ''
  }
  options.forEach(item => {
    const targetIndex: number = val.findIndex(
      (subItem: string | number) => subItem === item.value
    )
    if (targetIndex > -1) {
      data.push(val[targetIndex])
      labelData.push(item.label as string)
    }
  })
  if (!data.length) {
    returnData.value = ''
  } else {
    returnData.value = data
  }
  if (!labelData.length) {
    returnData.label = ''
  } else {
    returnData.label = labelData
  }
  returnData.field = item.field
  // name 是副组件的值
  returnData.name = item.formItem?.label || item.field
  return returnData
}

// 递归找到对应的值
const findVal = (
  options: CascaderOption[],
  val: string | number,
  selectProps: CascaderProps,
  returnData: string[] = []
): string[] | undefined => {
  for (const item of options) {
    if (item[selectProps?.value || 'value'] === val) {
      returnData.push(item[selectProps?.label || 'label'] as string)
      return returnData
    }
    if (
      item[selectProps?.children || 'children'] &&
      (item[selectProps?.children || 'children'] as CascaderOption[])?.length
    ) {
      findVal(item.children!, val, selectProps, returnData)
    }
  }
  return returnData
}

//  判断是否存在默认值
const checkHasDefaultValue = () => {
  //  特殊对照key---可修改
  const keys: string[] = ['$rn', '$pg', '$rt', '$st', '$sn']
  hasDefaultValue.value = Object.keys(formData.value).some(key =>
    keys.includes(key)
  )
}

// 值变化调用
const change = () => {
  if (formEl.value) {
    formEl.value.validate(valid => {
      if (valid) {
        // 节流一下
        handleCondition()
        if (timeOut.value) clearTimeout(timeOut.value)
        timeOut.value = window.setTimeout(() => {
          emits('change')
        }, 300)
      }
    })
  } else {
    // 节流一下
    handleCondition()
    if (timeOut.value) clearTimeout(timeOut.value)
    timeOut.value = window.setTimeout(() => {
      emits('change')
    }, 300)
  }
}

const validate = (callBack?: () => void) => {
  formEl.value?.validate((valid: boolean) => {
    if (valid) {
      callBack && callBack()
    }
  })
}

// 表单重置
const resetFields = (callBack?: () => void) => {
  formEl.value && formEl.value.resetFields()
  const keys: string[] = ['$rt', '$st', '$sn']
  Object.keys(formData.value).forEach(key => {
    if (!keys.includes(key)) {
      if (key === '$pg') {
        formData.value[key] = 1
      } else if (key === '$rn') {
        formData.value[key] = 20
      } else {
        formData.value[key] = undefined
      }
    }
  })
  callBack && callBack()
}

// 选项label过滤
const optionValue = (val?: string | number | boolean | Record<string, any>) => {
  if (val === undefined) {
    return ''
  }
  return val
}

// 下拉框clear函数
const clearData = (field: string) => {
  formData.value[field] = undefined
}

// formItem类名，无法通过ref方式拿到组件的dom元素，只能用原生获取
const formItemClass = ref<string>('formItem-width-searchForm')
// 单行显示个数,默认5个，数值不要改，计算方法依靠初始的item宽度进行计算，因此初始化需要大一些
const singleLineDisplays = ref(5)
// 计算搜索表单屏幕一行显示几个
const computedSearchFormShowCount = () => {
  // 表单搜索，才计算
  if (props.type === 'search') {
    const formItemEl = document.getElementsByClassName(formItemClass.value)
    if (formItemEl && formItemEl.length) {
      // 内容区域宽度
      const contentWidth = window.innerWidth - 250
      // formItem的宽度
      let allItemWidth = 0
      let count = 0
      for (const index in formItemEl) {
        // 元素
        const el = formItemEl[index]
        if (typeof el === 'object') {
          const elStyle = getComputedStyle(el)
          let elWidth = Number(elStyle.width.replace(/px/, ''))
          const elMargin = Number(
            elStyle.margin.split(' ')[1].replace(/px/, '')
          )
          if (isNaN(elWidth)) {
            // NaN, 则取值5减去已有的，拿取平均值
            const newCount = 5 - count
            const newWidth = contentWidth - allItemWidth
            if (newWidth > 320) {
              elWidth = Math.ceil(newWidth / newCount)
            } else {
              break
            }
          }
          allItemWidth += elWidth + elMargin
          if (allItemWidth <= contentWidth) {
            count += 1
          }
        }
      }
      singleLineDisplays.value = count
    } else {
      // 默认显示5个
      singleLineDisplays.value = 5
    }
  }
}

// 计算右侧是否展开缩放图标是否显示
const isShowCollapseIcon = computed(() => {
  if (mainStore.searchSettingModel === 1) {
    // 默认不显示
    return props.list.length > 0
  } else if (mainStore.searchSettingModel === 2) {
    // 默认显示一行
    if (props.list.length > 0) {
      if (props.list.length > singleLineDisplays.value) {
        return true
      }
      return false
    }
    return false
  }
  // 默认显示全部
  return props.list.length > 0
})

// 统一控制搜索框展开/收起状态
const applySearchModel = (expanded: boolean) => {
  const model = mainStore.searchSettingModel
  if (model === 2) {
    // 默认显示一行：showSearchInput 始终为 true，show 控制是否展开
    showSearchInput.value = true
    show.value = expanded
  } else {
    // model=1（默认不显示）/ model=3（默认全部）：两者同步
    showSearchInput.value = expanded
    show.value = expanded
  }
}

// 点击展开图标的函数
const handleExpand = () => applySearchModel(true)

// 点击缩起图标
const handleCollapse = () => applySearchModel(false)

// 搜索框显示模式（初始化/切换模式时调用）
const handleSearchModel = () => {
  const model = mainStore.searchSettingModel
  if (model === 1) {
    // 默认不显示：只隐藏输入框，不重置 show
    showSearchInput.value = false
  } else {
    applySearchModel(model !== 2)
  }
}

// 搜索框展示模式
const searchModel = computed(() => mainStore.searchSettingModel)

//  解决切换语言，tag语言不切换的问题
const stopWatchLang = watchDebounced(
  () => mainStore.i18n,
  () => {
    nextTick(() => {
      handleConditionDomWidth()
      handleCondition()
    })
  },
  { debounce: 500, maxWait: 1000 }
)

// 解决状态值异步请求导致的label为数字的问题
const stopWatchList = watchDebounced(
  () => props.list,
  () => {
    handleCondition()
  },
  {
    deep: true,
    debounce: 500,
    maxWait: 1000
  }
)

// 监听搜索框展示模式，进行状态统一
const stopWatchModel = watchDebounced(
  () => searchModel.value,
  () => {
    handleSearchModel()
  },
  { debounce: 500, maxWait: 1000 }
)

// 解决手动改变值，label不同步的问题
// eg: 直接手动改变 state = 0, 而不是通过搜索项改变对应的值，就会出现此类问题
// 手动改值需自己在外部调用请求方法，此方法只做手动改变值，label不同步的问题，不做自动请求
const stopWatchFormValue = watchDebounced(
  () => {
    return {
      ...formData.value
    }
  },
  (val, oldVal) => {
    // 只监听表单搜索项有的才触发请求
    const needKeys = props.list.map(item => item.field)
    const newChangeVal: Record<string, any> = {}
    const oldChangeVal: Record<string, any> = {}
    needKeys.forEach(key => {
      newChangeVal[key] = val[key]
      oldChangeVal[key] = oldVal[key]
    })
    if (JSON.stringify(newChangeVal) !== JSON.stringify(oldChangeVal)) {
      if (formEl.value) {
        formEl.value.validate(valid => {
          if (valid) {
            handleCondition()
          }
        })
      } else {
        handleCondition()
      }
    }
  },
  {
    deep: true,
    debounce: 500,
    maxWait: 1000
  }
)

onMounted(() => {
  computedSearchFormShowCount()
  checkHasDefaultValue()
  // 修复初始化状态，无法同步的问题，导致label不显示，转入微任务中执行
  nextTick(() => {
    handleCondition()
    handleSearchModel()
    handleConditionDomWidth()
  })
})

onUnmounted(() => {
  stopWatchLang()
  stopWatchList()
  stopWatchModel()
  stopWatchFormValue()
  timeOut.value && clearTimeout(timeOut.value)
})

const tabScrollEl = ref<InstanceType<typeof ElScrollbar>>()
const conditionRightRef = ref<HTMLDivElement>()
const conditionRightWidth = ref(0)

// 表单Dom宽度
const handleConditionDomWidth = () => {
  if (conditionRightRef.value?.offsetWidth) {
    conditionRightWidth.value = conditionRightRef.value?.offsetWidth
  }
}

// 设置滚动功能实现
const handleScroll = () => {
  nextTick(() => {
    const scrollWidth = tabScrollEl.value?.wrapRef?.scrollWidth || 0
    if (scrollWidth > 0) {
      tabScrollEl.value &&
        tabScrollEl.value.scrollTo({
          left: scrollWidth,
          behavior: 'smooth'
        })
    }
  })
}

defineExpose({
  show,
  validate,
  resetFields
})
</script>

<template>
  <div
    v-if="props.type === 'search'"
    class="form-condition space-between flex-align margin-bottom-10 padding-left-15 padding-right-15"
    v-bind="$attrs"
  >
    <div
      class="form-condition__left flex-align"
      :style="{ 'max-width': `calc(100% - ${conditionRightWidth}px)` }"
    >
      <span class="form-condition__label">
        {{ $t('search') + $t('condition') }}:
      </span>
      <el-scrollbar ref="tabScrollEl">
        <TransitionGroup name="slide">
          <el-tag
            v-for="tag in tagList"
            :key="tag.name"
            class="margin-left-10"
            closable
            :disable-transitions="true"
            @close="closeTag(tag)"
          >
            {{ tag.name }}: {{ tag.label || tag.value }}
          </el-tag>
        </TransitionGroup>
      </el-scrollbar>
      <el-button
        class="margin-left-10"
        type="primary"
        size="small"
        round
        :loading="props.bntLoading"
        :icon="Search"
        @click="clickSearch"
      >
        {{ $t('search') }}
      </el-button>
      <slot name="left"></slot>
    </div>
    <div
      ref="conditionRightRef"
      class="form-condition__right flex-align"
    >
      <!-- 右侧 插槽 -->
      <slot name="right"></slot>
      <div
        v-if="isShowCollapseIcon"
        class="form-show cursor-p"
      >
        <Transition name="show-fade">
          <div
            class="flex-align"
            v-if="showSearchInput && show"
            @click="handleCollapse"
          >
            <el-icon>
              <ArrowUp />
            </el-icon>
            <span class="form-show__btn">
              {{ $t('packUpScreenCondition') }}
            </span>
          </div>
          <div
            class="flex-align"
            v-else
            @click="handleExpand"
          >
            <el-icon>
              <ArrowDown />
            </el-icon>
            <span class="form-show__btn">
              {{ $t('expandScreenCondition') }}
            </span>
          </div>
        </Transition>
      </div>
    </div>
  </div>
  <el-form
    ref="formEl"
    v-bind="props.formAttributes"
    :model="formData"
    :rules="props.rules"
    v-show="showSearchInput || type === 'form'"
  >
    <slot name="showInfoTitle"></slot>
    <slot name="formContentTitle"></slot>
    <TransitionGroup name="el-fade-in">
      <template
        v-for="(item, index) in filterList"
        :key="index"
      >
        <el-form-item
          v-bind="item.formItem"
          :prop="item.field"
          :style="{
            width:
              typeof item.formItemWidth === 'number'
                ? item.formItemWidth + 'px'
                : item.formItemWidth
          }"
          v-show="typeof item.isShow === 'undefined' ? true : item.isShow"
          :class="formItemClass"
        >
          <template v-if="item.componentType === 'radio'">
            <el-radio-group
              v-model="formData[item.field]"
              v-bind="item.expand ? item.expand : ''"
              @change="val => (change(), item.change && item.change(val))"
            >
              <el-radio
                v-for="radio in item.options"
                :key="radio.value"
                :label="radio.label"
                :value="radio.value"
              ></el-radio>
            </el-radio-group>
          </template>
          <template v-else-if="item.componentType === 'select'">
            <el-select
              v-model="formData[item.field]"
              v-bind="item.expand ? item.expand : ''"
              :placeholder="item.placeholder"
              @change="val => (change(), item.change && item.change(val))"
              :clearable="item.clearable"
              :style="{
                width: item.componentWidth
                  ? typeof item.componentWidth === 'number'
                    ? item.componentWidth + 'px'
                    : item.componentWidth
                  : '100%'
              }"
              :disabled="item.disabled"
              @clear="() => clearData(item.field)"
            >
              <el-option
                v-for="(option, index) in item.options"
                :key="`${index}-${option.value}`"
                :label="option.label"
                :value="optionValue(option.value)"
              />
            </el-select>
          </template>
          <template v-else-if="item.componentType === 'selectv2'">
            <el-select-v2
              v-model="formData[item.field]"
              :options="item.options as OptionType[]"
              :placeholder="item.placeholder"
              :style="{
                width: item.componentWidth
                  ? typeof item.componentWidth === 'number'
                    ? item.componentWidth + 'px'
                    : item.componentWidth
                  : '100%'
              }"
              @change="val => (change(), item.change && item.change(val))"
              :clearable="item.clearable"
              v-bind="item.expand ? item.expand : ''"
              :disabled="item.disabled"
              @clear="() => clearData(item.field)"
            />
          </template>
          <template v-else-if="item.componentType === 'datePicker'">
            <el-date-picker
              v-model="formData[item.field]"
              v-bind="item.expand ? item.expand : ''"
              :readonly="item.readonly"
              :disabled="item.disabled"
              :placeholder="item.placeholder"
              :startPlaceholder="item.startPlaceholder"
              :endPlaceholder="item.endPlaceholder"
              :clearable="item.clearable"
              :type="item.type as any"
              :format="item.format"
              :value-format="item.valueFormat"
              :default-time="item.defaultTime"
              @change="
                (val: any) => (change(), item.change && item.change(val))
              "
              :style="{
                width: item.componentWidth
                  ? typeof item.componentWidth === 'number'
                    ? item.componentWidth + 'px'
                    : item.componentWidth
                  : '100%'
              }"
              @clear="() => clearData(item.field)"
            />
          </template>
          <template v-else-if="item.componentType === 'input'">
            <el-input
              v-model.trim="formData[item.field]"
              v-bind="item.expand ? item.expand : ''"
              :type="item.type"
              :placeholder="item.placeholder"
              :clearable="item.clearable"
              :show-password="item.showPassword"
              :disabled="item.disabled"
              :readonly="item.readonly"
              @input="val => (change(), item.change && item.change(val))"
              :style="{
                width: item.componentWidth
                  ? typeof item.componentWidth === 'number'
                    ? item.componentWidth + 'px'
                    : item.componentWidth
                  : '100%'
              }"
              @clear="() => clearData(item.field)"
            />
          </template>
          <template v-else-if="item.componentType === 'inputNumber'">
            <el-input-number
              v-model="formData[item.field]"
              v-bind="item.expand ? item.expand : ''"
              :placeholder="item.placeholder"
              :disabled="item.disabled"
              :readonly="item.readonly"
              @change="val => (change(), item.change && item.change(val))"
              :style="{
                width: item.componentWidth
                  ? typeof item.componentWidth === 'number'
                    ? item.componentWidth + 'px'
                    : item.componentWidth
                  : '100%'
              }"
              @clear="() => clearData(item.field)"
            />
          </template>
          <template v-else-if="item.componentType === 'selectAndDatePicker'">
            <!-- 下拉选择、时间选择组合 -->
            <div class="space-between">
              <el-select
                v-model="formData[item.combinationField as string]"
                v-bind="item.expand ? item.expand : ''"
                @change="val => (change(), item.change && item.change(val))"
                :style="{
                  width:
                    typeof item.combinationWidth === 'number'
                      ? item.combinationWidth + 'px'
                      : item.combinationWidth
                }"
                :multiple="false"
              >
                <el-option
                  v-for="option in item.combinationOptions"
                  :key="option.value"
                  :label="option.label"
                  :value="optionValue(option.value)"
                />
              </el-select>
              <el-date-picker
                v-model="formData[item.field]"
                v-bind="item.expand ? item.expand : ''"
                :readonly="item.readonly"
                :disabled="item.disabled"
                :placeholder="item.placeholder"
                :startPlaceholder="item.startPlaceholder"
                :endPlaceholder="item.endPlaceholder"
                :clearable="item.clearable"
                :type="item.type as any"
                :format="item.format"
                :value-format="item.valueFormat"
                :default-time="item.defaultTime"
                @change="
                  (val: any) => (change(), item.change && item.change(val))
                "
                :style="{
                  width:
                    typeof item.componentWidth === 'number'
                      ? item.componentWidth + 'px'
                      : item.componentWidth
                }"
              />
            </div>
          </template>
          <template v-else-if="item.componentType === 'cascader'">
            <el-cascader
              v-model="formData[item.field]"
              :options="item.cascaderOptions"
              @change="val => (change(), item.change && item.change(val))"
              :disabled="item.disabled"
              :clearable="item.clearable"
              :placeholder="item.placeholder"
              v-bind="item.expand ? item.expand : ''"
              :style="{
                width: item.componentWidth
                  ? typeof item.componentWidth === 'number'
                    ? item.componentWidth + 'px'
                    : item.componentWidth
                  : '100%'
              }"
              @clear="() => (clearData(item.field), change())"
              ref="cascaderRef"
            />
            <!-- 这里的地区组件clear之后不会触发change事件，手动调用 -->
          </template>
          <template v-else-if="item.componentType === 'inputNumberRange'">
            <InputNumberRange
              v-model.trim="formData[item.field]"
              v-bind="item.expand ? item.expand : ''"
              :disabled="item.disabled"
              :readonly="item.readonly"
              :startPlaceholder="item.startPlaceholder"
              :endPlaceholder="item.endPlaceholder"
              @change="val => (change(), item.change && item.change(val))"
              :style="{
                width:
                  typeof item.componentWidth === 'number'
                    ? item.componentWidth + 'px'
                    : item.componentWidth
              }"
            />
          </template>
          <template v-else-if="item.componentType === 'timePicker'">
            <el-time-picker
              v-model.trim="formData[item.field]"
              v-bind="item.expand ? item.expand : ''"
              :disabled="item.disabled"
              :readonly="item.readonly"
              :clearable="item.clearable"
              :format="item.format"
              :value-format="item.valueFormat"
              :startPlaceholder="item.startPlaceholder"
              :endPlaceholder="item.endPlaceholder"
              @change="
                (val: any) => (change(), item.change && item.change(val))
              "
              :style="{
                width: item.componentWidth
                  ? typeof item.componentWidth === 'number'
                    ? item.componentWidth + 'px'
                    : item.componentWidth
                  : '100%'
              }"
            />
          </template>
        </el-form-item>
        <div v-if="item.br"></div>
      </template>
    </TransitionGroup>
    <!-- 默认插槽 -->
    <slot></slot>
  </el-form>
</template>

<style lang="scss" scoped>
.slide-move,
/* 对移动中的元素应用的过渡 */
.slide-enter-active,
.slide-leave-active {
  transition: all 0.5s ease;
}

.slide-enter-from,
.slide-leave-to {
  opacity: 0;
  transform: translateX(30px);
}

.slide-leave-active {
  position: absolute;
}

/* 1. 声明过渡效果 */
.fade-move,
.fade-enter-active,
.fade-leave-active {
  transition: all 0.3s ease;
}

/* 2. 声明进入和离开的状态 */
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: scaleY(0.01);
}

/* 1. 声明过渡效果 */
.show-fade-move,
.show-fade-enter-active,
.show-fade-leave-active {
  transition: all 0.3s ease;
}

.show-fade-enter-from {
  opacity: 0;
  transform: translateY(-34px);
}

.show-fade-leave-to {
  opacity: 0;
  transform: translate(34px);
}

.show-fade-leave-active {
  position: absolute;
}

.form-condition {
  width: 100%;
  height: 40px;
  border: 1px solid var(--el-border-color-light);
  border-radius: 20px;
  box-sizing: border-box;

  .form-condition__left {
    :deep(.el-scrollbar) {
      // 控制el-tag不换行
      .el-scrollbar__view {
        display: flex;
        align-items: center;
      }
    }
  }
  // .form-condition__right {}

  .form-condition__label {
    font-size: 14px;
    color: #999;
    flex-shrink: 0;
  }

  .form-show {
    position: relative;
    display: inline-flex;
    align-items: center;
    vertical-align: middle;
    font-size: 14px;
    color: var(--el-color-primary);
    margin-left: 10px;
    .form-show__btn {
      display: flex;
      flex-shrink: 0;
    }
  }
}
</style>
