<script lang="ts" setup>
import * as echarts from 'echarts'

export type EChartsOption = echarts.EChartsCoreOption

const props = withDefaults(
  defineProps<{
    width?: number | string
    height?: number | string
    options: EChartsOption
    onMouseOverEvent?: boolean
    onMouseOutEvent?: boolean
    isAutoShowTooltip?: boolean
  }>(),
  {
    width: '100%',
    height: '100%',
    onMouseOverEvent: false,
    onMouseOutEvent: false,
    isShowTooltip: false
  }
)
const emits = defineEmits<{
  (e: 'mouseOverFn', value: echarts.ECElementEvent): void
  (e: 'mouseOutFn', value: echarts.ECElementEvent): void
}>()

const myChart = ref<echarts.ECharts>()
const chartEl = ref<HTMLElement>()
const time = ref(0)

const width = computed(() => {
  if (typeof props.width === 'number') return props.width + 'px'
  return props.width
})

const height = computed(() => {
  if (typeof props.height === 'number') return props.height + 'px'
  return props.height
})

watch(
  () => props.options,
  newData => {
    if (myChart.value) {
      myChart.value.setOption(newData)
    }
  },
  {
    deep: true
  }
)

const resizeObserver = new ResizeObserver(() => {
  if (time.value) clearTimeout(time.value)
  time.value = setTimeout(() => {
    if (chartEl.value) {
      myChart.value?.resize()
    }
  }, 200)
})

const chartWrapper = ref<HTMLDivElement>()
const chartWrapperMouseOver = () => {
  myChart.value &&
    myChart.value?.dispatchAction({
      type: 'showTip',
      seriesIndex: 0,
      dataIndex: 0
    })
}
const chartWrapperMouseLeave = () => {
  myChart.value &&
    myChart.value?.dispatchAction({
      type: 'hideTip'
    })
}

onMounted(() => {
  if (chartEl.value) {
    resizeObserver.observe(chartEl.value)
    myChart.value = markRaw(echarts.init(chartEl.value))
    myChart.value.setOption(props.options)
    //  是否需要监听mouseOver
    if (props.onMouseOverEvent || props.isAutoShowTooltip) {
      myChart.value.on('mouseover', params => {
        if (props.onMouseOverEvent) {
          emits('mouseOverFn', params)
        }
      })
    }
    //  是否监听mouseOut
    if (props.onMouseOutEvent || props.isAutoShowTooltip) {
      myChart.value.on('mouseout', params => {
        if (props.onMouseOutEvent) {
          emits('mouseOutFn', params)
        }
      })
    }
  }
  if (chartWrapper.value && props.isAutoShowTooltip) {
    chartWrapper.value.addEventListener('mousemove', chartWrapperMouseOver)
    chartWrapper.value.addEventListener('mouseout', chartWrapperMouseLeave)
  }
})

onUnmounted(() => {
  if (props.onMouseOverEvent) {
    myChart.value?.off('mouseover')
  }
  if (props.onMouseOutEvent) {
    myChart.value?.off('mouseout')
  }
  if (chartWrapper.value && props.isAutoShowTooltip) {
    chartWrapper.value.removeEventListener('mousemove', chartWrapperMouseOver)
    chartWrapper.value.removeEventListener('mouseout', chartWrapperMouseLeave)
  }
})
</script>

<template>
  <div ref="chartWrapper">
    <div
      class="chart"
      ref="chartEl"
    ></div>
  </div>
</template>

<style lang="scss" scoped>
.chart {
  position: relative;
  width: v-bind(width);
  height: v-bind(height);
}
</style>
