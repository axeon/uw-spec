<script lang="ts" setup>
import * as ElementPlusIconsVue from '@element-plus/icons-vue'

const props = withDefaults(
  defineProps<{
    iconName: string
    size?: number | string
  }>(),
  {
    iconName: '',
    size: 14
  }
)

const render = () => {
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  const icon = ElementPlusIconsVue[props.iconName]
  if (icon) {
    return h(icon)
  }
  return h('i', {
    class: ['iconfont', props.iconName],
    style: {
      'font-size':
        typeof props.size === 'number' ? props.size + 'px' : props.size
    }
  })
}
</script>

<template>
  <div class="menu-icon__box">
    <el-icon :size="size">
      <render></render>
    </el-icon>
  </div>
</template>

<style lang="scss" scoped>
.menu-icon__box {
  flex-shrink: 0;
  display: inline-flex;
  width: 50px;
  height: 100%;
  align-items: center;
  justify-content: center;
}
</style>
