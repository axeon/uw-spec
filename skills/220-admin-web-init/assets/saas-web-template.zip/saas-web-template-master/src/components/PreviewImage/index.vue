<template>
  <div class="demo-image__preview">
    <el-image-viewer
      v-if="isShow"
      :initial-index="initialIndex"
      infinite
      hide-on-click-modal
      @close="isShow = false"
      :url-list="srcList.data"
      :teleported="true"
    />
  </div>
</template>

<script setup lang="ts">
/**
 * url: 图片路径，string或数组  必传
 * show: v-model:show='xxx' 控制是否显示 必传
 * 预览图片
 */

interface srcListType {
  data: Array<string>
}

const props = withDefaults(
  defineProps<{
    url?: string | Array<string>
    show: boolean
    initialIndex?: number
  }>(),
  {
    initialIndex: 0
  }
)
const emits = defineEmits(['update:show'])
const isShow = computed({
  get() {
    return props.show
  },
  set(val) {
    emits('update:show', val)
  }
})

const srcList = reactive<srcListType>({
  data: []
})

watch(
  () => props.url,
  val => {
    if (typeof val === 'string') {
      srcList.data = [val]
    }
    if (Array.isArray(val) && val.length) {
      srcList.data = [...val]
    }
  },
  {
    immediate: true
  }
)
</script>

<style scoped lang="scss">
.demo-image__error .image-slot {
  font-size: 30px;
}

.demo-image__error .image-slot .el-icon {
  font-size: 30px;
}

.demo-image__error .el-image {
  width: 95%;
  height: 200px;
}
</style>
