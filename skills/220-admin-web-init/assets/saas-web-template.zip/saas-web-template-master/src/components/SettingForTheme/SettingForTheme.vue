<script lang="ts" setup>
import { Sunny, Moon, Check } from '@element-plus/icons-vue'
import { useMainStore } from '@/store/main'
import { setCssVar } from '@/utils/tool'
import { useI18n } from 'vue-i18n'
import { useCustomDark } from '@/hooks/useCustomDark'

const { t } = useI18n()
const mainStore = useMainStore()
const props = withDefaults(
  defineProps<{
    showValue: boolean
  }>(),
  {
    showValue: false
  }
)

const emits = defineEmits<{
  (e: 'update:showValue', showValue: boolean): void
}>()

const showDrawer = computed({
  get() {
    return props.showValue
  },
  set(val) {
    emits('update:showValue', val)
  }
})

//  暗夜模式切换
const themeValue = ref(false)
const isDark = useCustomDark()
const toggleDark = useToggle(isDark)
const handleChange = () => {
  toggleDark()
}

//  当前系统主题色
const colorVal = computed(() => {
  return mainStore.systemThemeColors
})
//  系统颜色值
const schema = shallowRef([
  '#409eff',
  '#009688',
  '#536DFE',
  '#FF5C93',
  '#EE4F12',
  '#0096C7',
  '#9C27B0',
  '#FF9800'
])
//  切换颜色
const handleChangeColor = (color: string) => {
  setCssVar('--el-color-primary', color)
  mainStore.setSystemThemeColors(color)
}

//  系统颜色值
const schemaSlideMenu = shallowRef([
  '#001529',
  '#222222',
  '#016259',
  '#0f467f',
  '#2a377f',
  '#802e49',
  '#77280b',
  '#0c4b64'
])

//  当前侧边栏主题色
const slideMenuColor = computed(() => {
  return mainStore.slideMenuColor
})

// 切换颜色 slideMenu
const handleChangeColorForSlideMenu = (color: string) => {
  setCssVar('--el-slide-menu-background', color)
  mainStore.setSlideMenuColor(color)
}

//  是否首次加载
const isFirstLoad = ref(true)
//  监听
watch(
  () => isDark.value,
  val => {
    if (val) {
      // 是暗色模式
      themeValue.value = true
      mainStore.setSystemDark(true)
      // 还要做主题适配
      handleChangeColorForSlideMenu('#222222')
      setCssVar('--el-header-tab-background', 'transparent')
      setCssVar('--el-main-container-background', '#393A3C')
      setCssVar('--el-expand-table-border-bottom-color', '#414243')
    } else {
      // 不是暗色模式
      themeValue.value = false
      mainStore.setSystemDark(false)
      if (!isFirstLoad.value) {
        // 还要做主题适配, 返回默认的主题
        handleChangeColor('#409eff')
        handleChangeColorForSlideMenu('#001529')
        setCssVar('--el-header-tab-background', '#ffffff')
        setCssVar('--el-main-container-background', '#f2f3f5')
        setCssVar('--el-expand-table-border-bottom-color', '#F0F2F5')
      }
    }
  },
  {
    immediate: true
  }
)

// 搜索栏设置
const searchSetting = computed({
  get() {
    return mainStore.searchSettingModel
  },
  set(val) {
    mainStore.setSearchSettingModel(val)
  }
})

// 页签是否显示
const isShowTabPag = computed({
  get() {
    return mainStore.showPaTab
  },
  set(val) {
    mainStore.setShowTabPage(val)
  }
})

// 布局
const layoutMode = computed(() => {
  return mainStore.layoutMode
})

// 切换布局
const handleChangeLayoutMode = (mode: 'default' | 'vertical' | 'slide') => {
  mainStore.setLayoutMode(mode)
}

onMounted(() => {
  isFirstLoad.value = false
  handleChangeColor(colorVal.value)
  handleChangeColorForSlideMenu(slideMenuColor.value)
})
</script>

<template>
  <div class="draw-wrapper">
    <el-drawer
      v-model="showDrawer"
      :size="410"
    >
      <template #header>
        <span style="color: var(--el-text-color-primary); font-weight: 500">
          {{ t('personalizationSetting') }}
        </span>
      </template>
      <el-divider
        content-position="center"
        style="color: var(--el-text-color-primary)"
      >
        {{ t('theme') }}
      </el-divider>
      <div class="theme-wrapper margin-bottom-40">
        <el-switch
          v-model="themeValue"
          active-color="black"
          inactive-color="black"
          :active-icon="Sunny"
          :inactive-icon="Moon"
          inline-prompt
          @change="handleChange"
        />
      </div>
      <el-divider
        content-position="center"
        style="color: var(--el-text-color-primary)"
      >
        {{ t('layout') }}
      </el-divider>
      <div class="space-around layout-icon-wrapper">
        <div
          class="layout-default layout-icon"
          :class="{ active: layoutMode === 'default' }"
          @click="handleChangeLayoutMode('default')"
        ></div>
        <div
          class="layout-vertical layout-icon"
          :class="{ active: layoutMode === 'vertical' }"
          @click="handleChangeLayoutMode('vertical')"
        ></div>
        <div
          class="layout-slide layout-icon"
          :class="{ active: layoutMode === 'slide' }"
          @click="handleChangeLayoutMode('slide')"
        ></div>
      </div>
      <el-divider
        content-position="center"
        style="color: var(--el-text-color-primary)"
      >
        {{ t('systemTheme') }}
      </el-divider>
      <div class="color-picker-wrapper margin-bottom-40">
        <span
          v-for="(item, i) in schema"
          :key="`radio-${i}`"
          :class="{ 'is-active': colorVal === item }"
          :style="{
            background: item
          }"
          class="colorPicker"
          @click="handleChangeColor(item)"
        >
          <el-icon
            v-if="colorVal === item"
            :size="16"
            color="#fff"
          >
            <Check />
          </el-icon>
        </span>
      </div>
      <el-divider
        content-position="center"
        style="color: var(--el-text-color-primary)"
      >
        {{ t('slideMenuTheme') }}
      </el-divider>
      <div class="color-picker-wrapper margin-bottom-40">
        <span
          v-for="(item, i) in schemaSlideMenu"
          :key="`radio-${i}`"
          :class="{ 'is-active': slideMenuColor === item }"
          :style="{
            background: item
          }"
          class="colorPicker"
          @click="handleChangeColorForSlideMenu(item)"
        >
          <el-icon
            v-if="slideMenuColor === item"
            :size="16"
            color="#fff"
          >
            <Check />
          </el-icon>
        </span>
      </div>

      <!-- 搜索栏设置 -->
      <el-divider
        content-position="center"
        style="color: var(--el-text-color-primary)"
      >
        {{ t('searchSetting') }}
      </el-divider>
      <div class="searchSetting-wrapper margin-bottom-40 flex-center">
        <el-radio-group v-model="searchSetting">
          <el-radio-button :value="1">默认不显示</el-radio-button>
          <el-radio-button :value="2">默认显示一行</el-radio-button>
          <el-radio-button :value="3">默认显示全部</el-radio-button>
        </el-radio-group>
      </div>
      <!-- 界面设置 -->
      <el-divider
        content-position="center"
        style="color: var(--el-text-color-primary)"
      >
        界面设置
      </el-divider>
      <div class="space-between">
        <div class="title">页签显示</div>
        <div>
          <el-switch
            v-model="isShowTabPag"
            inline-prompt
            active-icon="Check"
            inactive-icon="Close"
          />
        </div>
      </div>
    </el-drawer>
  </div>
</template>

<style lang="scss" scoped>
.draw-wrapper {
  .theme-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;

    :deep(.el-icon) {
      color: rgb(253, 224, 71);
      font-size: 16px;
    }
  }

  .color-picker-wrapper {
    display: flex;
    justify-content: space-around;

    .colorPicker {
      display: inline-block;
      width: 20px;
      height: 20px;
      cursor: pointer;
      border-radius: 2px;
      border: 2px solid rgba(128, 128, 128, 0.3);
      text-align: center;
    }
  }
  .title {
    font-size: 14px;
  }
  .layout-icon-wrapper {
    width: 100%;
    .layout-icon {
      width: 56px;
      height: 48px;
      background: #dcdfe6;
      border-radius: 4px;
      cursor: pointer;
      border: 2px solid #cdd0d6;
    }
    .active {
      border-color: var(--el-color-primary);
    }
    .layout-vertical {
      position: relative;
      &::after {
        position: absolute;
        content: '';
        top: 0;
        left: 0;
        z-index: 1;
        width: 56px;
        height: 14px;
        background: #273352;
        border-radius: 4px 4px 0 0;
        box-sizing: border-box;
      }
    }
    .layout-default {
      position: relative;
      &::after {
        position: absolute;
        content: '';
        top: 0;
        left: 0;
        z-index: 2;
        width: 56px;
        height: 14px;
        background: #273352;
        border-radius: 4px 4px 0 0;
        box-sizing: border-box;
      }
      &::before {
        position: absolute;
        content: '';
        top: 14px;
        left: 0;
        z-index: 1;
        width: 16px;
        height: 34px;
        background: #fff;
        border-radius: 4px 0 0 4px;
        box-sizing: border-box;
      }
    }

    .layout-slide {
      position: relative;
      &::after {
        position: absolute;
        content: '';
        top: 0;
        left: 0;
        z-index: 2;
        width: 14px;
        height: 48px;
        background: #273352;
        border-radius: 4px 0 0 4px;
        box-sizing: border-box;
      }
      &::before {
        position: absolute;
        content: '';
        top: 0;
        left: 14px;
        z-index: 1;
        width: 42px;
        height: 12px;
        background: #fff;
        border-radius: 0 4px 4px 0;
        box-sizing: border-box;
      }
    }
  }
}
</style>
