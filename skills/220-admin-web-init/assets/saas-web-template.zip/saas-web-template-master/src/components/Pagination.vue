<script lang="ts" setup>
const props = withDefaults(
  defineProps<{
    pageSize: number // 页数
    currentPage: number // 条数
    total: number // 总数
  }>(),
  {
    pageSize: 0,
    currentPage: 1,
    total: 0
  }
)

const emits = defineEmits<{
  (e: 'current-change', value: number): void
  (e: 'update:currentPage', value: number): void
  (e: 'update:pageSize', value: number): void
  (e: 'pageSizeChange', val: number): void
}>()

// 页数
const currentPage = computed({
  get: () => {
    return props.currentPage
  },
  set: (val: number) => {
    emits('update:currentPage', val)
  }
})

// 页数变化
const currentChange = (val: number) => {
  emits('current-change', val)
}

// 条数
const currentSize = computed({
  get: () => {
    return props.pageSize
  },
  set: (val: number) => {
    emits('update:pageSize', val)
  }
})

// 条数变换
const pageSizeChange = (val: number) => {
  emits('pageSizeChange', val)
}
</script>

<template>
  <el-pagination
    class="flex-end padding-top-20"
    background
    v-model:currentPage="currentPage"
    v-model:page-size="currentSize"
    layout="total, sizes, prev, pager, next, jumper"
    :total="props.total"
    @current-change="currentChange"
    :page-sizes="[10, 20, 30, 40, 50]"
    @update:page-size="pageSizeChange"
  />
</template>
