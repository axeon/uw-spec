<script setup lang="ts">
import { FormInstance } from 'element-plus'

//   'string' |
//   'text' |
//   'set<string>' |
//   'int' |
//   'set<int>' |
//   'long' |
//   'boolean' |
//   'float' |
//   'set<float>' |
//   'double' |
//   'set<double>' |
//   'date' |
//   'set<date>' |
//   'time' |
//   'set<time>' |
//   'datetime' |
//   'set<datetime>' |
//   'enum' |
//   'set<enum>' |
//   'map'
interface configListType {
  key: string
  value: string | string[] | number
  desc: string
  name?: string
  regex?: RegExp | null
  type: string
  options?: Array<{
    label: string
    value: string
  }>
}

const props = withDefaults(
  defineProps<{
    modelValue: configListType[] // 配置列表
  }>(),
  {}
)

const emits = defineEmits<{
  (e: 'update:modelValue', val: configListType[]): void
}>()

// 配置列表
const configTableList = computed({
  get() {
    return props.modelValue
  },
  set(val) {
    emits('update:modelValue', val)
  }
})

// 点击删除
const handleDelete = (row: configListType) => {
  const index = configTableList.value.findIndex(item => item.key === row.key)
  if (index > -1) {
    configTableList.value.splice(index, 1)
  }
}

// 用于校验
const formRef = ref<FormInstance>()
const formData = ref({})

// 通用校验
const commonValidate = (rule: any, value: string, callback: any) => {
  const index = rule.field.split('-')[1]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    callback()
  } else {
    callback(new Error('请输入'))
  }
}

// 参数默认值
const commonValidateValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const target = configTableList.value[index]
  if (target.regex && target?.value) {
    let regex = target.regex
    // @ts-expect-error
    const firstReg = regex[0] === '/'
    // @ts-expect-error
    const lastReg = regex[target.regex.length - 1] === '/'
    if (firstReg && lastReg) {
      // @ts-expect-error
      regex = regex.substring(1, target.regex.length - 1)
    }
    const reg = new RegExp(regex)
    if (reg.test(target.value as string)) {
      callback()
    } else {
      callback(new Error('自定义校验不通过'))
    }
  } else {
    callback()
  }
}

// 参数默认值--数组形式
const commonValidateValueByArray = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target?.regex) {
    let regex = target.regex
    // @ts-expect-error
    const firstReg = regex[0] === '/'
    // @ts-expect-error
    const lastReg = regex[target.regex.length - 1] === '/'
    if (firstReg && lastReg) {
      // @ts-expect-error
      regex = regex.substring(1, target.regex.length - 1)
    }
    const reg = new RegExp(regex)
    const targetArray = target[field as keyof configListType] as string[]
    const isRight = targetArray.every(item => reg.test(item))
    if (isRight) {
      callback()
    } else {
      callback(new Error('自定义校验不通过'))
    }
  } else {
    callback()
  }
}

// 校验整数正则
const validateIntValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    if (/^-?\d+$/.test(target[field as keyof configListType] as string)) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        if (reg.test(target[field as keyof configListType] as string)) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入整数'))
    }
  } else {
    callback()
  }
}

// 校验long类型正则
const validateLongValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    if (
      /^[+-]?(0|[1-9]\d*)$/.test(
        target[field as keyof configListType] as string
      )
    ) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        if (reg.test(target[field as keyof configListType] as string)) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入long类型'))
    }
  } else {
    callback()
  }
}

// 校验double类型正则
const validateDoubleValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    if (
      /^[+-]?\d*\.?\d+$/.test(target[field as keyof configListType] as string)
    ) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        if (reg.test(target[field as keyof configListType] as string)) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入double类型'))
    }
  } else {
    callback()
  }
}

// 校验float类型正则
const validateFloatValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    if (
      /^[+-]?\d*\.?\d+$/.test(target[field as keyof configListType] as string)
    ) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        if (reg.test(target[field as keyof configListType] as string)) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入float类型'))
    }
  } else {
    callback()
  }
}

// 校验整数正则
const validateIntArrayValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (
    target[field as keyof configListType] &&
    Array.isArray(target[field as keyof configListType])
  ) {
    const isRight = (target[field as keyof configListType] as string[]).every(
      item => /^[0-9]*$/.test(item)
    )
    if (isRight) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        const customValidate = (
          target[field as keyof configListType] as string[]
        ).every(item => reg.test(item))
        if (customValidate) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入整数'))
    }
  } else {
    callback()
  }
}

// 校验double类型正则
const validateDoubleArrayValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (
    target[field as keyof configListType] &&
    Array.isArray(target[field as keyof configListType])
  ) {
    const isRight = (target[field as keyof configListType] as string[]).every(
      item => /^[+-]?\d*\.?\d+$/.test(item)
    )
    if (isRight) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        const customValidate = (
          target[field as keyof configListType] as string[]
        ).every(item => reg.test(item))
        if (customValidate) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入double类型'))
    }
  } else {
    callback()
  }
}

// 校验float类型正则
const validateFloatArrayValue = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (
    target[field as keyof configListType] &&
    Array.isArray(target[field as keyof configListType])
  ) {
    const isRight = (target[field as keyof configListType] as string[]).every(
      item => /^[+-]?\d*\.?\d+$/.test(item)
    )
    if (isRight) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        const customValidate = (
          target[field as keyof configListType] as string[]
        ).every(item => reg.test(item))
        if (customValidate) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('请输入float类型'))
    }
  } else {
    callback()
  }
}

const validateEnum = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    // 枚举值可以只填写一个或多个
    if (!(target[field as keyof configListType] as string)?.includes(',')) {
      // 如果存在一个的情况，则只是字符串就行
      callback()
    } else {
      // 多个的情况
      if (
        /^[^,]+(,[^,]+){2}$/.test(
          target[field as keyof configListType] as string
        )
      ) {
        if (target.regex) {
          let regex = target.regex
          // @ts-expect-error
          const firstReg = regex[0] === '/'
          // @ts-expect-error
          const lastReg = regex[target.regex.length - 1] === '/'
          if (firstReg && lastReg) {
            // @ts-expect-error
            regex = regex.substring(1, target.regex.length - 1)
          }
          const reg = new RegExp(regex)
          if (reg.test(target[field as keyof configListType] as string)) {
            callback()
          } else {
            callback(new Error('自定义校验不通过'))
          }
        } else {
          callback()
        }
      } else {
        callback(new Error('格式错误，请输入： xxx,xxx,xxx 格式的值'))
      }
    }
  } else {
    callback()
  }
}

const validateEnumByArray = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (
    target[field as keyof configListType] &&
    Array.isArray(target[field as keyof configListType])
  ) {
    const isRight = (target[field as keyof configListType] as string[]).every(
      item => /^[^,]+(,[^,]+){2}$/.test(item)
    )
    if (isRight) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        const customValidate = (
          target[field as keyof configListType] as string[]
        ).every(item => reg.test(item))
        if (customValidate) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(new Error('格式错误，请输入： xxx,xxx,xxx 格式的值'))
    }
  } else {
    callback()
  }
}

const validateMap = (rule: any, value: any, callback: any) => {
  const index = rule.field.split('-')[2]
  const field = rule.field.split('-')[0]
  const target = configTableList.value[index]
  if (target[field as keyof configListType]) {
    if (
      /^\s*\{\s*('[^']*'|"[^"]*"|\w+)\s*:\s*('[^']*'|"[^"]*"|\d+)\s*(,\s*('[^']*'|"[^"]*"|\w+)\s*:\s*('[^']*'|"[^"]*"|\d+)\s*)*\}\s*$/.test(
        target[field as keyof configListType] as string
      )
    ) {
      if (target.regex) {
        let regex = target.regex
        // @ts-expect-error
        const firstReg = regex[0] === '/'
        // @ts-expect-error
        const lastReg = regex[target.regex.length - 1] === '/'
        if (firstReg && lastReg) {
          // @ts-expect-error
          regex = regex.substring(1, target.regex.length - 1)
        }
        const reg = new RegExp(regex)
        if (reg.test(target[field as keyof configListType] as string)) {
          callback()
        } else {
          callback(new Error('自定义校验不通过'))
        }
      } else {
        callback()
      }
    } else {
      callback(
        new Error('格式错误，请输入： {"xxx": "xxx", "xxx": "xxx"} 格式的值')
      )
    }
  } else {
    callback()
  }
}

// 参数
const typeOptions = computed(() => [
  {
    label: '字符串',
    value: 'string'
  },
  {
    label: '字符串数组',
    value: 'set<string>'
  },
  {
    label: '文本',
    value: 'text'
  },
  {
    label: '富文本',
    value: 'textRich'
  },
  {
    label: '整数',
    value: 'int'
  },
  {
    label: '整数数组',
    value: 'set<int>'
  },
  {
    label: '长整型',
    value: 'long'
  },
  {
    label: '布尔',
    value: 'boolean'
  },
  {
    label: '浮点数',
    value: 'float'
  },
  {
    label: '浮点数数组',
    value: 'set<float>'
  },
  {
    label: '双精度',
    value: 'double'
  },
  {
    label: '双精度数组',
    value: 'set<double>'
  },
  {
    label: '日期',
    value: 'date'
  },
  {
    label: '日期范围',
    value: 'set<date>'
  },
  {
    label: '时间',
    value: 'time'
  },
  {
    label: '时间范围',
    value: 'set<time>'
  },
  {
    label: '日期时间',
    value: 'datetime'
  },
  {
    value: 'set<datetime>',
    label: '日期时间范围'
  },
  {
    label: '枚举',
    value: 'enum'
  },
  {
    label: '枚举数组',
    value: 'set<enum>'
  },
  {
    label: 'map结构',
    value: 'map'
  }
])

// 新增配置参数
const handleAdd = () => {
  configTableList.value.push({
    key: '',
    value: '',
    desc: '',
    type: ''
  })
}

// 类型切换
const handleTypeChange = (val: string, index: number) => {
  const keys = ['int', 'long', 'float', 'double']
  if (val.includes('set')) {
    configTableList.value[index].value = []
  } else if (keys.includes(val)) {
    configTableList.value[index].value = 0
  } else {
    configTableList.value[index].value = ''
  }
}

// 校验
const validate = async (callback?: (data: string) => void) => {
  if (callback) {
    formRef.value?.validate(val => {
      if (val) {
        callback(JSON.stringify(configTableList.value))
      }
    })
  } else {
    return new Promise(resolve => {
      formRef.value?.validate(validate => {
        resolve(validate)
      })
    })
  }
}

defineExpose({
  validate
})
</script>

<template>
  <el-form
    ref="formRef"
    :model="formData"
    label-width="0"
    :style="{ width: '100%' }"
  >
    <el-table
      :data="configTableList"
      border
      :header-cell-style="{ backgroundColor: '#f2f2f2' }"
    >
      <el-table-column
        label="参数"
        width="200px"
        align="left"
        header-align="center"
      >
        <template #default="scope">
          <el-form-item
            label=""
            :prop="`key-${scope.$index}`"
            :rules="[
              {
                validator: commonValidate,
                trigger: 'blur'
              }
            ]"
          >
            <el-input
              v-model="scope.row.key"
              placeholder="请输入参数"
              class="w100"
            />
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column
        label="参数类型"
        width="200px"
        align="center"
      >
        <template #default="scope">
          <el-form-item
            label=""
            :prop="`type-${scope.$index}`"
            :rules="[
              {
                validator: commonValidate,
                trigger: 'blur'
              }
            ]"
          >
            <el-select
              v-model="scope.row.type"
              placeholder="请选择参数类型"
              class="w100"
              @change="(val: string) => handleTypeChange(val, scope.$index)"
            >
              <el-option
                v-for="item in typeOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column
        label="参数默认值"
        minWidth="350px"
        align="center"
      >
        <template #default="scope">
          <el-form-item
            label=""
            v-if="scope.row.type === 'set<string>'"
            :prop="`value-setString-${scope.$index}`"
            :rules="[{ validator: commonValidateValue, trigger: 'blur' }]"
          >
            <InputTag
              v-model:tagValue="scope.row.value"
              class="w100"
            ></InputTag>
          </el-form-item>
          <el-form-item
            label=""
            v-else-if="
              scope.row.type === 'text' || scope.row.type === 'textRich'
            "
            :prop="`value-text-${scope.$index}`"
            :rules="[{ validator: commonValidateValue, trigger: 'blur' }]"
          >
            <el-input
              v-model="scope.row.value"
              placeholder="请输入"
              class="w100"
              type="textarea"
              :rows="4"
            ></el-input>
          </el-form-item>
          <el-form-item
            v-else-if="scope.row.type === 'int'"
            label=""
            :prop="`value-int-${scope.$index}`"
            :rules="[{ validator: validateIntValue, trigger: 'blur' }]"
          >
            <el-input-number
              v-model="scope.row.value"
              placeholder="请输入"
              :style="{ width: '100%' }"
            />
          </el-form-item>
          <el-form-item
            v-else-if="scope.row.type === 'long'"
            label=""
            :prop="`value-long-${scope.$index}`"
            :rules="[{ validator: validateLongValue, trigger: 'blur' }]"
          >
            <el-input
              v-model="scope.row.value"
              placeholder="请输入"
            />
          </el-form-item>
          <el-form-item
            v-else-if="scope.row.type === 'double'"
            label=""
            :prop="`value-double-${scope.$index}`"
            :rules="[{ validator: validateDoubleValue, trigger: 'blur' }]"
          >
            <el-input-number
              v-model="scope.row.value"
              placeholder="请输入"
              :style="{ width: '100%' }"
            />
          </el-form-item>
          <el-form-item
            v-else-if="scope.row.type === 'float'"
            label=""
            :prop="`value-float-${scope.$index}`"
            :rules="[{ validator: validateFloatValue, trigger: 'blur' }]"
          >
            <el-input-number
              v-model="scope.row.value"
              placeholder="请输入"
              :style="{ width: '100%' }"
            />
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-setInt-${scope.$index}`"
            :rules="[{ validator: validateIntArrayValue, trigger: 'blur' }]"
            v-else-if="scope.row.type === 'set<int>'"
          >
            <InputTag
              v-model:tagValue="scope.row.value"
              class="w100"
            ></InputTag>
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-setFloat-${scope.$index}`"
            :rules="[{ validator: validateFloatArrayValue, trigger: 'blur' }]"
            v-else-if="scope.row.type === 'set<float>'"
          >
            <InputTag
              v-model:tagValue="scope.row.value"
              class="w100"
            ></InputTag>
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-setDouble-${scope.$index}`"
            :rules="[{ validator: validateDoubleArrayValue, trigger: 'blur' }]"
            v-else-if="scope.row.type === 'set<double>'"
          >
            <InputTag
              v-model:tagValue="scope.row.value"
              class="w100"
            ></InputTag>
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-boolean-${scope.$index}`"
            :rules="[{ validator: commonValidateValue, trigger: 'blur' }]"
            v-else-if="scope.row.type === 'boolean'"
          >
            <el-radio-group
              v-model="scope.row.value"
              class="w100"
            >
              <el-radio :value="true">true</el-radio>
              <el-radio :value="false">false</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-date-${scope.$index}`"
            :rules="[{ validator: commonValidateValue, trigger: 'blur' }]"
            v-else-if="scope.row.type === 'date'"
          >
            <el-date-picker
              v-model="scope.row.value"
              type="date"
              value-format="YYYY-MM-DD HH:mm:ss"
              :style="{ width: '100%' }"
            />
          </el-form-item>

          <el-form-item
            label=""
            :prop="`value-daterange-${scope.$index}`"
            :rules="[
              { validator: commonValidateValueByArray, trigger: 'blur' }
            ]"
            v-else-if="scope.row.type === 'set<date>'"
          >
            <el-date-picker
              v-model="scope.row.value"
              type="daterange"
              value-format="YYYY-MM-DD HH:mm:ss"
              class="w100"
            />
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-time-${scope.$index}`"
            :rules="[{ validator: commonValidateValue, trigger: 'blur' }]"
            v-else-if="scope.row.type === 'time'"
          >
            <el-time-picker
              v-model="scope.row.value"
              arrow-control
              value-format="YYYY-MM-DD HH:mm:ss"
              :style="{ width: '100%' }"
            />
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-setTime-${scope.$index}`"
            :rules="[
              { validator: commonValidateValueByArray, trigger: 'blur' }
            ]"
            v-else-if="scope.row.type === 'set<time>'"
          >
            <el-time-picker
              v-model="scope.row.value"
              is-range
              value-format="YYYY-MM-DD HH:mm:ss"
              class="w100"
            />
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-datetime-${scope.$index}`"
            :rules="[{ validator: commonValidateValue, trigger: 'blur' }]"
            v-else-if="scope.row.type === 'datetime'"
          >
            <el-date-picker
              v-model="scope.row.value"
              type="datetime"
              value-format="YYYY-MM-DD HH:mm:ss"
              class="w100"
            />
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-setDatetime-${scope.$index}`"
            :rules="[
              { validator: commonValidateValueByArray, trigger: 'blur' }
            ]"
            v-else-if="scope.row.type === 'set<datetime>'"
          >
            <el-date-picker
              v-model="scope.row.value"
              type="datetimerange"
              value-format="YYYY-MM-DD HH:mm:ss"
              class="w100"
            />
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-enum-${scope.$index}`"
            :rules="[{ validator: validateEnum, trigger: 'blur' }]"
            v-else-if="scope.row.type === 'enum'"
          >
            <el-input
              v-model="scope.row.value"
              placeholder="请输入 eg: xxx,xxx,xxx"
              class="w100"
            />
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-setEnum-${scope.$index}`"
            :rules="[{ validator: validateEnumByArray, trigger: 'blur' }]"
            v-else-if="scope.row.type === 'set<enum>'"
          >
            <InputTag
              v-model:tagValue="scope.row.value"
              class="w100"
            ></InputTag>
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-map-${scope.$index}`"
            :rules="[{ validator: validateMap, trigger: 'blur' }]"
            v-else-if="scope.row.type === 'map'"
          >
            <el-input
              v-model="scope.row.value"
              type="textarea"
              :rows="4"
              placeholder="请输入 eg: {'xxx': 'xxx', 'xxx': 'xxx'}"
              class="w100"
            />
          </el-form-item>
          <el-form-item
            label=""
            :prop="`value-string-${scope.$index}`"
            :rules="[{ validator: commonValidateValue, trigger: 'blur' }]"
            v-else
          >
            <el-input
              v-model="scope.row.value"
              placeholder="请输入"
              class="w100"
            />
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column
        label="参数描述"
        width="300px"
        align="center"
      >
        <template #default="{ row }">
          <el-form-item label="">
            <el-input
              v-model="row.desc"
              type="textarea"
              class="w100"
              :rows="1"
              placeholder="请输入"
            ></el-input>
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column
        label="参数正则校验规则"
        width="300px"
        align="center"
      >
        <template #default="{ row }">
          <el-form-item label="">
            <el-input
              v-model="row.regex"
              type="textarea"
              class="w100"
              :rows="1"
              placeholder="请输入"
            ></el-input>
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        width="70px"
        align="center"
      >
        <template #default="{ row }">
          <el-text
            type="danger"
            @click="handleDelete(row)"
            class="cursor-p"
          >
            删除
          </el-text>
        </template>
      </el-table-column>
    </el-table>
    <div class="flex-center flex-align cursor-p icon-wrapper">
      <el-icon
        @click="handleAdd"
        size="26"
        color="var(--el-color-primary)"
      >
        <CirclePlus />
      </el-icon>
    </div>
  </el-form>
</template>

<style lang="scss" scoped>
.w100 {
  width: 100%;
}

.icon-wrapper {
  height: 60px;
}

:deep(.el-form-item__content) {
  min-height: 64px;
  .el-form-item__error {
    top: 75% !important;
  }
}
</style>
