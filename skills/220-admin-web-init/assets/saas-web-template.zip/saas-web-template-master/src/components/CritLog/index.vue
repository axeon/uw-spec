<template>
  <div class="critLodDetail">
    <el-dialog
      v-model="isShow"
      :title="critLogTitle"
      @close="closeHistoryLog"
      :width="props.width"
      draggable
      :close-on-click-modal="false"
    >
      <el-table
        border
        :style="{ width: '100%' }"
        :header-cell-style="{
          backgroundColor: 'var(--el-color-info-light-9)'
        }"
        :data="critLogData"
        v-loading="critLogLoading"
      >
        <el-table-column
          prop="userInfo"
          label="用户信息"
          align="left"
          minWidth="150"
          fixed="left"
        >
          <template #default="scope">
            <div class="textAlignLeft">
              <span>用户名：</span>
              <span>{{ scope.row.userName }}</span>
            </div>
            <div class="textAlignLeft">
              <span>用户Ip：</span>
              <span>{{ scope.row.userIp ? scope.row.userIp : '' }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="apiUri"
          label="请求url"
          align="left"
          minWidth="200"
        ></el-table-column>
        <el-table-column
          prop="apiName"
          label="API名称"
          align="left"
          minWidth="100"
        ></el-table-column>
        <el-table-column
          prop="requestInfo"
          label="请求信息"
          align="left"
          minWidth="180"
        >
          <template #default="scope">
            <div class="textAlignLeft">
              <el-tooltip
                effect="dark"
                :content="scope.row.requestBody ? scope.row.requestBody : ''"
                placement="top-start"
              >
                <el-text type="primary">请求参数</el-text>
              </el-tooltip>
            </div>
            <div class="textAlignLeft">
              <span>请求时间：</span>
              <span>
                {{ dayjs(scope.row.requestDate).format('YYYY-MM-DD HH:mm:ss') }}
              </span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="responseInfo"
          label="响应信息"
          align="left"
          minWidth="150"
        >
          <template #default="scope">
            <div class="textAlignLeft">
              <el-tooltip
                effect="dark"
                :content="scope.row.responseBody ? scope.row.responseBody : ''"
                placement="top-start"
              >
                <el-text type="primary">响应信息</el-text>
              </el-tooltip>
            </div>
            <div class="textAlignLeft">
              <span>响应毫秒：</span>
              <span>
                {{
                  scope.row.responseMillis
                    ? scope.row.responseMillis + '(ms)'
                    : ''
                }}
              </span>
            </div>
            <div class="textAlignLeft">
              <span>响应状态：</span>
              <el-text
                :type="scope.row.statusCode === 200 ? 'success' : 'danger'"
              >
                {{ scope.row.statusCode ? scope.row.statusCode : '' }}
              </el-text>
            </div>
            <div
              v-if="scope.row.exception"
              class="textAlignLeft"
            >
              <span>异常信息：</span>
              <el-tooltip
                effect="dark"
                :content="scope.row.exception ? scope.row.exception : ''"
                placement="top-start"
              >
                <span>
                  {{ scope.row.exception ? scope.row.exception : '' }}
                </span>
              </el-tooltip>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="opLog"
          label="日志内容"
          align="left"
          minWidth="180"
        ></el-table-column>
      </el-table>
      <Pagination
        v-show="props.showPage"
        v-model:page-size="params.$rn"
        @page-size-change="handleSizeChange"
        :total="tableSizeAll"
        v-model:current-page="params.$pg"
        @current-change="handlePageChange"
      />
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ResponseData, DataList } from '@/api/uwAuthCenterAuthApi'
import dayjs from 'dayjs'

//OPS数据历史
interface SysCritLog {
  id?: number //ID
  saasId?: number //saasId
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  bizType?: string //操作对象类型
  bizId?: string //操作对象id
  apiUri?: string //请求uri
  apiName?: string //API名称
  opState?: string //操作状态
  opLog?: string //日志内容
  requestBody?: string //请求参数
  responseBody?: string //响应日志
  responseMillis?: number //请求毫秒数
  exception?: string //异常信息
  statusCode?: number //响应状态码
  appInfo?: string //应用信息
  appHost?: string //应用主机
  userIp?: string //操作人ip
  requestDate?: string //创建时间
}
//ops数据历史列表查询参数
interface SysCritLogQueryParam {
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  id?: number //ID
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  bizType?: string //操作对象类型
  bizId?: string //操作对象id
  apiUri?: string //请求uri
  apiName?: string //API名称
  opState?: string //操作状态
  responseMillis?: number //请求毫秒数
  responseMillisRange?: Array<number> //请求毫秒数范围
  statusCode?: number //响应状态码
  statusCodeRange?: Array<number> //响应状态码范围
  appInfo?: string //应用信息
  appHost?: string //应用主机
  userIp?: string //操作人ip
  requestDateRange?: Array<string> //创建时间范围
  $rn?: number //每页条数
  $pg?: number //当前页码
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}

interface historyLogType {
  showDetail: boolean // 显示更改详情的弹窗变量
  width?: string // 弹窗宽度
  queryCritLog: (
    item: SysCritLogQueryParam
  ) => Promise<ResponseData<DataList<SysCritLog>>> // 请求的接口  :xxx="xxx(item: SysCritLogQueryParam))"
  showPage?: boolean // 是否显示分页
}

// 传入的props
const props = withDefaults(defineProps<historyLogType>(), {
  width: '800px',
  showPage: false
})
// 是否显示
const isShow = ref(false)

// 表格数据
const critLogData = ref<SysCritLog[]>([])
const params = ref<SysCritLogQueryParam>({
  $pg: 1,
  $rn: 10,
  $rt: 2,
  $st: [2],
  $sn: ['id']
})
const tableSizeAll = ref(0)
const critLogLoading = ref(false)

// 获取表格数据
const getHistoryList = () => {
  critLogLoading.value = true
  // 是否显示分页，显示分页则默认取10，不显示默认取100
  if (props.showPage) {
    params.value.$rn = 10
  } else {
    params.value.$rn = 100
  }
  props
    .queryCritLog(params.value)
    .then(res => {
      critLogData.value = res.data?.results || []
      tableSizeAll.value = res.data?.sizeAll || 0
      critLogLoading.value = false
    })
    .catch(() => {
      critLogLoading.value = false
    })
}

// 条数变化
const handleSizeChange = (value: number) => {
  params.value.$rn = value
  props
    .queryCritLog(params.value)
    .then(res => {
      critLogData.value = res.data?.results || []
      tableSizeAll.value = res.data?.sizeAll || 0
      critLogLoading.value = false
    })
    .catch(() => {
      critLogLoading.value = false
    })
}

// 页数变化
const handlePageChange = (value: number) => {
  params.value.$pg = value
  props
    .queryCritLog(params.value)
    .then(res => {
      critLogData.value = res.data?.results || []
      tableSizeAll.value = res.data?.sizeAll || 0
      critLogLoading.value = false
    })
    .catch(() => {
      critLogLoading.value = false
    })
}

// 关闭重置相关变量
const resetForm = () => {
  critLogData.value = []
  params.value = {
    $pg: 1,
    $rn: 10,
    $rt: 2,
    $st: [2],
    $sn: ['id']
  }
}

// 历史记录弹窗标题
const critLogTitle = ref('')

// 打开查看操作日志弹窗
const openCritLog = (bizId: string, bizType: string) => {
  isShow.value = true
  params.value.bizId = bizId
  params.value.bizType = bizType
  critLogTitle.value = `关键日志#${bizId}`
  params.value.$rt = 2
  getHistoryList()
}

// 关闭查看历史弹窗
const closeHistoryLog = () => {
  isShow.value = false
  resetForm()
}

defineExpose({
  openCritLog,
  closeHistoryLog
})
</script>

<style scoped lang="scss">
.critLodDetail {
  :deep(.el-dialog__body) {
    height: 500px;
    overflow: auto;
  }
}
</style>
