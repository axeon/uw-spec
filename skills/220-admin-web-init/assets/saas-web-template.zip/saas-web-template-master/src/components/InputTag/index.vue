<template>
  <div class="inputTag-wrapper">
    <div class="inputTag-content-wrapper">
      <!-- tag标签 -->
      <el-tag
        v-for="tag in inputTagValue"
        :key="tag"
        :closable="!disabled"
        :disable-transitions="false"
        @close="handleClose(tag)"
        class="tag-item"
        v-bind="tagAttributes"
      >
        {{ tag }}
      </el-tag>
      <!-- 输入框 -->
      <el-input
        v-model.trim="inputValue"
        :placeholder="placeholder"
        class="tag-select"
        @keyup.enter="handleInputConfirm"
        @blur="handleInputConfirm"
        :disabled="disabled"
      />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'

const props = withDefaults(
  defineProps<{
    tagValue?: string[] | undefined
    tagType?: '' | 'success' | 'info' | 'warning' | 'danger'
    tagAttributes?: Record<string, any> // 扩展的tag属性
    placeholder?: string
    disabled?: boolean
  }>(),
  {
    tagValue: () => [],
    tagType: '',
    disabled: false
  }
)

const emits = defineEmits<{
  (e: 'update:tagValue', val: string[] | undefined): void
}>()

// 绑定值
const inputTagValue = computed({
  set(val: string[] | undefined) {
    emits('update:tagValue', val)
  },
  get() {
    return props.tagValue && Array.isArray(props.tagValue) ? props.tagValue : []
  }
})

// 输入的值
const inputValue = ref('')

// 回车、失去焦点
const handleInputConfirm = () => {
  if (props.disabled) {
    return
  }
  if (inputValue.value) {
    // 不包含同样的值，则添加
    if (!inputTagValue.value?.includes(inputValue.value)) {
      inputTagValue.value?.push(inputValue.value)
    }
  }
  inputValue.value = ''
}

// 点击删除tag
const handleClose = (tag: string) => {
  inputTagValue.value = inputTagValue.value?.filter(item => item !== tag)
}
</script>

<style lang="scss" scoped>
.inputTag-wrapper {
  width: 100%;
  .inputTag-content-wrapper {
    position: relative;
    font-size: var(--el-font-size-base);
    display: inline-flex;
    width: 100%;
    line-height: 32px;
    box-sizing: border-box;
    vertical-align: middle;
    display: inline-flex;
    flex-wrap: wrap;
    align-items: center;
    padding: 1px 11px;
    box-shadow: 0 0 0 1px var(--el-input-border-color, var(--el-border-color))
      inset;
    border-radius: var(--el-input-border-radius, var(--el-border-radius-base));
    .tag-item {
      margin: 5px 5px 5px 0;
    }
    .tag-select {
      flex: 1;
      min-width: 80px;
      :deep(.el-input__wrapper) {
        box-shadow: unset;
      }
    }
  }
}
</style>
