###### 组件属性

```typescript
v-model:tagValue                      绑定的值
tagType                               tag类型 '' | 'success' | 'info' | 'warning' | 'danger'
tagAttributes                         tag扩展属性
placeholder                           输入提示
```
