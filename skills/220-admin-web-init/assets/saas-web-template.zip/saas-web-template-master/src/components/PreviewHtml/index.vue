<script lang="ts" setup>
import { IframeHTMLAttributes } from 'vue'

const props = withDefaults(
  defineProps<{
    sourceCode: string
    height?: string | number
  }>(),
  {
    sourceCode: '',
    height: '300px'
  }
)

// 显示的源码
const textContent = useModel(props, 'sourceCode')

// 内容高度
const contentHeight = computed(() => {
  if (typeof props.height === 'number') {
    return props.height + 'px'
  }
  return props.height
})

// iframe ref
const iframe = useTemplateRef<IframeHTMLAttributes>('iframe')
const currentUrlBlob = ref<string>()
const timerByBlob = ref()
const timerByClear = ref()

// 处理blob
const handleBlob = () => {
  if (iframe.value) {
    if (currentUrlBlob.value) {
      URL.revokeObjectURL(currentUrlBlob.value)
    }
    const content = handleHtmlContent()
    const blob = new Blob([content], {
      type: 'text/html;charset=UTF-8'
    })
    currentUrlBlob.value = URL.createObjectURL(blob)
    iframe.value.src = currentUrlBlob.value
  } else {
    timerByBlob.value = setTimeout(() => {
      handleBlob()
      clearTimeout(timerByBlob.value)
    }, 200)
  }
}

// 生成正则
const createRegex = (tagName: string) => {
  const dynamicRegex = new RegExp(
    `<${tagName}[^>]*>([\\s\\S]+?)<\\/${tagName}>`,
    'i'
  )
  return dynamicRegex
}

// 处理html内容
const handleHtmlContent = (): string => {
  const bodyRegex = createRegex('body')
  const styleRegex = createRegex('style')
  const matchBody = bodyRegex.exec(textContent.value)
  // 拿取body标签里面的内容
  const bodyContent = matchBody
    ? matchBody[1]
        .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
        .replace(/on\w+="[^"]*"/gi, '')
    : null
  const matchStyle = styleRegex.exec(textContent.value)
  // 拿取style标签里面的内容
  const styleContent = matchStyle ? matchStyle[1] : null
  return `<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org">
  <head>
    <meta charset="UTF-8" />
    <style>
      ${styleContent}
    </style>
  </head>
  <body>
    ${bodyContent}
  </body>
</html>`
}

// 清空iframe展示内容
const clearIframe = () => {
  if (iframe.value) {
    if (currentUrlBlob.value) {
      URL.revokeObjectURL(currentUrlBlob.value)
    }
    iframe.value.src = ''
  } else {
    timerByClear.value = setTimeout(() => {
      clearIframe()
      clearTimeout(timerByClear.value)
    }, 200)
  }
}

watchDebounced(
  () => textContent.value,
  val => {
    if (val) {
      handleBlob()
    } else {
      clearIframe()
    }
  },
  {
    immediate: true,
    debounce: 500,
    maxWait: 1000
  }
)

onUnmounted(() => {
  timerByBlob.value && clearTimeout(timerByBlob.value)
  timerByClear.value && clearTimeout(timerByClear.value)
})
</script>

<template>
  <el-row
    :gutter="1"
    style="width: 100%"
  >
    <el-col :span="12">
      <el-input
        v-model="textContent"
        type="textarea"
      />
    </el-col>
    <el-col :span="12">
      <div
        :style="{ width: '100%', height: contentHeight }"
        class="iframe-wrapper"
      >
        <iframe
          ref="iframe"
          frameborder="0"
          :style="{ width: '100%', height: contentHeight }"
        ></iframe>
      </div>
    </el-col>
  </el-row>
</template>

<style scoped lang="scss">
:deep(.el-textarea) {
  .el-textarea__inner {
    height: v-bind(contentHeight);
  }
}

.iframe-wrapper {
  box-shadow: 0 0 0 1px var(--el-input-border-color, var(--el-border-color))
    inset;
  border-radius: var(--el-input-border-radius, var(--el-border-radius-base));
}
</style>
