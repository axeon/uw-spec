<script setup lang="ts">
interface listItem {
  url?: string
  check?: boolean
  type?: 'video' | 'image'
}

const props = withDefaults(
  defineProps<{
    modeValue: listItem[]
    itemWidth?: number | string
    itemHeight?: number | string
    fitType?: '' | 'fill' | 'contain' | 'cover' | 'none' | 'scale-down'
  }>(),
  {
    itemWidth: 126,
    itemHeight: 126,
    fitType: 'fill'
  }
)

// 宽度
const listItemWidth = computed(() => {
  if (typeof props.itemWidth === 'number') {
    return props.itemWidth + 'px'
  }
  return props.itemWidth
})

const listItemHeight = computed(() => {
  if (typeof props.itemHeight === 'number') {
    return props.itemHeight + 'px'
  }
  return props.itemHeight
})
</script>

<template>
  <div class="item-wrapper">
    <template
      v-for="item in modeValue"
      :key="item.url"
    >
      <div
        v-if="item.type === 'image'"
        class="img-wrapper margin-right-5 margin-bottom-5"
      >
        <el-image
          :style="{ width: listItemWidth, height: listItemHeight }"
          :src="item.url"
          :fit="props.fitType"
          style="border-radius: 4px"
        />
        <div
          class="remark"
          @click="item.check = !item.check"
        >
          <el-checkbox
            v-model="item.check"
            class="checkBox"
          />
        </div>
      </div>
      <div
        v-else
        class="margin-right-5 margin-bottom-5 video-wrapper"
      >
        <video
          :src="item.url"
          :style="{
            width: listItemWidth,
            height: listItemHeight,
            objectFit: 'fill',
            borderRadius: '4px'
          }"
        ></video>
        <div
          class="remark"
          @click="item.check = !item.check"
        >
          <el-checkbox
            v-model="item.check"
            class="checkBox"
          />
        </div>
      </div>
    </template>
  </div>
</template>

<style scoped lang="scss">
.item-wrapper {
  display: flex;
  flex-wrap: wrap;
  cursor: pointer;

  .img-wrapper,
  .video-wrapper {
    position: relative;

    .remark {
      position: absolute;
      top: 0;
      left: 0;
      width: v-bind(listItemWidth);
      height: v-bind(listItemHeight);
      // border: 1px dashed var(--el-border-color-darker);
      box-sizing: border-box;
      border-radius: 4px;

      :deep(.el-checkbox) {
        position: absolute;
        top: 0;
        right: 0;
        height: 15px;
      }
    }
  }
}

.checkBox {
  :deep(.el-checkbox__inner) {
    background: transparent;
    border-color: transparent;
  }

  :deep(.el-checkbox__input.is-checked .el-checkbox__inner) {
    background-color: var(--el-checkbox-checked-bg-color);
    border-color: var(--el-checkbox-checked-input-border-color);
  }
}
</style>
