<template>
  <transition name="el-fade-in">
    <div
      :class="{ relative: mode === 'fixed', fixed: mode === 'pop' }"
      v-show="showCaptcha"
      ref="captChaRef"
    >
      <div class="opt-content">
        <el-row
          type="flex"
          justify="center"
          align="middle"
          class="margin-bottom-5"
        >
          <el-col
            :span="24"
            class="margin-bottom-5"
          >
            <div class="header-tip">
              {{
                captchaType === 'CalculateCaptchaStrategy'
                  ? t('CalculateCaptchaStrategy')
                  : t('SimpleCaptchaStrategyTip')
              }}
            </div>
          </el-col>
          <el-col :span="24">
            <div class="code-image">
              <el-image :src="imgUrl" />
              <div
                class="verify-refresh"
                @click="handleRefreshGenCaptcha"
                v-show="showRefresh"
              >
                <el-icon
                  size="22px"
                  color="var(--el-slide-menu-background)"
                >
                  <Refresh />
                </el-icon>
              </div>
            </div>
          </el-col>
        </el-row>
        <el-row
          type="flex"
          justify="center"
          align="middle"
          :gutter="10"
        >
          <el-col :span="18">
            <el-input
              v-model="validateResult"
              :placeholder="
                captchaType === 'CalculateCaptchaStrategy'
                  ? t('CalculateCaptchaStrategy')
                  : t('SimpleCaptchaStrategyTip')
              "
              :style="{ width: '100%' }"
              @input="handleInput"
            />
          </el-col>
          <el-col :span="6">
            <el-button
              type="primary"
              icon="Check"
              @click="handleValidateImgCode"
              :disabled="!validateResult"
            >
              {{ t('validate') }}
            </el-button>
          </el-col>
        </el-row>
      </div>
    </div>
  </transition>
</template>

<script setup lang="ts" name="ImageInputVerification">
import { ElMessage } from 'element-plus'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()
const props = withDefaults(
  defineProps<{
    show?: boolean
    mode?: 'fixed' | 'pop'
    width?: string
    height?: string
    imgCodeForValidate: string // 图片验证码
    captchaType?: 'StringCaptchaStrategy' | 'CalculateCaptchaStrategy'
  }>(),
  {
    show: true,
    mode: 'pop',
    width: '380px',
    height: '230px'
  }
)

const emits = defineEmits<{
  (e: 'update:show', val: boolean): void
  (e: 'refresh'): void
  (e: 'validate', val: string): void
}>()

const showCaptcha = computed({
  get() {
    return props.show
  },
  set(val) {
    emits('update:show', val)
  }
})

const imgUrl = computed(() => {
  return 'data:image/png;base64,' + props.imgCodeForValidate
})

const dialogWidth = computed(() => props.width)
const dialogHeight = computed(() => props.height)
const showRefresh = ref(true)
const captChaRef = ref()
onClickOutside(captChaRef, () => {
  if (props.mode === 'pop') {
    showCaptcha.value = false
  }
})

// 返回的图片
// 输入的验证码
const validateResult = ref('')
// 机器验证码刷新
const handleRefreshGenCaptcha = () => {
  emits('refresh')
  startTime.value = 0
  isFirstStr.value = false
}

// 点击图形检验
const handleValidateImgCode = () => {
  const data = {
    answerData: validateResult.value,
    opTime: new Date().getTime() - startTime.value
  }
  emits('validate', JSON.stringify(data))
}

defineExpose({
  validateSuccess: () => {
    ElMessage.success(t('validateSuccess'))
    showCaptcha.value = false
    showRefresh.value = false
  },
  validateError: () => {
    ElMessage.error(t('validateError'))
    validateResult.value = ''
    startTime.value = 0
    isFirstStr.value = false
    showRefresh.value = true
  },
  reset: () => {
    validateResult.value = ''
    startTime.value = 0
    isFirstStr.value = false
    showRefresh.value = true
  }
})

const isFirstStr = ref(false)
const startTime = ref(0)
const handleInput = () => {
  if (!isFirstStr.value) {
    startTime.value = new Date().getTime()
    isFirstStr.value = true
  }
}

watch(
  () => props.show,
  val => {
    if (!val) {
      validateResult.value = ''
      startTime.value = 0
      isFirstStr.value = false
    }
  },
  {
    immediate: true
  }
)
</script>

<style scoped lang="scss">
.relative {
  position: relative;
  width: v-bind(dialogWidth);
  height: v-bind(dialogHeight);
  :deep(.menu-icon__box) {
    width: 100%;
  }
}
.fixed {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: v-bind(dialogWidth);
  height: v-bind(dialogHeight);
  z-index: 10;
  box-shadow: 0 0 11px 0 #999;
  background-color: var(--el-bg-color);
  box-sizing: border-box;
  border-radius: 6px;
  padding: 10px;
  :deep(.menu-icon__box) {
    width: 100%;
  }
}

.code-header {
  height: 30px;
  line-height: 30px;
  font-size: 16px;
}

.header-tip {
  color: var(--el-text-color-primary);
  font-size: 16px;
}
.code-image {
  width: 370px;
  height: 138px;
  box-sizing: border-box;
  position: relative;
  border-radius: 4px;
  :deep(.el-image__inner) {
    width: 365px;
    height: 135px;
  }
  .verify-refresh {
    position: absolute;
    top: 2px;
    right: 0;
    z-index: 2;
    width: 25px;
    height: 25px;
    padding: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
  }
}

:deep(.el-image__inner) {
  height: 140px;
}
</style>
