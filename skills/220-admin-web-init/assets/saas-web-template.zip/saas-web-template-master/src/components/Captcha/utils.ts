import CryptoJS from 'crypto-js'
/**
 * @word 要加密的内容
 * @keyWord String  服务器随机返回的关键字
 *  */
export const aesEncrypt = (word: string, keyWord = 'XwKsGlMcdPMEhR1B') => {
  const key = CryptoJS.enc.Utf8.parse(keyWord)
  const src = CryptoJS.enc.Utf8.parse(word)
  const encrypted = CryptoJS.AES.encrypt(src, key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  })
  return encrypted.toString()
}

/**
 *
 * @param cipherText 要解密的内容
 * @param passphrase 服务器随机返回的关键字
 * @returns
 */
export const decrypt = (
  cipherText: string,
  passphrase = 'XwKsGlMcdPMEhR1B'
) => {
  const keyBytes = CryptoJS.enc.Utf8.parse(passphrase)
  const bytes = CryptoJS.AES.decrypt(cipherText, keyBytes, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  })
  return bytes.toString(CryptoJS.enc.Utf8)
}

export const resetSize = (vm: any) => {
  let img_width = 0,
    img_height = 0,
    bar_width = 0,
    bar_height = 0 //图片的宽度、高度，移动条的宽度、高度
  const parentWidth = vm.$el.parentNode.offsetWidth
  const parentHeight = vm.$el.parentNode.offsetHeight
  if (vm.imgSize.width.indexOf('%') !== -1) {
    img_width = (parseInt(vm.imgSize.width) / 100) * parentWidth
  } else {
    img_width =
      typeof vm.imgSize.width === 'string'
        ? Number(vm.imgSize.width.replace(/px/, ''))
        : vm.imgSize.width
  }

  if (vm.imgSize.height.indexOf('%') !== -1) {
    img_height = (parseInt(vm.imgSize.height) / 100) * parentHeight
  } else {
    img_height =
      typeof vm.imgSize.height === 'string'
        ? Number(vm.imgSize.height.replace(/px/, ''))
        : vm.imgSize.height
  }

  if (vm.barSize.width.indexOf('%') !== -1) {
    bar_width = (parseInt(vm.barSize.width) / 100) * parentWidth
  } else {
    bar_width =
      typeof vm.barSize.width === 'string'
        ? Number(vm.barSize.width.replace(/px/, ''))
        : vm.barSize.width
  }

  if (vm.barSize.height.indexOf('%') !== -1) {
    bar_height = (parseInt(vm.barSize.height) / 100) * parentHeight
  } else {
    bar_height =
      typeof vm.barSize.height === 'string'
        ? Number(vm.barSize.height.replace(/px/, ''))
        : vm.barSize.height
  }

  return {
    imgWidth: img_width,
    imgHeight: img_height,
    barWidth: bar_width,
    barHeight: bar_height
  }
}

export const _code_chars = [
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  'a',
  'b',
  'c',
  'd',
  'e',
  'f',
  'g',
  'h',
  'i',
  'j',
  'k',
  'l',
  'm',
  'n',
  'o',
  'p',
  'q',
  'r',
  's',
  't',
  'u',
  'v',
  'w',
  'x',
  'y',
  'z',
  'A',
  'B',
  'C',
  'D',
  'E',
  'F',
  'G',
  'H',
  'I',
  'J',
  'K',
  'L',
  'M',
  'N',
  'O',
  'P',
  'Q',
  'R',
  'S',
  'T',
  'U',
  'V',
  'W',
  'X',
  'Y',
  'Z'
]
export const _code_color1 = ['#fffff0', '#f0ffff', '#f0fff0', '#fff0f0']
export const _code_color2 = [
  '#FF0033',
  '#006699',
  '#993366',
  '#FF9900',
  '#66CC66',
  '#FF33CC'
]
