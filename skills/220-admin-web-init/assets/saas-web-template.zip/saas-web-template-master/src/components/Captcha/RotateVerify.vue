<template>
  <transition name="el-fade-in">
    <div
      :class="{ relative: mode === 'fixed', fixed: mode === 'pop' }"
      v-show="showCaptcha"
      ref="captChaRef"
    >
      <div class="header-tip margin-bottom-5">{{ explain }}</div>
      <div
        class="verify-img-out"
        :style="{ height: setSize.imgHeight + vSpace + 'px' }"
      >
        <div
          class="verify-img-panel"
          :style="{
            width: setSize.imgWidth + 'px',
            height: setSize.imgHeight + 'px'
          }"
        >
          <img
            :src="'data:image/png;base64,' + backImgBase"
            alt=""
            draggable="false"
          />
          <div
            class="verify-refresh"
            @click="refresh"
            v-show="showRefresh"
          >
            <el-icon
              size="22px"
              color="var(--el-slide-menu-background)"
            >
              <Refresh />
            </el-icon>
          </div>
          <div
            class="verify-sub-block"
            :style="{
              width: '100px',
              height: '100px',
              top: `${rotateImageY}px`,
              left: `${rotateImageX}px`,
              transform: `rotate(${rotateDeg}deg)`
            }"
          >
            <img
              :src="'data:image/png;base64,' + blockBackImgBase"
              alt=""
            />
          </div>
          <transition name="tips">
            <span
              class="verify-tips"
              v-if="tipWords"
              :class="passFlag ? 'suc-bg' : 'err-bg'"
            >
              {{ tipWords }}
            </span>
          </transition>
        </div>
      </div>
      <div
        class="verify-bar-area"
        :style="{
          width: setSize.imgWidth + 'px',
          height: setSize.barHeight + 'px',
          lineHeight: setSize.barHeight + 'px'
        }"
      >
        <span
          class="verify-msg"
          v-text="text"
        ></span>
        <div
          class="verify-left-bar"
          :style="{
            width:
              leftBarWidth !== undefined
                ? leftBarWidth
                : setSize.barHeight + 'px',
            height: setSize.barHeight + 'px',
            transition: transitionWidth
          }"
        >
          <span
            class="verify-msg"
            v-text="finishText"
          ></span>
          <div
            class="verify-move-block"
            @touchstart="start"
            @mousedown="start"
            :style="{
              width: setSize.barHeight + 'px',
              height: setSize.barHeight + 'px',
              backgroundColor: moveBlockBackgroundColor,
              left: moveBlockLeft,
              transition: transitionLeft
            }"
          >
            <MenuIcon
              :iconName="iconClass"
              :color="iconColor"
              :size="16"
            ></MenuIcon>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>
<script setup lang="ts" name="SliderCaptcha">
import { resetSize } from './utils'
import { ComponentInternalInstance } from 'vue'
import { onClickOutside } from '@vueuse/core'
import { useI18n } from 'vue-i18n'

interface sizeType {
  width: string
  height: string
}

const { t } = useI18n()
const props = withDefaults(
  defineProps<{
    show?: boolean
    mode?: 'fixed' | 'pop' // fixed 正常展示  pop弹窗展示
    imgCodeForValidate: string // 图片url
    blockBackImgBase: string // 滑块图片
    rotatePoint: {
      // 滑动的圆心位置
      x: number
      y: number
    }
    vSpace?: number
    explain?: string
    imgSize?: sizeType
    blockSize?: sizeType
    barSize?: sizeType
  }>(),
  {
    show: true,
    mode: 'pop',
    vSpace: 5,
    explain: '向右滑动让图片旋转到合适的角度',
    imgSize: () => ({
      width: '360px',
      height: '140px'
    }),
    blockSize: () => ({
      width: '50px',
      height: '50px'
    }),
    barSize: () => ({
      width: '360px',
      height: '40px'
    })
  }
)

const emits = defineEmits<{
  (e: 'update:show', val: boolean): void
  (e: 'validate', val: string): void
  (e: 'refresh'): void
}>()

const showCaptcha = computed({
  get() {
    return props.show
  },
  set(val) {
    emits('update:show', val)
  }
})

const { proxy } = getCurrentInstance() as ComponentInternalInstance
const passFlag = ref<boolean>() //是否通过的标识
const startMoveTime = ref<number>(0) //移动开始的时间
const endMoveTime = ref<number>() //移动结束的时间
const tipWords = ref<string>('')
const text = ref<string>('')
const finishText = ref('')
const setSize = reactive({
  imgHeight: 140,
  imgWidth: 360,
  barHeight: 40,
  barWidth: 360
})
const moveBlockLeft = ref<string>()
const leftBarWidth = ref<string>()
// 移动中样式
const moveBlockBackgroundColor = ref<string>()
const leftBarBorderColor = ref('#ddd')
const iconColor = ref<string>()
const iconClass = ref('ArrowRight')
const status = ref(false) //鼠标状态
const isEnd = ref(false) //是够验证完成
const showRefresh = ref(true)
const transitionLeft = ref('')
const transitionWidth = ref('')
const startLeft = ref(0)

const barArea = computed(() => {
  return proxy!.$el.querySelector('.verify-bar-area')
})

// 校验图片
const backImgBase = computed(() => props.imgCodeForValidate)
// 校验旋转图片
const blockBackImgBase = computed(() => props.blockBackImgBase)
// 旋转图片圆心位置
const rotateImageX = computed(() => {
  return props.rotatePoint.x - 50
})
const rotateImageY = computed(() => props.rotatePoint.y - 50)
// 图片旋转角度
const rotateDeg = ref(0)

const init = () => {
  text.value = props.explain
  nextTick(() => {
    const { imgHeight, imgWidth, barHeight, barWidth } = resetSize(proxy)
    setSize.imgHeight = imgHeight
    setSize.imgWidth = imgWidth
    setSize.barHeight = barHeight
    setSize.barWidth = barWidth
  })

  window.removeEventListener('touchmove', function (e) {
    move(e)
  })
  window.removeEventListener('mousemove', function (e) {
    move(e)
  })

  //鼠标松开
  window.removeEventListener('touchend', function () {
    end()
  })
  window.removeEventListener('mouseup', function () {
    end()
  })

  window.addEventListener('touchmove', function (e) {
    move(e)
  })
  window.addEventListener('mousemove', function (e) {
    move(e)
  })

  //鼠标松开
  window.addEventListener('touchend', function () {
    end()
  })
  window.addEventListener('mouseup', function () {
    end()
  })
}

//鼠标按下
const start = (e: MouseEvent | TouchEvent) => {
  let x = 0
  e = e || window.event
  if (!(e as TouchEvent).touches) {
    //兼容PC端
    x = (e as MouseEvent).clientX
  } else {
    //兼容移动端
    x = (e as TouchEvent).touches[0].pageX
  }
  startLeft.value = Math.floor(x - barArea.value.getBoundingClientRect().left)
  startMoveTime.value = +new Date() //开始滑动的时间
  if (isEnd.value === false) {
    text.value = ''
    moveBlockBackgroundColor.value = 'var(--el-color-primary-light-3)'
    leftBarBorderColor.value = 'var(--el-color-primary)'
    iconColor.value = '#fff'
    e.stopPropagation()
    status.value = true
  }
}

//鼠标移动
const move = (e: MouseEvent | TouchEvent) => {
  let x = 0
  e = e || window.event
  if (status.value && isEnd.value === false) {
    if ('clientX' in e) {
      //兼容PC端
      x = e.clientX
    } else {
      //兼容移动端
      x = e.touches[0].pageX
    }
    let bar_area_left = barArea.value.getBoundingClientRect().left
    let move_block_left = x - bar_area_left //小方块相对于父元素的left值
    if (
      move_block_left >=
      barArea.value.offsetWidth -
        parseInt(String(parseInt(props.blockSize.width) / 2 - 2))
    ) {
      move_block_left =
        barArea.value.offsetWidth -
        parseInt(String(parseInt(props.blockSize.width) / 2 - 2))
    }
    if (move_block_left <= 0) {
      move_block_left = parseInt(String(parseInt(props.blockSize.width) / 2))
    }
    // 旋转角度
    rotateDeg.value = (move_block_left - startLeft.value) * 1.139
    //拖动后小方块的left值
    moveBlockLeft.value = move_block_left - startLeft.value + 'px'
    leftBarWidth.value = move_block_left - startLeft.value + 'px'
  }
}

//鼠标松开
const end = () => {
  endMoveTime.value = +new Date()
  //判断是否重合
  if (status.value && isEnd.value === false) {
    let moveLeftDistance = parseInt(
      (moveBlockLeft.value || '').replace('px', '')
    )
    moveLeftDistance =
      (moveLeftDistance * 360) / parseInt(String(setSize.imgWidth))
    const data = {
      answerData: String(Math.floor(moveLeftDistance) * 1.139),
      opTime: endMoveTime.value - startMoveTime.value
    }
    emits('validate', JSON.stringify(data))
    status.value = false
  }
}

// 验证成功
const validateSuccess = () => {
  moveBlockBackgroundColor.value = '#5cb85c'
  leftBarBorderColor.value = '#5cb85c'
  iconColor.value = '#fff'
  iconClass.value = 'Check'
  showRefresh.value = false
  isEnd.value = true
  passFlag.value = true
  tipWords.value = `${(
    (endMoveTime.value! - startMoveTime.value) /
    1000
  ).toFixed(2)}s${t('validateSuccess')}`
  if (props.mode === 'pop') {
    setTimeout(() => {
      showCaptcha.value = false
      tipWords.value = ''
    }, 1500)
  } else {
    showCaptcha.value = false
    tipWords.value = ''
  }
}

// 验证失败
const validateError = () => {
  moveBlockBackgroundColor.value = '#d9534f'
  leftBarBorderColor.value = '#d9534f'
  iconColor.value = '#fff'
  iconClass.value = 'Close'
  passFlag.value = false
  tipWords.value = t('validateError')
  setTimeout(() => {
    tipWords.value = ''
  }, 1000)
}

// 刷新
const refresh = () => {
  showRefresh.value = true
  finishText.value = ''
  transitionLeft.value = 'left .3s'
  moveBlockLeft.value = ''
  leftBarWidth.value = undefined
  transitionWidth.value = 'width .3s'
  leftBarBorderColor.value = '#ddd'
  moveBlockBackgroundColor.value = '#fff'
  iconColor.value = '#000'
  iconClass.value = 'ArrowRight'
  isEnd.value = false
  rotateDeg.value = 0
  emits('refresh')
  setTimeout(() => {
    transitionWidth.value = ''
    transitionLeft.value = ''
    text.value = props.explain
  }, 300)
}

// 重置
const reset = () => {
  showRefresh.value = true
  finishText.value = ''
  transitionLeft.value = 'left .3s'
  moveBlockLeft.value = ''
  leftBarWidth.value = undefined
  transitionWidth.value = 'width .3s'
  leftBarBorderColor.value = '#ddd'
  moveBlockBackgroundColor.value = '#fff'
  iconColor.value = '#000'
  iconClass.value = 'ArrowRight'
  isEnd.value = false
  rotateDeg.value = 0
  setTimeout(() => {
    transitionWidth.value = ''
    transitionLeft.value = ''
    text.value = props.explain
  }, 300)
}

const dialogWidth = computed(() => {
  return Number(props.imgSize.width.replace(/px/, '')) + 20 + 'px'
})

const dialogHeight = computed(() => {
  return Number(props.imgSize.height.replace(/px/, '')) + 90 + 'px'
})

// 元素
const captChaRef = ref()
// 点击外部关闭
onClickOutside(captChaRef, () => {
  if (props.mode === 'pop') {
    showCaptcha.value = false
    reset()
  }
})

watch(
  () => props.imgCodeForValidate,
  val => {
    if (props.show) {
      if (val) {
        reset()
        init()
      } else {
        reset()
      }
    }
  },
  {
    immediate: true
  }
)

onMounted(() => {
  // 禁止拖拽
  proxy!.$el.onselectstart = function () {
    return false
  }
})

onUnmounted(() => {
  window.removeEventListener('touchmove', function (e) {
    move(e)
  })
  window.removeEventListener('mousemove', function (e) {
    move(e)
  })

  //鼠标松开
  window.removeEventListener('touchend', function () {
    end()
  })
  window.removeEventListener('mouseup', function () {
    end()
  })
})

defineExpose({
  validateError,
  validateSuccess
})
</script>

<style scoped lang="scss">
.relative {
  position: relative;
  :deep(.menu-icon__box) {
    width: 100%;
  }
}
.fixed {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: v-bind(dialogWidth);
  height: v-bind(dialogHeight);
  z-index: 10;
  box-shadow: 0 0 11px 0 #999;
  background-color: var(--el-bg-color);
  box-sizing: border-box;
  border-radius: 6px;
  padding: 10px;
  :deep(.menu-icon__box) {
    width: 100%;
  }
}

.verify-tips {
  position: absolute;
  left: 0px;
  bottom: 0px;
  width: 100%;
  height: 30px;
  line-height: 30px;
  color: #fff;
}
.suc-bg {
  background-color: var(--el-color-success);
  color: #fff;
  text-align: center;
  font-size: 14px;
}
.err-bg {
  background-color: var(--el-color-danger);
  color: #fff;
  text-align: center;
  font-size: 14px;
}
.tips-enter,
.tips-leave-to {
  bottom: -30px;
}
.tips-enter-active,
.tips-leave-active {
  transition: bottom 0.5s;
}
/* ---------------------------- */
/*常规验证码*/
.verify-code {
  font-size: 20px;
  text-align: center;
  cursor: pointer;
  margin-bottom: 5px;
  border: 1px solid #ddd;
}

.cerify-code-panel {
  height: 100%;
  overflow: hidden;
}

.verify-code-area {
  float: left;
}

.verify-input-area {
  float: left;
  width: 60%;
  padding-right: 10px;
}

.verify-change-area {
  line-height: 30px;
  float: left;
}

.varify-input-code {
  display: inline-block;
  width: 100%;
  height: 25px;
}

.verify-change-code {
  color: #337ab7;
  cursor: pointer;
}

.verify-btn {
  width: 200px;
  height: 30px;
  background-color: #337ab7;
  color: #ffffff;
  border: none;
  margin-top: 10px;
}

/*滑动验证码*/
.verify-bar-area {
  position: relative;
  background: var(--el-main-container-background);
  text-align: center;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  border-radius: 4px;
  box-sizing: border-box;
}

.verify-bar-area .verify-move-block {
  position: absolute;
  top: 0;
  background: var(--el-bg-color);
  cursor: pointer;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.2);
}

.verify-bar-area .verify-left-bar {
  position: absolute;
  top: 0;
  left: 0;
  background: var(--el-color-primary-light-7);
  cursor: pointer;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
}

.verify-img-panel {
  margin: 0;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  border: 1px solid #ddd;
  border-radius: 3px;
  position: relative;
  img {
    width: 100%;
    height: 100%;
    display: block;
    border-radius: 4px;
  }
}

.verify-img-panel .verify-refresh {
  width: 25px;
  height: 25px;
  text-align: center;
  padding: 5px;
  cursor: pointer;
  position: absolute;
  top: 0;
  right: 0;
  z-index: 2;
}

.verify-img-panel .icon-refresh {
  font-size: 20px;
  color: #fff;
}

.verify-img-panel .verify-gap {
  background-color: #fff;
  position: relative;
  z-index: 2;
  border: 1px solid #fff;
}

.verify-sub-block {
  position: absolute;
  text-align: center;
  z-index: 3;
  img {
    width: 100%;
    height: 100%;
    display: block;
    -webkit-user-drag: none;
    border: 1px solid var(--el-color-success);
    border-radius: 50%;
  }
}

.verify-bar-area .verify-move-block .verify-icon {
  font-size: 18px;
}

.verify-bar-area .verify-msg {
  z-index: 3;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.header-tip {
  color: var(--el-slide-menu-background);
  font-size: 16px;
}
</style>
