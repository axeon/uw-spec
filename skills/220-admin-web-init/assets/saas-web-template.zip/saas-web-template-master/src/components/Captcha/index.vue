<script setup lang="ts">
import { aesEncrypt, decrypt } from './utils'
import { type CaptchaQuestion } from '@/api/uwAuthCenterAuthApi'
import { useI18n } from 'vue-i18n'

type captchaForType =
  | 'StringCaptchaStrategy'
  | 'CalculateCaptchaStrategy'
  | 'ClickWordCaptchaStrategy'
  | 'SlidePuzzleCaptchaStrategy'
  | 'RotatePuzzleCaptchaStrategy'

// 滑动校验
const SliderCaptcha = defineAsyncComponent(() => import('./SliderCaptcha.vue'))
// 图片点击
const TextClickCaptcha = defineAsyncComponent(
  () => import('./TextClickCaptcha.vue')
)
// 图片输入
const ImageInputVerification = defineAsyncComponent(
  () => import('./ImageInputVerification.vue')
)
// 旋转校验
const RotateVerify = defineAsyncComponent(() => import('./RotateVerify.vue'))
const { t } = useI18n()
const props = withDefaults(
  defineProps<{
    show: boolean // 是否显示
    mode?: 'pop' | 'fixed' // pop弹窗  fixed 固定页面
    data: CaptchaQuestion // 校验相关信息
  }>(),
  {
    show: false,
    mode: 'fixed'
  }
)

const emit = defineEmits<{
  (e: 'update:show', val: boolean): void
  (e: 'refresh'): void
  (e: 'validate', val: string): void
}>()

// 控制组件的显示与隐藏
const isShow = computed({
  get: () => props.show,
  set: val => {
    emit('update:show', val)
  }
})

// 校验方式
const captchaType = ref<captchaForType>('StringCaptchaStrategy')

// 展示的组件
const componentName = toRaw({
  SlidePuzzleCaptchaStrategy: SliderCaptcha,
  ClickWordCaptchaStrategy: TextClickCaptcha,
  StringCaptchaStrategy: ImageInputVerification,
  CalculateCaptchaStrategy: ImageInputVerification,
  RotatePuzzleCaptchaStrategy: RotateVerify
})

// 相关属性
const attrs = computed(() => {
  if (
    captchaType.value === 'StringCaptchaStrategy' ||
    captchaType.value === 'CalculateCaptchaStrategy'
  ) {
    return {
      captchaType: captchaType.value
    }
  } else if (captchaType.value === 'ClickWordCaptchaStrategy') {
    return {
      pointTextList: pointTextList.value
    }
  } else if (captchaType.value === 'RotatePuzzleCaptchaStrategy') {
    return {
      blockBackImgBase: blockBackImgBase.value,
      rotatePoint: {
        x: rotatePoint.x,
        y: rotatePoint.y
      },
      explain: t('RotatePuzzleCaptchaStrategyTip')
    }
  }
  return {
    blockBackImgBase: blockBackImgBase.value,
    rotatePoint: {
      x: rotatePoint.x,
      y: rotatePoint.y
    },
    explain: t('SlidePuzzleCaptchaStrategyTip')
  }
})

// ref
const captchaRef = ref()
// 主要校验图
const imageCodeUrl = ref('')
// 图片点击需要点击的文字
const pointTextList = ref<string[]>([])
// 滑块检验需要检验的文字
const blockBackImgBase = ref<string>('')
// 加密密钥
const secretKey = ref<string>('')
// 旋转的图片圆心
const rotatePoint = reactive({
  x: 0,
  y: 0
})

// 校验id
const captchaId = ref<string>('')
// 发起请求
const getPicture = () => {
  if (props.data.captchaType === 'ClickWordCaptchaStrategy') {
    pointTextList.value = JSON.parse(
      decrypt(props.data.subData!, props.data.captchaId)
    )
    nextTick(() => {
      setTimeout(() => {
        captchaRef.value?.changeWord()
      })
    })
  }
  if (
    props.data.captchaType === 'StringCaptchaStrategy' ||
    props.data.captchaType === 'RotatePuzzleCaptchaStrategy'
  ) {
    blockBackImgBase.value = props.data.subImageBase64!
  }
  // 旋转角度 滑动
  if (
    props.data.captchaType === 'RotatePuzzleCaptchaStrategy' ||
    props.data.captchaType === 'SlidePuzzleCaptchaStrategy'
  ) {
    rotatePoint.x = JSON.parse(
      decrypt(props.data.subData!, props.data.captchaId)
    ).x
    rotatePoint.y = JSON.parse(
      decrypt(props.data.subData!, props.data.captchaId)
    ).y
  }
  // 滑块
  if (props.data.captchaType === 'SlidePuzzleCaptchaStrategy') {
    blockBackImgBase.value = props.data.subImageBase64!
  }
  imageCodeUrl.value = props.data.mainImageBase64!
  captchaId.value = props.data.captchaId!
  captchaType.value = props.data.captchaType as captchaForType
  secretKey.value = props.data.captchaId!
}

// 校验
const validate = (val: string) => {
  const target = JSON.parse(val)
  target.captchaType = props.data.captchaType as captchaForType
  const data = aesEncrypt(JSON.stringify(target), secretKey.value)
  emit('validate', data)
}

watch(
  () => props.data,
  val => {
    if (isShow.value && val) {
      getPicture()
    }
  },
  {
    immediate: true,
    deep: true
  }
)

defineExpose({
  validateSuccess: () => {
    captchaRef.value?.validateSuccess()
  },
  validateError: () => {
    captchaRef.value?.validateError()
  }
})
</script>

<template>
  <component
    v-if="isShow"
    :is="componentName[captchaType]"
    v-model:show="isShow"
    :mode="mode"
    :imgCodeForValidate="imageCodeUrl"
    v-bind="attrs"
    @refresh="emit('refresh')"
    @validate="validate"
    ref="captchaRef"
  ></component>
</template>

<style scoped lang="scss"></style>
