###### 组件属性

```typescript
modelValue?: number[] // 值
size?: 'small' | 'default' | 'large' // 尺寸
startPlaceholder?: string // 起始输入placeholder
endPlaceholder?: string // 结束输入placeholder
readonly?: boolean // 是否只读
disabled?: boolean // 是否禁用
to?: string // 至
precision?: number // 精度参数 -保留小数位数
valueRange?: number[] // 限制取值范围
slotStyle?: string // 插槽样式
```

###### 组件事件

```typescript
change: () => void                                                              // 组件搜索项发生改变时触发
```
