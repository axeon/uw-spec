import request from '@/utils/request'
import { ResponseData, DataList, ESDataList } from './uwAuthCenterAuthApi'

//修改用户
export const mchAccountUserUpdate = (
  data: MscUser,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<MscUser>> => {
  return request('/uw-auth-center/mch/account/user/update', {
    method: 'PUT',
    data,
    params
  })
}
//修改用户权限
export const mchAccountUserUpdatePerm = (params: {
  id: number // 用户ID
  userPerm: string // 用户权限ID列表
  userConfig: string // 用户配置信息列表
  remark: string // 备注
}): Promise<ResponseData<MscUserPerm>> => {
  return request('/uw-auth-center/mch/account/user/updatePerm', {
    method: 'PUT',
    params
  })
}
//重置用户密码
export const mchAccountUserResetPassword = (params: {
  loginAgent: string // 登录代理
  id: number // 平台管理员ID
  password: string // 密码
  remark: string // 备注
}): Promise<ResponseData<number>> => {
  return request('/uw-auth-center/mch/account/user/resetPassword', {
    method: 'PUT',
    params
  })
}
//启用用户
export const mchAccountUserEnable = (params: {
  loginAgent: string // 登录代理
  id: number // 用户ID
  remark: string // 备注
}): Promise<ResponseData<number>> => {
  return request('/uw-auth-center/mch/account/user/enable', {
    method: 'PUT',
    params
  })
}
//禁用用户
export const mchAccountUserDisable = (params: {
  loginAgent: string // 登录代理
  id: number // 用户ID
  remark: string // 备注
}): Promise<ResponseData<number>> => {
  return request('/uw-auth-center/mch/account/user/disable', {
    method: 'PUT',
    params
  })
}
//修改用户组
export const mchAccountGroupUpdate = (
  data: MscGroupUpdateRequest,
  params: {
    remark: string // 备注
  }
): Promise<ResponseData<MscUserGroup>> => {
  return request('/uw-auth-center/mch/account/group/update', {
    method: 'PUT',
    data,
    params
  })
}
//禁用用户组
export const mchAccountGroupDisable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/mch/account/group/disable', {
    method: 'PUT',
    params
  })
}
//新建用户
export const mchAccountUserSave = (
  data: MscUserRegister
): Promise<ResponseData<MscUser>> => {
  return request('/uw-auth-center/mch/account/user/save', {
    method: 'POST',
    data
  })
}
//新建用户组
export const mchAccountGroupSave = (
  data: MscUserGroup
): Promise<ResponseData<MscUserGroup>> => {
  return request('/uw-auth-center/mch/account/group/save', {
    method: 'POST',
    data
  })
}
//登录日志查询
export const mchLogLoginLogList = (
  params: MscLoginLogEsQueryParam
): Promise<ResponseData<ESDataList<MscLoginEsLog>>> => {
  return request('/uw-auth-center/mch/log/loginLog/list', {
    method: 'GET',
    params
  })
}
//关键日志查询
export const mchLogCritLogList = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/uw-auth-center/mch/log/critLog/list', {
    method: 'GET',
    params
  })
}
//操作日志查询
export const mchLogActionLogList = (
  params: MscActionEsLogQueryParam
): Promise<ResponseData<ESDataList<MscActionEsLog>>> => {
  return request('/uw-auth-center/mch/log/actionLog/list', {
    method: 'GET',
    params
  })
}
//校验用户名
export const mchAccountUserValidUsername = (params: {
  username: string // 用户名
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/mch/account/user/validUsername', {
    method: 'GET',
    params
  })
}
//获取用户类型配置
export const mchAccountUserUserTypeConfig = (params: {
  userType: number // 用户类型
}): Promise<ResponseData<UserTypeConfig>> => {
  return request('/uw-auth-center/mch/account/user/userTypeConfig', {
    method: 'GET',
    params
  })
}
//查看用户
export const mchAccountUserLoad = (params: {
  id: number // 用户ID
}): Promise<ResponseData<MscUser>> => {
  return request('/uw-auth-center/mch/account/user/load', {
    method: 'GET',
    params
  })
}
//查看用户权限
export const mchAccountUserLoadPerm = (params: {
  id: number // 用户ID
}): Promise<ResponseData<MscUserPerm>> => {
  return request('/uw-auth-center/mch/account/user/loadPerm', {
    method: 'GET',
    params
  })
}
//加载授权菜单
export const mchAccountUserLoadPermMenu = (params: {
  groupId: number // 组ID
}): Promise<ResponseData<Array<MscAppPermVo>>> => {
  return request('/uw-auth-center/mch/account/user/loadPermMenu', {
    method: 'GET',
    params
  })
}
//用户管理列表
export const mchAccountUserLiteList = (
  params: MscUserQueryParam
): Promise<ResponseData<DataList<MscUserInfo>>> => {
  return request('/uw-auth-center/mch/account/user/liteList', {
    method: 'GET',
    params
  })
}
//用户管理列表
export const mchAccountUserList = (
  params: MscUserQueryParam
): Promise<ResponseData<DataList<MscUserInfo>>> => {
  return request('/uw-auth-center/mch/account/user/list', {
    method: 'GET',
    params
  })
}
//查询数据历史
export const mchAccountUserListDataHistory = (
  params: SysDataHistoryQueryParam
): Promise<ResponseData<DataList<SysDataHistory>>> => {
  return request('/uw-auth-center/mch/account/user/listDataHistory', {
    method: 'GET',
    params
  })
}
//查询操作日志
export const mchAccountUserListCritLog = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/uw-auth-center/mch/account/user/listCritLog', {
    method: 'GET',
    params
  })
}
//查看用户组
export const mchAccountGroupLoad = (params: {
  id: number // 用户组ID
}): Promise<ResponseData<MscUserGroup>> => {
  return request('/uw-auth-center/mch/account/group/load', {
    method: 'GET',
    params
  })
}
//加载授权菜单
export const mchAccountGroupLoadPermMenu = (params: {
  userType: number // 用户类型
  mchId?: number // 商户ID
}): Promise<ResponseData<Array<MscAppPermVo>>> => {
  return request('/uw-auth-center/mch/account/group/loadPermMenu', {
    method: 'GET',
    params
  })
}
//用户组管理列表
export const mchAccountGroupLiteList = (
  params: MscUserGroupQueryParam
): Promise<ResponseData<DataList<MscUserGroup>>> => {
  return request('/uw-auth-center/mch/account/group/liteList', {
    method: 'GET',
    params
  })
}
//用户组管理列表
export const mchAccountGroupList = (
  params: MscUserGroupQueryParam
): Promise<ResponseData<DataList<MscUserGroup>>> => {
  return request('/uw-auth-center/mch/account/group/list', {
    method: 'GET',
    params
  })
}
//查询数据历史
export const mchAccountGroupListDataHistory = (
  params: SysDataHistoryQueryParam
): Promise<ResponseData<DataList<SysDataHistory>>> => {
  return request('/uw-auth-center/mch/account/group/listDataHistory', {
    method: 'GET',
    params
  })
}
//查询操作日志
export const mchAccountGroupListCritLog = (
  params: SysCritLogQueryParam
): Promise<ResponseData<DataList<SysCritLog>>> => {
  return request('/uw-auth-center/mch/account/group/listCritLog', {
    method: 'GET',
    params
  })
}
//删除用户
export const mchAccountUserDelete = (params: {
  loginAgent: string // 登录代理
  id: number // 用户ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/mch/account/user/delete', {
    method: 'DELETE',
    params
  })
}
//启用用户组
export const mchAccountGroupEnable = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/mch/account/group/enable', {
    method: 'DELETE',
    params
  })
}
//删除用户组
export const mchAccountGroupDelete = (params: {
  id: number // 主键ID
  remark: string // 备注
}): Promise<ResponseData<void>> => {
  return request('/uw-auth-center/mch/account/group/delete', {
    method: 'DELETE',
    params
  })
}

//MSC用户
export interface MscUser {
  id?: number //用户Id
  saasId?: number //运营商Id
  userType?: number //用户类型
  mchId?: number //商户编号
  groupId?: number //所属用户组ID
  isMaster?: number //是否管理员
  username?: string //登录名称
  password?: string //登录密码
  realName?: string //真实名称
  nickName?: string //别名 [用于业务前台匿名]
  mobile?: string //手机号码
  email?: string //email
  wxId?: string //微信ID
  gender?: number //性别-1未知0女1男
  areaCode?: number //地区
  idType?: number //证件类型
  idInfo?: string //证件信息
  userIcon?: string //用户头像
  userGrade?: number //用户级别
  authFlag?: number //验证标识
  authSecret?: string //验证密钥
  remark?: string //备注
  lastPasswdDate?: string //最后更新密码时间
  lastLogonType?: number //最后登录类型
  lastLogonDate?: string //最后登录时间
  lastLogonIp?: string //最后登录ip
  logonCount?: number //登录次数
  createDate?: string //创建日期
  modifyDate?: string //修改日期
  state?: number //状态：-1: 删除 0: 冻结 1: 正常
}
//MSC用户权限
export interface MscUserPerm {
  id?: number //id
  saasId?: number //saasId
  userPerm?: string //用户权限ID列表
  userConfig?: string //用户资源权限json
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态值: -1: 删除 0: 冻结 1: 正常
}
//用户组修改Vo
export interface MscGroupUpdateRequest {
  id?: number //主键
  mchId?: number //商户ID
  groupName?: string //分组名称
  groupDesc?: string //分组描述
  groupPerm?: string //分组默认权限
  groupConfig?: string //分组默认权限资源
  syncToUserPerm?: boolean //同步到用户权限
  syncToUserConfig?: boolean //同步到用户配置
}
//MSC用户组
export interface MscUserGroup {
  id?: number //主键
  saasId?: number //运营商编号。0为全局权限。
  mchId?: number //商户编号。0运营商1默认供应商2默认分销商
  userType?: number //用户类型
  groupName?: string //分组名称
  groupDesc?: string //分组描述
  groupPerm?: string //分组默认权限
  groupConfig?: string //分组默认配置
  userNum?: number //用户数
  createDate?: string //创建时间
  modifyDate?: string //修改时间
  state?: number //状态值: -1: 删除 0: 冻结 1: 正常
}
//
export interface MscUserRegister {
  id?: number //用户Id
  saasId?: number //运营商Id
  userType?: number //用户类型
  mchId?: number //商户编号
  groupId?: number //所属用户组ID
  isMaster?: number //是否管理员
  username?: string //登录名称
  password?: string //登录密码
  realName?: string //真实名称
  nickName?: string //别名 [用于业务前台匿名]
  mobile?: string //手机号码
  email?: string //email
  wxId?: string //微信ID
  gender?: number //性别-1未知0女1男
  areaCode?: number //地区
  idType?: number //证件类型
  idInfo?: string //证件信息
  userIcon?: string //用户头像
  userGrade?: number //用户级别
  remark?: string //备注
  userPerm?: string //用户权限ID列表
  userConfig?: string //用户资源权限json
}
//用户登录日志查询参数
export interface MscLoginLogEsQueryParam {
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  appInfo?: string //App信息
  appHost?: string //App主机
  loginAgent?: string //登录代理
  loginType?: number //登录类型
  loginId?: string //登录标识
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //操作人ip
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMillisRange?: Array<number> //请求毫秒数范围
  loginDateRange?: Array<string> //登录时间范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//用户登录ES日志
export interface MscLoginEsLog {
  appInfo?: string //App信息
  appHost?: string //App主机
  loginAgent?: string //登录客户端
  loginType?: number //登录类型
  loginId?: string //登录标识
  userId?: number //用户Id
  userName?: string //用户信息
  nickName?: string //昵称信息
  realName?: string //真实姓名
  saasId?: number //运营商Id
  mchId?: number //商户Id
  groupId?: number //用户组Id
  userType?: number //用户类型
  userIp?: string //登录IP
  clientType?: number //登录设备
  clientAgent?: string //用户代理
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMsg?: string //响应消息
  loginDate?: string //登录时间
  responseMillis?: number //响应毫秒数
}
//系统关键日志列表查询参数
export interface SysCritLogQueryParam {
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  id?: number //ID
  ids?: Array<number> //数组ID
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //用户ip
  apiUri?: string //请求uri
  apiName?: string //API名称
  bizType?: string //业务类型
  bizId?: string //业务ID
  requestDateRange?: Array<string> //请求时间范围
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMillis?: number //请求毫秒数
  responseMillisRange?: Array<number> //请求毫秒数范围
  statusCode?: number //响应状态码
  statusCodeRange?: Array<number> //响应状态码范围
  appInfo?: string //应用信息
  appHost?: string //应用主机
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//系统关键日志
export interface SysCritLog {
  id?: number //ID
  saasId?: number //saasId
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //用户ip
  apiUri?: string //请求uri
  apiName?: string //API名称
  bizType?: string //业务类型
  bizId?: string //业务ID
  bizLog?: string //业务日志
  requestDate?: string //请求时间
  requestBody?: string //请求参数
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMsg?: string //响应消息
  responseBody?: string //响应日志
  responseMillis?: number //请求毫秒数
  statusCode?: number //响应状态码
  appInfo?: string //应用信息
  appHost?: string //应用主机
}
//用户操作日志查询参数
export interface MscActionEsLogQueryParam {
  mchId?: number //商户ID
  userId?: number //用户id
  userType?: number //用户类型
  appInfo?: string //应用信息
  appHost?: string //应用主机
  groupId?: number //用户组ID
  userName?: string //用户名
  nickName?: string //用户昵称
  realName?: string //真实名称
  userIp?: string //操作人ip
  bizType?: string //操作对象类型
  bizId?: string //操作对象id
  apiUri?: string //请求uri
  apiName?: string //API名称
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMillisRange?: Array<number> //请求毫秒数范围
  statusCode?: number //响应状态码
  statusCodeRange?: Array<number> //响应状态码范围
  requestDateRange?: Array<string> //创建时间范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//用户操作ES日志
export interface MscActionEsLog {
  appInfo?: string //App信息
  appHost?: string //App主机
  saasId?: number //运营商Id
  mchId?: number //商户Id
  userId?: number //用户Id
  userType?: number //用户类型
  groupId?: number //用户组Id
  userName?: string //用户信息
  nickName?: string //昵称信息
  realName?: string //真实姓名
  userIp?: string //用户IP
  apiUri?: string //API URI
  apiName?: string //API名称
  bizType?: string //业务类型
  bizId?: any //业务Id
  bizLog?: string //业务日志
  requestBody?: string //请求参数
  requestDate?: string //请求时间
  responseBody?: string //响应日志
  responseState?: string //响应状态
  responseCode?: string //响应代码
  responseMsg?: string //响应消息
  responseMillis?: number //执行返回毫秒数
  statusCode?: number //响应状态码
}
//数据
export interface UserTypeConfig {
  tokenExpire?: any //
  tokenRefreshExpire?: any //
  tokenTempExpire?: any //
  tokenSudoExpire?: any //
  passwordConfig?: string //登录类型
  loginTypes?: Array<string> //
  mfaTypes?: Array<string> //
}
//MSC菜单权限Vo
export interface MscAppPermVo {
  id?: number //应用Id
  appName?: string //应用唯一名称
  appVersion?: string //应用版本
  appLabel?: string //应用名称
  appRank?: number //应用显示顺序[ASC]
  lastUpdate?: string //最后更新时间
  displayState?: number //显示状态
  permVoList?: Array<PermVo> //菜单树列表
}
//菜单树列表
export interface PermVo {
  id?: number //id
  permCode?: string //权限菜单URI
  permName?: string //权限菜单名称
  permRank?: number //菜单排序
  licenseCode?: string //许可代码
  displayState?: number //1:显示,0:隐藏
}
//MSC用户列表查询参数
export interface MscUserQueryParam {
  mchId?: number //商户编号
  userType?: number //用户类型
  id?: number //用户Id
  ids?: Array<number> //ID数组
  groupId?: number //所属用户组ID
  isMaster?: number //是否管理员
  isMasterRange?: Array<number> //是否管理员范围
  username?: string //登录名称
  password?: string //登录密码
  realName?: string //真实名称
  nickName?: string //别名 [用于业务前台匿名]
  mobile?: string //手机号码
  email?: string //email
  wxId?: string //微信ID
  gender?: number //性别-1未知0女1男
  genderRange?: Array<number> //性别-1未知0女1男范围
  areaCode?: number //地区
  areaCodeRange?: Array<number> //地区范围
  idType?: number //证件类型
  idInfo?: string //证件信息
  userIcon?: string //用户头像
  userGrade?: number //用户级别
  userGradeRange?: Array<number> //用户级别范围
  authFlag?: number //验证标识
  authFlagRange?: Array<number> //验证标识范围
  authSecret?: string //验证密钥
  remark?: string //备注
  lastPasswdDateRange?: Array<string> //最后更新密码时间范围
  lastLogonType?: number //最后登录类型
  lastLogonDateRange?: Array<string> //最后登录时间范围
  lastLogonIp?: string //最后登录ip
  logonCount?: number //登录次数
  logonCountRange?: Array<number> //登录次数范围
  createDateRange?: Array<string> //创建日期范围
  modifyDateRange?: Array<string> //修改日期范围
  state?: number //状态：-1: 删除 0: 冻结 1: 正常
  states?: Array<number> //状态：-1: 删除 0: 冻结 1: 正常数组
  stateGte?: number //大于等于状态：-1: 删除 0: 冻结 1: 正常
  stateLte?: number //小于等于状态：-1: 删除 0: 冻结 1: 正常
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//MSC用户信息
export interface MscUserInfo {
  id?: number //用户Id
  saasId?: number //运营商Id
  userType?: number //用户类型
  mchId?: number //商户编号
  groupId?: number //用户组ID
  groupName?: string //用户组名
  isMaster?: number //是否管理员
  username?: string //登录名称
  realName?: string //真实名称
  nickName?: string //别名 [用于业务前台匿名]
  mobile?: string //手机号码
  email?: string //email
  wxId?: string //微信ID
  gender?: number //性别-1未知0女1男
  areaCode?: number //地区
  idType?: number //证件类型
  idInfo?: string //证件信息
  userIcon?: string //用户头像
  userGrade?: number //用户级别
  authFlag?: number //验证标记
  remark?: string //备注
  lastPasswdDate?: string //最后更新密码时间
  lastLogonDate?: string //最后登录时间
  lastLogonIp?: string //最后登录ip
  logonCount?: number //登录次数
  createDate?: string //创建日期
  modifyDate?: string //修改日期
  state?: number //状态：-1: 删除 0: 冻结 1: 正常
}
//系统数据历史列表查询参数
export interface SysDataHistoryQueryParam {
  mchId?: number //商户ID
  userId?: number //用户ID
  userType?: number //用户类型
  id?: number //ID
  ids?: Array<number> //数组ID
  groupId?: number //用户的组ID
  userName?: string //用户名称
  nickName?: string //用户昵称
  realName?: string //真实名称
  entityClass?: string //实体类
  entityId?: string //实体ID
  entityName?: string //实体名
  userIp?: string //用户IP
  createDateRange?: Array<string> //创建日期范围
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
//系统数据历史
export interface SysDataHistory {
  id?: number //ID
  saasId?: number //saasId
  mchId?: number //商户ID
  userId?: number //用户ID
  userType?: number //用户类型
  groupId?: number //用户的组ID
  userName?: string //用户名称
  nickName?: string //用户昵称
  realName?: string //真实名称
  entityClass?: string //实体类
  entityId?: string //实体ID
  entityName?: string //实体名
  entityData?: string //实体数据
  entityUpdateInfo?: string //实体修改信息
  remark?: string //备注信息
  userIp?: string //用户IP
  createDate?: string //创建日期
}
//MSC用户组列表查询参数
export interface MscUserGroupQueryParam {
  mchId?: number //商户编号。0运营商1默认供应商2默认分销商
  userType?: number //用户类型
  id?: number //主键
  ids?: Array<number> //ID数组
  groupName?: string //分组名称
  groupDesc?: string //分组描述
  userNum?: number //用户数
  userNumRange?: Array<number> //用户数范围
  createDateRange?: Array<string> //创建时间范围
  modifyDateRange?: Array<string> //修改时间范围
  state?: number //状态值: -1: 删除 0: 冻结 1: 正常
  states?: Array<number> //状态值: -1: 删除 0: 冻结 1: 正常数组
  stateGte?: number //大于等于状态值: -1: 删除 0: 冻结 1: 正常
  stateLte?: number //小于等于状态值: -1: 删除 0: 冻结 1: 正常
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序名称
}
