import request from '@/utils/request'
import { ResponseData } from './uwAuthCenterAuthApi'

//发送手机验证码
export const openRegistrySendDeviceCode = (params: {
  mobile: string //
  captchaId: string //
  captchaSign: string //
}): Promise<ResponseData<void>> => {
  return request('/saas-base-app/open/registry/sendDeviceCode', {
    method: 'POST',
    params
  })
}
//SAAS账号注册
export const openRegistrySave = (
  data: SaasRegistryParam,
  params: {
    deviceCode: string // 手机验证码
  }
): Promise<ResponseData<void>> => {
  return request('/saas-base-app/open/registry/save', {
    method: 'POST',
    data,
    params
  })
}
//
export const openSeqTest = (params: {
  saasId: number //
  productType: number //
}): Promise<ResponseData<string>> => {
  return request('/saas-base-app/open/seq/test', {
    method: 'GET',
    params
  })
}
//生成CAPTCHA
export const openRegistryGenCaptcha = (params: {
  captchaId?: string //
}): Promise<ResponseData<CaptchaQuestion>> => {
  return request('/saas-base-app/open/registry/genCaptcha', {
    method: 'GET',
    params
  })
}
//获取所有枚举
export const openEnumGetAllEnumMap = (): Promise<
  ResponseData<Record<string, any>>
> => {
  return request('/saas-base-app/open/enum/getAllEnumMap', {
    method: 'GET'
  })
}

//运营商注册信息
export interface SaasRegistryParam {
  id?: number //运营商ID
  saasName?: string //运营商名称
  orgType?: number //组织类型
  areaCode?: number //区域编码
  orgName?: string //公司名称
  contactName?: string //公司联系人姓名
  contactPhone?: string //公司联系电话
  contactMobile?: string //公司联系手机
  contactEmail?: string //公司联系邮箱
  adminPasswd?: string //管理员登录密码
}
//captcha问题信息
export interface CaptchaQuestion {
  captchaId?: string //captchaId
  captchaTTL?: number //captcha有效期
  captchaType?: string //captcha类型
  mainImageBase64?: string //原生图片base64
  subImageBase64?: string //拼图图片base64
  subData?: string //附加数据
}
