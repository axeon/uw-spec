import { onMounted, onUnmounted } from 'vue'

// usePostMessage通信
interface postMessageReturn {
  postMessage: (data?: any) => void
}

/**
 * 用于不同页面间通信
 * @param key 唯一标识符号，用于不同页面间通信标识，通常用一方的routeName作为
 * @param callback 接受收到消息后执行的回调
 * @returns
 */
export const usePostMessage = (
  key: string | number,
  callback?: (val: any) => void
): postMessageReturn => {
  // 事件处理
  const handleEvent = (event: MessageEvent) => {
    if (event.data[0] === key) {
      callback && callback(event.data[1])
    }
  }
  //  发送消息
  const postMessage = (data?: any): void => {
    window.postMessage([key, data])
  }
  onMounted(() => {
    callback && window.addEventListener('message', handleEvent)
  })
  onUnmounted(() => {
    callback && window.removeEventListener('message', handleEvent)
  })
  return {
    postMessage
  }
}
