import { computed, onDeactivated, onUnmounted, ref } from 'vue'
import { useRoute } from 'vue-router'
interface PollingOptions {
  times?: number // 轮询次数，默认无限制
  interval: number // 轮询间隔时间，单位ms
}

type PollingCallback = () => Promise<boolean> // 回调函数返回Promise<boolean>类型

/**
 * 轮询hooks
 * @param callback 传入一个promise 回调  resolve(true) 接着轮询  resolve(false) 停止轮询
 * @param options times 轮询次数，默认不传无限制  interval 轮询间隔，默认不转500ms
 */
export const usePolling = (
  callback: PollingCallback, // true接着轮询， false停止轮询
  options: PollingOptions
): {
  startPolling: () => void // 开始轮询
  stopPolling: () => void // 停止轮询
  restartPolling: () => void
} => {
  const { times = Infinity, interval = 500 } = options

  const route = useRoute()
  //  是否是具有缓存的
  const isKeepAlive = computed(() => {
    return route.meta.keepAlive
  })

  let timerId: ReturnType<typeof setTimeout> = 0 // 定时器ID
  const isPolling = ref(false) // 是否正在轮询
  const remainingTimes = ref(times) // 最大可轮询次数

  // 开始轮询
  const startPolling = () => {
    if (isPolling.value) return
    isPolling.value = true
    timerId = setTimeout(async () => {
      try {
        if (remainingTimes.value !== Infinity) {
          // 有最大轮询次数限制
          remainingTimes.value--
        }
        const shouldContinue = await callback()
        // 正在轮询状态改为false
        isPolling.value = false
        if (remainingTimes.value !== Infinity) {
          // 有最大轮询次数限制
          if (shouldContinue && remainingTimes.value >= 0) {
            // 需要接着轮询，并且还没超过最大轮询次数
            startPolling()
          } else {
            // 不需要接着轮询
            stopPolling()
          }
        } else {
          // 轮询次数不限制
          if (shouldContinue) {
            startPolling()
          } else {
            stopPolling()
          }
        }
      } catch (error) {
        console.error(error)
        stopPolling()
      }
    }, interval)
  }

  // 停止轮询
  const stopPolling = () => {
    timerId && clearTimeout(timerId)
    isPolling.value = false
    remainingTimes.value = times
  }

  // 重启轮询
  const restartPolling = () => {
    stopPolling()
    startPolling()
  }

  // 在组件销毁时自动停止轮询
  onUnmounted(() => stopPolling())
  // 判断是否具有缓存
  if (isKeepAlive.value) {
    // 页面路由有缓存时,
    onDeactivated(() => {
      stopPolling()
    })
  }
  return {
    startPolling,
    stopPolling,
    restartPolling
  }
}
