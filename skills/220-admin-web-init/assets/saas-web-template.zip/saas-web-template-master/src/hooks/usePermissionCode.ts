import { computed } from 'vue'
import { useRoute } from 'vue-router'
/**
 * 依据当前的页面，传入对应的接口权限字段，返回对应的permCode
 * @param currentPageValue 当前页面的接口权限字段 eg: 当前页面为部署方案管理界面  接口：/ops/deploy/plan/save:POST 保存部署方案, 校验使用 usePermissionCode('save')
 * @param otherPageValue 当前页面想获取其他页面的权限控制 eg: 当前页面为部署方案管理界面，在当前页面想获取部署环境管理的数据 /uwOpsCenter/ops/deploy/profile/list:GET, 校验使用 usePermissionCode('', '/uwOpsCenter/ops/deploy/profile/list')
 * @returns
 */
export const usePermissionCode = (
  currentPageValue: string,
  otherPageValue = ''
) => {
  const route = useRoute()
  // permission前缀
  const permissionKey = computed(() => {
    return route.path
  })
  if (otherPageValue) {
    // 控制非当前页面的权限
    return otherPageValue
  }
  return permissionKey.value + '/' + currentPageValue
}
