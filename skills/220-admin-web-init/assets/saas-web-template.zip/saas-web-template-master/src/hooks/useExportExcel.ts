import { computed, onUnmounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import { useMainStore } from '@/store/main'
import { type ResponseData } from '@/api/uwAuthCenterAuthApi'
import request from '@/utils/request'
import dayjs from 'dayjs'
import { sleep } from '@/utils/tool'
import * as XLSX from 'xlsx-js-style'
import * as FileSaver from 'file-saver'

// 导出excel参数
interface exportExcelType {
  url?: string // 请求地址
  queryParams?: queryParamsType // 请求参数数据
  sourceData?: Array<Record<string, any>> // 源数据， 传入该属性，不会调用请求接口, 直接用传进来的数据进行渲染
  columns: Column[] // 表头
  sizeAll: number // 条数
  fileName?: string // 文件名 默认取当前菜单名称
  isDataWithoutResults?: boolean // 是数据源返回结果是否带分页数据 默认false
  merges?: Array<mergeDataType> // 表头合并
  headers?: Array<Array<string>> // 自定义表头
  headerStyle?: Record<string, any> // 表头样式
  specifyColumnRowCellMerges?: number[] // 指定第几列行单元格内容相同的进行合并  列数索引从0开始
  specifyMergeField?: string // 用于specifyColumnRowCellMerges合并时，判断是否要specifyMergeField值相同且对应的内容也相同才合并，如果不传则行内同相同则直接合并
}

// 请求参数
interface queryParamsType extends baseListType {
  [key: string]: any
}

// 基本分页信息
interface baseListType {
  state?: number //状态
  $pg?: number //当前页码
  $rn?: number //每页条数
  $si?: number //起始位置
  $rt?: number //请求类型
  $sn?: Array<string> //排序名称
  $st?: Array<number> //排序类型
  stateGte?: number // 取state >=0  默认取0
}

// 列信息
interface Column {
  field: string // 对应请求结果返回的key
  label: string // 列名
  options?: Array<{
    label: string // 显示名称
    value: string | number // value值
  }>
  width?: number // 列宽
  valueFormat?: string // 'YYYY-MM-DD HH:mm:ss' | 'YYYY-MM-DD' // 时间格式化日期
  formatCallBack?: (
    value: any,
    rows: Record<string, any>,
    rowIndex: number
  ) => string // 自行处理的回调，优先级最高
}

// 合并的格式类型
interface mergeDataType {
  s: {
    r: number
    c: number
  }
  e: {
    r: number
    c: number
  }
}

/**
 * 导出Excel的钩子函数
 * @returns 返回包含开始导出和销毁导出线程的方法的对象
 */
export const useExportExcel = () => {
  // 使用主存储库以获取全局状态
  const mainStore = useMainStore()
  // 国际化支持，用于获取当前语言环境下的文本
  const { t } = useI18n()
  // 获取当前路由信息
  const routePath = location.hash.replace(/^#/, '').replace(/\?.+/g, '')
  // 进度条展示状态
  const showProgress = computed(() => mainStore.showProgress)
  // 参数
  const argumentsData = ref<exportExcelType>({
    url: '',
    queryParams: {},
    sizeAll: 0,
    columns: []
  })
  // 定时器
  let timer = 0

  // 开始导出
  const startExport = async (data: exportExcelType) => {
    argumentsData.value = data
    if (data.sizeAll === 0) {
      ElMessage.error(t('暂无数据导出！！'))
    } else {
      if (data.sourceData && data.sourceData?.length) {
        // 存在手动传入的源数据，直接不调用接口，直接渲染
        // 设置初始化进度
        handleExportLoading(30)
        mainStore.setAllDownloaded(data.sizeAll)
        processData(data.sourceData, data.columns)
      } else {
        if (data.isDataWithoutResults) {
          // 设置初始化进度
          handleExportLoading(0)
          mainStore.setAllDownloaded(data.sizeAll)
          handleRequestByWithoutResults(data)
        } else {
          if (data.sizeAll > 0 && data.sizeAll <= 1000) {
            // 设置初始化进度
            handleExportLoading(0)
            mainStore.setAllDownloaded(data.sizeAll)
            handleRequestBySmallData(data)
          } else {
            // 设置初始化进度
            handleExportLoading(0)
            mainStore.setAllDownloaded(data.sizeAll)
            handleRequestByBigData(data)
          }
        }
      }
    }
  }

  // 处理进度
  const handleExportLoading = (progressValue: number) => {
    if (!showProgress.value) {
      mainStore.setShowProgress(true)
    }
    mainStore.setProgressValue(Number(progressValue))
    mainStore.setAlreadyDownloaded(
      Math.ceil((Number(progressValue) / 100) * argumentsData.value.sizeAll)
    )
  }

  // 处理数据返回层只有到data没有深层results情况
  const handleRequestByWithoutResults = async (data: exportExcelType) => {
    try {
      // 模拟进度
      handleExportLoading(80)
      const res = await request<ResponseData<any>>(data.url!, {
        method: 'get',
        params: data.queryParams
      })
      if (res.state === 'success') {
        // 处理数据
        processData(res.data as Array<Record<string, any>>, data.columns)
      } else {
        ElMessage.error('数据异常，导出失败！！')
        closeProgress()
      }
    } catch (error) {
      console.log(error)
      ElMessage.error('导出失败！！')
      closeProgress()
    } finally {
      // 模拟进度
      handleExportLoading(100)
    }
  }

  // 处理不足1000条数据的情况
  const handleRequestBySmallData = async (data: exportExcelType) => {
    try {
      // 模拟进度
      handleExportLoading(80)
      const res = await request<ResponseData<any>>(data.url!, {
        method: 'get',
        params: {
          ...data.queryParams,
          $rt: 1,
          $pg: 1,
          $sn: 'id',
          $rn: data.sizeAll
        }
      })
      if (res.state === 'success') {
        // 处理数据
        processData(
          res.data.results as Array<Record<string, any>>,
          data.columns
        )
      } else {
        ElMessage.error('数据异常，导出失败！！')
        closeProgress()
      }
    } catch (error) {
      console.log(error)
      ElMessage.error(t('导出失败！！'))
      closeProgress()
    } finally {
      // 模拟进度
      handleExportLoading(100)
    }
  }

  // 处理超过1000条数据的情况
  const handleRequestByBigData = async (data: exportExcelType) => {
    // 请求是否发生错误
    let isError = false
    // 数据结果
    let results: Array<Record<string, any>> = []
    // 总页数
    const pageNum = Math.ceil(data.sizeAll / 1000)
    // 进度单位
    const progressStep = Number((95 / pageNum).toFixed(2))
    for (let i = 1; i <= pageNum; i++) {
      try {
        // eslint-disable-next-line no-await-in-loop
        await sleep(100) // 每次请求前等待 50ms
        // eslint-disable-next-line no-await-in-loop
        const res = await request<ResponseData<any>>(data.url!, {
          method: 'get',
          params: {
            ...data.queryParams,
            $rt: 1,
            $pg: i,
            $sn: 'id',
            $rn: 1000
          }
        })
        if (res.state === 'success') {
          results = results.concat(
            res.data.results as Array<Record<string, any>>
          )
        } else {
          isError = true
          break
        }
      } catch (error) {
        console.log(error)
        isError = true
        break
      } finally {
        handleExportLoading(Math.ceil(progressStep * i))
      }
    }
    if (isError) {
      ElMessage.error(t('导出失败!'))
      closeProgress()
    } else {
      processData(results as Array<Record<string, any>>, data.columns)
    }
  }

  /**
   * 将数字索引转换为Excel风格的列标（如 0→"A1", 26→"AA1"）
   * @param {number} index - 从0开始的列索引
   * @param {number} [row=1] - 行号，默认为1
   * @returns {string} Excel风格列标（如 "A1", "AB42"）
   */
  const getExcelColumnLabel = (index: number, row = 1) => {
    let colLabel = ''
    let n = index
    do {
      colLabel = String.fromCharCode(65 + (n % 26)) + colLabel
      n = Math.floor(n / 26) - 1
    } while (n >= 0)
    return `${colLabel}${row}`
  }

  // 依照数据处理成excel
  const processData = (
    data: Array<Record<string, any>>,
    columns: Array<Column>
  ) => {
    const result: Array<Record<string, any>> = []
    // 列宽
    const widthColumns: Array<{
      wch: number
    }> = []
    try {
      // 是否存在自定义表头，存在则其实行索引则不是0, 默认单表头，则其实索引是1
      let startRowIndex = 1
      if (argumentsData.value.headers?.length) {
        // 存在自定义表头，则索引为表头数量
        startRowIndex = argumentsData.value.headers?.length
      }
      // 指定第几列行单元格内容对象
      const rowCellObj: Record<string, any> = {}
      // 判断对比值
      let specifyFieldLabel = ''
      if (argumentsData.value.specifyMergeField) {
        specifyFieldLabel =
          columns.find(
            item => item.field === argumentsData.value.specifyMergeField
          )?.label || ''
      }
      data.forEach((item, index) => {
        const obj: Record<string, any> = {}
        columns.forEach((column, columnIndex) => {
          // 处理值长度限制
          let cellValue = ''
          // 有值
          if (item && (item[column.field] || item[column.field] === 0)) {
            if (column.formatCallBack) {
              cellValue = column.formatCallBack(item[column.field], item, index)
            } else {
              if (column.options?.length) {
                cellValue =
                  column.options.find(
                    option => option.value === item[column.field]
                  )?.label || ''
              } else if (column.valueFormat) {
                cellValue = column.field
                  ? dayjs(item[column.field]).format(column.valueFormat)
                  : ''
              } else {
                cellValue = item[column.field]
              }
            }
          } else {
            // 没有值，也给出来吧，防止排序异常
            obj[column.label] = ''
          }
          // ✅ 截断超长文本
          const MAX_LENGTH = 32767
          if (typeof cellValue === 'string' && cellValue.length > MAX_LENGTH) {
            cellValue = cellValue.substring(0, MAX_LENGTH)
          }
          obj[column.label] = cellValue
          // 这里判断单元格合并
          if (argumentsData.value?.specifyColumnRowCellMerges?.length) {
            if (
              argumentsData.value.specifyColumnRowCellMerges.includes(
                columnIndex
              )
            ) {
              // 当前label
              // 是否存在指定字段，即不但判断行内容相同还要求指定字段的值相同
              if (argumentsData.value.specifyMergeField) {
                if (index === 0) {
                  rowCellObj[columnIndex] = {
                    oldRowSpan: startRowIndex + index,
                    newRowSpan: undefined,
                    value: obj[column.label],
                    specifyFieldValue:
                      obj[specifyFieldLabel] ||
                      item[argumentsData.value.specifyMergeField]
                  }
                } else {
                  // 旧值
                  const oldValue = rowCellObj[columnIndex].value
                  // 新旧值对比
                  const isSame = oldValue === obj[column.label]
                  // 指定字段的旧值
                  const oldSpecifyFieldValue =
                    rowCellObj[columnIndex].specifyFieldValue
                  // 指定字段新旧值对比
                  // 新值优先拿取处理后的值（obj）, 没有拿取源数据中的值
                  const isSpecifyFieldSame =
                    oldSpecifyFieldValue ===
                    (obj[specifyFieldLabel] ||
                      item[argumentsData.value.specifyMergeField])
                  if (isSame && isSpecifyFieldSame) {
                    // 新旧值值相同，新索引改变
                    rowCellObj[columnIndex].newRowSpan = startRowIndex + index
                  } else {
                    // 值不同
                    // 如果不相同，且索引相差不是1，则添加合并值
                    const oldIndex = rowCellObj[columnIndex].newRowSpan
                    const newIndex = startRowIndex + index
                    if (newIndex - oldIndex === 1) {
                      if (argumentsData.value?.merges?.length) {
                        argumentsData.value.merges.push({
                          s: {
                            r: rowCellObj[columnIndex].oldRowSpan,
                            c: columnIndex
                          },
                          e: {
                            r: oldIndex,
                            c: columnIndex
                          }
                        })
                      } else {
                        // 且不存在，传入的合并值，则手动新增
                        argumentsData.value.merges = [
                          {
                            s: {
                              r: rowCellObj[columnIndex].oldRowSpan,
                              c: columnIndex
                            },
                            e: {
                              r: oldIndex,
                              c: columnIndex
                            }
                          }
                        ]
                      }
                      // 更新对比对象
                      rowCellObj[columnIndex] = {
                        oldRowSpan: startRowIndex + index,
                        newRowSpan: undefined,
                        value: obj[column.label],
                        specifyFieldValue:
                          obj[specifyFieldLabel] ||
                          item[argumentsData.value.specifyMergeField]
                      }
                    } else {
                      // 索引相差不是1，则继续更新
                      rowCellObj[columnIndex] = {
                        oldRowSpan: startRowIndex + index,
                        newRowSpan: undefined,
                        value: obj[column.label],
                        specifyFieldValue:
                          obj[specifyFieldLabel] ||
                          item[argumentsData.value.specifyMergeField]
                      }
                    }
                  }
                }
              } else {
                // 只要求对应列中的行内容相同即可
                if (index === 0) {
                  rowCellObj[columnIndex] = {
                    oldRowSpan: startRowIndex + index,
                    newRowSpan: undefined,
                    value: obj[column.label]
                  }
                } else {
                  // 旧值
                  const oldValue = rowCellObj[columnIndex].value
                  // 新旧值对比
                  const isSame = oldValue === obj[column.label]
                  if (isSame) {
                    // 值相同，新索引改变
                    rowCellObj[columnIndex].newRowSpan = startRowIndex + index
                  } else {
                    // 值不同
                    // 如果不相同，且索引相差不是1，则添加合并值
                    const oldIndex = rowCellObj[columnIndex].newRowSpan
                    const newIndex = startRowIndex + index
                    if (newIndex - oldIndex === 1) {
                      if (argumentsData.value?.merges?.length) {
                        argumentsData.value.merges.push({
                          s: {
                            r: rowCellObj[columnIndex].oldRowSpan,
                            c: columnIndex
                          },
                          e: {
                            r: oldIndex,
                            c: columnIndex
                          }
                        })
                      } else {
                        // 且不存在，传入的合并值，则手动新增
                        argumentsData.value.merges = [
                          {
                            s: {
                              r: rowCellObj[columnIndex].oldRowSpan,
                              c: columnIndex
                            },
                            e: {
                              r: oldIndex,
                              c: columnIndex
                            }
                          }
                        ]
                      }
                      // 更新对比对象
                      rowCellObj[columnIndex] = {
                        oldRowSpan: startRowIndex + index,
                        newRowSpan: undefined,
                        value: obj[column.label]
                      }
                    } else {
                      // 索引相差不是1，则继续更新
                      rowCellObj[columnIndex] = {
                        oldRowSpan: startRowIndex + index,
                        newRowSpan: undefined,
                        value: obj[column.label]
                      }
                    }
                  }
                }
              }
            }
          }
        })
        result.push(obj)
      })
      if (argumentsData.value?.specifyColumnRowCellMerges?.length) {
        argumentsData.value = { ...argumentsData.value }
      }
      // 给宽度
      columns.forEach(column => {
        let width = 8
        if (!column.width) {
          const target = result[0]
          if (target && target[column.label]) {
            width +=
              target[column.label]?.length > column.label?.length
                ? target[column.label]?.length
                : column.label?.length
          } else {
            // 拿取前10个值中的length
            let maxWidth = 0
            for (let index = 1; index <= 10; index++) {
              if (result[index] && result[index][column.label]) {
                const currentWidth = result[index][column.label]?.length
                maxWidth = maxWidth > currentWidth ? maxWidth : currentWidth
              } else if (index === 10) {
                width +=
                  maxWidth > column.label?.length
                    ? maxWidth
                    : column.label?.length
              }
            }
          }
        }
        widthColumns.push({
          wch: column?.width || width
        })
      })

      // 默认表头样式
      // 获取所有表头
      const headersStyleCode: string[] = []
      // 1. 初始化空工作表
      const ws = XLSX.utils.aoa_to_sheet([])
      // 如果存在自定义表头
      if (argumentsData.value.headers) {
        // 添加自定义表头
        argumentsData.value.headers.forEach((item, index) => {
          XLSX.utils.sheet_add_aoa(ws, [item], { origin: `A${index + 1}` })
          // 如果存在自定义样式
          item.forEach((subItem, subIndex) => {
            headersStyleCode.push(`${getExcelColumnLabel(subIndex, index + 1)}`)
          })
        })
      } else {
        // 使用默认表头
        XLSX.utils.sheet_add_aoa(ws, [columns.map(item => item.label)], {
          origin: 'A1'
        })
        // 如果存在自定义样式
        columns.forEach((item, index) => {
          // headersStyleCode.push(`${String.fromCharCode(65 + index)}1`)
          headersStyleCode.push(`${getExcelColumnLabel(index)}`)
        })
      }
      // 赋值
      XLSX.utils.sheet_add_aoa(
        ws,
        result.map(item => Object.values(item)),
        {
          origin: argumentsData.value.headers
            ? `A${argumentsData.value.headers.length + 1}`
            : 'A2'
        }
      )
      // 自定义表头样式
      if (headersStyleCode.length) {
        if (argumentsData.value.headerStyle) {
          headersStyleCode.forEach(code => {
            ws[code].s = argumentsData.value.headerStyle
          })
        } else {
          headersStyleCode.forEach(code => {
            ws[code].s = {
              font: { bold: true },
              fill: { fgColor: { rgb: 'c0c0c0' } },
              alignment: {
                vertical: 'center' // 垂直居中
              }
            }
          })
        }
      }
      // 宽度赋值
      ws['!cols'] = widthColumns
      // 存在合并单元格
      if (argumentsData.value.merges?.length) {
        ws['!merges'] = argumentsData.value.merges
        // 处理合并后的居中
        argumentsData.value.merges.forEach(item => {
          // 获取字母， 例如A1 B2
          const letter = getExcelColumnLabel(item.s.c)
          if (ws[letter]?.s) {
            ws[letter].s = {
              ...ws[letter].s,
              alignment: {
                vertical: 'center' // 垂直居中
              }
            }
          } else {
            ws[letter].s = {
              alignment: {
                vertical: 'center' // 垂直居中
              }
            }
          }
        })
      }
      const wb = XLSX.utils.book_new()
      XLSX.utils.book_append_sheet(wb, ws, 'Data')
      const excelBuffer = XLSX.write(wb, { type: 'array', bookType: 'xlsx' })
      // 处理完毕，直接导出
      handleExportFile(excelBuffer, argumentsData.value.fileName)
    } catch (error) {
      console.log(error)
      ElMessage.error('文件导出异常!')
      closeProgress()
    }
  }
  // 导出成文件
  const handleExportFile = (data: ArrayBuffer, fileName?: string) => {
    try {
      // 创建一个Blob对象来处理接收到的二进制数据
      const blob = new Blob([data], {
        type: 'application/octet-stream'
      })
      // 保存文件，使用提供的文件名或默认为当前路径和时间戳
      FileSaver.saveAs(
        blob,
        fileName || `${t(routePath)}-${new Date().getTime()}.xlsx`
      )
      handleExportLoading(100)
      timer = setTimeout(() => {
        closeProgress()
        clearTimeout(timer)
      }, 800)
    } catch (error) {
      console.log(error)
      ElMessage.error('文件导出异常!')
      closeProgress()
    }
  }

  // 终止进度条
  const closeProgress = () => {
    mainStore.setShowProgress(false)
  }

  onUnmounted(() => {
    timer && clearTimeout(timer)
  })

  // 返回开始导出和销毁方法
  return { startExport }
}
