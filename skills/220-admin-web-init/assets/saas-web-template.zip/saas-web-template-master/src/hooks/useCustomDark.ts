import { computed, type WritableComputedRef } from 'vue'
import { useMainStore } from '@/store/main'

/**
 * 主题模式切换，仿照useDark写， useDark在Edg浏览器会跟随浏览器主题切换，张总提出即使浏览器是深色主题也要默认白色，因此自己写一个
 * @returns 是否暗黑的值   true  暗黑模式  false 明亮，  可以手动改变返回的isDark
 * @author qjh
 */
export const useCustomDark = (): WritableComputedRef<boolean> => {
  const mainStore = useMainStore()
  // 是否暗黑模式
  const isDark = computed({
    get() {
      return mainStore.systemDark
    },
    set(value: boolean) {
      mainStore.setSystemDark(value)
      changeHtmlClass()
    }
  })
  // 改变html的class类名
  const changeHtmlClass = () => {
    const html = document.documentElement
    html.setAttribute('class', isDark.value ? 'dark' : 'light')
  }
  // 初始化执行一遍
  changeHtmlClass()
  return isDark
}
