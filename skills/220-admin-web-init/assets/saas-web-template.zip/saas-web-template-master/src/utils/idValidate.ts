// @ts-nocheck
/* eslint-disable*/
export const CheckIdCard = {
  // Wi 加权因子 Xi 余数0~10对应的校验码 Pi省份代码
  Wi: [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2],
  Xi: ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'],
  Pi: [
    11, 12, 13, 14, 15, 21, 22, 23, 31, 32, 33, 34, 35, 36, 37, 41, 42, 43, 44,
    45, 46, 50, 51, 52, 53, 54, 61, 62, 63, 64, 65, 71, 81, 82, 91
  ],

  // 检验18位身份证号码出生日期是否有效
  birthDay18: function (sIdCard: string) {
    var year = parseFloat(sIdCard.substr(6, 4))
    var month = parseFloat(sIdCard.substr(10, 2))
    var day = parseFloat(sIdCard.substr(12, 2))
    var checkDay = new Date(year, month - 1, day)
    var nowDay = new Date()
    if (
      year >= 1900 &&
      year <= nowDay.getFullYear() &&
      month == checkDay.getMonth() + 1 &&
      day == checkDay.getDate()
    ) {
      return true
    }
  },

  // 检验15位身份证号码出生日期是否有效
  birthday15: function (sIdCard: string) {
    var year = parseFloat(sIdCard.substr(6, 2))
    var month = parseFloat(sIdCard.substr(8, 2))
    var day = parseFloat(sIdCard.substr(10, 2))
    var checkDay = new Date(year, month - 1, day)
    if (month == checkDay.getMonth() + 1 && day == checkDay.getDate()) {
      return true
    }
  },

  // 检验校验码是否有效
  validate: function (sIdCard: string) {
    var aIdCard = sIdCard.split('')
    var sum = 0
    for (var i = 0; i < CheckIdCard.Wi.length; i++) {
      sum += CheckIdCard.Wi[i] * aIdCard[i] // 线性加权求和
    }
    var index = sum % 11 // 求模，可能为0~10,可求对应的校验码是否于身份证的校验码匹配
    if (CheckIdCard.Xi[index] == aIdCard[17].toUpperCase()) {
      return true
    }
  },

  // 检验输入的省份编码是否有效
  province: function (sIdCard: string) {
    var p2 = sIdCard.substr(0, 2)
    for (var i = 0; i < CheckIdCard.Pi.length; i++) {
      if (CheckIdCard.Pi[i] == p2) {
        return true
      }
    }
  }
}

/**
 * 校验身份证
 * @param {string} value 身份证号
 */
export const chkIdCard = (value: string) => {
  var cardno = value
  var sIdCard = cardno.replace(/^\s+|\s+$/g, '') // 去除字符串的前后空格，允许用户不小心输入前后空格
  if (sIdCard.match(/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/) == null) {
    // 判断是否全为18或15位数字，最后一位可以是大小写字母X
    // alert('身份证号码须为18位或15位数字') // 允许用户输入大小写X代替罗马数字的Ⅹ
    return false
  } else if (sIdCard.length == 18) {
    if (
      !(
        CheckIdCard.province(sIdCard) &&
        CheckIdCard.birthDay18(sIdCard) &&
        CheckIdCard.validate(sIdCard)
      )
    ) {
      // alert('请输入有效的身份证号码，不合法的证件号为：' + sIdCard)
      return false
    }
  } else if (sIdCard.length == 15) {
    if (!CheckIdCard.province(sIdCard) && !CheckIdCard.birthday15(sIdCard)) {
      // alert('请输入有效的身份证号码，不合法的证件号为：' + sIdCard)
      return false
    }
  }
  return true
}
