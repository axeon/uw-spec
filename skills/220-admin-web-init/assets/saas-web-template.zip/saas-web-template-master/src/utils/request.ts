import axios, { AxiosRequestConfig, AxiosResponse } from 'axios'
import { ElMessageBox, ElMessage } from 'element-plus'
import { useMainStore } from '@/store/main'
import router from '@/router/index'
import { authRefreshToken } from '@/api/uwAuthCenterAuthApi'
import { Observer, Subject } from './PubSub/index'
import { getT } from '@/i18n'
import { replacePlaceholders } from '@/utils/tool'
import dayjs from 'dayjs'
import {
  ANONYMOUS_TOKEN,
  REQUEST_WHITE_LIST,
  ANONYMOUS_TOKEN_LIST
} from '@/config/common'

let baseURL = ''
let __API_LOGIN_ = false
let errorTime = 0
const subject = new Subject()

// 获取网关地址
const getGatewayUrl = () => {
  // 判断是否是IP的正则
  const ipRegex =
    /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
  // 判断是否为开发环境
  const isDevEnvironment = import.meta.env.DEV
  let baseURL = 'http://192.168.88.21:80'
  // 如果是开发环境，返回固定的IP地址作为网关
  if (isDevEnvironment || location.hostname.includes('192.168.88.21')) {
    return baseURL
    // 带端口访问 或 直接IP访问
  } else if (location.port || ipRegex.test(location.hostname)) {
    // 带端口访问
    baseURL = `${location.protocol}//${location.host}`
  } else {
    // 域名访问
    // 匹配主机名以(-dev|-test|-beta|-stag|-prod|-stab|-debug)结尾的情况
    const envPattern =
      /-dev|-debg|-test|-beta|-stag|-prod|-stab|-dbg|-sit|-tst|-uat|-stg|-prd|-stb$/i
    const matchResult = location.host.match(envPattern)
    const hostEnd = location.host.split('.').slice(1).join('.')
    // 如果匹配成功，生成对应的gw$1网关URL
    if (matchResult) {
      const env = matchResult[0]
      baseURL = `${location.protocol}//gw${env}.${hostEnd}`
    } else {
      baseURL = `${location.protocol}//gw.${hostEnd}`
    }
  }
  return baseURL
}

baseURL = getGatewayUrl()

const service = axios.create({
  baseURL: baseURL,
  timeout: 15000,
  headers: {
    'Content-type': 'application/json; charset=UTF-8',
    verion: 100
  },
  transformResponse: function (data) {
    try {
      // 如果转换成功则返回转换的数据结果
      if (typeof data === 'object' && data?.size) {
        // 是blob直接返回
        return data
      }
      // 先处理字符串中的大数字，匹配16-20位数字，可以以L结尾
      const processedJsonStr = (data as string).replace(
        /:\s*(\d{16,20}L?)/g,
        (match, number) => {
          return `: "${number}"`
        }
      )
      return JSON.parse(processedJsonStr)
    } catch (err) {
      // 如果转换失败，则包装为统一数据格式并返回
      console.log(err, '正则转换大数字失败------')
      // 如果转换成功则返回转换的数据结果
      if (typeof data === 'object' && data?.size) {
        // 是blob直接返回
        return data
      }
      // 非blob，直接JSON.parset处理
      return JSON.parse(data)
    }
  }
})

service.interceptors.request.use(
  config => {
    const mainStore = useMainStore()
    // 设置水印操作时间
    if (mainStore.waterMarkOperatorTime) {
      const currentDate = new Date().getTime()
      if (
        currentDate - new Date(mainStore.waterMarkOperatorTime).getTime() >
        1000 * 10
      ) {
        mainStore.setWaterMarkOperatorTime(
          dayjs(currentDate).format('YYYY-MM-DDTHH:mm:ssZ')
        )
      }
    }
    // 设置token
    if (mainStore.loginInfo.token) {
      config.headers.Authorization = `Bearer ${mainStore.loginInfo.token}`
    } else if (ANONYMOUS_TOKEN_LIST.includes(config.url!)) {
      // 设置匿名token
      config.headers.Authorization = ANONYMOUS_TOKEN
    }
    if (mainStore.saasInfo.saasLang) {
      // 设置多语言请求
      // 设置默认语言请求头
      config.headers['Default-Language'] = mainStore.saasInfo.saasLang
    }
    // 设置当前想要的语言请求头
    config.headers['Accept-Language'] = mainStore.i18n
    // get请求做处理, 数组格式转换为 xxx,xxx
    if (config.method?.toLowerCase() === 'get') {
      const params = config.params
      if (params && Object.keys(params).length) {
        // 由于$sn、$st改成传数组了，因此不能简单判断list, 所有包含$st、$sn参数且是get请求的也得走一下逻辑
        // 由于不好逐个判断，通常情况下的url最后一个字段包含list，则走一下逻辑
        const lastUrlKey = config.url?.split('/').slice(-1)[0]
        const isQueryList =
          lastUrlKey &&
          (lastUrlKey.includes('list') || lastUrlKey.includes('List'))
        Object.keys(params).forEach(key => {
          // get方式 list请求接口，空字符串情况，值赋值为undefined
          if (isQueryList && params[key] === '') {
            params[key] = undefined
          }
          // get请求特殊字符会导致400，因此对[]\{}`替换为空 qjh-2024/11/19
          if (params[key] && typeof params[key] === 'string') {
            const regex = /[\[\]{}\\`]/g // eslint-disable-line
            params[key] = params[key].replace(regex, '')
          }
          // get请求做处理, 数组格式转换为 xxx,xxx
          if (Array.isArray(params[key])) {
            params[key] = params[key].join() ? params[key].join() : undefined
          }
        })
      }
    }
    // put post patch 请求中如果只有url传参就用formData传参处理，如果既包含url传参还包括请求体传参则不做处理
    if (
      config.method &&
      ['put', 'post', 'patch'].includes(config.method?.toLowerCase())
    ) {
      // 不包含请求体中的参数
      if (!config.data) {
        // 对于params全部放进FormData
        const params = config.params
        if (params && Object.keys(params).length) {
          const formData = new FormData()
          Object.keys(params).forEach(key => {
            formData.append(key, params[key])
          })
          config.data = formData
          config.headers['Content-Type'] = 'multipart/form-data'
          delete config.params
        }
      }
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

service.interceptors.response.use(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  (response: AxiosResponse<any, any>) => {
    const t = getT()
    // 根据code返回 修改i18n语言
    if (response?.data?.code?.includes('-')) {
      response.data.msg = replacePlaceholders(
        t(response.data.code),
        response.data.msg
      )
    }
    // 判断是否是load接口，其次返回值状态是否为warn,并且没有数据，则更改msg为暂无数据
    if (response.config.url) {
      const urlArray = response.config.url!.split('/')
      if (urlArray[urlArray.length - 1].toLowerCase().includes('load')) {
        if (response.data.state === 'warn' && !response.data.data) {
          response.data.msg = t('noData')
        }
      }
    }
    return response.data
  },
  async error => {
    /**
     * 此处做 接口失败处理
     */

    const mainStore = useMainStore()
    const status = error.response?.status
    const url = error.config?.url
    const err = error.response.data.msg || error.message
    let msg = ''
    try {
      const handleError = await new Promise((resolve, reject) => {
        if (status === 498 && url !== '/uw-auth-center/auth/refreshToken') {
          if (mainStore.loginInfo.refreshToken) {
            // 用于区分token过期，前端需要识别后进行token刷新
            // 实例化订阅者
            const obs = new Observer(() => {
              service(error.config)
                .then(res => {
                  resolve(res)
                })
                .catch(error => {
                  reject(error)
                })
            })
            // 添加订阅者
            subject.add(obs)
            if (!__API_LOGIN_) {
              __API_LOGIN_ = true
              authRefreshToken({
                refreshToken: mainStore.loginInfo.refreshToken as string,
                loginAgent: mainStore.loginAgent
              })
                .then(res => {
                  // @ts-expect-error refreshToken res type mismatch
                  mainStore.setRefreshTokenInfo(res.data)
                  // 发布者 通知 订阅者
                  subject.notify()
                })
                .catch(() => {
                  router.replace(
                    `/login?fullPath=${encodeURIComponent(
                      location.hash.replace('#', '')
                    )}`
                  )
                })
                .finally(() => {
                  __API_LOGIN_ = false
                })
            }
          } else {
            router.replace(
              `/login?fullPath=${encodeURIComponent(
                location.hash.replace('#', '')
              )}`
            )
          }
        } else if (status === 401 && url !== '/uw-auth-center/auth/login') {
          if (__API_LOGIN_) {
            // 正在刷新token，同时又发出了请求则将其添加到订阅者，等刷新token成功后调用
            // 实例化订阅者
            const obs = new Observer(() => {
              service(error.config)
                .then(res => {
                  resolve(res)
                })
                .catch(error => {
                  reject(error)
                })
            })
            // 添加订阅者
            subject.add(obs)
          } else {
            // 异常需要识别跳转登录页，并展示错误。
            if (url === '/uw-auth-center/user/mfaVerify') {
              if (!errorTime) {
                errorTime = setTimeout(() => {
                  msg = handleErrorMsg(err)
                  ElMessageBox.confirm(msg, status, {
                    showCancelButton: false,
                    type: 'error',
                    draggable: true
                  }).then(() => {
                    window.location.reload()
                  })
                  clearTimeout(errorTime)
                  errorTime = 0
                }, 300)
              }
            } else {
              if (!errorTime) {
                errorTime = setTimeout(() => {
                  msg = handleErrorMsg(err)
                  ElMessageBox.confirm(msg, status, {
                    showCancelButton: false,
                    type: 'error',
                    draggable: true
                  })
                  clearTimeout(errorTime)
                  errorTime = 0
                }, 300)
              }
              router.replace(
                `/login?fullPath=${encodeURIComponent(
                  location.hash.replace('#', '')
                )}`
              )
            }
          }
        } else if (status === 409) {
          // 于区分用户重复登录，前端需要识别跳转登录页并展示错误。
          if (!errorTime) {
            errorTime = setTimeout(() => {
              ElMessageBox.confirm(err, `${status} 当前账户在其他设备登录`, {
                showCancelButton: false,
                type: 'error',
                draggable: true
              })
              clearTimeout(errorTime)
              errorTime = 0
            }, 300)
          }
          router.replace(
            `/login?fullPath=${encodeURIComponent(
              location.hash.replace('#', '')
            )}`
          )
        } else if (url !== '/uw-auth-center/auth/login') {
          if (!errorTime) {
            errorTime = setTimeout(() => {
              clearTimeout(errorTime)
              errorTime = 0
              ElMessage.error(handleErrorMsg(err))
            }, 300)
          }
          reject(error)
        } else {
          reject(error)
        }
      })
      return Promise.resolve(handleError)
    } catch (e) {
      return Promise.reject(e)
    }
  }
)

// 错误信息提示处理
export const handleErrorMsg = (val: string) => {
  const t = getT()
  let msg = ''
  if (val) {
    if (val.search('!Center AccessToken expired') !== -1) {
      // 无效token
      msg = t('login.invalid')
    } else if (val.search('LOGIN_DOUBLE') !== -1) {
      const IP = val.split('LOGIN_DOUBLE:')[1]
      // 重复登录
      msg = IP ? `IP: ${IP} ${t('someoneIsLogin')}` : t('login.loginDouble')
    } else if (val.search('LOGOUT') !== -1) {
      // 用户登出
      msg = t('login.logOut')
    } else if (val.search('REFRESH') !== -1) {
      // 刷新作废
      msg = t('login.refresh')
    } else if (val.search('KICK_OUT') !== -1) {
      // 踢出用户
      msg = t('login.kickOut')
    } else if (val.search('Token header null') !== -1) {
      msg = t('login.headNull')
    } else if (val.search('No Permission!') !== -1) {
      msg = t('accountIsNullPerm')
    } else {
      msg = val
    }
  }
  return msg
}

export default function request<T>(url: string, config?: AxiosRequestConfig) {
  return new Promise(
    (resolve: (value: T) => void, reject: (value: unknown) => void) => {
      // 判断有无token
      const mainStore = useMainStore()
      // 无token, 且不在白名单,中断请求，直接返回，路由会直接进入登录页
      if (!mainStore.loginInfo.token && !REQUEST_WHITE_LIST.includes(url)) {
        reject(false)
        return
      }
      service({
        url,
        ...config
      } as AxiosRequestConfig)
        .then(res => {
          resolve(res as T)
        })
        .catch(err => {
          reject(err)
        })
    }
  )
}
