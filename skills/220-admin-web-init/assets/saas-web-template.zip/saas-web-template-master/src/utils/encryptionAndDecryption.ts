import { JSEncrypt } from 'jsencrypt'
import { PUBLIC_KEY } from '@/config/common'

/**
 * RSA非对称加密
 * @param data 需要加密的数据
 */
export const rsaEncrypt = (data: any): string | false => {
  const encrypt = new JSEncrypt()
  // 使用公钥加密
  encrypt.setPublicKey(PUBLIC_KEY)
  const result = encrypt.encrypt(data)
  return result
}

/**
 * RSA 安全加密，会有一定几率是false, 如果false,会执行多次加密，如果还是false,就返回false
 * @param data  加密的字符
 * @param retryNum 重试的次数
 */
export const secureRSAEncryption = (
  data: any,
  retryNum = 5
): string | false => {
  if (!data || typeof data !== 'string') {
    console.error('Invalid input data, it should be a non-empty string.')
    return false
  }
  let retryCount = 0
  let result: string | false = false
  // 重试加密操作3次
  while (retryCount < retryNum) {
    result = rsaEncrypt(data)
    // 如果结果不是 false，则跳出循环
    if (result !== false) break
    retryCount++
  }
  // 超过3次仍然返回 false 的情况
  if (result === false) {
    return false
  }
  return result
}
