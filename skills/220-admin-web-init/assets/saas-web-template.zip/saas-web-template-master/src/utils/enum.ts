// 标签父级类型
export enum TAG_PARENT_TYPE {
  POI = 'poi', // poi标签
  PRODUCT = 'product' // 产品标签
}

// 产品标签枚举
export enum TAG_TYPE_PRODUCT {
  TICKET = 'ticket', // 门票
  HOTEL = 'product_hotel', // 酒店
  TOUR_ROUTE = 'tour_route' // 线路
}

// POI标签枚举
export enum TAG_TYPE_POI {
  ATTRACTION = 'attraction', // 景区
  HOTEL = 'poi_hotel' // 酒店
}

// 字典表  规格、单位
export enum DICT_TYPE {
  SPEC = 'SPEC', // 规格
  UNIT = 'UNIT' // 单位
}
