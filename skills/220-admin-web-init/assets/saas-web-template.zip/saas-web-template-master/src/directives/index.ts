// 自动导入当前文件夹的所有文件
const directives = import.meta.glob(['./*', '!./index'], {
  import: 'default',
  eager: true
})

export default directives
