import { Directive } from 'vue'

//--------------------------------------增加其他指令
// 千分位分隔符指令
const thousandSeparator: Directive = {
  mounted(el: any) {
    const value = el.innerText
    if (value && !isNaN(Number(value))) {
      el.innerText = Number(value).toLocaleString('en-US')
    }
  },
  updated(el: any) {
    const value = el.innerText
    if (value && !isNaN(Number(value))) {
      el.innerText = Number(value).toLocaleString('en-US')
    }
  }
}

export default thousandSeparator
