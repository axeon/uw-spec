import { Directive, DirectiveBinding } from 'vue'
import store from '@/store/index'
import { useMainStore } from '@/store/main'
import { PermVo } from '@/api/uwAuthCenterUserApi'
// import { usePermissionCode } from '@/utils/hooks'

type menuList = Array<PermVo>

//  store中存储的信息
const mainStore = useMainStore(store)

/**
 * 按钮权限控制指令，用在自定义组件上外层需包裹一层template或div, 否则浏览器会报出警告
 *      控制当前页面的权限
 *      <template v-permission="usePermissionCode('delete')">
            <el-popconfirm v-if="scope.row.state === 1" title="确认删除" @confirm="deleteTableRow(scope.row.id)">
              <template #reference>
                <el-button type="danger">删除</el-button>
              </template>
            </el-popconfirm>
          </template>

 * eg:
        当前页面控制其他页面的接口权限
        <div v-permission="usePermissionCode('', '/uwOpsCenter/ops/deploy/profile/delete')>
            <el-popconfirm v-if="scope.row.state === 1" title="确认删除" @confirm="deleteTableRow(scope.row.id)">
              <template #reference>
                <el-button type="danger">删除</el-button>
              </template>
            </el-popconfirm>
          </div>   
 * 
 * 
 */

// 权限控制指令具体实现
const ExecutePermissionForPermCode = (el: any, binding: DirectiveBinding) => {
  const perVal = binding.value
  if (binding.value) {
    const menu = mainStore.loadAppMenu
    const menuTree = menu.map(item => item.permVoList)
    // 使用permissionMap做缓存，有缓存拿取缓存的
    let hasPermission = false
    if (mainStore.permissionMap.has(perVal)) {
      hasPermission = mainStore.permissionMap.get(perVal)
    } else {
      hasPermission = searchPermCode(perVal, menuTree as menuList[])
      mainStore.setPermissionMap(perVal, hasPermission)
    }
    if (!hasPermission) {
      el.style.display = 'none'
    } else {
      el.style.display = 'unset'
    }
  }
}

//  查找permCode
export const searchPermCode = (code: string, data: menuList[]): boolean => {
  let hasPermCode = false
  for (const item of data) {
    const target = item.find(subItem => {
      const permCode = subItem.permCode?.split(':')[0]
      return permCode === code
    })
    if (target) {
      hasPermCode = true
      break
    }
  }
  return hasPermCode
}

const permission: Directive = {
  mounted(el: any, binding: DirectiveBinding) {
    // 依据标识符进行权限赋值
    const path = location.hash.slice(1)
    if (!binding.value.includes('/')) {
      binding.value = path + '/' + binding.value
    }
    ExecutePermissionForPermCode(el, binding)
  },
  updated(el: any, binding: DirectiveBinding) {
    // 依据标识符进行权限赋值
    const path = location.hash.slice(1)
    if (!binding.value.includes('/')) {
      binding.value = path + '/' + binding.value
    }
    ExecutePermissionForPermCode(el, binding)
  }
}

export default permission
