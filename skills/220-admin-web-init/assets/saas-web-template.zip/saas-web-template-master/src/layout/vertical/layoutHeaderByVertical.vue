<script lang="ts" setup>
import { useMainStore } from "@/store/main";
import LangSelect from "@/components/LangSelect/index.vue";
import { useI18n } from "vue-i18n";
import { ElNotification } from "element-plus";
import iconRender from "../../config/icon";
import { SHOW_SECOND_MENU_ICON } from "@/config/common";
// 头像图片
import header1 from "@/assets/headerImg/img1.png";
import header2 from "@/assets/headerImg/img2.png";
import header3 from "@/assets/headerImg/img3.png";
import header4 from "@/assets/headerImg/img4.png";
import header5 from "@/assets/headerImg/img5.png";
import header6 from "@/assets/headerImg/img6.png";
import header7 from "@/assets/headerImg/img7.png";
import header8 from "@/assets/headerImg/img8.png";
import header9 from "@/assets/headerImg/img9.png";
import header10 from "@/assets/headerImg/img10.png";
import header11 from "@/assets/headerImg/img11.png";
import header12 from "@/assets/headerImg/img12.png";
import header13 from "@/assets/headerImg/img13.png";
import header14 from "@/assets/headerImg/img14.png";
import header15 from "@/assets/headerImg/img15.png";
import header16 from "@/assets/headerImg/img16.png";
import logo from "@/assets/logo.png";
import { formatToHump } from "@/utils/tool";

const emits = defineEmits<{
  (e: "showSettingForTheme", val: boolean): void;
  (e: "showSystemInfo", val: boolean): void;
}>();

const { t } = useI18n();
const router = useRouter();
const mainStore = useMainStore();

// 用户信息
const userInfo = computed(() => {
  return mainStore.userInfo;
});
// 路由
const route = useRoute();

// 当前路由
const currentRoute = computed(() => {
  return route.path;
});

const routeList = computed(() => {
  return mainStore.appMenu;
});

const clickUser = (index: number) => {
  // 用户资料
  if (index === 1) router.push("/userInfo");
  // 关于
  if (index === 2) emits("showSystemInfo", true);
  // 退出
  if (index === 3) mainStore.Logout();
  // 个性化设置
  if (index === 4) emits("showSettingForTheme", true);
};

// 点击头部菜单
const clickTopNav = (index: number) => {
  let route = routeList.value[index];
  if (route.children) {
    const childrenItem = route.children;
    for (let i = 0; i < childrenItem.length; i++) {
      const item = childrenItem[i];
      if (item.children && item.children.length) {
        const li = item.children;
        router.push(li[0].permCode!);
        menuRef.value.updateActiveIndex(li[0].permCode!);
        break;
      } else {
        router.push(item.permCode!);
        menuRef.value.updateActiveIndex(item.permCode!);
        break;
      }
    }
  }
  mainStore.setNavIndex(index);
};

// 点击全屏
const clickFullScreen = () => {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
  } else {
    document.exitFullscreen();
  }
};

// 返回首页
const handleRouterGo = () => {
  clickTopNav(0);
};

// 强制登录提示
const loginNotice = computed(() => mainStore.loginInfo.loginNotice);
// 是否加载过强制登录提示
const hasLoadLoginNotice = computed(() => mainStore.hasLoadLoginNotice);
// 强制登录提示
const handleForceLoginTip = () => {
  // 网站打开后是否加载了
  if (loginNotice.value && !hasLoadLoginNotice.value) {
    ElNotification({
      title: t("tip"),
      message: loginNotice.value,
      type: "warning",
      duration: 0,
    });
    mainStore.setHasLoadLoginNotice(true);
  }
};

// 头像列表
const headerImgList = [
  header1,
  header2,
  header3,
  header4,
  header5,
  header6,
  header7,
  header8,
  header9,
  header10,
  header11,
  header12,
  header13,
  header14,
  header15,
  header16,
];

// 用户头像回显
const userIcon = computed(() => {
  return userInfo.value.userIcon
    ? headerImgList[Number(userInfo.value.userIcon)]
    : header1;
});

// 菜单Ref
const menuRef = ref();
// 菜单选择
const handleMenuSelect = (index: string) => {
  if (index !== currentRoute.value) {
    router.push(index);
    // 当前激活模块名
    const appName = index.split("/")[1];
    // 当前激活模块索引
    const navIndex = routeList.value.findIndex(
      (item) => formatToHump(item.appName) === appName
    );
    if (navIndex !== -1) {
      mainStore.setNavIndex(navIndex);
    }
  }
};

// 首次登录处理菜单栏激活
const handleMenuActive = (activeIndex?: string) => {
  menuRef.value.updateActiveIndex(activeIndex || currentRoute.value);
};

onMounted(() => {
  if (!userInfo.value.id) {
    // 获取当前用户信息
    mainStore.handleUserProfile();
  }
  // 处理强制登录提示
  handleForceLoginTip();
  // 首次登录处理菜单栏激活
  handleMenuActive();
});

defineExpose({
  handleMenuActive,
});
</script>

<template>
  <el-header class="layout-header space-between">
    <div class="layout-logo flex-align flex-center" @click="handleRouterGo">
      <el-image
        class="aside-logo__img"
        style="width: 105px; height: 40px"
        :src="logo"
      />
    </div>
    <div class="layout-header__main flex-align space-between">
      <!-- 顶部 左侧导航栏 -->
      <div class="header-main__nav flex-row">
        <el-menu
          ellipsis
          mode="horizontal"
          @select="handleMenuSelect"
          ref="menuRef"
        >
          <el-sub-menu
            v-for="(item, index) in routeList"
            :key="index"
            :index="item.appName"
          >
            <template #title>{{ t(item.appName) }}</template>
            <template v-for="subItem in item.children" :key="subItem.permCode">
              <!-- 存在多级菜单 -->
              <el-sub-menu
                :index="subItem.permCode!"
                v-if="subItem.children?.length"
              >
                <template #title>
                  <menuIcon
                    :icon-name="iconRender(subItem.permCode!)"
                  ></menuIcon>
                  <span>{{ t(subItem.permCode!) }}</span>
                </template>
                <el-menu-item
                  :index="child.permCode"
                  v-for="child in subItem.children"
                  :key="child.permCode"
                >
                  <menuIcon
                    :icon-name="iconRender(child.permCode!)"
                    v-if="SHOW_SECOND_MENU_ICON"
                  ></menuIcon>
                  <span>{{ t(child.permCode!) }}</span>
                </el-menu-item>
              </el-sub-menu>
              <!-- 不存在多级菜单 -->
              <el-menu-item :index="subItem.permCode" v-else>
                <menuIcon :icon-name="iconRender(subItem.permCode!)"></menuIcon>
                <span>{{ t(subItem.permCode!) }}</span>
              </el-menu-item>
            </template>
          </el-sub-menu>
        </el-menu>
      </div>
      <!-- 顶部 右侧菜单栏 -->
      <div class="header-main__right flex-align">
        <div
          class="padding-right-20 flex-align cursor-p"
          @click="clickFullScreen"
        >
          <el-tooltip
            effect="dark"
            :content="t('fullScreen')"
            placement="bottom"
          >
            <el-icon color="var(--el-text-color-primary)">
              <FullScreen />
            </el-icon>
          </el-tooltip>
        </div>
        <div class="padding-right-20 flex-align cursor-p">
          <LangSelect />
        </div>
        <el-dropdown @command="clickUser">
          <div class="layout-header__label layout-header__locale flex-align">
            <el-image :src="userIcon" class="user-avatar"></el-image>
            <span>{{ userInfo.realName }}</span>
            <el-icon>
              <ArrowDown />
            </el-icon>
          </div>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item :command="1" icon="User">
                <span class="font12">{{ $t("user.userInfo") }}</span>
              </el-dropdown-item>
              <el-dropdown-item :command="4" icon="Connection">
                <span class="font12">{{ $t("personalizationSetting") }}</span>
              </el-dropdown-item>
              <el-dropdown-item :command="2" icon="More">
                <span class="font12">{{ $t("user.about") }}</span>
              </el-dropdown-item>
              <el-dropdown-item :command="3" icon="Promotion">
                <span class="font12">{{ $t("user.logOut") }}</span>
              </el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>
  </el-header>
</template>

<style lang="scss" scoped>
.layout-header {
  position: relative;
  background-color: $headerBackgroundColor;
  color: var(--el-text-color-primary);
  height: var(--header-height);
  padding: 0;

  &::after {
    content: "";
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 1px;
    background-color: var(--el-border-color-light);
    transform: scaleY(0.5);
  }

  .layout-logo {
    position: absolute;
    top: 0;
    left: 0;
    width: 180px;
    height: 100%;
  }

  .layout-header__label {
    color: var(--el-text-color-primary);

    &:focus-visible,
    &:focus {
      outline: none;
    }

    .user-avatar {
      display: inline-block;
      width: 35px;
      height: 35px;
      line-height: 35px;
      text-align: center;
      border-radius: 50%;
      vertical-align: middle;
      color: #fff;
      font-size: 22px;
      margin-right: 10px;
    }
  }

  .layout-header__main {
    width: 100%;
    height: 100%;
    padding-left: $asideWidth;

    .header-main__nav {
      flex: 1;
      height: 100%;
      .el-menu {
        width: 100%;
        height: 50px;
        border-bottom: unset;
        & > div {
          width: 140px;
        }
      }
    }

    .header-main__right {
      width: 210px;
      .layout-header__locale {
        margin-right: 20px;

        span {
          margin-right: 4px;
        }
      }
    }
  }
}

.build-info__title {
  font-size: 16px;
  line-height: 30px;
  color: #333;
  border-bottom: 1px solid var(--el-color-primary);
}

.font12 {
  font-size: 12px;
}
</style>
