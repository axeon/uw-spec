<script lang="ts" setup>
import layoutContainerByDefault from './default/layoutContainerByDefault.vue'
import layoutContainerByVertical from './vertical/layoutContainerByVertical.vue'
import layoutContainerBySlide from './slide/layoutContainerBySlide.vue'
import { useMainStore } from '@/store/main'
import appVersion from '@/config/appVersion'
import { formatDate } from '@/utils/tool'

const mainStore = useMainStore()
// 布局模式
const layoutMode = computed(() => {
  return mainStore.layoutMode
})

// 是否显示个性化设置
const showSystem = ref(false)
// 是否显示系统信息
const aboutShow = ref(false)
const gitSHA = computed(() => {
  return import.meta.env.VITE_GIT_SHA || ''
})

// 是否显示进度条
const isShowProgress = computed(() => mainStore.showProgress)
// 进度条进度值
const progressValue = computed(() => mainStore.progressValue)
// 总数
const allDownloaded = computed(() => mainStore.allDownloaded)
// 已下载数
const downloaded = computed(() => mainStore.alreadyDownloaded)
// 计算下载预计时间
const calculateTime = computed(() => {
  // 500ms是等待时间  500ms是请求时间  便于计算用
  // 1s是下载一个500条数据的预计时间
  const allTime = Math.ceil((allDownloaded.value - downloaded.value) / 500)
  const minutes = Math.floor(allTime / 60)
  const remainingSeconds = allTime % 60
  return `${String(minutes).padStart(2, '0')}:${String(
    remainingSeconds
  ).padStart(2, '0')}`
})
</script>

<template>
  <el-container
    direction="vertical"
    class="layout-container"
  >
    <!-- 默认布局模式头部 -->
    <layoutContainerByDefault
      v-if="layoutMode === 'default'"
      @show-setting-for-theme="showSystem = true"
      @show-system-info="aboutShow = true"
    />
    <!-- 垂直布局 -->
    <layoutContainerByVertical
      v-else-if="layoutMode === 'vertical'"
      @show-setting-for-theme="showSystem = true"
      @show-system-info="aboutShow = true"
    />
    <!-- 侧边栏布局 -->
    <layoutContainerBySlide
      v-else
      @show-setting-for-theme="showSystem = true"
      @show-system-info="aboutShow = true"
    />
  </el-container>
  <!-- 导出excel进度弹窗 -->
  <div class="download-progress">
    <el-dialog
      :model-value="isShowProgress"
      title="正在导出Excel"
      width="400"
      :show-close="false"
      :close-on-click-modal="false"
    >
      <el-progress
        :percentage="progressValue"
        :stroke-width="24"
        striped
        striped-flow
        :duration="10"
        :text-inside="true"
        :style="{ width: '100%' }"
      />
      <div class="margin-top-10 space-between">
        <div>
          导出进度：
          <span>{{ downloaded }}</span>
          <span class="margin-left-5 margin-right-5">/</span>
          <span>{{ allDownloaded }}</span>
          <span class="margin-left-5">{{ `(${progressValue}%)` }}</span>
        </div>
        <div>{{ calculateTime }}</div>
      </div>
    </el-dialog>
  </div>
  <!-- 主题设置界面 -->
  <SettingForTheme v-model:show-value="showSystem" />
  <!-- 系统信息 -->
  <el-dialog
    v-model="aboutShow"
    title="UI / APP Build Info"
    width="30%"
  >
    <p class="build-info__title margin-bottom-10">UI Build Info</p>
    <div class="flex-row margin-bottom-10">
      <p class="flex-row flex-1">
        <span class="flex-2 flex-end padding-right-10">AppName:</span>
        <span class="flex-8">{{ appVersion.name }}</span>
      </p>
      <p class="flex-row flex-1">
        <span class="flex-2 flex-end padding-right-10">BuildDate:</span>
        <span class="flex-8">{{ formatDate(appVersion.buildTime) }}</span>
      </p>
    </div>
    <div class="flex-row margin-bottom-20">
      <p class="flex-row flex-1">
        <span class="flex-2 flex-end padding-right-10">AppVersion:</span>
        <span class="flex-8">{{ appVersion.version }}/{{ gitSHA }}</span>
      </p>
      <p class="flex-1"></p>
    </div>
    <p class="build-info__title margin-bottom-10">App Build Info</p>
    <template
      v-for="(item, index) in mainStore.loadAppMenu"
      :key="index"
    >
      <div class="flex-row margin-bottom-10">
        <p class="flex-row flex-1">
          <span class="flex-2 flex-end padding-right-10">AppName:</span>
          <span class="flex-8">{{ item.appName }}</span>
        </p>
        <p class="flex-row flex-1">
          <span class="flex-2 flex-end padding-right-10">ID:</span>
          <span class="flex-8">{{ item.id }}</span>
        </p>
      </div>
      <div class="flex-row margin-bottom-20">
        <p class="flex-row flex-1">
          <span class="flex-2 flex-end padding-right-10">AppVersion:</span>
          <span class="flex-8">{{ item.appVersion }}</span>
        </p>
        <p class="flex-1"></p>
      </div>
    </template>
  </el-dialog>
</template>

<style lang="scss" scoped>
.download-progress {
  :deep(.el-dialog__body) {
    height: 80px;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
}

:deep(.layout-container) {
  .custom-tooltip {
    .el-text {
      color: var(--el-bg-color);
      font-size: 12px;
    }
  }
}
</style>
