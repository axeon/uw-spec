export interface MENU_ITEM {
  name?: string
  icon?: string // icon 图标名
  route: string // 有这个参数的时候 将会通过路由跳转
  list?: MENU_ITEM[]
}
