<script lang="ts" setup>
import {
  DArrowLeft,
  DArrowRight,
  RefreshRight,
  Setting,
  CloseBold,
  SemiSelect,
  Delete,
  FullScreen
} from '@element-plus/icons-vue'
import layoutAside from './layoutAside.vue'
import layoutHeaderByDefault from './layoutHeaderByDefault.vue'
import ContextMenu, { type MenuType } from '@/components/ContextMenu/index.vue'
import { useMainStore } from '@/store/main'
import { ElScrollbar } from 'element-plus'
import { useI18n } from 'vue-i18n'
import { useCustomDark } from '@/hooks/useCustomDark'
import { formatToHump } from '@/utils/tool'

interface sysTemMenuType {
  id?: number
  permCode?: string
  permName?: string
  permRank?: number
  children?: Array<sysTemMenuType>
}

const emits = defineEmits<{
  (e: 'showSettingForTheme', val: boolean): void
  (e: 'showSystemInfo', val: boolean): void
}>()

const { t } = useI18n()
const mainStore = useMainStore()
const route = useRoute()
const router = useRouter()

const layoutMainRef = ref<Element>()
const menuList = computed(() => {
  return [
    {
      label: t('closeCurrent'),
      value: 1,
      icon: 'CloseBold'
    },
    {
      label: t('closeOther'),
      value: 2,
      icon: 'SemiSelect'
    },
    {
      label: t('closeAll'),
      value: 3,
      icon: 'Delete'
    },
    {
      label: t('fullScreenCurrent'),
      value: 4,
      icon: 'FullScreen'
    }
  ]
})

const pageTabs = computed(() => {
  return mainStore.pageTabs
})

// 当前的一级菜单名
const currentAppName = computed(() => {
  return mainStore.appMenu[mainStore.navIndex]?.appName || ''
})

// 面包屑
const breadcrumbList = computed(() => {
  const returnRoutes: any[] = []
  const matchRoutes = route.matched.filter(item => item.meta && item.meta.title)
  matchRoutes.forEach(item => {
    if (item.path.includes(':')) {
      item.path = route.path
    }
    returnRoutes.push(item)
  })
  let index = returnRoutes.length - 1
  const target = returnRoutes[index]
  if (!target.meta.isHomePage && target.path !== '/userInfo') {
    const lastIndex = target.path.lastIndexOf('/')
    returnRoutes[index] = {
      path: target.path.slice(0, lastIndex)
    }
    ++index
    // 如果是手动添加的路由，可能匹配的值会出现问题
    if (target.meta.dynamicRoute) {
      returnRoutes[index] = {
        ...target,
        path: route.path
      }
    } else {
      returnRoutes[index] = target
    }
  }
  return returnRoutes
})

const goHome = computed(() => {
  if (mainStore.appMenu.length === 0) return '/'
  let path = ''
  const route = mainStore.appMenu[mainStore.navIndex]
  if (route.children) {
    const childrenItem = route.children
    for (let i = 0; i < childrenItem.length; i++) {
      const item = childrenItem[i]
      if (item.children && item.children.length) {
        const li = item.children
        path = li[0].permCode!
        break
      } else {
        console.log(item.permCode)
        path = item.permCode!
      }
    }
  }
  return path
})

const clickCollapse = () => {
  mainStore.setCollapse()
}

const delPageTabs = (index: number) => {
  mainStore.deletePageTabs(index)
}
const clickMenu = (menu: MenuType, index: number) => {
  // 关闭当前
  if (menu.value === 1) {
    delPageTabs(index)
    return
  }
  // 关闭其他
  if (menu.value === 2) {
    // 因为是关闭其他所有页签，所以直接设置页签为当前页就好了
    mainStore.setPageTabs([pageTabs.value[index]])
    ResetTabScroll()
    return
  }
  // 关闭所有
  if (menu.value === 3) {
    mainStore.setPageTabs([])
    // 关闭所有，那么就要跳转到每个服务的默认首页去
    router.push(mainStore.defaultRoutePath!)
    ResetTabScroll()
    return
  }
  // 全屏页签内容
  if (menu.value === 4 && layoutMainRef.value) {
    router.push(pageTabs.value[index].path)
    document.documentElement.requestFullscreen()
    return
  }
}

//  特殊处理--相关首页不需要背景色
const isNeedBackground = computed(() => {
  const displayBackground = route.meta.displayBackgroundColor
  if (displayBackground === false) {
    return false
  }
  return true
})

//  滚动条
const tabScrollEl = ref<InstanceType<typeof ElScrollbar>>()
const tabWrapperEl = ref<HTMLDivElement>()
const scrollDistance = ref(0)
//  设置滚动功能实现
const handleScroll = (type: 'right' | 'left', scrollNum = 350) => {
  const width = tabWrapperEl.value?.clientWidth as number
  const scrollWidth = tabWrapperEl.value?.scrollWidth as number
  // 有滚动的距离
  const canScroll = scrollWidth - width
  if (type === 'right') {
    // 右边滚进
    if (canScroll) {
      if (scrollDistance.value + scrollNum > canScroll) {
        tabScrollEl.value &&
          tabScrollEl.value.scrollTo({
            left: canScroll + 15,
            behavior: 'smooth'
          })
        scrollDistance.value = canScroll
      } else {
        tabScrollEl.value &&
          tabScrollEl.value.scrollTo({
            left: scrollDistance.value + scrollNum,
            behavior: 'smooth'
          })
        scrollDistance.value = scrollDistance.value + scrollNum
      }
    }
  } else {
    // 左边滚回
    if (canScroll && scrollDistance.value) {
      if (scrollDistance.value - scrollNum < 0) {
        ResetTabScroll()
      } else {
        tabScrollEl.value &&
          tabScrollEl.value.scrollTo({
            left: scrollDistance.value - scrollNum,
            behavior: 'smooth'
          })
        scrollDistance.value = scrollDistance.value - scrollNum
      }
    }
  }
}

//  刷新
const handleRefresh = () => {
  window.location.reload()
}

// 设置
const handleCommand = (val: string) => {
  if (val === '0') {
    // 重新加载
    handleRefresh()
  } else if (val === '1') {
    // 关闭当前
    if (currentTabIndex.value > -1) {
      delPageTabs(currentTabIndex.value)
    }
  } else if (val === '2') {
    // 关闭其他
    if (currentTabIndex.value > -1) {
      mainStore.setPageTabs([pageTabs.value[currentTabIndex.value]])
      ResetTabScroll()
    }
  } else if (val === '3') {
    // 关闭所有
    mainStore.setPageTabs([])
    // 关闭所有，那么就要跳转到每个服务的默认首页去
    router.push(mainStore.defaultRoutePath!)
    ResetTabScroll()
  } else if (val === '4') {
    // 全屏页签内容
    router.push(pageTabs.value[currentTabIndex.value].path)
    document.documentElement.requestFullscreen()
  }
}

// 返回当前页签的index
const currentTabIndex = computed<number>(() => {
  const targetIndex = pageTabs.value.findIndex(item => item.path === route.path)
  return targetIndex
})

// 监听当前激活页签项(索引)的变化
watch(
  () => currentTabIndex.value,
  (newVal, oldVal) => {
    if (!isClickForSelf.value) {
      // 是手动点击不执行
      nextTick(() => {
        // 依据路由以及页签进行滚动
        handleScrollAutoForRoute(newVal, oldVal)
      })
    } else {
      isClickForSelf.value = false
    }
  }
)

// 是否手动点击
const isClickForSelf = ref(false)
// 自动滚动依据路由进行滚动
const handleScrollAutoForRoute = (newVal: number, oldVal = 0) => {
  // 宽度
  const width = tabWrapperEl.value?.clientWidth as number
  // 滚动的宽度
  const scrollWidth = tabWrapperEl.value?.scrollWidth as number
  // 是否有滚动的距离
  const canScroll = scrollWidth - width > 0
  if (canScroll) {
    // 判断向左或向右
    const scrollDirection = newVal > oldVal ? 'right' : 'left'
    // 滚动距离 默认大概取值是130px
    const scrollDistanceForWatch = Math.abs(newVal - oldVal) * 100
    if (scrollDirection === 'right') {
      tabScrollEl.value &&
        tabScrollEl.value.scrollTo({
          left: scrollDistance.value + scrollDistanceForWatch,
          behavior: 'smooth'
        })
      scrollDistance.value = scrollDistance.value + scrollDistanceForWatch
    } else {
      const data = scrollDistance.value - scrollDistanceForWatch
      tabScrollEl.value &&
        tabScrollEl.value.scrollTo({
          left: data > 0 ? data : 0,
          behavior: 'smooth'
        })
      scrollDistance.value = data
    }
  }
}

// 菜单
const appMenu = computed(() => mainStore.appMenu)
// 页签点击
const handleClickForTabTag = (path: string) => {
  const appName = path.split('/')[1]
  const navIndex = appMenu.value.findIndex(
    item => formatToHump(item.appName) === appName
  )
  if (navIndex > -1) {
    if (navIndex !== mainStore.navIndex) {
      // 先切换导航
      mainStore.setNavIndex(navIndex)
      // 切换完导航，再切换路由
      nextTick(() => {
        router.push(path)
      })
    } else {
      router.push(path)
    }
  } else if (path === '/userInfo') {
    router.push(path)
  } else {
    let isFlag = false
    // 如果找不到，就从menu里面找
    for (const index in appMenu.value) {
      const target = findTarget(path, appMenu.value[index].children)
      if (target) {
        // 先切换导航
        mainStore.setNavIndex(Number(index))
        // 切换完导航，再切换路由
        nextTick(() => {
          router.push(path)
        })
        isFlag = true
        break
      }
    }
    if (!isFlag) {
      router.push(path)
    }
  }
  isClickForSelf.value = true
}

// 找到对应的target
const findTarget = (
  path: string,
  data: sysTemMenuType[]
): sysTemMenuType | undefined => {
  for (const target of data) {
    if (target.permCode === path) {
      return target
    }
    if (target.children) {
      const data = findTarget(path, target.children)
      if (data) {
        return data
      }
    }
  }
}

// 滚动重置
const ResetTabScroll = () => {
  tabScrollEl.value &&
    tabScrollEl.value.scrollTo({
      left: 0,
      behavior: 'smooth'
    })
  scrollDistance.value = 0
}

// 当前激活的页签前一个tab的index
const activePrevTab = computed<number>(() => {
  if (currentTabIndex.value > -1) {
    if (currentTabIndex.value - 1 >= 0) {
      return currentTabIndex.value - 1
    }
    return -1
  }
  return -1
})

// 当前激活的页签后一个tab的index
const activeNextTab = computed<number>(() => {
  if (currentTabIndex.value > -1) {
    const target = pageTabs.value[currentTabIndex.value + 1]
    if (target) {
      return currentTabIndex.value + 1
    }
    return -1
  }
  return -1
})

//  是否是暗黑模式
const isDark = useCustomDark()

//  tab页签border
const tabBorder = computed(() => {
  if (isDark.value) {
    // 暗色
    return '1px solid transparent'
  }
  // 非暗色
  return '1px solid #f6f6f6'
})

const headerHeight = ref(
  getComputedStyle(document.documentElement).getPropertyValue('--header-height')
)
// 页签高度
const pageTabHeight = computed(() => {
  return isShowTabPag.value
    ? getComputedStyle(document.documentElement).getPropertyValue(
        '--page-tab-height'
      )
    : '0px'
})

// 是否显示页签
const isShowTabPag = computed(() => mainStore.showPaTab)

// 不显示水印的页面
const unShowWatermarkPage = computed(() => {
  return !['/login', '/404', '/password'].includes(route.path)
})

// 字体颜色
const fontStyle = reactive({
  color: 'rgba(0, 0, 0, 0.04)'
})
// 水印内容
const watermarkContent = computed<string[]>(() => {
  if (!unShowWatermarkPage.value) {
    return []
  }
  return [
    `${mainStore.userInfo.id}@${mainStore.userInfo.saasId}`,
    `${mainStore.userInfo.realName || mainStore.userInfo.username || ''}@${
      mainStore.userInfo.lastLogonIp || ''
    }`,
    mainStore.waterMarkOperatorTime || ''
  ]
})

const asideWidth = computed(() => {
  return !mainStore.collapse ? '180px' : '60px'
})

// 页签内容显示长度
const pageTabContentWidth = computed(() => {
  return !mainStore.collapse ? 'calc(100vw - 336px)' : 'calc(100vw - 210px)'
})

watch(
  isDark,
  () => {
    fontStyle.color = isDark.value
      ? 'rgba(255, 255, 255, 0.04)'
      : 'rgba(0, 0, 0, 0.04)'
  },
  {
    immediate: true
  }
)

onMounted(() => {
  nextTick(() => {
    // 依据路由以及页签进行滚动
    handleScrollAutoForRoute(currentTabIndex.value, 0)
  })
})
</script>

<template>
  <el-container direction="vertical">
    <layoutHeaderByDefault
      @show-setting-for-theme="emits('showSettingForTheme', true)"
      @show-system-info="emits('showSystemInfo', true)"
    />
    <el-container>
      <layoutAside />
      <el-container direction="vertical">
        <div class="flex-align layout-breadcrumb padding-10">
          <el-icon
            size="20px"
            @click="clickCollapse"
            class="layout-collapse__icon padding-right-15"
          >
            <svg
              data-v-92973da6=""
              viewBox="0 0 1024 1024"
              xmlns="http://www.w3.org/2000/svg"
              width="64"
              height="64"
              class="hamburger is-active"
              :style="{
                transform: mainStore.collapse
                  ? 'rotate(0deg)'
                  : 'rotate(180deg)'
              }"
            >
              <path
                data-v-92973da6=""
                d="M408 442h480c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8H408c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8zm-8 204c0 4.4 3.6 8 8 8h480c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8H408c-4.4 0-8 3.6-8 8v56zm504-486H120c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8zm0 632H120c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8zM142.4 642.1L298.7 519a8.84 8.84 0 0 0 0-13.9L142.4 381.9c-5.8-4.6-14.4-.5-14.4 6.9v246.3a8.9 8.9 0 0 0 14.4 7z"
              ></path>
            </svg>
          </el-icon>
          <el-breadcrumb separator-icon="ArrowRight">
            <el-breadcrumb-item :to="{ path: goHome }">
              {{ t(currentAppName) }}
            </el-breadcrumb-item>
            <TransitionGroup>
              <el-breadcrumb-item
                v-for="(item, index) in breadcrumbList"
                :key="item.path"
                :class="{
                  specialStyle: breadcrumbList.length === 2 && index === 0
                }"
              >
                <span>{{ $t(item.path) }}</span>
              </el-breadcrumb-item>
            </TransitionGroup>
          </el-breadcrumb>
        </div>
        <!-- 页签 -->
        <div
          class="layout-tabs"
          v-show="isShowTabPag"
        >
          <div
            class="tab-arrowLeft commonIcon"
            @click="handleScroll('left')"
          >
            <el-icon>
              <DArrowLeft />
            </el-icon>
          </div>
          <el-scrollbar ref="tabScrollEl">
            <div
              class="layout-tab-wrapper"
              ref="tabWrapperEl"
            >
              <ContextMenu
                v-for="(item, index) in pageTabs"
                :key="index"
                :list="menuList"
                @click="menu => clickMenu(menu, index)"
              >
                <el-tag
                  class="layout-tab inline-flex flex-align cursor-p"
                  :class="{
                    active:
                      route.path === item.path ||
                      route.path === item.path.replace(/\?.+/g, ''),
                    prev: activePrevTab === index,
                    next: activeNextTab === index,
                    borderRight: !isDark
                  }"
                  @click="handleClickForTabTag(item.path)"
                  :color="
                    route.path === item.path ||
                    route.path === item.path.replace(/\?.+/g, '')
                      ? ''
                      : 'var(--el-header-tab-background)'
                  "
                >
                  <u v-if="route.path === item.path"></u>
                  {{
                    item.path.includes('?')
                      ? $t(item.path.replace(/\?.+/g, ''))
                      : $t(item.path)
                  }}
                  <s
                    @click.stop="delPageTabs(index)"
                    class="close-tab-icon"
                  >
                    ×
                  </s>
                </el-tag>
              </ContextMenu>
            </div>
          </el-scrollbar>
          <div
            class="tab-arrowRight commonIcon"
            @click="handleScroll('right')"
          >
            <el-icon>
              <DArrowRight />
            </el-icon>
          </div>
          <div
            class="tab-refresh commonIcon"
            @click="handleRefresh"
          >
            <el-icon>
              <RefreshRight />
            </el-icon>
          </div>
          <div class="tab-setting-wrapper">
            <el-dropdown @command="handleCommand">
              <div class="tab-setting commonIcon">
                <el-icon>
                  <Setting />
                </el-icon>
              </div>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item
                    :icon="RefreshRight"
                    command="0"
                  >
                    <span class="font12">{{ t('reload') }}</span>
                  </el-dropdown-item>
                  <el-dropdown-item
                    :icon="CloseBold"
                    command="1"
                  >
                    <span class="font12">{{ t('closeCurrent') }}</span>
                  </el-dropdown-item>
                  <el-dropdown-item
                    :icon="SemiSelect"
                    command="2"
                  >
                    <span class="font12">{{ t('closeOther') }}</span>
                  </el-dropdown-item>
                  <el-dropdown-item
                    :icon="Delete"
                    command="3"
                  >
                    <span class="font12">{{ t('closeAll') }}</span>
                  </el-dropdown-item>
                  <el-dropdown-item
                    :icon="FullScreen"
                    command="4"
                  >
                    <span class="font12">{{ t('fullScreenCurrent') }}</span>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
        </div>
        <el-container>
          <el-watermark
            :font="fontStyle"
            :content="watermarkContent"
          >
            <el-main
              class="layout-main"
              ref="layoutMainRef"
              :class="{
                bgColor: isNeedBackground,
                'need-box-shadow': isNeedBackground
              }"
            >
              <router-view v-slot="{ Component }">
                <keep-alive :include="mainStore.keepAliveInclude">
                  <component :is="Component" />
                </keep-alive>
              </router-view>
              <el-backtop
                target=".layout-main"
                :right="50"
                :bottom="100"
              />
            </el-main>
          </el-watermark>
        </el-container>
      </el-container>
    </el-container>
  </el-container>
</template>

<style lang="scss" scoped>
.v-leave-active {
  position: absolute;
}

.v-enter-active,
.v-leave-active {
  transition: all 0.5s ease;
}

.v-enter-from,
.v-leave-to {
  opacity: 0;
  transform: translateX(50px);
}

.layout-breadcrumb {
  border-bottom: solid 1px var(--el-border-color-light);
  box-sizing: border-box;

  .layout-collapse__icon {
    cursor: pointer;
  }

  .layout-collapse__breadcrumb {
    font-size: 14px;
  }
}

.layout-tabs {
  display: flex;
  align-items: center;
  padding-left: 10px;
  border-bottom: 1px solid var(--el-border-color-light);
  box-sizing: border-box;

  .commonIcon {
    width: 36px;
    text-align: center;
    height: 34px;
    line-height: $pageTabHeight;
    color: var(--el-text-color-placeholder);

    &:hover {
      color: var(--el-color-primary);
    }
  }

  .tab-arrowRight {
    border-left: 1px solid var(--el-border-color);
    border-right: 1px solid var(--el-border-color);
  }

  .tab-refresh {
    border-right: 1px solid var(--el-border-color);
  }

  .layout-tab-wrapper {
    width: v-bind(pageTabContentWidth);
    height: $pageTabHeight;
    display: flex;
    align-items: center;

    .layout-tab {
      text-align: center;
      font-size: 12px;
      color: var(--el-text-color-primary);
      height: $pageTabHeight;
      transition: all 0.2s;
      margin: 0 auto;
      box-sizing: border-box;

      &.active {
        padding-left: 20px;
        padding-right: 10px;
        color: #666;
        background-color: $mainBackgroundColor;
        border-radius: 10px 10px 0 0;
        color: var(--el-color-primary);
      }

      &:hover {
        padding-left: 20px;
        padding-right: 10px;
        color: #666;
        background-color: $mainBackgroundColor !important;
        border-radius: 10px 10px 0 0;
        color: var(--el-color-primary);
      }

      s {
        display: inline-block;
        width: 16px;
        height: 16px;
        line-height: 16px;
        text-align: center;
        text-decoration: none;
        background-color: transparent;
        box-sizing: border-box;
        border-radius: 50%;
        transition: all 0.2s;

        &:hover {
          background-color: #b4bccc;
          color: #fff;
        }
      }

      &.prev {
        border-right: 1px solid transparent !important;
      }

      &:last-child {
        border: none;
      }

      &:first-child {
        border-right: v-bind(tabBorder);
      }
    }
  }
}

.layout-main {
  width: calc(100vw - v-bind(asideWidth));
  height: calc(100vh - v-bind(headerHeight) - v-bind(pageTabHeight) - 37px);
  overflow: hidden auto;
  padding: 10px 0 10px 10px;

  .layout-main__view {
    box-sizing: border-box;
    border-radius: 4px;
    transition: box-shadow 0.3s ease;
  }

  .need-box-shadow {
    &:hover {
      box-shadow: var(--el-box-shadow-light);
    }
  }

  .padding15 {
    padding: 15px;
  }

  .bgColor {
    background-color: var(--el-bg-color);
  }
}

// 面包屑导航栏处理
:deep(.el-breadcrumb) {
  .specialStyle {
    .el-breadcrumb__inner {
      font-weight: bold;
      text-decoration: none;
      transition: var(--el-transition-color);
      color: var(--el-text-color-primary);
    }
  }
}

.font12 {
  font-size: 12px;
}

.download-progress {
  :deep(.el-dialog__body) {
    height: 80px;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
}
</style>
