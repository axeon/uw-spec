//  通用字典表类型，通用只读
export interface commonType {
  readonly label: string
  readonly value: number | string
}

//  echart params 类型
export interface EChartParams {
  componentType: 'series'
  // 系列类型
  seriesType: string
  // 系列在传入的 option.series 中的 index
  seriesIndex: number
  // 系列名称
  seriesName: string
  // 数据名，类目名
  name: string
  // 数据在传入的 data 数组中的 index
  dataIndex: number
  // 传入的原始数据项
  data: object
  // 传入的数据值。在多数系列下它和 data 相同。在一些系列下是 data 中的分量（如 map、radar 中）
  value: number | [] | object
  // 坐标轴 encode 映射信息，
  encode: object
  // 维度名列表
  dimensionNames: Array<string>
  // 数据的维度 index，如 0 或 1 或 2 ...
  // 仅在雷达图中使用。
  dimensionIndex: number
  // 数据图形的颜色
  color: string
  // 饼图/漏斗图的百分比
  percent: number
  // 旭日图中当前节点的祖先节点（包括自身）
  treePathInfo: []
  // 树图/矩形树图中当前节点的祖先节点（包括自身）
  treeAncestors: []
  marker: string
  componentIndex: number
}

//  表格展开类型
export interface expandListType {
  label: string
  width?: string
  field: string
  toolTip?: boolean
}

// 文件上传获取token格式
export interface uploadFileToken {
  refType: string // 关联的表名
  refId: string // 关联表的id
  fileName: string // 文件名
  fileSize: number // 文件大小
  saasId?: number // 运营商编号
  accessType?: 0 | 1 // 访问类型。0，公共文件；1.隐私文件
  expireDate?: string // 文件过期时间
}

// 日期类型
export type Date_Type = Date | string | number
