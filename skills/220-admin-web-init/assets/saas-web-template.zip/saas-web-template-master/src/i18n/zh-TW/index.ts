import zhTwLocale from 'element-plus/dist/locale/zh-tw.mjs'

// 自动导入当前文件夹的所有文件下多语言包
const twCN = import.meta.glob(['./*', '!./index', '!./type.d.ts'], {
  import: 'default',
  eager: true
})

let i18nTw = {
  ...zhTwLocale
}

for (const key in twCN) {
  if (Object.hasOwn(twCN, key)) {
    const item = twCN[key]
    i18nTw = Object.assign(i18nTw, item)
  }
}
export default i18nTw
