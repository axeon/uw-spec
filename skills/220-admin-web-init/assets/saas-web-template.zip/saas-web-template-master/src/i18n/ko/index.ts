import koLocale from 'element-plus/dist/locale/ko.mjs'

// 自动导入当前文件夹的所有文件下多语言包
const koCN = import.meta.glob(['./*', '!./index', '!./type.d.ts'], {
  import: 'default',
  eager: true
})

let i18nKo = {
  ...koLocale
}

for (const key in koCN) {
  if (Object.hasOwn(koCN, key)) {
    const item = koCN[key]
    i18nKo = Object.assign(i18nKo, item)
  }
}
export default i18nKo
