import enLocale from 'element-plus/dist/locale/en.mjs'

// 自动导入当前文件夹的所有文件下多语言包
const jaCN = import.meta.glob(['./*', '!./index', '!./type.d.ts'], {
  import: 'default',
  eager: true
})

let i18nEn = {
  ...enLocale
}

for (const key in jaCN) {
  if (Object.hasOwn(jaCN, key)) {
    const item = jaCN[key]
    i18nEn = Object.assign(i18nEn, item)
  }
}

export default i18nEn
