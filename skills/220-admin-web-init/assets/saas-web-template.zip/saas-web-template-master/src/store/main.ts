import { defineStore } from "pinia";
import { ElMessage, ElLoading } from "element-plus";
import router, { routes } from "@/router";
import type { I18N } from "@/i18n/i18n.type";
import { TokenResponse, authRefreshToken } from "@/api/uwAuthCenterAuthApi";
import {
  MscUser,
  MscAppPermVo,
  userLogout,
  userLoadAppMenu,
  userProfile,
} from "@/api/uwAuthCenterUserApi";
import { formatToHump } from "@/utils/tool";
import { type RouteRecordRaw } from "vue-router";
import { HIDE_MENU, SHOW_SECOND_MENU_ICON } from "@/config/common";
import { MscUserInfo } from "@/api/uwAuthCenterSaasApi";
import { name, version } from "../../package.json";
import {
  userCommonInfoSysOssSite,
  userCommonInfoSaasOssSite,
} from "@/api/saasBaseAppUserApi";
import { type SaasInfo } from "@/api/saasBaseAppSaasApi";
import { handleBuildSlideMenu } from "@/utils/buildTreeMenu";
import dayjs from "dayjs";

const ElTitle = document.querySelector("title");

// 上传域名的ossSite
export type OSS_SITE = "sysOssSite" | "saasOssSite";

// 具体侧边菜单类型
interface MenuType {
  id?: number;
  permCode?: string;
  permName?: string;
  permRank?: number;
  children?: Array<MenuType>;
}

// 头部菜单类型
export interface MenuAppType {
  appLabel: string;
  appName: string;
  appRank: number;
  appVersion: string;
  displayState: number;
  id: number;
  children: Array<MenuType>;
}

// 页签
export interface PageTab {
  title: string;
  path: string;
  name: string;
  dynamicRoute?: string;
  query?: any;
  params?: any;
}

// 搜索框显示模式 1 默认不显示 2 默认显示一行 3 默认显示全部
export type searchSettingModelType = 1 | 2 | 3;

export interface saasUserInfoType {
  [propName: number | string]: MscUser;
}

type layoutMode = "default" | "vertical" | "slide";

export const useMainStore = defineStore("main", {
  state: () => {
    // 登录信息
    const loginInfo = JSON.parse(
      sessionStorage.getItem(`${name}-loginInfo`) || "{}"
    ) as TokenResponse;
    // 头部菜单激活索引
    const navIndex = Number(sessionStorage.getItem(`${name}-navIndex`)) || 0;
    // 页签
    const pageTabs: PageTab[] = JSON.parse(
      sessionStorage.getItem(`${name}-pageTabs`) || "[]"
    );
    // 我的通知已读列表
    const noticeReadList: number[] = JSON.parse(
      localStorage.getItem(`${name}-noticeReadList`) || "[]"
    );
    // 系统通知已读列表
    const sysNoticeReadList: number[] = JSON.parse(
      localStorage.getItem(`${name}-sysNoticeReadList`) || "[]"
    );
    // 系统语言
    const i18n = localStorage.getItem(`${name}-lang`) as I18N;
    const curBrownerLang = window.navigator.language as I18N; // 当前浏览器语言
    //  系统主题色
    const systemThemeColors =
      localStorage.getItem(`${name}-systemThemeColors`) || "#409eff";
    // 侧边栏菜单主题
    const slideMenuColor =
      localStorage.getItem(`${name}-slideMenuColor`) || "#001529";
    // 搜索框显示模式
    const searchSettingModelValue = localStorage.getItem(
      `${name}-searchSettingModel`
    )
      ? Number(localStorage.getItem(`${name}-searchSettingModel`))
      : 1;
    // 是否显示页签
    const showPaTab = localStorage.getItem(`${name}-showPaTab`)
      ? JSON.parse(localStorage.getItem(`${name}-showPaTab`) as string)
      : true;
    // 其余账号的登录信息
    const otherAccountsLoginInfo = JSON.parse(
      sessionStorage.getItem(`${name}-otherAccountsLoginInfo`) || "[]"
    ) as TokenResponse[];
    // sys系统回显域名
    const sysDomain: string =
      sessionStorage.getItem(`${name}-sysOssSite`) || "";
    // saas系统回显域名
    const saasDomain: string =
      sessionStorage.getItem(`${name}-saasOssSite`) || "";
    // 运营商信息
    const saasInfo = JSON.parse(
      sessionStorage.getItem(`${name}-saasInfo`) || "[]"
    ) as SaasInfo;
    // 权限map, 用于v-permission指令判断
    const permissionMap = new Map();
    // 系统主题模式明亮light、暗黑dark两种 true代表暗黑、false代表明亮, 默认明亮模式
    const systemDark = localStorage.getItem(`${name}-systemDark`)
      ? JSON.parse(localStorage.getItem(`${name}-systemDark`) as string)
      : false;
    // 是否加载过登录提示
    const hasLoadLoginNotice = sessionStorage.getItem(
      `${name}-hasLoadLoginNotice`
    )
      ? JSON.parse(
          sessionStorage.getItem(`${name}-hasLoadLoginNotice`) as string
        )
      : false;
    // 页面布局模式
    const layoutMode =
      (localStorage.getItem(`${name}-layout`) as layoutMode) || "default";
    return {
      collapse: false, // 是否水平折叠收起菜单
      navIndex, // 顶部激活索引
      loginInfo,
      userInfo: {} as MscUserInfo,
      i18n,
      curBrownerLang,
      loadAppMenu: [] as MscAppPermVo[], // 未处理的导航栏接口数据
      appMenu: [] as MenuAppType[],
      // 用户类型枚举
      userTypeEnum: {
        "-1": "C站用户",
        0: "C站用户",
        1: "RPC用户",
        100: "平台管理员",
        110: "OPS用户",
        200: "运营商管理员",
        300: "运营商用户",
        310: "SAAS商户",
      },
      pageTabs, // 页签数据
      systemThemeColors, // 系统主题色
      slideMenuColor, // 侧边栏菜单颜色
      systemDark: systemDark, // 是否暗黑模式
      saasUserInfo: {} as saasUserInfoType, // 用户悬浮资料卡片信息
      noticeReadList, //我的通知已读列表
      sysNoticeReadList, //系统已读列表
      searchSettingModel: searchSettingModelValue as searchSettingModelType, // 搜索框显示模式
      showPaTab, // 是否显示页签
      otherAccountsLoginInfo, // 其余账号的用户信息
      /** sys文件上传回显域名 (系统公共资源使用，比如接口图标，AIP广告资源。) */
      sysDomain,
      /** saas文件上传回显域名 (一般场景用) */
      saasDomain,
      saasInfo, // 运营商信息
      permissionMap, // 权限map，用于权限指令判断
      loginAgent: `${name}:${version}`, // 登录代理标识
      hasLoadLoginNotice: hasLoadLoginNotice, // 是否显示登录提示信息
      showProgress: false, // 是否显示进度弹窗
      progressValue: 0, // 进度条进度值
      allDownloaded: 0, // 下载总数
      alreadyDownloaded: 0, // 已下载进度
      waterMarkOperatorTime: dayjs().format("YYYY-MM-DDTHH:mm:ssZ"), // 水印操作时间
      layoutMode: layoutMode,
    };
  },
  getters: {
    keepAliveInclude: (state) => {
      return state.pageTabs.map((item) => item.name);
    },
    // 初始默认路由路径 根据顶部导航索引决定初始默认首页
    defaultRoutePath: (state) => {
      const item = state.appMenu[state.navIndex];
      if (!item) return "";
      const childrenLength = item.children[0]?.children?.length;
      if (item.children.length && item.children[0].children && childrenLength) {
        return item.children[0].children[0].permCode;
      }
      return item.children[0].permCode;
    },
  },
  actions: {
    setLayoutMode(mode: layoutMode) {
      this.layoutMode = mode;
      localStorage.setItem(`${name}-layout`, mode);
    },
    setWaterMarkOperatorTime(time: string) {
      this.waterMarkOperatorTime = time;
    },

    setAllDownloaded(value: number) {
      this.allDownloaded = value;
    },
    setAlreadyDownloaded(value: number) {
      this.alreadyDownloaded = value;
    },
    // 设置进度条进度值
    setProgressValue(value: number) {
      this.progressValue = value;
    },
    // 设置是否显示进度条
    setShowProgress(status: boolean) {
      this.showProgress = status;
      if (!status) {
        this.progressValue = 0;
      }
    },
    setHasLoadLoginNotice(value: boolean) {
      this.hasLoadLoginNotice = value;
      sessionStorage.setItem(
        `${name}-hasLoadLoginNotice`,
        JSON.stringify(value)
      );
    },
    // 设置权限map指令
    setPermissionMap(pathKey: string, hasPermission: boolean) {
      this.permissionMap.set(pathKey, hasPermission);
    },
    // 设置运营商信息
    setSaasInfo(value: SaasInfo) {
      this.saasInfo = value;
      sessionStorage.setItem(`${name}-saasInfo`, JSON.stringify(value));
    },
    // 设置文件上传回显域名
    setUploadDomain(value: string, ossSite: OSS_SITE) {
      let domain = value.startsWith("https://") ? value : "https://" + value;
      domain = domain.endsWith("/") ? domain : domain + "/";
      if (ossSite === "saasOssSite") {
        this.saasDomain = domain;
      } else if (ossSite === "sysOssSite") {
        this.sysDomain = domain;
      }
      sessionStorage.setItem(`${name}-${ossSite}`, domain);
    },
    // 设置其余的账号信息
    setOtherAccountsLoginInfo(info: TokenResponse[]) {
      this.otherAccountsLoginInfo = info;
      sessionStorage.setItem(
        `${name}-otherAccountsLoginInfo`,
        JSON.stringify(info)
      );
    },
    // 设置是否显示页签
    setShowTabPage(value: boolean) {
      this.showPaTab = value;
      localStorage.setItem(`${name}-showPaTab`, JSON.stringify(value));
    },
    // 设置搜索框的显示模式
    setSearchSettingModel(model: searchSettingModelType) {
      this.searchSettingModel = model;
      localStorage.setItem(`${name}-searchSettingModel`, String(model));
    },
    // 设置saas用户信息
    setSaasUserInfo(id: string | number, data: MscUser) {
      this.saasUserInfo[id] = data;
    },
    // 设置暗黑模式
    setSystemDark(isDark: boolean) {
      this.systemDark = isDark;
      localStorage.setItem(`${name}-systemDark`, JSON.stringify(isDark));
    },
    // 设置侧边栏主题色
    setSlideMenuColor(color: string) {
      this.slideMenuColor = color;
      localStorage.setItem(`${name}-slideMenuColor`, color);
    },
    // 设置系统主题色
    setSystemThemeColors(color: string) {
      this.systemThemeColors = color;
      localStorage.setItem(`${name}-systemThemeColors`, color);
    },
    // 设置侧边栏 展开/塌陷
    setCollapse(status?: boolean) {
      if (typeof status === "boolean") {
        this.collapse = status;
      } else {
        this.collapse = !this.collapse;
      }
    },
    // 设置国家化语言
    setI18n(lang: I18N) {
      this.i18n = lang;
      localStorage.setItem(`${name}-lang`, lang);
    },
    // 设置顶部Nav导航选择的是第几个
    setNavIndex(index: number) {
      this.navIndex = index;
      sessionStorage.setItem(`${name}-navIndex`, String(index));
    },
    // 设置登录信息
    setLoginInfo(info: TokenResponse) {
      this.loginInfo = info;
      sessionStorage.setItem(`${name}-loginInfo`, JSON.stringify(info));
    },
    // 更新token
    setRefreshTokenInfo(info: {
      createAt: number;
      expiresIn: number;
      token: string;
    }) {
      this.loginInfo = {
        ...this.loginInfo,
        ...info,
      };
      sessionStorage.setItem(
        `${name}-loginInfo`,
        JSON.stringify(this.loginInfo)
      );
    },
    // 设置用户信息
    setUserInfo(info: MscUserInfo) {
      this.userInfo = info;
      if (ElTitle) {
        ElTitle.innerText = info.realName + "@saas运营商后台";
      }
    },
    // 设置菜单栏
    setAppMenu(menuList?: MscAppPermVo[]) {
      this.loadAppMenu = menuList || [];
      return new Promise((resolve) => {
        // 这个数据是后台返回的所有路由参数
        let voList: {
          id: number;
          permCode: string;
          permName: string;
        }[] = [];
        // 是否手动添加且需展示在菜单上的路由
        const isOwnHandRoutesAndShowInMenu: RouteRecordRaw[] = [];
        // 是否是系统首页的页面路由  permCode 数组
        const isHomePageRoutes: string[] = [];
        menuList?.forEach((items) => {
          if (items.permVoList && items.permVoList.length) {
            items.permVoList.map((item) => {
              item.permCode =
                "/" + formatToHump(items.appName as string) + item.permCode;
              return item;
            });
            // @ts-expect-error
            voList = voList.concat(items.permVoList || []);
          }
        });
        // 动态添加路由
        routes.forEach((item) => {
          for (let i = 0; i < voList.length; i++) {
            const element = voList[i];
            // 判断本地路由和接口拿到的权限路由是否一致 或者是否是手动添加的界面，如果是就一直就动态注册路由
            if (item.path === element.permCode || item.meta?.isOwnHand) {
              if (item.path === element.permCode) {
                // 判断是否存在list接口，存在list接口才设置界面
                // 我的账户特殊处理 qjh 2024/8/21
                const hasListApi = voList.find(
                  (voListItem) =>
                    voListItem.permCode === `${element.permCode}/list:GET`
                );
                if (hasListApi) {
                  item.meta = {
                    ...item.meta,
                    title: item.meta?.isOwnHand
                      ? item.meta.title
                      : element.permName,
                    keepAlive: true,
                    showMenuIcon: item.meta?.isHomePage
                      ? true
                      : SHOW_SECOND_MENU_ICON,
                    onlyShowContent:
                      typeof item.meta?.onlyShowContent === "undefined"
                        ? false
                        : item.meta?.onlyShowContent,
                  };
                  if (item.meta?.isHomePage) {
                    // 是否是首页
                    isHomePageRoutes.push(item.path);
                  }
                  if (!HIDE_MENU.includes(item.path)) {
                    router.addRoute("app", item);
                    break;
                  }
                }
              }
              // 手动添加的路由
              if (item.meta?.isOwnHand) {
                item.meta = {
                  ...item.meta,
                  title: item.meta?.isOwnHand
                    ? item.meta.title
                    : element.permName,
                  keepAlive: true,
                  showMenuIcon: item.meta?.isHomePage
                    ? true
                    : SHOW_SECOND_MENU_ICON,
                  onlyShowContent:
                    typeof item.meta?.onlyShowContent === "undefined"
                      ? false
                      : item.meta?.onlyShowContent,
                };
                if (item.meta?.isShowInSlideMenu) {
                  // 是否需要显示在菜单上
                  isOwnHandRoutesAndShowInMenu.push(item);
                }
                if (item.meta?.isHomePage) {
                  // 是否是首页
                  isHomePageRoutes.push(item.path);
                }
                router.addRoute("app", item);
                break;
              }
            }
          }
        });

        // 处理侧边导航栏显示
        const menu: MenuAppType[] = [];
        menuList?.forEach((item) => {
          const childrenData = handleBuildSlideMenu(
            item.permVoList!,
            isOwnHandRoutesAndShowInMenu,
            isHomePageRoutes
          ).filter(
            (child) =>
              child?.children?.length || child.permCode?.includes("dashboard")
          );

          const menuItem = {
            appLabel: item.appLabel,
            appName: item.appName,
            appRank: item.appRank,
            appVersion: item.appVersion,
            displayState: item.displayState,
            id: item.id,
            children: childrenData,
          };
          menu.push(menuItem as MenuAppType);
        });
        this.appMenu = menu;
        resolve(true);
      });
    },
    // 设置 页签
    setPageTabs(tabInfo: Array<PageTab> | PageTab) {
      let flag = false;
      // 如果是数组 那么就直接替换
      if (Array.isArray(tabInfo)) {
        this.pageTabs = tabInfo;
        flag = true;
      } else if (
        !tabInfo.path.startsWith("/login") &&
        tabInfo.title !== "404" &&
        !tabInfo.path.startsWith("/password")
      ) {
        if (this.pageTabs.length === 0) {
          this.pageTabs.push(tabInfo);
        } else {
          let newPath = false;
          for (let i = 0; i < this.pageTabs.length; i++) {
            const item = this.pageTabs[i];
            if (item.path === tabInfo.path || tabInfo.path === "/login") {
              newPath = false;
              break;
            } else {
              newPath = true;
            }
          }
          if (newPath) {
            //  动态路由路径
            const isDynamicRoute = tabInfo.dynamicRoute;
            //  路由是否包含参数
            const hasParams = tabInfo.path.includes("?");
            // 是否是动态匹配路由
            if (isDynamicRoute) {
              //  存在相同路径的动态路由就删除
              const targetIndex = this.pageTabs.findIndex((item) =>
                item.path.includes(isDynamicRoute)
              );
              if (targetIndex !== -1) {
                // 删除重复的
                this.pageTabs.splice(targetIndex, 1);
              }
            }
            if (hasParams) {
              // 包含参数则去除掉?后的参数，进行对比，否则取原来的值
              const targetPath = tabInfo.path.replace(/\?.+/g, "");
              // 去除参数后有重复的
              const isRepeat = this.pageTabs.findIndex(
                (item) => item.path.replace(/\?.+/g, "") === targetPath
              );
              if (isRepeat !== -1) {
                // 删除重复的
                this.pageTabs.splice(isRepeat, 1);
              }
            }
            this.pageTabs.push(tabInfo);
            if (this.pageTabs.length > 10) {
              // 取最近的10个
              this.pageTabs.shift();
            }
            flag = true;
          }
        }
      }
      if (flag) {
        sessionStorage.setItem(
          `${name}-pageTabs`,
          JSON.stringify(this.pageTabs)
        );
      }
    },
    // 删除 页签
    deletePageTabs(index: number) {
      const path = this.pageTabs[index].path;
      this.pageTabs.splice(index, 1);
      sessionStorage.setItem(`${name}-pageTabs`, JSON.stringify(this.pageTabs));
      if (router.options.history.location.includes(path)) {
        if (this.pageTabs[index]) {
          router.replace(this.pageTabs[index]);
        } else if (this.pageTabs[index - 1]) {
          router.replace(this.pageTabs[index - 1]);
        } else {
          router.replace(this.defaultRoutePath!);
        }
      }
    },
    // 单一删除tabs,指定跳转页面
    singleDeletePageTabs(index: number, newPath: string) {
      this.pageTabs.splice(index, 1);
      sessionStorage.setItem(`${name}-pageTabs`, JSON.stringify(this.pageTabs));
      router.replace(newPath);
    },
    // 添加我的通知已读列表
    setNoticeReadList(id: number) {
      if (!this.noticeReadList.includes(id)) {
        this.noticeReadList.push(id);
        localStorage.setItem(
          "noticeReadList",
          JSON.stringify(this.noticeReadList)
        );
      }
    },
    // 添加系统通知已读列表
    setSysNoticeReadList(id: number) {
      if (!this.sysNoticeReadList.includes(id)) {
        this.sysNoticeReadList.push(id);
        localStorage.setItem(
          `${name}-sysNoticeReadList`,
          JSON.stringify(this.sysNoticeReadList)
        );
      }
    },
    // -------------- 带接口请求 ----------------- start ----------------
    // 获取用户信息
    handleUserProfile() {
      userProfile()
        .then((res) => {
          if (res.state === "success") {
            this.setUserInfo(res.data as MscUserInfo);
          } else {
            ElMessage.error("获取的数据为空");
          }
        })
        .catch((err) => {
          ElMessage.error(JSON.stringify(err));
        });
    },
    // 退出登录
    Logout() {
      userLogout({
        loginAgent: this.loginAgent,
      }).then(() => {
        this.$reset();
        this.loginInfo = {};
        this.pageTabs = [];
        sessionStorage.clear();
        router.replace(
          `/login?fullPath=${encodeURIComponent(
            location.hash.replace("#", "")
          )}`
        );
      });
    },
    // 获取当前用户菜单信息
    handleUserLoadAppMenu() {
      return new Promise<MscAppPermVo[]>((resolve) => {
        userLoadAppMenu({
          appId: 0,
        }).then((res) => {
          if (res.state === "success" && res.data) {
            resolve(res.data);
          } else {
            ElMessage.error(res.msg || "账号无权限");
          }
        });
      });
    },
    // 强制重刷token, 重新获取最新的token并且加载最新菜单
    handleReloadMenu(token?: string) {
      return new Promise<TokenResponse>((resolve, reject) => {
        authRefreshToken({
          refreshToken: token || (this.loginInfo.refreshToken as string),
          loginAgent: this.loginAgent,
          forceRefresh: true, // 强制刷新
        })
          .then((res) => {
            if (res.state === "success" && res.data) {
              const refreshToken = token || this.loginInfo.refreshToken;
              this.loginInfo = {
                ...res.data,
                refreshToken: refreshToken,
              };
            } else {
              this.loginInfo = {};
            }
            sessionStorage.setItem(
              `${name}-loginInfo`,
              JSON.stringify(this.loginInfo)
            );
            resolve(res.data || {});
          })
          .catch(() => {
            sessionStorage.setItem(`${name}-loginInfo`, JSON.stringify({}));
            reject({});
          });
      });
    },
    // 获取最新权限
    handleReloadAuth() {
      // 重刷token
      const currentAppName = this.loadAppMenu[this.navIndex]?.appName;
      const loadingInstance = ElLoading.service({ fullscreen: true });
      // 之前的登录信息
      const prevLoginInfo = this.loginInfo;
      this.handleReloadMenu(prevLoginInfo.refreshToken)
        .then(() => {
          // 重新获取用户资料
          this.handleUserProfile();
          // 重新获取菜单
          this.handleUserLoadAppMenu().then((menu) => {
            // 重新设置菜单
            this.setAppMenu(menu).then(() => {
              // 顶部导航处理保持
              const targetIndex = menu.findIndex(
                (item) => item.appName === currentAppName
              );
              if (targetIndex > -1) {
                this.setNavIndex(targetIndex);
              }
              // 权限Map清空
              this.permissionMap.clear();
            });
          });
          setTimeout(() => {
            loadingInstance.close();
          }, 1500);
        })
        .catch(() => {
          setTimeout(() => {
            loadingInstance.close();
          }, 1500);
        });
    },
    // 获取文件回显域名
    handleGetOssSite() {
      userCommonInfoSysOssSite({}).then((res) => {
        this.setUploadDomain(res.data || "", "sysOssSite");
      });
      userCommonInfoSaasOssSite({}).then((res) => {
        this.setUploadDomain(res.data || "", "saasOssSite");
      });
    },
    // -------------- 带接口请求 ----------------- end ----------------
  },
});
