// rsa 公钥
export const PUBLIC_KEY =
  'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlMYtTE8xBlM4AiwedCJRPEdyMaUA6ZnOovripQzVfZKgG/N846T5KbfnJljlz4QkLXjYUSSxu0+TS26koyHV4fA6WqNzKzDXE0wVJI15eIj6KWuJF0gWwdOwUHJRHZHPH46NX5uqcckY7BW8S6rFxX4Ep7xGy0xT/KqqEoteqHRndX/Idpyg8RcglS4vDkXPz/I4C8bxBnbVKkoYH3M1eTcaIPNRfKKCyGEQOYrpG1OVMJ2yW4Kf5bGOtYAP4ds5DzfpaYTSUjPbteHp7ry+Bp06fH3IY3NRuAU69tJpEIZSX4N9nRbfgieFUFRKMq9/XtPSHxm1AjpABNjvZpXBMQIDAQAB'

// 是否显示二级菜单图标
export const SHOW_SECOND_MENU_ICON = false

// 隐藏的菜单路径, 对应的路由不会被注册
export const HIDE_MENU = ['/saasMallApp/saas/poi/hotel']

// 匿名token
export const ANONYMOUS_TOKEN = 'Bearer 0$0!0@0'

// 请求白名单
export const REQUEST_WHITE_LIST = [
  '/uw-auth-center/auth/genCaptcha',
  '/uw-auth-center/auth/login',
  '/uw-auth-center/auth/refreshToken',
  '/uw-auth-center/auth/sendDeviceCode',
  '/saas-base-app/open/registry/save',
  '/saas-base-app/open/registry/sendDeviceCode',
  '/saas-base-app/open/registry/genCaptcha',
  '/uw-auth-center/auth/resetPassword'
]

// 需要匿名token的接口
export const ANONYMOUS_TOKEN_LIST = [
  '/saas-base-app/open/registry/save',
  '/saas-base-app/open/registry/sendDeviceCode'
]
