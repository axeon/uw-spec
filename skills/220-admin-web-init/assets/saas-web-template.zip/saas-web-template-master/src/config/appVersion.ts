import { name, version } from '../../package.json'

export default {
  name: name,
  version: version,
  buildTime: new Date().getTime()
}
