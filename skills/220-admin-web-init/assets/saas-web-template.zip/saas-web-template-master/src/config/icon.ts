const iconEnum: Record<string, string> = {
  '/uwAuthCenter/saas/log': 'Memo',
  '/uwAuthCenter/saas/log/actionLog': 'DocumentChecked',
  '/uwAuthCenter/saas/log/loginLog': 'Document',
  '/uwAuthCenter/saas/home/dashboard': 'Odometer',
  '/uwAuthCenter/saas/log/critLog': 'DocumentChecked',
  '/uwAuthCenter/saas/log/dataHistory': 'Document',
  '/uwAuthCenter/saas/msc': 'Operation'
}

export default (permCode: string) => {
  if (iconEnum[permCode]) return iconEnum[permCode]
  return 'Menu'
}
