<script lang="ts" setup>
import { useI18n } from 'vue-i18n'
import { useMainStore } from '@/store/main'
import logo from '@/assets/logo_cl_light.png'
import logoDark from '@/assets/logo_cl_dark.png'
import { FormInstance, FormRules, ElMessageBox, ElMessage } from 'element-plus'
import LangSelect from '@/components/LangSelect/index.vue'
import {
  authLogin,
  authGenCaptcha,
  authSendDeviceCode,
  type TokenResponse,
  type CaptchaQuestion
} from '@/api/uwAuthCenterAuthApi'
import {
  useParallax,
  type MaybeElementRef,
  type MaybeElement
} from '@vueuse/core'
import { extractContentFromBrackets } from '@/utils/tool'
import { rsaEncrypt } from '@/utils/encryptionAndDecryption'
import { useCustomDark } from '@/hooks/useCustomDark'
import { userMfaVerify } from '@/api/uwAuthCenterUserApi'

// 校验
const Captcha = defineAsyncComponent(
  () => import('@/components/Captcha/index.vue')
)

// 修改密码组件
const UpdatePasswordDialog = defineAsyncComponent(
  () => import('@/pages/login/components/UpdatePasswordDialog/index.vue')
)

// MFA初始化组件
const MFACodeDialog = defineAsyncComponent(
  () => import('@/pages/login/components/MFACodeDialog/index.vue')
)

// MFA验证
const ForceMFADialog = defineAsyncComponent(
  () => import('@/pages/login/components/ForceMFADialog/index.vue')
)

// 多账户选择
const MultipartUserSelectDialog = defineAsyncComponent(
  () => import('@/pages/login/components/MultipartUserSelectDialog/index.vue')
)

interface MenuType {
  id: number
  permCode: string
  permName: string
  children?: Array<MenuType>
}

interface MenuAppType {
  appLabel: string
  appName: string
  appRank: number
  appVersion: string
  displayState: number
  id: number
  children: Array<MenuType>
}

const mainStore = useMainStore()
const router = useRouter()
const route = useRoute()
const { t } = useI18n()

const formEl = ref<FormInstance>()
const loading = ref(false)
const loginForm = reactive<{
  userType: number
  loginId: string
  loginSecret: string
  loginPass: string
  forceLogin: boolean
  userId?: number
}>({
  userType: 110,
  loginId: '',
  loginSecret: '',
  loginPass: '',
  forceLogin: false, // 默认不强制登录
  userId: undefined // 多用户情况下，所选择需要登录的用户ID
})

// 校验参数
const validateParams = ref<CaptchaQuestion>({})
// 加密的签名
const validateSign = ref('')

// 校验规则
const rules = computed<FormRules>(() => {
  return {
    loginId: [
      {
        required: true,
        message: t('login.pleaseInputUserName'),
        trigger: 'blur'
      },
      {
        validator: validateLoginId
      }
    ],
    loginSecret: [
      {
        required: activeLoginType.value === 0,
        message: t('login.pleaseInputPassWord'),
        trigger: 'blur'
      }
    ],
    loginPass: [
      {
        required: activeLoginType.value === 1,
        message: t('pleaseInputPhoneOrEmail'),
        trigger: 'blur'
      }
    ]
  }
})

// 账号校验
const validateLoginId = (rule: any, value: any, callback: any) => {
  if (activeLoginType.value === 1) {
    if (disabledGetCodeBtnForLogin.value) {
      callback(new Error(t('phoneOrEmailFormatError')))
    } else {
      callback()
    }
  } else {
    callback()
  }
}

// 多次登录失败提示文字
const showFailuresText = ref('')
// 生成Captcha
const getGenCaptcha = () => {
  showFailuresText.value = ''
  loading.value = true
  authGenCaptcha({
    captchaId: validateParams.value.captchaId || ''
  })
    .then(res => {
      loading.value = false
      if (res.state === 'success') {
        validateParams.value = {}
        // 直接登录
        queryForLogin()
      } else if (res.state === 'error' && res.msg) {
        showFailuresText.value = res.msg
        showCaptcha.value = false
        const matchData = extractContentFromBrackets(res.msg)
        ElMessage.error({
          message: showFailuresText.value,
          duration: matchData[matchData.length - 1]
            ? Number(matchData[matchData.length - 1]) * 1000
            : 60 * 1000,
          showClose: true
        })
        // 重置MFA初始化绑定变量
        resetBindMFAData()
      } else if (res.data && res.data.captchaId) {
        validateParams.value = { ...res.data }
        showCaptcha.value = true
        // 重置MFA初始化绑定变量
        resetBindMFAData()
      }
    })
    .catch(() => {
      loading.value = false
      // 重置MFA初始化绑定变量
      resetBindMFAData()
    })
}

// 处理用户、权限信息
const handleInfo = async () => {
  const menuList = await mainStore.handleUserLoadAppMenu()
  loading.value = true
  mainStore
    .setAppMenu(menuList)
    .then(() => {
      const navIndex = getMenuNavIndex(mainStore.appMenu as MenuAppType[])
      mainStore.setNavIndex(navIndex)
      const appMenu = mainStore.appMenu[navIndex]
      let path = mainStore.defaultRoutePath
      // 判断菜单里面有没有route.query.fullPath，有执行，没有走默认
      if (route.query.fullPath) {
        const isHasPath = hasPath(
          appMenu.children as MenuType[],
          route.query.fullPath as string
        )
        if (isHasPath && isHasPath[0]) {
          path = route.query.fullPath as string
        } else {
          path = mainStore.defaultRoutePath
        }
      } else {
        // 赋值默认路径
        path = mainStore.defaultRoutePath
      }
      const time = setTimeout(() => {
        clearTimeout(time)
        loading.value = false
        // 判断是否存在跳转的路径
        if (path) {
          router.replace(path)
        } else {
          ElMessageBox.alert(t('loginByGetAuthError'), t('login.loginFail'), {
            type: 'error',
            showClose: false,
            confirmButtonText: t('confirm')
          })
        }
      }, 300)
    })
    .catch(() => {
      loading.value = false
    })
    .finally(() => {
      // 设置登录提示为false
      mainStore.setHasLoadLoginNotice(false)
    })
}

// 获取一级菜单索引值
const getMenuNavIndex = (menu: MenuAppType[]): number => {
  let navIndex = 0
  for (let index in menu) {
    if (menu[index] && menu[index].children && menu[index].children?.length) {
      navIndex = Number(index)
      break
    }
  }
  return navIndex
}

// 判断菜单里面是否有对应的路径
const hasPath = (
  menu: MenuType[],
  target: string,
  data: boolean[] = []
): boolean[] => {
  for (const item of menu) {
    if (item.permCode === target) {
      data.push(true)
      return data
    }
    if (item.children && item.children.length) {
      hasPath(item.children, target, data)
    }
  }
  return data
}

// 点击登录
const clickLogin = () => {
  formEl.value?.validate(valid => {
    if (valid) {
      // 调用验证接口，判断是否需要验证
      if (activeLoginType.value === 0) {
        // 用户名密码登录
        getGenCaptcha()
      } else {
        // 短信验证码, 邮箱验证登录
        loginByPhoneOrEmail()
      }
    }
  })
}

// 短信验证码登录
const loginByPhoneOrEmail = () => {
  loading.value = true
  // 判断是邮箱还是手机号
  let loginType = 23
  const type = getLoginTypeForPasswordLogin()
  if (type === 2) {
    loginType = 22
  } else {
    loginType = 23
  }
  authLogin({
    loginId: loginForm.loginId,
    loginPass: loginForm.loginPass,
    loginType: loginType,
    userType: loginForm.userType,
    captchaId: validateParams.value.captchaId || '',
    captchaSign: validateParams.value.captchaId ? validateSign.value : '',
    loginAgent: mainStore.loginAgent,
    forceLogin: loginForm.forceLogin,
    userId: loginForm.userId || undefined
  })
    .then(res => {
      if (res.state === 'success' && res.data?.length) {
        res.data && mainStore.setLoginInfo(res.data[0])
        handleInfo()
        // 重置MFA初始化绑定变量
        resetBindMFAData()
      } else {
        if (res.code === 'auth.center.passwd.expire.warn') {
          // 密码过期
          passwordExpiredTip(res.data![0])
        } else if (res.code === 'auth.center.passwd.init.warn') {
          // 密码初始化，需要修改密码
          defaultPasswordTip(res.data![0])
        } else if (res.code === 'auth.center.login.double.warn') {
          // 双登
          const msgArray = extractContentFromBrackets(res.msg!)
          const msg = `IP:${msgArray[0]}${
            t('in') + msgArray[1] + t('someoneIsLogin')
          },${t('loginNoticeByForce')}`
          // 双登
          unForceLoginTip(msg)
        } else if (res.code === 'auth.center.mfa.init.warn') {
          // MFA未初始化
          mfaNotInitTip(res.data![0])
        } else if (res.code === 'auth.center.mfa.force.warn') {
          if (isInitMFA.value) {
            // 赋值临时token，不然无法验证
            mainStore.setLoginInfo(res.data![0])
            // 刚刚初始化了MFA，手动调用接口
            handleManualMFAValidate()
          } else {
            // MFA强制校验
            forceMFAValidate(res.data![0])
          }
        } else if (res.code === 'auth.center.user.multi.warn') {
          // 存在多个用户，选择需要登录的用户
          showMultipartUserSelectDialogTip(res.data!)
        } else {
          ElMessage.error(res.msg)
          // 重置MFA初始化绑定变量
          resetBindMFAData()
        }
        loading.value = false
      }
    })
    .catch(err => {
      ElMessageBox.alert(err.response.data.msg, t('login.loginFail'), {
        type: 'error',
        showClose: false,
        confirmButtonText: t('confirm'),
        callback: () => {
          loading.value = false
        }
      })
      // 重置MFA初始化绑定变量
      resetBindMFAData()
    })
}

// 登录
const queryForLogin = () => {
  loading.value = true
  authLogin({
    loginId: loginForm.loginId,
    loginSecret: rsaEncrypt(loginForm.loginSecret) as string,
    loginType: getLoginTypeForPasswordLogin(),
    userType: loginForm.userType,
    captchaId: validateParams.value.captchaId,
    captchaSign: validateParams.value.captchaId ? validateSign.value : '',
    loginAgent: mainStore.loginAgent,
    forceLogin: loginForm.forceLogin,
    userId: loginForm.userId || undefined
  })
    .then(res => {
      if (res.state === 'success') {
        res.data && mainStore.setLoginInfo(res.data[0])
        handleInfo()
        // 重置MFA初始化绑定变量
        resetBindMFAData()
      } else if (res.state === 'warn') {
        if (res.code === 'auth.center.passwd.expire.warn') {
          // 密码过期
          passwordExpiredTip(res.data![0])
        } else if (res.code === 'auth.center.passwd.init.warn') {
          // 密码初始化，需要修改密码
          defaultPasswordTip(res.data![0])
        } else if (res.code === 'auth.center.login.double.warn') {
          // 双登
          const msgArray = extractContentFromBrackets(res.msg!)
          const msg = `IP:${msgArray[0]}${
            t('in') + msgArray[1] + t('someoneIsLogin')
          },${t('loginNoticeByForce')}`
          // 双登
          unForceLoginTip(msg)
        } else if (res.code === 'auth.center.mfa.init.warn') {
          // MFA未初始化
          mfaNotInitTip(res.data![0])
        } else if (res.code === 'auth.center.mfa.force.warn') {
          if (isInitMFA.value) {
            // 赋值临时token，不然无法验证
            mainStore.setLoginInfo(res.data![0])
            // 刚刚初始化了MFA，手动调用接口
            handleManualMFAValidate()
          } else {
            // MFA强制校验
            forceMFAValidate(res.data![0])
          }
        } else if (res.code === 'auth.center.user.multi.warn') {
          // 存在多个用户，选择需要登录的用户
          showMultipartUserSelectDialogTip(res.data!)
        } else {
          ElMessage.warning(res.msg)
          // 重置MFA初始化绑定变量
          resetBindMFAData()
        }
        loading.value = false
      } else {
        ElMessage.error(res.msg)
        loading.value = false
        // 重置MFA初始化绑定变量
        resetBindMFAData()
      }
    })
    .catch(err => {
      ElMessageBox.alert(err.response.data.msg, t('login.loginFail'), {
        type: 'error',
        showClose: false,
        confirmButtonText: t('confirm'),
        callback: () => {
          loading.value = false
        }
      })
      // 重置MFA初始化绑定变量
      resetBindMFAData()
    })
}

// 密码登录时获取登录的类型
const getLoginTypeForPasswordLogin = (): number => {
  // 手机号正则
  const phoneReg =
    /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/
  // 邮箱正则
  const emailReg = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
  if (phoneReg.test(loginForm.loginId)) {
    return 3
  } else if (emailReg.test(loginForm.loginId)) {
    return 2
  }
  // 普通账户密码登录
  return 1
}

//  判断是否是暗黑
const isDark = useCustomDark()

const loginRef = ref<HTMLElement | null>(null)
const { tilt, roll } = useParallax(
  loginRef.value as MaybeElementRef<MaybeElement>
)
const logoAnimation = computed(() => ({
  transform: `translateX(${tilt.value * 20}px) translateY(${
    roll.value * 30
  }px) scale(1)`
}))

// 是否显示验证弹窗
const showCaptcha = ref(false)
const captchaRef = ref()

// 刷新验证
const handleRefreshCode = () => {
  authGenCaptcha({
    captchaId: validateParams.value.captchaId || ''
  }).then(res => {
    if (res.state === 'success') {
      validateParams.value = {}
      showCaptcha.value = false
    } else if (res.state === 'error' && res.msg) {
      showFailuresText.value = res.msg
      showCaptcha.value = false
      const matchData = extractContentFromBrackets(res.msg)
      ElMessage.error({
        message: showFailuresText.value,
        duration: matchData[matchData.length - 1]
          ? Number(matchData[matchData.length - 1]) * 1000
          : 60 * 1000,
        showClose: true
      })
    } else if (res.data && res.data.captchaId) {
      validateParams.value = { ...res.data }
      showCaptcha.value = true
    }
  })
}

// 点击验证
const handleValidate = (val: string) => {
  loading.value = true
  validateSign.value = val
  if (activeLoginType.value === 0) {
    // 用户密码登录方式
    authLogin({
      loginId: loginForm.loginId,
      loginSecret: rsaEncrypt(loginForm.loginSecret) as string,
      loginType: getLoginTypeForPasswordLogin(),
      userType: loginForm.userType,
      captchaId: validateParams.value.captchaId,
      captchaSign: validateParams.value.captchaId ? validateSign.value : '',
      loginAgent: mainStore.loginAgent,
      forceLogin: loginForm.forceLogin,
      userId: loginForm.userId || undefined
    })
      .then(res => {
        if (res.state === 'success') {
          captchaRef.value?.validateSuccess()
          const timer = setTimeout(() => {
            res.data && mainStore.setLoginInfo(res.data[0])
            handleInfo()
            clearTimeout(timer)
          }, 1500)
          // 重置MFA初始化绑定变量
          resetBindMFAData()
        } else {
          if (String(res.code).includes('auth.center.captcha.verify')) {
            // 验证码错误重新刷新
            captchaRef.value?.validateError()
            const timer = setTimeout(() => {
              handleRefreshCode()
              clearTimeout(timer)
            }, 1500)
            // 重置MFA初始化绑定变量
            resetBindMFAData()
          } else if (res.code === 'auth.center.passwd.verify.error') {
            // 用户密码错误，关闭弹窗
            showCaptcha.value = false
            ElMessage.error(res.msg)
            // 重置MFA初始化绑定变量
            resetBindMFAData()
          } else if (res.code === 'auth.center.passwd.expire.warn') {
            // 密码过期
            passwordExpiredTip(res.data![0])
            showCaptcha.value = false
          } else if (res.code === 'auth.center.passwd.init.warn') {
            // 密码初始化，需要修改密码
            defaultPasswordTip(res.data![0])
            showCaptcha.value = false
          } else if (res.code === 'auth.center.login.double.warn') {
            // 双登
            const msgArray = extractContentFromBrackets(res.msg!)
            const msg = `IP:${msgArray[0]}${t('in') + t('someoneIsLogin')},${t(
              'loginNoticeByForce'
            )}`
            // 双登
            unForceLoginTip(msg)
            showCaptcha.value = false
          } else if (res.code === 'auth.center.mfa.init.warn') {
            // MFA未初始化
            mfaNotInitTip(res.data![0])
            showCaptcha.value = false
          } else if (res.code === 'auth.center.mfa.force.warn') {
            showCaptcha.value = false
            if (isInitMFA.value) {
              // 赋值临时token，不然无法验证
              mainStore.setLoginInfo(res.data![0])
              // 刚刚初始化了MFA，手动调用接口
              handleManualMFAValidate()
            } else {
              // MFA强制校验
              forceMFAValidate(res.data![0])
            }
          } else if (res.code === 'auth.center.user.multi.warn') {
            // 存在多个用户，选择需要登录的用户
            showMultipartUserSelectDialogTip(res.data!)
            showCaptcha.value = false
          } else {
            ElMessage.error(res.msg)
            showCaptcha.value = false
            // 重置MFA初始化绑定变量
            resetBindMFAData()
          }
          loading.value = false
        }
      })
      .catch(err => {
        ElMessageBox.alert(err.response.data.msg, t('login.loginFail'), {
          type: 'error',
          showClose: false,
          confirmButtonText: t('confirm'),
          callback: () => {
            loading.value = false
          }
        })
        // 重置MFA初始化绑定变量
        resetBindMFAData()
      })
  } else {
    // 手机号注册方式
    queryCodeForMessageNeedCaptchaForLogin()
  }
}

// 非强制登录弹窗
const unForceLoginTip = (msg: string) => {
  // 重置MFA初始化绑定变量
  resetBindMFAData()
  ElMessageBox.confirm(msg, t('tip'), {
    confirmButtonText: t('confirm'),
    cancelButtonText: t('cancel'),
    type: 'warning'
  }).then(() => {
    // 将forceLogin设置为true
    // 重新强制登录
    loginForm.forceLogin = true
    clickLogin()
  })
}

// 密码修改弹窗
const showUpdatePassword = ref(false)
const updatePasswordDialogRef = ref()
// MFA初始化弹窗
const showMFACodeDialog = ref(false)
const MFACodeDialogRef = ref()
// MFA强制验证
const showMFACodeForceDialog = ref(false)
const forceMFADialogRef = ref()
// 多账户选择弹窗
const showMultipartUserSelectDialog = ref(false)
// 多账户信息
const multipartUserInfo = ref<TokenResponse[]>([])

// 初始化密码修改提示
const defaultPasswordTip = (loginIno: TokenResponse) => {
  // 重置MFA初始化绑定变量
  resetBindMFAData()
  const startTime = new Date().getTime()
  ElMessageBox.confirm(t('defaultPasswordEditTip'), t('tip'), {
    confirmButtonText: t('user.updatePassword'),
    cancelButtonText: t('cancel'),
    type: 'warning'
  })
    .then(() => {
      const endTime = new Date().getTime()
      const countTime = (endTime - startTime) / 1000
      const expiresIn = loginIno.expiresIn! / 1000
      // 防止长时间不点击导致临时token都失效了
      if (expiresIn - countTime > 0) {
        // 设置临时身份token
        mainStore.setLoginInfo(loginIno)
        //  打开修改密码弹窗
        showUpdatePassword.value = true
        // 直接倒计时
        updatePasswordDialogRef.value?.start(expiresIn - countTime)
      } else {
        ElMessage.warning(t('tempTokenExpired'))
      }
    })
    .catch(() => {
      mainStore.setLoginInfo({})
    })
}

// 密码过期修改提示
const passwordExpiredTip = (loginIno: TokenResponse) => {
  // 重置MFA初始化绑定变量
  resetBindMFAData()
  const startTime = new Date().getTime()
  ElMessageBox.confirm(t('passwordExpired'), t('tip'), {
    confirmButtonText: t('user.updatePassword'),
    cancelButtonText: t('cancel'),
    type: 'warning'
  })
    .then(() => {
      const endTime = new Date().getTime()
      const countTime = (endTime - startTime) / 1000
      const expiresIn = loginIno.expiresIn! / 1000
      // 防止长时间不点击导致临时token都失效了
      if (expiresIn - countTime > 0) {
        // 设置临时身份token
        mainStore.setLoginInfo(loginIno)
        //  打开修改密码弹窗
        showUpdatePassword.value = true
        // 直接倒计时
        updatePasswordDialogRef.value?.start(expiresIn - countTime)
      } else {
        ElMessage.warning(t('tempTokenExpired'))
      }
    })
    .catch(() => {
      mainStore.setLoginInfo({})
    })
}

// MFA未初始化提示
const mfaNotInitTip = (loginIno: TokenResponse) => {
  // 重置MFA初始化绑定变量
  resetBindMFAData()
  const startTime = new Date().getTime()
  ElMessageBox.confirm(t('mfaNotInitTip'), t('tip'), {
    confirmButtonText: t('confirm'),
    cancelButtonText: t('cancel'),
    type: 'warning'
  })
    .then(() => {
      const endTime = new Date().getTime()
      const countTime = (endTime - startTime) / 1000
      const expiresIn = loginIno.expiresIn! / 1000
      // 防止长时间不点击导致临时token都失效了
      if (expiresIn - countTime > 0) {
        // 设置临时身份token
        mainStore.setLoginInfo(loginIno)
        //  打开MFA初始化弹窗
        showMFACodeDialog.value = true
        // 直接倒计时
        MFACodeDialogRef.value?.start(expiresIn - countTime)
        nextTick(() => {
          MFACodeDialogRef.value?.getSecret()
        })
      } else {
        ElMessage.warning(t('tempTokenExpired'))
      }
    })
    .catch(() => {
      mainStore.setLoginInfo({})
    })
}

// 是否初始化MFA
const isInitMFA = ref(false)
// 输入的mfa码
const mfaCode = ref('')
// 初始化绑定MFA成功
const handleInitBindSuccess = (TotpCode: string) => {
  isInitMFA.value = true
  mfaCode.value = TotpCode
  // 调用登录接口
  clickLogin()
}

// 重置MFA初始化绑定变量
const resetBindMFAData = () => {
  isInitMFA.value = false
  mfaCode.value = ''
}

// 手动调用MFA验证登录
const handleManualMFAValidate = () => {
  const data = {
    loginAgent: mainStore.loginAgent,
    mfaType: 21, // 固定TOTP验证码登录
    mfaCode: mfaCode.value
  }
  loading.value = true
  userMfaVerify(data)
    .then(res => {
      if (res.state === 'success') {
        // 直接登录
        mainStore.setLoginInfo(res.data!)
        handleInfo()
      } else {
        const msg = t('MFAValidate') + t('error')
        ElMessage.error(`${msg}，请重新登录！`)
      }
      loading.value = false
    })
    .catch(() => {
      loading.value = false
    })
    .finally(() => {
      // 重置绑定MFA数据
      resetBindMFAData()
    })
}

// MFA强制校验
const forceMFAValidate = (loginIno: TokenResponse) => {
  // 重置MFA初始化绑定变量
  resetBindMFAData()
  // 设置临时身份token
  mainStore.setLoginInfo(loginIno)
  showMFACodeForceDialog.value = true
  // 直接倒计时, 减去1防止临界情况
  forceMFADialogRef.value?.start(loginIno.expiresIn! / 1000 - 1)
}

// 存在多账户提示
const showMultipartUserSelectDialogTip = (loginIno: TokenResponse[]) => {
  // 重置MFA初始化绑定变量
  resetBindMFAData()
  ElMessageBox.confirm(t('multipartUserSelect'), t('tip'), {
    confirmButtonText: t('confirm'),
    cancelButtonText: t('cancel'),
    type: 'warning'
  }).then(() => {
    // 设置临时身份token
    showMultipartUserSelectDialog.value = true
    multipartUserInfo.value = loginIno
  })
}

// 是否显示短信验证码登录  0 用户名密码登录  1 短信验证码登录, 邮箱登录  后续可能出现第三方登录
const activeLoginType = ref(0)
// 点击短信验证码登录
const handleTextMessageLogin = () => {
  activeLoginType.value = 1
  formEl.value?.resetFields()
}
// 点击用户名密码登录
const handleUserPasswordLogin = () => {
  activeLoginType.value = 0
  loginForm.loginSecret = ''
}

// 获取验证码
const countdownForLogin = ref(60)
// 是否显示获取验证码按钮，用于判断倒计时以及获取验证码按钮
const showGetCodeForLogin = ref(true)

// 获取验证码是否禁用
const disabledGetCodeBtnForLogin = computed(() => {
  if (loginForm.loginId) {
    // 手机号正则
    const phoneReg =
      /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/
    // 邮箱正则
    const emailReg =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    if (phoneReg.test(loginForm.loginId) || emailReg.test(loginForm.loginId)) {
      return false
    }
    return true
  }
  return true
})

// 获取验证码
const getLoginCode = () => {
  // 点击之后验证码60s后才可点击
  loginForm.loginPass = ''
  // 获取手机验证码
  getGenCaptchaForLogin()
}

// 获取手机短信验证码判断是否需要填写验证码
const getGenCaptchaForLogin = () => {
  loading.value = true
  authGenCaptcha({
    captchaId: validateParams.value.captchaId || ''
  })
    .then(res => {
      loading.value = false
      if (res.state === 'success') {
        // 成功
        validateParams.value = {}
        // 直接获取手机验证码
        queryCodeForMessageNoCaptchaForLogin()
      } else if (res.state === 'error' && res.msg) {
        // 失败
        showFailuresText.value = res.msg
        showCaptcha.value = false
        const matchData = extractContentFromBrackets(res.msg)
        ElMessage.error({
          message: showFailuresText.value,
          duration: matchData[matchData.length - 1]
            ? Number(matchData[matchData.length - 1]) * 1000
            : 60 * 1000,
          showClose: true
        })
      } else if (res.data && res.data.captchaId) {
        validateParams.value = { ...res.data }
        showCaptcha.value = true
      }
    })
    .catch(() => {
      loading.value = false
    })
}

const timer = ref()
// 倒计时60s
const countdownTimeForLogin = () => {
  timer.value = setInterval(() => {
    if (countdownForLogin.value > 0) {
      countdownForLogin.value--
    } else {
      showGetCodeForLogin.value = true
      timer.value && clearInterval(timer.value)
    }
  }, 1000)
}

// 发送手机验证码--无需机器校验
const queryCodeForMessageNoCaptchaForLogin = () => {
  loading.value = true
  // 判断是邮箱还是手机号
  let loginType = 23
  const type = getLoginTypeForPasswordLogin()
  if (type === 2) {
    loginType = 22
  } else {
    loginType = 23
  }
  authSendDeviceCode({
    loginType: loginType,
    loginId: loginForm.loginId,
    captchaId: validateParams.value.captchaId || '',
    captchaSign: validateParams.value.captchaId ? validateSign.value : '',
    userType: 110,
    loginAgent: mainStore.loginAgent
  })
    .then((res: any) => {
      if (res.state === 'success') {
        // 倒计时
        showGetCodeForLogin.value = false
        if (countdownForLogin.value === 0) {
          countdownForLogin.value = 60
        }
        // 开始倒计时
        countdownTimeForLogin()
      } else {
        ElMessage.error(res.msg)
      }
      loading.value = false
    })
    .catch(() => {
      loading.value = false
    })
}

// 发送手机验证码--需要机器校验
const queryCodeForMessageNeedCaptchaForLogin = () => {
  loading.value = true
  // 判断是邮箱还是手机号
  let loginType = 23
  const type = getLoginTypeForPasswordLogin()
  if (type === 2) {
    loginType = 22
  } else {
    loginType = 23
  }
  authSendDeviceCode({
    loginType: loginType,
    loginId: loginForm.loginId,
    captchaId: validateParams.value.captchaId || '',
    captchaSign: validateParams.value.captchaId ? validateSign.value : '',
    userType: 110,
    loginAgent: mainStore.loginAgent
  })
    .then((res: any) => {
      if (res.state === 'success') {
        captchaRef.value?.validateSuccess()
        // 倒计时
        showGetCodeForLogin.value = false
        if (countdownForLogin.value === 0) {
          countdownForLogin.value = 60
        }
        // 开始倒计时
        countdownTimeForLogin()
      } else {
        if (String(res.code).includes('auth.center.captcha.verify')) {
          // 验证码错误重新刷新
          captchaRef.value?.validateError()
          setTimeout(() => {
            handleRefreshCode()
          }, 1500)
        } else {
          ElMessage.error(res.msg)
          showCaptcha.value = false
        }
      }
      loading.value = false
    })
    .catch(() => {
      loading.value = false
    })
}

// 账户选择后，继续登录
const handleContinueLogin = (loginInfo: TokenResponse) => {
  showMultipartUserSelectDialog.value = false
  const timer = setTimeout(() => {
    clearTimeout(timer)
    // 选中当前的需要登录的用户ID
    // 进行登录
    loginForm.userId = loginInfo.userId
    // 调用登录
    clickLogin()
  }, 500)
}

// MFA强制校验后登录
const handleMFACodeForceLogin = (loginInfo: TokenResponse) => {
  showMFACodeForceDialog.value = false
  const timer = setTimeout(() => {
    clearTimeout(timer)
    mainStore.setLoginInfo(loginInfo)
    handleInfo()
  }, 500)
}

// 跳转忘记密码页面
const handleForgetPassword = () => {
  router.push('/password')
}

onMounted(() => {
  // 清除临时token之类的信息，防止异常
  mainStore.setLoginInfo({})
})

onUnmounted(() => {
  timer.value && clearInterval(timer.value)
})
</script>

<template>
  <div
    class="login"
    :class="{ lightImg: !isDark, darkImg: isDark }"
    ref="loginRef"
  >
    <div class="login_top space-between padding-top-10">
      <el-image
        class="login-top__image"
        fit="cover"
        :src="isDark ? logoDark : logo"
        :style="logoAnimation"
      />
      <div class="login-top__right flex-row flex-align">
        <p class="padding-left-15 flex-align">
          <!-- 语言切换 -->
          <LangSelect />
          <!-- 黑夜模式切换 -->
          <el-switch
            v-model="isDark"
            active-color="black"
            active-action-icon="Moon"
            inactive-action-icon="Sunny"
            class="margin-left-20"
          ></el-switch>
        </p>
      </div>
    </div>
    <div
      class="login-box flex-align flex-col flex-center"
      :style="{ background: isDark ? '#18222C' : 'var(--el-color-white)' }"
    >
      <div
        :class="{
          'light-animation': loading && !isDark,
          'dark-animation': loading && isDark
        }"
      ></div>
      <!-- 登录表单 -->
      <div
        v-show="!showCaptcha"
        style="width: 100%"
        class="flex-align flex-col padding-top-20 padding-bottom-20"
      >
        <el-form
          ref="formEl"
          label-position="right"
          :model="loginForm"
          :rules="rules"
          class="login-box__form"
          size="large"
          :validate-on-rule-change="false"
        >
          <el-row
            type="flex"
            justify="center"
          >
            <el-col :span="18">
              <h2
                class="title"
                :style="{
                  color: isDark ? '#ffffff' : 'var(--el-text-color-regular)'
                }"
              >
                {{ t('login.signIn') }}
              </h2>
            </el-col>
            <el-col :span="18">
              <el-form-item prop="loginId">
                <el-input
                  v-model.trim="loginForm.loginId"
                  prefix-icon="User"
                  :placeholder="
                    activeLoginType === 0
                      ? t('idOrPhoneOrEmail')
                      : t('phoneOrEmail')
                  "
                />
              </el-form-item>
            </el-col>
            <!-- 短信验证码登录时不需要密码输入框 -->
            <el-col
              :span="18"
              v-show="activeLoginType === 0"
            >
              <el-form-item prop="loginSecret">
                <el-input
                  v-model.trim="loginForm.loginSecret"
                  type="password"
                  show-password
                  prefix-icon="Unlock"
                  :placeholder="t('pleaseInput') + t('login.passWord')"
                />
              </el-form-item>
            </el-col>
            <el-col
              :span="18"
              v-show="activeLoginType === 1"
            >
              <el-row
                :gutter="5"
                style="margin-bottom: 22px"
              >
                <el-col :span="showGetCodeForLogin ? 16 : 14">
                  <el-input
                    v-model.trim="loginForm.loginPass"
                    :placeholder="t('pleaseInputValidateCode')"
                    clearable
                    style="width: 100%"
                    :disabled="disabledGetCodeBtnForLogin"
                    prefix-icon="Lock"
                  />
                </el-col>
                <el-col :span="showGetCodeForLogin ? 8 : 10">
                  <el-button
                    type="primary"
                    :disabled="disabledGetCodeBtnForLogin"
                    @click="getLoginCode"
                    v-if="showGetCodeForLogin"
                  >
                    {{ t('getValidateCode') }}
                  </el-button>
                  <el-button
                    type="primary"
                    :disabled="true"
                    v-else
                  >
                    {{ `${t('getValidateCode')}(${countdownForLogin}s)` }}
                  </el-button>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="18">
              <div class="space-between margin-bottom-5">
                <div class="text-message-forceLogin flex-align">
                  <el-checkbox
                    v-model="loginForm.forceLogin"
                    :label="t('forceLogin')"
                    size="default"
                  />
                </div>
                <div class="flex-end">
                  <div
                    class="text-message flex-align flex-end"
                    @click="handleUserPasswordLogin"
                    v-show="activeLoginType === 1"
                  >
                    <el-text
                      type="primary"
                      size="default"
                    >
                      {{ t('passwordLogin') }}
                    </el-text>
                  </div>
                  <div
                    class="text-message flex-align flex-end"
                    @click="handleTextMessageLogin"
                    v-show="activeLoginType === 0"
                  >
                    <el-text
                      type="primary"
                      size="default"
                    >
                      {{ t('validateCodeLogin') }}
                    </el-text>
                  </div>
                </div>
              </div>
            </el-col>
            <el-col :span="18">
              <el-button
                type="primary"
                class="login-box__btn"
                :class="{
                  'margin-top-10': showFailuresText
                }"
                @click="clickLogin"
                :loading="loading"
                :style="{
                  background: isDark ? '#153D73' : 'var(--el-color-primary)',
                  borderColor: isDark
                    ? '#153D73'
                    : 'var(--el-button-border-color)'
                }"
              >
                {{ t('login.signIn') }}
              </el-button>
            </el-col>
            <el-col :span="18">
              <div
                class="flex-center cursor-p margin-top-10 forgetPass"
                @click="handleForgetPassword"
              >
                <el-text
                  type="primary"
                  size="default"
                >
                  {{ t('forgetPassword') }}
                </el-text>
              </div>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <!-- 校验窗口 -->
      <Captcha
        ref="captchaRef"
        v-model:show="showCaptcha"
        :data="validateParams"
        @refresh="handleRefreshCode"
        @validate="handleValidate"
      ></Captcha>
    </div>
  </div>
  <!-- 修改密码 -->
  <UpdatePasswordDialog
    v-model="showUpdatePassword"
    ref="updatePasswordDialogRef"
  />
  <!-- MFA初始化 -->
  <MFACodeDialog
    v-model="showMFACodeDialog"
    ref="MFACodeDialogRef"
    @onInitBindSuccess="handleInitBindSuccess"
  />
  <!-- MFA强制校验 -->
  <ForceMFADialog
    v-model="showMFACodeForceDialog"
    @login="handleMFACodeForceLogin"
    :captchaId="validateParams.captchaId"
    :captchaSign="validateSign"
    ref="forceMFADialogRef"
  />
  <!-- 多账户选择 -->
  <MultipartUserSelectDialog
    v-model="showMultipartUserSelectDialog"
    :user-info-list="multipartUserInfo"
    @continueLogin="handleContinueLogin"
  />
</template>

<style lang="scss" scoped>
.lightImg {
  background: url('../../assets/login_background.jpg') no-repeat;
}

.darkImg {
  background: url('../../assets/login_background_dark.png') no-repeat;
}

.login {
  position: relative;
  height: 100vh;
  background-size: cover;

  .login_top {
    max-width: 1200px;
    margin: 0 auto;

    .login-top__right {
      color: var(--el-color-white);
    }
  }

  .login-box {
    width: 450px;
    height: 340px;
    box-shadow: 0px 8px 21px 0px rgba(5, 76, 138, 0.45);
    border-radius: 20px;
    box-sizing: border-box;
    overflow: hidden;
    margin: 10vh auto;
    position: relative;

    .login-box__form {
      width: 100%;
      box-sizing: border-box;
      .text-message {
        width: 80px;
        height: 32px;
        cursor: pointer;
        text-align: right;
      }
      .text-message-forceLogin {
        width: 80px;
        height: 32px;
        cursor: pointer;
        text-align: left;
        :deep(.el-checkbox__label) {
          color: var(--el-color-primary);
          font-weight: normal;
        }
      }
      .forgetPass {
        height: 30px;
      }
      .title {
        text-align: center;
        letter-spacing: 10px;
      }
    }

    .login-box__btn {
      font-size: 16px;
      width: 340px;
      height: 45px;
    }

    .light-animation {
      position: absolute;
      top: 0;
      left: 0;
      width: 0;
      height: 100%;
      background: linear-gradient(
        0deg,
        rgba(255, 255, 255, 0),
        rgba(135, 206, 235, 0.4),
        rgba(255, 255, 255, 0)
      );
      animation: skeleton-animation 1s ease;
      animation-iteration-count: 1;
      animation-fill-mode: forwards;
    }
    .dark-animation {
      position: absolute;
      top: 0;
      left: 0;
      width: 0;
      height: 100%;
      background: linear-gradient(
        0deg,
        rgba(255, 255, 255, 0),
        rgba(255, 255, 255, 0.4),
        rgba(255, 255, 255, 0)
      );
      animation: skeleton-animation 1s ease;
      animation-iteration-count: 1;
      animation-fill-mode: forwards;
    }
  }
}

@keyframes skeleton-animation {
  0% {
    width: 0;
  }
  50% {
    width: 100%;
  }
  100% {
    width: 0;
  }
}
</style>
