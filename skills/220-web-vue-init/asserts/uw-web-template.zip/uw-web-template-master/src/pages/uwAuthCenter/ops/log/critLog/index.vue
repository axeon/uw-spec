<script setup lang="ts">
import { type ComponentInternalInstance } from 'vue'
import { SearchFormType } from '@/components/SearchForm/type'
import {
  opsLogCritLogList,
  SysCritLog,
  type SysCritLogQueryParam
} from '@/api/uwAuthCenterOpsApi'
import { useCommonSelectTypes } from '@/utils/selectOptions'
import { useI18n } from 'vue-i18n'
import { useCrud } from '@/hooks/useCrud'
import { ResponseData, DataList } from '@/api/uwAuthCenterAuthApi'
import { useExportExcel } from '@/hooks/useExportExcel'

// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance
const { dayjs, useActivated } = proxy as any
const { t } = useI18n()
const { userTypes } = useCommonSelectTypes()

const {
  tableConfig, // 表格相关配置属性
  handleList // 列表请求函数
} = useCrud<SysCritLog, SysCritLogQueryParam>({
  // 列表请求接口
  listFn: (): Promise<ResponseData<DataList<SysCritLog>>> => {
    tableConfig.queryParams.$sn = ['id']
    return opsLogCritLogList(tableConfig.queryParams)
  }
})

// 搜索表单 结构组成数据
const searchList = computed<SearchFormType[]>(() => {
  return [
    {
      field: 'userName',
      formItem: {
        label: '用户名称',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + '用户名称'
    },
    {
      field: 'realName',
      formItem: {
        label: t('user.realName'),
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + t('user.realName')
    },
    {
      field: 'userType',
      formItem: {
        label: '用户类型',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'select',
      options: userTypes.value,
      placeholder: t('pleaseSelect') + '用户类型',
      value: ''
    },
    {
      field: 'userIp',
      formItem: {
        label: '用户IP',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + '用户IP'
    },
    {
      field: 'apiUri',
      formItem: {
        label: '请求uri',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + '请求uri',
      value: ''
    },
    {
      field: 'appInfo',
      formItem: {
        label: '应用信息',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + '应用信息',
      value: ''
    },
    {
      field: 'appHost',
      formItem: {
        label: '应用主机',
        labelWidth: '90'
      },
      formItemWidth: 280,
      clearable: true,
      componentType: 'input',
      placeholder: t('pleaseInput') + '应用主机'
    },
    {
      field: 'requestDateRange',
      componentType: 'datePicker',
      formItem: {
        label: '请求日期',
        labelWidth: 90
      },
      clearable: true,
      formItemWidth: 480,
      type: 'datetimerange',
      startPlaceholder: t('pleaseSelect') + '开始日期',
      endPlaceholder: t('pleaseSelect') + '结束日期',
      defaultTime: [
        new Date(2000, 1, 1, 0, 0, 0),
        new Date(2000, 2, 1, 23, 59, 59)
      ],
      valueFormat: 'YYYY-MM-DD HH:mm:ss'
    }
  ]
})

// 用户资料
const popoverData = ref({})
// popover 显示
const handlePopoverShow = (item: SysCritLog) => {
  popoverData.value = item || {}
}

const showLog = ref(false)
const logContent = ref('')
const handleShowDetail = (data: string) => {
  showLog.value = true
  logContent.value = data
}

const data = computed(() => [
  {
    field: 'appHost',
    label: 'App主机'
  },
  {
    field: 'appInfo',
    label: 'App信息'
  },
  {
    field: 'userId',
    label: '用户Id'
  },
  {
    field: 'userName',
    label: '用户信息'
  },
  {
    field: 'nickName',
    label: '昵称信息'
  },
  {
    field: 'realName',
    label: '真实姓名'
  },
  {
    field: 'saasId',
    label: '运营商Id'
  },
  {
    field: 'mchId',
    label: '商户Id'
  },
  {
    field: 'groupId',
    label: '用户组Id'
  },
  {
    field: 'userType',
    label: '用户类型',
    options: userTypes.value
  },
  {
    field: 'apiUri',
    label: 'URI'
  },
  {
    field: 'apiName',
    label: 'API名称'
  },
  {
    field: 'clientAgent',
    label: '用户代理'
  },
  {
    field: 'bizType',
    label: '业务类型'
  },
  {
    field: 'bizId',
    label: '业务Id'
  },
  {
    field: 'requestDate',
    label: '请求时间',
    valueFormat: 'YYYY-MM-DD HH:mm:ss'
  },
  {
    field: 'responseBody',
    label: '响应日志'
  },
  {
    field: 'responseMillis',
    label: '执行返回毫秒数'
  },
  {
    field: 'exception',
    label: '异常信息'
  },
  {
    field: 'statusCode',
    label: '响应状态码'
  }
])

const { startExport } = useExportExcel()
const exportExcel = () => {
  startExport({
    url: '/uw-auth-center/ops/log/critLog/list',
    queryParams: tableConfig.queryParams,
    columns: data.value,
    sizeAll: tableConfig.sizeAll
  })
}

useActivated(() => {
  handleList()
})
</script>

<template>
  <div class="flex_col">
    <div class="flex_col_header">
      <SearchForm
        v-model="tableConfig.queryParams"
        :bnt-loading="tableConfig.tableLoading"
        :list="searchList"
        @change="handleList"
        @search="handleList"
      >
        <template #right>
          <el-button
            @click="exportExcel"
            round
            type="primary"
            size="small"
            icon="Download"
          >
            导出
          </el-button>
        </template>
      </SearchForm>
    </div>

    <el-table
      border
      style="width: 100%"
      :header-cell-style="{
        backgroundColor: 'var(--el-color-info-light-9)'
      }"
      :data="tableConfig.dataList"
      v-loading="tableConfig.tableLoading"
      class="flex_col_body"
      stripe
    >
      <el-table-column
        prop="id"
        label="ID"
        align="center"
        minWidth="90"
        fixed="left"
      ></el-table-column>
      <el-table-column
        prop="userInfo"
        label="用户信息"
        align="center"
        width="140"
      >
        <template #default="{ row }">
          <p>
            {{ row.userName }}
          </p>
          <p>{{ row.userIp ? row.userIp : '' }}</p>
        </template>
      </el-table-column>
      <el-table-column
        prop="bizType"
        label="操作对象类型"
        align="center"
        minWidth="120"
      ></el-table-column>
      <el-table-column
        prop="apiUri"
        label="请求URL"
        align="center"
        minWidth="180"
      ></el-table-column>
      <el-table-column
        prop="apiName"
        label="方法操作描述"
        align="center"
        minWidth="100"
      ></el-table-column>
      <el-table-column
        prop="requestInfo"
        label="请求信息"
        align="center"
        minWidth="180"
      >
        <template #default="scope">
          <div class="textAlignLeft">
            <el-link
              type="primary"
              @click="handleShowDetail(scope.row.requestBody)"
              underline="never"
            >
              请求参数
            </el-link>
          </div>
          <div class="textAlignLeft">
            <span>请求时间：</span>
            <span>
              {{
                scope.row.requestDate
                  ? dayjs(scope.row.requestDate).format('YYYY-MM-DD HH:mm:ss')
                  : ''
              }}
            </span>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="responseInfo"
        label="响应信息"
        align="center"
        minWidth="150"
      >
        <template #default="scope">
          <div class="textAlignLeft">
            <el-link
              type="primary"
              @click="handleShowDetail(scope.row.responseBody)"
              underline="never"
            >
              响应信息
            </el-link>
          </div>
          <div class="textAlignLeft">
            <span>响应毫秒：</span>
            <span>
              {{
                scope.row.responseMillis
                  ? scope.row.responseMillis + '(ms)'
                  : ''
              }}
            </span>
          </div>
          <div class="textAlignLeft">
            <span>响应状态码：</span>
            <el-text
              :type="scope.row.statusCode === 200 ? 'success' : 'danger'"
            >
              {{ scope.row.statusCode ? scope.row.statusCode : '' }}
            </el-text>
          </div>
          <div
            v-if="scope.row.exception"
            class="textAlignLeft"
          >
            <span>异常信息：</span>
            <el-tooltip
              effect="dark"
              :content="scope.row.exception ? scope.row.exception : ''"
              placement="top-start"
            >
              <span>{{ scope.row.exception ? scope.row.exception : '' }}</span>
            </el-tooltip>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="appInfo"
        label="应用信息"
        align="center"
        minWidth="150"
      >
        <template #default="scope">
          <p>{{ scope.row.appInfo ? scope.row.appInfo : '' }}</p>
          <p>{{ scope.row.appHost ? scope.row.appHost : '' }}</p>
        </template>
      </el-table-column>
      <el-table-column
        prop="opLog"
        label="日志"
        align="center"
        minWidth="150"
      ></el-table-column>
    </el-table>
    <Pagination
      v-model:page-size="tableConfig.queryParams.$rn"
      @page-size-change="handleList(false)"
      :total="tableConfig.sizeAll"
      v-model:current-page="tableConfig.queryParams.$pg"
      @current-change="handleList(false)"
      class="flex_col_bottom"
    />
  </div>

  <QueryLog
    v-model="showLog"
    :content="logContent"
  ></QueryLog>
</template>

<style lang="scss" scoped>
.textAlignLeft {
  text-align: left;
}
</style>
