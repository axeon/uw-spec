<script setup lang="ts">
import { type ComponentInternalInstance } from 'vue'
import { ElMessage, ElMessageBox, type FormInstance } from 'element-plus'
import {
  opsMscMscPermUpdate,
  opsMscMscPermForceAppPermRank,
  opsMscMscPermResetAppPermRank,
  opsMscMscPermLoad,
  opsMscMscPermList,
  opsMscMscPermDelete,
  opsMscMscPermListMenuUserType,
  type PermVo
} from '@/api/uwAuthCenterOpsApi'
import { useI18n } from 'vue-i18n'
import { useCommonSelectTypes } from '@/utils/selectOptions'
import { EnumStruct } from '@/api/uwAuthCenterAuthApi'

interface MscMenu {
  id?: number | string //id
  permCode?: string //权限菜单URI
  permName?: string //权限菜单名称
  permRank?: number
  label?: string
  permList?: MscMenu[]
  children?: MscMenu[]
  permVoList?: PermVo[]
}

interface newMscMenuTreeVo extends PermVo {
  children?: newMscMenuTreeVo[] // 树状结构展示用，只展示到第二级
  permList?: newMscMenuTreeVo[] // 右边权限结构展示用，只有第三级
  childrenForSort?: newMscMenuTreeVo[] // 完整权限结构，用于排序
  label?: string
}

const { t } = useI18n()
// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance
const { useActivated } = proxy as any
const { getAllUserTypes } = useCommonSelectTypes()

const form = ref<FormInstance>()
const form1 = ref<FormInstance>()
const loading = ref(false)
const userType = ref<number>(100)
const permissionList = ref<any[]>([])
const tabActive = ref(0)
const updatePermId = ref<null | number>(null)
const dialogFormVisible = ref(false)
const formData = reactive({
  id: 0,
  appId: 0,
  permName: '',
  permLevel: 1,
  permRank: 1,
  state: 1,
  userType: 0,
  permDesc: '',
  permCode: '',
  displayState: 1
})
const formData1 = reactive({
  id: 0,
  appId: 0,
  permName: '',
  permLevel: 1,
  permRank: 1,
  state: 1,
  userType: 0,
  permDesc: '',
  permCode: '',
  displayState: 1
})
const levelOptions = computed(() => [
  {
    value: 1,
    label: '权限分类'
  },
  {
    value: 2,
    label: '菜单分类'
  },
  {
    value: 3,
    label: '菜单'
  },
  {
    value: 31,
    label: '权限'
  }
])
const treeRef = ref()

const treeListData = computed(() => {
  if (permissionList.value.length === 0) return []
  if (permissionList.value[tabActive.value]) {
    return permissionList.value[tabActive.value]?.children
  }
  return []
})

// 获取管理员类型
const getMscMenuUserTypes = ref<EnumStruct[]>([])
const getUserTypes = () => {
  opsMscMscPermListMenuUserType()
    .then(res => {
      getMscMenuUserTypes.value = res.data || []
    })
    .catch(() => {
      getMscMenuUserTypes.value = []
    })
}

// 接口权限 二维数组格式
const newApiAuth = ref<MscMenu[]>([])
// 数字倒序以3进行分割
const formatNumberToGroups = (data: number) => {
  const numStr = data.toString() // 将数字转换为字符串
  const result = [] // 初始化结果数组
  // 从字符串的末尾开始，每三个字符一组添加到结果数组
  for (let i = numStr.length - 1; i >= 0; i -= 3) {
    // 如果不是起始位置，则添加逗号
    if (i > 0) {
      result.unshift(numStr.substring(i - 2, i + 1)) // 取当前位置前两个字符到当前位置的子串
    } else {
      result.unshift(numStr.substring(0, i + 1)) // 处理不足三位数的情况
    }
  }
  return result
}

//  处理树形菜单数据
const handleTreeMenu = (menu: newMscMenuTreeVo[]) => {
  if (!menu || menu.length === 0) return []
  const data: newMscMenuTreeVo[] = []
  const merchantData: newMscMenuTreeVo[] = []
  // 正常一级菜单数据
  const allFirstNumberForNormal: number[] = []
  // 分销商、供应商一级菜单数据（合并成一个商户）
  const allFirstNumberForMerchant: number[] = []
  // 正常的菜单
  menu.forEach(item => {
    // 正常
    if (!item.permCode?.startsWith('/mch/')) {
      const permRankSplit = formatNumberToGroups(item.permRank!)
      const newFirstRank = Number(permRankSplit[0])
      if (!allFirstNumberForNormal.includes(newFirstRank)) {
        allFirstNumberForNormal.push(newFirstRank)
      }
    }
    // 商户
    if (item.permCode?.startsWith('/mch/')) {
      const permRankSplit = formatNumberToGroups(item.permRank!)
      const newFirstRank = Number(permRankSplit[0])
      if (!allFirstNumberForMerchant.includes(newFirstRank)) {
        allFirstNumberForMerchant.push(newFirstRank)
      }
    }
  })
  allFirstNumberForNormal.sort()
  allFirstNumberForMerchant.sort()
  // 一级菜单
  allFirstNumberForNormal.forEach(item => {
    const target = menu.find(
      targetItem =>
        String(targetItem.permRank) === `${item}000000000` &&
        !targetItem.permCode?.startsWith('/mch/')
    )
    if (target) {
      data.push({ ...target, label: target.permName })
    }
  })
  // 二级目录
  data.forEach(item => {
    const rank = formatNumberToGroups(item.permRank!)[0]
    const targetArray = menu.filter(menuItem => {
      const splitRank = formatNumberToGroups(menuItem.permRank!)
      if (
        splitRank[0] === rank &&
        '000' === splitRank[2] &&
        '000' === splitRank[3] &&
        String(menuItem.permRank) !== `${rank}000000000` &&
        !menuItem.permCode?.startsWith('/mch/')
      ) {
        return true
      }
      return false
    })
    if (targetArray.length) {
      // 树状结构展示用，只展示到第二级
      if (item.children) {
        targetArray.forEach(target =>
          item.children!.push({ ...target, label: target.permName })
        )
      } else {
        item.children = targetArray.map(target => {
          return {
            ...target,
            label: target.permName
          }
        })
      }
      // 完整权限结构，用于排序
      if (item.childrenForSort) {
        targetArray.forEach(target =>
          item.childrenForSort!.push({ ...target, label: target.permName })
        )
      } else {
        item.childrenForSort = targetArray.map(target => {
          return {
            ...target,
            label: target.permName
          }
        })
      }
    }
    // 右边权限结构展示用，只有第三级，当前二级赋值为空
    item.permList = []
  })

  // 三级目录
  data.forEach(item => {
    // 展示所用结构
    // 左边用children 展示菜单
    // 右边用permList 展示菜单对应下的权限
    if (item.children && item.children.length) {
      item.children.forEach(subItem => {
        const rankGroup = formatNumberToGroups(subItem.permRank!)
        const rank1 = rankGroup[0]
        const rank2 = rankGroup[1]
        // 接口
        const permArray = menu.filter(menuItem => {
          const splitRank = formatNumberToGroups(menuItem.permRank!)
          //  必须是接口
          if (
            splitRank[0] === rank1 &&
            rank2 === splitRank[1] &&
            String(menuItem.permRank) !== `${rank1}${rank2}000000` &&
            !menuItem.permCode?.startsWith('/mch/')
          ) {
            return true
          }
          return false
        })
        if (permArray?.length) {
          // 对菜单对应下属权限赋值
          subItem.permList = permArray
        } else {
          subItem.permList = []
        }
      })
    }
    // 完整结构childrenForSort 用于排序时上传结构
    if (item.childrenForSort?.length) {
      item.childrenForSort.forEach(subItem => {
        const rankGroup = formatNumberToGroups(subItem.permRank!)
        const rank1 = rankGroup[0]
        const rank2 = rankGroup[1]
        // 菜单
        const targetArray = menu.filter(menuItem => {
          const splitRank = formatNumberToGroups(menuItem.permRank!)
          if (
            splitRank[0] === rank1 &&
            rank2 === splitRank[1] &&
            String(menuItem.permRank) !== `${rank1}${rank2}000000` &&
            !menuItem.permCode?.includes(':') &&
            !menuItem.permCode?.startsWith('/mch/')
          ) {
            return true
          }
          return false
        })
        // 接口
        const permArray = menu.filter(menuItem => {
          const splitRank = formatNumberToGroups(menuItem.permRank!)
          //  必须是接口
          if (
            splitRank[0] === rank1 &&
            rank2 === splitRank[1] &&
            splitRank[2] === '000' &&
            String(menuItem.permRank) !== `${rank1}${rank2}000000` &&
            !menuItem.permCode?.startsWith('/mch/')
          ) {
            return true
          }
          return false
        })
        if (targetArray.length) {
          // 菜单对应下属权限赋值
          targetArray.forEach(childItem => {
            const splitRank = formatNumberToGroups(childItem.permRank!)
            if (splitRank[2] !== '000' && splitRank[3] === '000') {
              const threeChild = menu.filter(menuItem => {
                const childRankGroup = formatNumberToGroups(menuItem.permRank!)
                if (
                  splitRank[0] === childRankGroup[0] &&
                  splitRank[1] === childRankGroup[1] &&
                  splitRank[2] === childRankGroup[2] &&
                  childRankGroup[2] !== '000' &&
                  menuItem.permCode?.includes(':') &&
                  !menuItem.permCode?.startsWith('/mch/')
                ) {
                  return true
                }
                return false
              })
              if (threeChild?.length) {
                threeChild.forEach(threeChildItem => {
                  if (childItem?.childrenForSort) {
                    childItem.childrenForSort.push({
                      ...threeChildItem,
                      label: threeChildItem.permName
                    })
                  } else {
                    childItem.childrenForSort = [
                      { ...threeChildItem, label: threeChildItem.permName }
                    ]
                  }
                })
              }
            }
          })
          if (subItem.childrenForSort) {
            targetArray.forEach(target =>
              subItem.childrenForSort!.push({
                ...target,
                label: target.permName
              })
            )
          } else {
            subItem.childrenForSort = targetArray.map(target => {
              return {
                ...target,
                label: target.permName
              }
            })
          }
          // 不仅有对应的3.5级，还有三级对应的权限
          if (permArray?.length) {
            for (let i = permArray.length - 1; i >= 0; i--) {
              subItem.childrenForSort.unshift(permArray[i])
            }
          }
        } else {
          subItem.childrenForSort = permArray
        }
      })
    }
  })

  if (allFirstNumberForMerchant?.length) {
    // 商户一级菜单
    allFirstNumberForMerchant.forEach(item => {
      const target = menu.find(
        targetItem =>
          String(targetItem.permRank) === `${item}000000000` &&
          targetItem.permCode?.startsWith('/mch/')
      )
      if (target) {
        merchantData.push({ ...target, label: target.permName })
      }
    })
    // 供应商的二级菜单
    merchantData.forEach(item => {
      const rank = formatNumberToGroups(item.permRank!)[0]
      const targetArray = menu.filter(menuItem => {
        const splitRank = formatNumberToGroups(menuItem.permRank!)
        if (
          splitRank[0] === rank &&
          '000' === splitRank[2] &&
          '000' === splitRank[3] &&
          String(menuItem.permRank) !== `${rank}000000000` &&
          menuItem.permCode?.startsWith('/mch/')
        ) {
          return true
        }
        return false
      })
      if (targetArray.length) {
        // 树状结构展示用，只展示到第二级
        if (item.children) {
          targetArray.forEach(target =>
            item.children!.push({ ...target, label: target.permName })
          )
        } else {
          item.children = targetArray.map(target => {
            return {
              ...target,
              label: target.permName
            }
          })
        }
        // 完整权限结构，用于排序
        if (item.childrenForSort) {
          targetArray.forEach(target =>
            item.childrenForSort!.push({ ...target, label: target.permName })
          )
        } else {
          item.childrenForSort = targetArray.map(target => {
            return {
              ...target,
              label: target.permName
            }
          })
        }
      }
      // 右边权限结构展示用，只有第三级  ，当前二级赋值为空
      item.permList = []
    })
    // 供应商的三级菜单
    merchantData.forEach(item => {
      // 展示所用结构
      // 左边用children 展示菜单
      // 右边用permList 展示菜单对应下的权限
      if (item.children && item.children.length) {
        item.children.forEach(subItem => {
          const rankGroup = formatNumberToGroups(subItem.permRank!)
          const rank1 = rankGroup[0]
          const rank2 = rankGroup[1]
          const targetArray = menu.filter(menuItem => {
            const splitRank = formatNumberToGroups(menuItem.permRank!)
            //  菜单
            if (
              splitRank[0] === rank1 &&
              rank2 === splitRank[1] &&
              String(menuItem.permRank) !== `${rank1}${rank2}000000` &&
              !menuItem.permCode?.includes(':') &&
              menuItem.permCode?.startsWith('/mch/')
            ) {
              return true
            }
            return false
          })
          // 接口
          const permArray = menu.filter(menuItem => {
            const splitRank = formatNumberToGroups(menuItem.permRank!)
            //  必须是接口
            if (
              splitRank[0] === rank1 &&
              rank2 === splitRank[1] &&
              splitRank[2] === '000' &&
              String(menuItem.permRank) !== `${rank1}${rank2}000000` &&
              menuItem.permCode?.includes(':') &&
              menuItem.permCode?.startsWith('/mch/')
            ) {
              return true
            }
            return false
          })
          if (targetArray.length) {
            // 菜单对应下属权限赋值
            targetArray.forEach(childItem => {
              const splitRank = formatNumberToGroups(childItem.permRank!)
              if (splitRank[2] !== '000' && splitRank[3] === '000') {
                const threeChild = menu.filter(menuItem => {
                  const childRankGroup = formatNumberToGroups(
                    menuItem.permRank!
                  )
                  if (
                    splitRank[0] === childRankGroup[0] &&
                    splitRank[1] === childRankGroup[1] &&
                    splitRank[2] === childRankGroup[2] &&
                    childRankGroup[3] !== '000' &&
                    menuItem.permCode?.includes(':') &&
                    menuItem.permCode?.startsWith('/mch/')
                  ) {
                    return true
                  }
                  return false
                })
                if (threeChild?.length) {
                  threeChild.forEach(threeChildItem => {
                    if (childItem?.permList) {
                      childItem.permList.push({
                        ...threeChildItem,
                        label: threeChildItem.permName
                      })
                    } else {
                      childItem.permList = [
                        { ...threeChildItem, label: threeChildItem.permName }
                      ]
                    }
                  })
                }
              }
            })
            if (subItem.children) {
              targetArray.forEach(target =>
                subItem.children!.push({ ...target, label: target.permName })
              )
            } else {
              subItem.children = targetArray.map(target => {
                return {
                  ...target,
                  label: target.permName
                }
              })
            }
          }
          if (permArray?.length) {
            // 对菜单对应下属权限赋值
            subItem.permList = permArray
          } else {
            subItem.permList = []
          }
        })
      }
      if (item.childrenForSort?.length) {
        item.childrenForSort.forEach(subItem => {
          const rankGroup = formatNumberToGroups(subItem.permRank!)
          const rank1 = rankGroup[0]
          const rank2 = rankGroup[1]
          const targetArray = menu.filter(menuItem => {
            const splitRank = formatNumberToGroups(menuItem.permRank!)
            //  菜单
            if (
              splitRank[0] === rank1 &&
              rank2 === splitRank[1] &&
              String(menuItem.permRank) !== `${rank1}${rank2}000000` &&
              menuItem.permCode?.startsWith('/mch/')
            ) {
              return true
            }
            return false
          })
          // 接口
          const permArray = menu.filter(menuItem => {
            const splitRank = formatNumberToGroups(menuItem.permRank!)
            //  必须是接口
            if (
              splitRank[0] === rank1 &&
              rank2 === splitRank[1] &&
              splitRank[2] === '000' &&
              String(menuItem.permRank) !== `${rank1}${rank2}000000` &&
              menuItem.permCode?.includes(':') &&
              menuItem.permCode?.startsWith('/mch/')
            ) {
              return true
            }
            return false
          })
          if (targetArray.length) {
            // 菜单对应下属权限赋值
            targetArray.forEach(childItem => {
              const splitRank = formatNumberToGroups(childItem.permRank!)
              if (splitRank[2] !== '000' && splitRank[3] === '000') {
                const threeChild = menu.filter(menuItem => {
                  const childRankGroup = formatNumberToGroups(
                    menuItem.permRank!
                  )
                  if (
                    splitRank[0] === childRankGroup[0] &&
                    splitRank[1] === childRankGroup[1] &&
                    splitRank[2] === childRankGroup[2] &&
                    childRankGroup[3] !== '000' &&
                    menuItem.permCode?.includes(':') &&
                    menuItem.permCode?.startsWith('/mch/')
                  ) {
                    return true
                  }
                  return false
                })
                if (threeChild?.length) {
                  threeChild.forEach(threeChildItem => {
                    if (childItem?.childrenForSort) {
                      childItem.childrenForSort.push({
                        ...threeChildItem,
                        label: threeChildItem.permName
                      })
                    } else {
                      childItem.childrenForSort = [
                        { ...threeChildItem, label: threeChildItem.permName }
                      ]
                    }
                  })
                }
              }
            })
            if (subItem.childrenForSort) {
              targetArray.forEach(target =>
                subItem.childrenForSort!.push({
                  ...target,
                  label: target.permName
                })
              )
            } else {
              subItem.childrenForSort = targetArray.map(target => {
                return {
                  ...target,
                  label: target.permName
                }
              })
            }
            // 不仅有对应的3.5级，还有三级对应的权限
            if (permArray?.length) {
              for (let i = permArray.length - 1; i >= 0; i--) {
                subItem.childrenForSort.unshift(permArray[i])
              }
            }
          } else {
            subItem.childrenForSort = permArray
          }
        })
      }
    })
  }
  if (merchantData?.length) {
    merchantData.forEach(item => data.push(item))
  }

  return data
}

// 获取排序的权限
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const expansion = (list: any[]) => {
  let arr: any[] = []
  list.forEach(item => {
    arr.push({
      id: item.id,
      permCode: item.permCode,
      permName: item.permName,
      permRank: item.permRank,
      displayState: item.displayState
    })
    if (item.childrenForSort?.length) {
      let arr1 = expansion(item.childrenForSort)
      arr = arr.concat(arr1)
    }
  })
  return arr
}

// 树结构数据
const handleRootMscMscPermList = () => {
  loading.value = true
  opsMscMscPermList({
    userType: userType.value as number
  })
    .then(res => {
      loading.value = false
      let data: any[] = []
      if (res.data && res.data.length) {
        data = res.data.map(ele => {
          let tempArray: MscMenu[] = []
          if (ele.permVoList && ele.permVoList.length) {
            tempArray = handleTreeMenu(ele.permVoList)
          }
          // @ts-expect-error
          ele.permId = `app${ele.id}`
          // @ts-expect-error
          ele.permName = `${ele.appLabel}`
          // @ts-expect-error
          ele.permList = tempArray
          // @ts-expect-error
          ele.childrenForSort = tempArray
          return {
            ...ele,
            permId: `app${ele.id}`,
            permName: ele.appLabel,
            children: tempArray,
            childrenForSort: tempArray
          }
        })
      }
      permissionList.value = data
      // 存在的索引数据
      const indexData = data.map((item, index) => {
        return index
      })
      if (tabActive.value !== 0) {
        if (!indexData.includes(tabActive.value)) {
          tabActive.value = 0
        }
      }
    })
    .catch(() => {
      loading.value = false
    })
}

// 是否允许拖拽
const allowDrop = (draggingNode: any, dropNode: any, type: any) => {
  const permCode = draggingNode.data.permCode
  const parentCode = dropNode.parent.data.permCode || ''
  if (
    permCode.includes(parentCode) &&
    draggingNode.level === dropNode.level &&
    type !== 'inner'
  ) {
    return true
  }
  return false
}

// 点击树形菜单
const handleClickNode = (data: any) => {
  // 接口权限做处理
  newApiAuth.value = data?.permList || []
  opsMscMscPermLoad({
    id: data.id
  }).then(res => {
    if (res.state === 'success') {
      formData.id = res.data?.id as number
      formData.permCode = res.data?.permCode as string
      formData.permDesc = res.data?.permDesc as string
      formData.permLevel = res.data?.permLevel as number
      formData.permName = res.data?.permName as string
      formData.permRank = res.data?.permRank as number
      formData.state = res.data?.state as number
      formData.userType = res.data?.userType as number
      formData.appId = res.data?.appId as number
      formData.displayState = res.data?.displayState as number
    } else {
      ElMessage.error(res.msg)
    }
  })
}

// 保存排序
const handleSaveSort = () => {
  const arr: any[] = []
  const sourceSortData = treeRef.value?.store?.root?.data
  const appId = permissionList.value[tabActive.value].id
  sourceSortData.forEach((item: any) => {
    arr.push({
      id: item.id,
      permCode: item.permCode,
      permName: item.permName,
      displayState: item.displayState,
      permRank: item.permRank
    })
    if (item.children?.length) {
      item.children.forEach((child: any) => {
        arr.push({
          id: child.id,
          permCode: child.permCode,
          permName: child.permName,
          permRank: child.permRank,
          displayState: child.displayState
        })
        if (child?.permList?.length) {
          child.permList.forEach((perm: any) => {
            arr.push({
              id: perm.id,
              permCode: perm.permCode,
              permName: perm.permName,
              permRank: perm.permRank,
              displayState: perm.displayState
            })
          })
        }
      })
    }
  })
  if (userType.value) {
    if (
      !permissionList.value?.length &&
      !permissionList.value[tabActive.value]
    ) {
      return
    }
    opsMscMscPermForceAppPermRank(
      [
        {
          appLabel: permissionList.value[tabActive.value].appLabel,
          appName: permissionList.value[tabActive.value].appName,
          id: appId,
          appVersion: permissionList.value[tabActive.value].appVersion,
          appRank: permissionList.value[tabActive.value].appRank,
          displayState: permissionList.value[tabActive.value].displayState,
          permVoList: arr
        }
      ],
      {
        userType: userType.value,
        appId
      }
    ).then(res => {
      if (res.state === 'success') {
        ElMessage.success('排序保存成功！')
      } else if (res.state === 'error') {
        ElMessage.error(res.msg)
      } else {
        ElMessage.warning(res.msg)
      }
    })
  }
}

// 重置排序
const handleResetSort = () => {
  if (!permissionList.value?.length && !permissionList.value[tabActive.value]) {
    return
  }
  const appId = permissionList.value[tabActive.value].id
  opsMscMscPermResetAppPermRank({
    userType: userType.value,
    appId: appId
  }).then(res => {
    if (res.state === 'success') {
      ElMessage.success('重置排序成功！')
      handleRootMscMscPermList()
    } else {
      ElMessage.error(res.msg)
    }
  })
}

const handleEditApi = (data: any) => {
  updatePermId.value = data.id
  opsMscMscPermLoad({
    id: data.id
  }).then(res => {
    if (res.state === 'success') {
      dialogFormVisible.value = true
      formData1.id = res.data?.id as number
      formData1.permCode = res.data?.permCode as string
      formData1.permDesc = res.data?.permDesc as string
      formData1.permLevel = res.data?.permLevel as number
      formData1.permName = res.data?.permName as string
      formData1.permRank = res.data?.permRank as number
      formData1.state = res.data?.state as number
      formData1.userType = res.data?.userType as number
      formData1.appId = res.data?.appId as number
      formData1.displayState = res.data?.displayState as number
    } else {
      ElMessage.error(res.msg)
    }
  })
}

const rules = computed(() => {
  return {
    permName: [
      {
        required: true,
        message: t('pleaseInput') + '权限名称',
        trigger: 'blur'
      }
    ],
    permDesc: [
      {
        required: true,
        message: t('pleaseInput') + '权限描述',
        trigger: 'blur'
      }
    ],
    permCode: [
      {
        required: true,
        message: t('pleaseInput') + '应用权限',
        trigger: 'blur'
      }
    ]
  }
})

const save = (formEl?: FormInstance, name?: 'formData' | 'formData1') => {
  if (!formEl) return
  formEl.validate(valid => {
    if (valid) {
      ElMessageBox.prompt(t('pleaseInput') + t('修改说明'), t('tip'), {
        type: 'warning',
        confirmButtonText: t('confirm'),
        cancelButtonText: t('cancel'),
        inputValidator: (value: string) => {
          if (value) {
            return true
          }
          return false
        },
        inputErrorMessage: t('pleaseInput') + t('修改说明'),
        inputType: 'textarea'
      })
        .then(({ value }) => {
          opsMscMscPermUpdate(name === 'formData1' ? formData1 : formData, {
            remark: value
          }).then(res => {
            if (res.state === 'success') {
              ElMessage.success('修改成功')
              if (name === 'formData1') dialogFormVisible.value = false
            } else if (res.state === 'error') {
              ElMessage.error(res.msg)
            } else {
              ElMessage.warning(res.msg)
            }
          })
        })
        .catch(e => {
          console.log(e)
        })
    }
  })
}

const handleRemove = (id: number) => {
  ElMessageBox.prompt(t('pleaseInput') + '删除说明', t('tip'), {
    type: 'warning',
    confirmButtonText: t('confirm'),
    cancelButtonText: t('cancel'),
    inputValidator: (value: string) => {
      if (value) {
        return true
      }
      return false
    },
    inputErrorMessage: t('pleaseInput') + '删除说明',
    inputType: 'textarea'
  }).then(({ value }) => {
    const queryParams = {
      id,
      remark: value
    }
    opsMscMscPermDelete(queryParams).then(res => {
      if (res.state === 'success') {
        ElMessage.success(res.msg)
      } else if (res.state === 'error') {
        ElMessage.error(res.msg)
      } else {
        ElMessage.warning(res.msg)
      }
    })
  })
}

useActivated(() => {
  handleRootMscMscPermList()
  getUserTypes()
})
</script>

<template>
  <el-form :inline="true">
    <el-form-item>
      <el-select
        v-model="userType"
        :placeholder="t('pleaseSelect') + '用户类型'"
        @change="handleRootMscMscPermList"
        style="width: 180px"
      >
        <el-option
          v-for="item in getMscMenuUserTypes"
          :key="item.value"
          :label="item.label"
          :value="item.value as number"
        />
      </el-select>
    </el-form-item>
    <el-form-item>
      <el-button
        type="primary"
        @click="handleRootMscMscPermList"
        icon="Search"
      >
        {{ t('search') }}
      </el-button>
      <el-button
        type="primary"
        @click="handleSaveSort"
        icon="Sort"
      >
        {{ t('saveSort') }}
      </el-button>
      <el-button
        type="primary"
        @click="handleResetSort"
        icon="Refresh"
      >
        重置排序
      </el-button>
    </el-form-item>
  </el-form>
  <div class="tabs">
    <div class="tabs-top">
      <span
        v-for="(item, index) in permissionList"
        :key="index"
        :class="{
          'tabs-label': true,
          active: tabActive === index
        }"
        @click="tabActive = index"
      >
        {{ item.permName }}
      </span>
    </div>

    <div
      class="tabs-box"
      v-if="treeListData.length"
    >
      <div class="tabs-box__tree">
        <el-tree
          ref="treeRef"
          :data="treeListData"
          :props="{
            children: 'children',
            label: 'permName'
          }"
          :expand-on-click-node="false"
          node-key="id"
          draggable
          default-expand-all
          highlight-current
          :allow-drop="allowDrop"
          @node-click="handleClickNode"
        ></el-tree>
      </div>
      <div class="tabs-box__line"></div>
      <div style="width: 850px">
        <el-form
          ref="form"
          :model="formData"
          label-width="80px"
          :rules="rules"
        >
          <el-row>
            <el-col :span="20">
              <el-form-item
                label="权限名称"
                prop="permName"
              >
                <el-input v-model="formData.permName"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10">
            <el-col :span="14">
              <el-form-item label="用户类型">
                <el-row>
                  <el-col :span="12">
                    <el-form-item>
                      <el-select
                        v-model="formData.userType"
                        :placeholder="t('pleaseSelect') + '用户类型'"
                        :disabled="true"
                        style="width: 150px"
                      >
                        <el-option
                          v-for="(item, index) in getAllUserTypes"
                          :label="item.label"
                          :value="item.value"
                          :key="index"
                        ></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="权限等级">
                      <el-select
                        v-model="formData.permLevel"
                        :placeholder="t('pleaseSelect') + '权限等级'"
                        :disabled="true"
                        style="width: 150px"
                      >
                        <el-option
                          v-for="item in levelOptions"
                          :label="item.label"
                          :value="item.value"
                          :key="item.value"
                        ></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="状态">
                <el-switch
                  v-model="formData.state"
                  :active-text="t('enable')"
                  :inactive-text="t('disable')"
                  :active-value="1"
                  :inactive-value="2"
                ></el-switch>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="20">
              <el-form-item
                label="应用权限"
                prop="permCode"
              >
                <el-input
                  type="textarea"
                  v-model="formData.permCode"
                  :placeholder="t('pleaseInput') + '应用权限'"
                  disabled
                  :rows="4"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="20">
              <el-form-item
                v-if="newApiAuth.length"
                label="接口权限"
              >
                <div class="margin-bottom-15">
                  <span
                    v-for="item in newApiAuth"
                    :key="item.permCode"
                    class="api-auth"
                    :class="{ blockStyle: !item.permCode!.includes(':') }"
                  >
                    <span style="margin-right: 4px">{{ item.permName }}</span>
                    <el-button-group v-if="item.permCode!.includes(':')">
                      <el-button
                        :title="t('edit')"
                        icon="Edit"
                        type="primary"
                        link
                        @click="handleEditApi(item)"
                      ></el-button>
                      <el-button
                        :title="t('delete')"
                        link
                        type="danger"
                        icon="Delete"
                        @click="handleRemove(item.id as number)"
                      ></el-button>
                    </el-button-group>
                  </span>
                </div>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="20">
              <el-form-item label="权限描述">
                <el-input
                  type="textarea"
                  v-model="formData.permDesc"
                  size="small"
                  :placeholder="t('pleaseInput') + '权限描述'"
                  :rows="4"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item>
            <el-button
              type="primary"
              @click="save(form, 'formData')"
              icon="Check"
            >
              {{ t('save') }}
            </el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>

  <el-dialog
    v-model="dialogFormVisible"
    :title="t('edit') + '权限'"
    destroy-on-close
    width="800px"
    draggable
  >
    <div class="padding-top-15">
      <el-form
        ref="form1"
        :model="formData1"
        :rules="rules"
        label-width="120px"
      >
        <el-row :gutter="10">
          <el-col :span="10">
            <el-form-item
              label="权限名称"
              prop="permName"
            >
              <el-input v-model="formData1.permName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10">
            <el-form-item label="用户类型">
              <el-select
                v-model="formData1.userType"
                :placeholder="t('pleaseSelect') + '用户类型'"
              >
                <el-option
                  v-for="item in getAllUserTypes"
                  :label="item.label"
                  :value="item.value || ''"
                  :key="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="10">
            <el-form-item label="权限等级">
              <el-select
                v-model="formData1.permLevel"
                :placeholder="t('pleaseSelect') + '权限等级'"
              >
                <el-option
                  v-for="item in levelOptions"
                  :label="item.label"
                  :value="item.value"
                  :key="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10">
            <el-form-item label="状态">
              <el-form-item>
                <el-switch
                  v-model="formData1.state"
                  :active-text="t('enable')"
                  :inactive-text="t('disable')"
                  :active-value="1"
                  :inactive-value="2"
                ></el-switch>
              </el-form-item>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="20">
            <el-form-item
              label="应用权限"
              prop="permCode"
            >
              <el-input
                type="textarea"
                v-model="formData1.permCode"
                :placeholder="t('pleaseInput') + '应用权限'"
                disabled
                :rows="4"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="20">
            <el-form-item label="权限描述">
              <el-input
                type="textarea"
                v-model="formData1.permDesc"
                :placeholder="t('pleaseInput') + '权限描述'"
                :rows="4"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <template #footer>
      <div class="dialog-footer">
        <el-button
          @click="dialogFormVisible = false"
          icon="Close"
        >
          {{ t('cancel') }}
        </el-button>
        <el-button
          type="primary"
          @click="save(form1, 'formData1')"
          icon="Check"
        >
          {{ t('save') }}
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<style lang="scss" scoped>
.tabs {
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-light);
  box-shadow:
    0 2px 4px 0 rgba(0, 0, 0, 0.12),
    0 0 6px 0 rgba(0, 0, 0, 0.04);
  margin-bottom: 20px;

  .tabs-top {
    background: var(--el-bg-color);
    margin: 0;
    border-bottom: 1px solid var(--el-border-color-light);

    .tabs-label {
      cursor: pointer;
      display: inline-block;
      line-height: 40px;
      font-size: 14px;
      color: #909399;
      padding: 0 20px;
      transition: background 0.2s;
      margin-bottom: -1px;

      &.active {
        color: var(--el-color-primary);
        border-right: 1px solid var(--el-main-container-background);
        border-left: 1px solid var(--el-main-container-background);
        background-color: var(--el-main-container-background);
        border-bottom: 1px solid transparent;
      }

      &.drag-over {
        &.drag-over-l {
          border-left: 1px solid #409eff;
        }

        &.drag-over-r {
          border-right: 1px solid #409eff;
        }
      }
    }
  }

  .tabs-box {
    display: flex;
    min-height: calc(100vh - 210px);
    padding: 15px;
    box-sizing: border-box;

    .tabs-box__tree {
      width: 220px;
      flex-shrink: 0;
    }

    .tabs-box__line {
      width: 1px;
      background-color: var(--el-border-color-light);
      margin-right: 20px;
    }
  }
}

.api-auth {
  display: inline-block;
  cursor: pointer;
  white-space: nowrap;
  margin-right: 20px;

  &.drag-over {
    &.drag-over-l {
      border-left: 1px solid #409eff;
    }

    &.drag-over-r {
      border-right: 1px solid #409eff;
    }
  }
}

.blockStyle {
  display: block;
}
</style>
