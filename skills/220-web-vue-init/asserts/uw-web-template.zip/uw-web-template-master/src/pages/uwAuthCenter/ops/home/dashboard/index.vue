<script setup lang="ts">
import { type ComponentInternalInstance } from 'vue'
import ECharts, { type EChartsOption } from '@/components/ECharts/index.vue'
import { useTransition } from '@vueuse/core'
import {
  opsHomeDashboardListStats,
  opsHomeDashboardLastMetrics,
  opsHomeDashboardListMetrics,
  opsHomeDashboardLastStats,
  type MscMetrics,
  type MscStats
} from '@/api/uwAuthCenterOpsApi'
import * as echarts from 'echarts'
import { useMainStore } from '@/store/main'
import { convertBytes, thousands } from '@/utils/tool'

// 获取全局挂载的方法
const { proxy } = getCurrentInstance() as ComponentInternalInstance
const { dayjs, useActivated } = proxy as any
const mainStore = useMainStore()
const loading = ref(false)
const dateTime = ref<[Date, Date]>()

// 登录信息
const option1 = computed<EChartsOption>(() => {
  return {
    title: {
      text: '登录信息',
      textStyle: {
        color: mainStore.systemDark ? '#A8ABB2' : '#25371C'
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: '#6a7985'
        }
      },
      appendToBody: true
    },
    legend: {
      right: '5%',
      left: '100px',
      data: [
        '登录成功',
        '登录失败',
        '退出登录',
        '双登',
        '踢出',
        'captcha请求',
        'captcha成功',
        'captcha失败',
        '登录码请求',
        '登录码成功',
        '登录码失败',
        '刷新token成功',
        '刷新token失败'
      ],
      textStyle: {
        color: '#86909C'
      }
    },
    grid: {
      left: '3%',
      right: '3%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        boundaryGap: false,
        data: statsData.value.map(item => {
          return dayjs(item.statsDate).format('YYYY/MM/DD')
        }),
        axisLabel: {
          show: true,
          color: '#86909C'
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: '#86909C'
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: 'dashed'
          }
        },
        axisTick: {
          show: false
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        axisLabel: {
          show: true,
          color: '#86909C'
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: 'dashed'
          }
        }
      }
    ],
    series: [
      {
        name: '登录成功',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(17,128,255,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(17,126,255,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        data: statsData.value.map(item => {
          return item.loginSuccess || 0
        }),
        color: '#239DFF',
        lineStyle: {
          color: '#239DFF'
        },
        smooth: true
      },
      {
        name: '登录失败',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(255,17,17,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(255,17,17,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#FF1111',
        data: statsData.value.map(item => {
          return item.loginFail || 0
        }),
        lineStyle: {
          color: '#FF1111'
        },
        smooth: true
      },
      {
        name: '退出登录',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(73,181,75,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(73,181,75,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#49B54B',
        data: statsData.value.map(item => {
          return item.tokenLogout || 0
        }),
        lineStyle: {
          color: '#49B54B'
        },
        smooth: true
      },
      {
        name: '双登',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(255,156,35,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(255,156,35,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#FF9C23',
        data: statsData.value.map(item => {
          return item.tokenDouble || 0
        }),
        lineStyle: {
          color: '#FF9C23'
        },
        smooth: true
      },
      {
        name: '踢出',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(133,233,45,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(133,233,45,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#83e82d',
        data: statsData.value.map(item => {
          return item.tokenKickout || 0
        }),
        lineStyle: {
          color: '#83e82d'
        },
        smooth: true
      },
      {
        name: 'captcha请求',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: '#f4eafb'
            },
            {
              offset: 1,
              color: '#faf6fd'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#A253DF',
        data: statsData.value.map(item => {
          return item.loginCaptcha || 0
        }),
        lineStyle: {
          color: '#A253DF'
        },
        smooth: true
      },
      {
        name: 'captcha成功',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(207,126,66,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(207,126,66,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#CF7E42',
        data: statsData.value.map(item => {
          return item.loginCaptchaSuccess || 0
        }),
        lineStyle: {
          color: '#CF7E42'
        },
        smooth: true
      },
      {
        name: 'captcha失败',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(212,30,182,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(212,30,182,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#D41EB6',
        data: statsData.value.map(item => {
          return item.loginCaptchaFail || 0
        }),
        lineStyle: {
          color: '#D41EB6'
        },
        smooth: true
      },
      {
        name: '登录码请求',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(73,205,255,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(73,205,255,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#49CDFF',
        data: statsData.value.map(item => {
          return item.loginCode || 0
        }),
        lineStyle: {
          color: '#49CDFF'
        },
        smooth: true
      },
      {
        name: '登录码成功',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(179,73,255,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(179,73,255,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#B349FF',
        data: statsData.value.map(item => {
          return item.loginCodeSuccess || 0
        }),
        lineStyle: {
          color: '#B349FF'
        },
        smooth: true
      },
      {
        name: '登录码失败',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(211,227,253,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(211,227,253,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#D3E3FD',
        data: statsData.value.map(item => {
          return item.loginCodeFail || 0
        }),
        lineStyle: {
          color: '#D3E3FD'
        },
        smooth: true
      },
      {
        name: '刷新token成功',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(31,40,222,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(31,40,222,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#1F28DE',
        data: statsData.value.map(item => {
          return item.tokenRefreshSuccess || 0
        }),
        lineStyle: {
          color: '#1F28DE'
        },
        smooth: true
      },
      {
        name: '刷新token失败',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(225,227,225,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(225,227,225,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#E1E3E1',
        data: statsData.value.map(item => {
          return item.tokenRefreshFail || 0
        }),
        lineStyle: {
          color: '#E1E3E1'
        },
        smooth: true
      }
    ]
  }
})

// 客户登录信息
const option5 = computed<EChartsOption>(() => {
  return {
    title: {
      text: '客户登录信息',
      textStyle: {
        color: mainStore.systemDark ? '#A8ABB2' : '#25371C'
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: '#6a7985'
        }
      },
      appendToBody: true
    },
    legend: {
      right: '5%',
      left: '120px',
      data: [
        '客户登录成功',
        '客户登录失败',
        '客户刷新成功',
        '客户刷新失败',
        '客户退出登录',
        '客户双登',
        '客户踢出'
      ],
      textStyle: {
        color: '#86909C'
      }
    },
    grid: {
      left: '3%',
      right: '3%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        boundaryGap: false,
        data: statsData.value.map(item => {
          return dayjs(item.statsDate).format('YYYY/MM/DD')
        }),
        axisLabel: {
          show: true,
          color: '#86909C'
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: '#86909C'
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: 'dashed'
          }
        },
        axisTick: {
          show: false
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        axisLabel: {
          show: true,
          color: '#86909C'
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: 'dashed'
          }
        }
      }
    ],
    series: [
      {
        name: '客户登录成功',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(17,128,255,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(17,126,255,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        data: statsData.value.map(item => {
          return item.guestLoginSuccess || 0
        }),
        color: '#239DFF',
        lineStyle: {
          color: '#239DFF'
        },
        smooth: true
      },
      {
        name: '客户登录失败',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(255,17,17,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(255,17,17,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#FF1111',
        data: statsData.value.map(item => {
          return item.guestLoginFail || 0
        }),
        lineStyle: {
          color: '#FF1111'
        },
        smooth: true
      },
      {
        name: '客户刷新成功',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(73,181,75,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(73,181,75,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#49B54B',
        data: statsData.value.map(item => {
          return item.guestRefreshSuccess || 0
        }),
        lineStyle: {
          color: '#49B54B'
        },
        smooth: true
      },
      {
        name: '客户刷新失败',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(255,156,35,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(255,156,35,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#FF9C23',
        data: statsData.value.map(item => {
          return item.guestRefreshFail || 0
        }),
        lineStyle: {
          color: '#FF9C23'
        },
        smooth: true
      },
      {
        name: '客户退出登录',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(133,233,45,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(133,233,45,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#83e82d',
        data: statsData.value.map(item => {
          return item.guestLogout || 0
        }),
        lineStyle: {
          color: '#83e82d'
        },
        smooth: true
      },
      {
        name: '客户双登',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: '#f4eafb'
            },
            {
              offset: 1,
              color: '#faf6fd'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#A253DF',
        data: statsData.value.map(item => {
          return item.guestDouble || 0
        }),
        lineStyle: {
          color: '#A253DF'
        },
        smooth: true
      },
      {
        name: '客户踢出',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(207,126,66,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(207,126,66,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#CF7E42',
        data: statsData.value.map(item => {
          return item.guestKickout || 0
        }),
        lineStyle: {
          color: '#CF7E42'
        },
        smooth: true
      }
    ]
  }
})

// 操作信息
const option2 = computed<EChartsOption>(() => {
  return {
    title: {
      text: '操作信息',
      textStyle: {
        color: mainStore.systemDark ? '#A8ABB2' : '#25371C'
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: '#6a7985'
        }
      }
    },
    legend: {
      right: '10%',
      data: ['用户操作成功', '用户操作失败'],
      textStyle: {
        color: '#86909C'
      }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        boundaryGap: false,
        data: statsData.value.map(item => {
          return dayjs(item.statsDate).format('YYYY/MM/DD')
        }),
        axisLabel: {
          show: true,
          color: '#86909C'
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: '#86909C'
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: 'dashed'
          }
        },
        axisTick: {
          show: false
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        axisLabel: {
          show: true,
          color: '#86909C'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: 'dashed'
          }
        }
      }
    ],
    series: [
      {
        name: '用户操作成功',
        type: 'line',
        emphasis: {
          focus: 'series'
        },

        data: statsData.value.map(item => {
          return item.logActionSuccess || 0
        }),
        color: '#49B54B',
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(73,181,75,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(73,181,75,0.16)'
            }
          ])
        },
        lineStyle: {
          color: '#49B54B'
        },
        smooth: true
      },
      {
        name: '用户操作失败',
        type: 'line',
        emphasis: {
          focus: 'series'
        },

        data: statsData.value.map(item => {
          return item.logActionFail || 0
        }),
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(255,17,17,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(255,17,17,0.16)'
            }
          ])
        },
        color: '#FF1111',
        lineStyle: {
          color: '#FF1111'
        },
        smooth: true
      }
    ]
  }
})

// 用户数量信息
const option3 = computed<EChartsOption>(() => {
  return {
    title: {
      text: '新增用户信息',
      textStyle: {
        color: mainStore.systemDark ? '#A8ABB2' : '#25371C'
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: '#6a7985'
        }
      }
    },
    legend: {
      right: '10%',
      data: ['新增saas', '新增用户组', '新增用户'],
      textStyle: {
        color: '#86909C'
      }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        boundaryGap: false,
        data: statsData.value.map(item => {
          return dayjs(item.statsDate).format('YYYY/MM/DD')
        }),
        axisLabel: {
          show: true,
          color: '#86909C'
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: '#86909C'
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: 'dashed'
          }
        },
        axisTick: {
          show: false
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        axisLabel: {
          show: true,
          color: '#86909C'
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: 'dashed'
          }
        }
      }
    ],
    series: [
      {
        name: '新增saas',
        type: 'line',
        emphasis: {
          focus: 'series'
        },

        data: statsData.value.map(item => {
          return item.newSaas || 0
        }),
        color: '#49B54B',
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(73,181,75,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(73,181,75,0.16)'
            }
          ])
        },
        lineStyle: {
          color: '#49B54B'
        },
        smooth: true
      },
      {
        name: '新增用户组',
        type: 'line',
        emphasis: {
          focus: 'series'
        },

        data: statsData.value.map(item => {
          return item.newGroup || 0
        }),
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(255,17,17,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(255,17,17,0.16)'
            }
          ])
        },
        color: '#FF1111',
        lineStyle: {
          color: '#FF1111'
        },
        smooth: true
      },
      {
        name: '新增用户',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(255,156,35,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(255,156,35,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#FF9C23',
        data: statsData.value.map(item => {
          return item.newUser || 0
        }),
        lineStyle: {
          color: '#FF9C23'
        },
        smooth: true
      }
    ]
  }
})

// 登录活跃指数
const option4 = computed<EChartsOption>(() => {
  return {
    title: {
      text: '登录活跃指数',
      textStyle: {
        color: mainStore.systemDark ? '#A8ABB2' : '#25371C'
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: '#6a7985'
        }
      },
      appendToBody: true
    },
    legend: {
      right: '10%',
      data: ['活跃用户峰值', '登录用户峰值', '非法token峰值', '登录峰值指数'],
      textStyle: {
        color: '#86909C'
      }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        boundaryGap: false,
        data: statsData.value.map(item => {
          return dayjs(item.statsDate).format('YYYY/MM/DD')
        }),
        axisLabel: {
          show: true,
          color: '#86909C'
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: '#86909C'
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: 'dashed'
          }
        },
        axisTick: {
          show: false
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        axisLabel: {
          show: true,
          color: '#86909C'
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: 'dashed'
          }
        }
      }
    ],
    series: [
      {
        name: '活跃用户峰值',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(17,128,255,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(17,126,255,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        data: statsData.value.map(item => {
          return item.userActiveMax || 0
        }),
        color: '#239DFF',
        lineStyle: {
          color: '#239DFF'
        },
        smooth: true
      },
      {
        name: '登录用户峰值',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(255,17,17,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(255,17,17,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#FF1111',
        data: statsData.value.map(item => {
          return item.userLogonMax || 0
        }),
        lineStyle: {
          color: '#FF1111'
        },
        smooth: true
      },
      {
        name: '非法token峰值',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(73,181,75,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(73,181,75,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#49B54B',
        data: statsData.value.map(item => {
          return item.invalidTokenMax || 0
        }),
        lineStyle: {
          color: '#49B54B'
        },
        smooth: true
      },
      {
        name: '登录峰值指数',
        type: 'line',

        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            {
              offset: 0,
              color: 'rgba(255,156,35,0.00)'
            },
            {
              offset: 1,
              color: 'rgba(255,156,35,0.16)'
            }
          ])
        },
        emphasis: {
          focus: 'series'
        },
        color: '#FF9C23',
        data: statsData.value.map(item => {
          return item.loginLimitMax || 0
        }),
        lineStyle: {
          color: '#FF9C23'
        },
        smooth: true
      }
    ]
  }
})

// 当前指标
const currentMetrics = ref<MscMetrics>({})
// 指标
const getMetrics = () => {
  loading.value = true
  opsHomeDashboardLastMetrics()
    .then(res => {
      currentMetrics.value = res.data || {}
      loading.value = false
    })
    .catch(() => {
      loading.value = false
    })
}

// 当前的运行状态数据
const currentStats = ref<MscStats>({})
const getLastStats = () => {
  loading.value = true
  opsHomeDashboardLastStats()
    .then(res => {
      currentStats.value = res.data || {}
      loading.value = false
    })
    .catch(() => {
      loading.value = false
    })
}

// 应用信息-----------------------------
// 应用数量
const runAppValue = computed(() => currentMetrics.value.runApp || 0)
const mscApp = computed(() => currentStats.value.mscApp || 0)
const runApp = useTransition(runAppValue, {
  duration: 1500
})

// 应用权限数量
const mscPremValue = computed(() => currentStats.value.mscPerm || 0)
const mscPerm = useTransition(mscPremValue, {
  duration: 1500
})

// 应用实时数量
const mscRunHostValue = computed(() => currentMetrics.value.runHost || 0)
const mscRunHost = useTransition(mscRunHostValue, {
  duration: 1500
})

// 线程
const runThreadValue = computed(() => currentMetrics.value.runThread || 0)
const runThread = useTransition(runThreadValue, {
  duration: 1500
})

// 应用实时内存
const mscRunMem = computed(() => {
  if (currentMetrics.value.runMem) {
    return convertBytes(currentMetrics.value.runMem, false) as number
  }
  return 0
})

// 应用实时在线用户
const mscRunUserValue = computed(() => currentMetrics.value.runUser || 0)
const mscRunUser = useTransition(mscRunUserValue, {
  duration: 1500
})

// 应用实时访问数
const mscRunAccessValue = computed(() => currentMetrics.value.runAccess || 0)
const mscRunAccess = useTransition(mscRunAccessValue, {
  duration: 1500
})

// 系统容量---------------------------
// saas系统
const allSaasValue = computed(() => currentStats.value.allSaas || 0)
const allSaas = useTransition(allSaasValue, {
  duration: 1500
})
// 当日新增saas系统
const newSaasValue = computed(() => currentMetrics.value.newSaas || 0)

// 用户组数量
const allGroupValue = computed(() => currentStats.value.allGroup || 0)
const allGroup = useTransition(allGroupValue, {
  duration: 1500
})
// 当日新增用户组数量
const newGroupValue = computed(() => currentMetrics.value.newGroup || 0)

// 用户数量
const allUserValue = computed(() => currentStats.value.allUser || 0)
const allUser = useTransition(allUserValue, {
  duration: 1500
})
// 新增用户数量
const newUserValue = computed(() => currentMetrics.value.newUser || 0)

// 实时在线用户数量
const userActive = computed(() => currentMetrics.value.userActive || 0)
// 实时登录用户数量
const userLogon = computed(() => currentMetrics.value.userLogon || 0)
// 成功操作
const logActionSuccess = computed(() => currentStats.value.logActionSuccess)
// 失败操作
const logActionError = computed(() => currentStats.value.logActionFail)

// 用户数量
const userRoot = computed(() => currentStats.value.userRoot || 0)
const userAdmin = computed(() => currentStats.value.userAdmin || 0)
const userRpc = computed(() => currentStats.value.userRpc || 0)
const userOps = computed(() => currentStats.value.userOps || 0)
const userSaas = computed(() => currentStats.value.userSaas || 0)
const userMch = computed(() => currentStats.value.userMch || 0)

// 登录信息
// 登录成功数
const todayLoginSuccess = computed(() => currentMetrics.value.loginSuccess || 0)
const yesterDayLoginSuccess = computed(
  () => currentStats.value.loginSuccess || 0
)
// 登录失败数
const todayLoginFail = computed(() => currentMetrics.value.loginFail || 0)
const yesterdayLoginFail = computed(() => currentStats.value.loginFail || 0)
// 退出登录次数
const todayLogout = computed(() => currentMetrics.value.tokenLogout || 0)
const yesterdayLogout = computed(() => currentStats.value.tokenLogout || 0)
// 双登录次数
const todayLoginDouble = computed(() => currentMetrics.value.tokenDouble || 0)
const yesterdayLoginDouble = computed(() => currentStats.value.tokenDouble || 0)
// 踢出数
const todayLoginKickout = computed(() => currentMetrics.value.tokenKickout || 0)
const yesterdayLoginKickout = computed(
  () => currentStats.value.tokenKickout || 0
)
// captcha请求数
const todayLoginCaptcha = computed(() => currentMetrics.value.loginCaptcha || 0)
const yesterdayLoginCaptcha = computed(
  () => currentStats.value.loginCaptcha || 0
)
// 成功数
const todayLoginCaptchaSuccess = computed(
  () => currentMetrics.value.loginCaptchaSuccess || 0
)
const yesterdayLoginCaptchaSuccess = computed(
  () => currentStats.value.loginCaptchaSuccess || 0
)
// 失败数
const todayLoginCaptchaFail = computed(
  () => currentMetrics.value.loginCaptchaFail || 0
)
const yesterdayLoginCaptchaFail = computed(
  () => currentStats.value.loginCaptchaFail || 0
)
// 登录码请求数
const todayLoginCode = computed(() => currentMetrics.value.loginCode || 0)
const yesterdayLoginCode = computed(() => currentStats.value.loginCode || 0)
// 登录码成功数
const todayLoginCodeSuccess = computed(
  () => currentMetrics.value.loginCodeSuccess || 0
)
const yesterdayLoginCodeSuccess = computed(
  () => currentStats.value.loginCodeSuccess || 0
)

// 登录码失败数
const todayLoginCodeFail = computed(
  () => currentMetrics.value.loginCodeFail || 0
)
const yesterdayLoginCodeFail = computed(
  () => currentStats.value.loginCodeFail || 0
)
// 刷新token成功数
const todayRefreshTokenSuccess = computed(
  () => currentMetrics.value.tokenRefreshSuccess || 0
)
const yesterdayRefreshTokenSuccess = computed(
  () => currentStats.value.tokenRefreshSuccess || 0
)
// 刷新token失败数
const todayRefreshTokenFail = computed(
  () => currentMetrics.value.tokenRefreshFail || 0
)
const yesterdayRefreshTokenFail = computed(
  () => currentStats.value.tokenRefreshFail || 0
)
// 游客登录成功次数
const todayGuestLoginSuccess = computed(
  () => currentMetrics.value.guestLoginSuccess || 0
)
const yesterdayGuestLoginSuccess = computed(
  () => currentStats.value.guestLoginSuccess || 0
)
// 游客登录失败次数
const todayGuestLoginFail = computed(
  () => currentMetrics.value.guestLoginFail || 0
)
const yesterdayGuestLoginFail = computed(
  () => currentStats.value.guestLoginFail || 0
)
// 游客刷新成功次数
const todayGuestRefreshSuccess = computed(
  () => currentMetrics.value.guestRefreshSuccess || 0
)
const yesterdayGuestRefreshSuccess = computed(
  () => currentStats.value.guestRefreshSuccess || 0
)
// 游客刷新失败次数
const todayGuestRefreshFail = computed(
  () => currentMetrics.value.guestRefreshFail || 0
)
const yesterdayGuestRefreshFail = computed(
  () => currentStats.value.guestRefreshFail || 0
)

// 游客登出
const todayGuestLogout = computed(() => currentMetrics.value.guestLogout || 0)
const yesterdayGuestLogout = computed(() => currentStats.value.guestLogout || 0)

// 游客双登
const todayGuestDouble = computed(() => currentMetrics.value.guestDouble || 0)
const yesterdayGuestDouble = computed(() => currentStats.value.guestDouble || 0)

// 游客踢出
const todayGuestKickout = computed(() => currentMetrics.value.guestKickout || 0)
const yesterdayGuestKickout = computed(
  () => currentStats.value.guestKickout || 0
)

// msc统计信息
const statsData = ref<MscStats[]>([])
const getStats = () => {
  loading.value = true
  opsHomeDashboardListStats({
    // @ts-expect-error
    statsDateRange: dateTime.value,
    $pg: 1,
    $rn: 99
  })
    .then(res => {
      statsData.value = res.data?.results || []
    })
    .catch(() => {
      statsData.value = []
    })
    .finally(() => {
      loading.value = false
    })
}

// 运行指标
const dateTimeForMetrics = ref<[Date, Date]>()
const metricsData = ref<MscMetrics[]>([])
const getMetricsData = () => {
  opsHomeDashboardListMetrics({
    // @ts-expect-error
    statsDateRange: dateTimeForMetrics.value,
    $pg: 1,
    $rn: 99
  })
    .then(res => {
      metricsData.value = res.data?.results || []
    })
    .catch(() => {
      metricsData.value = []
    })
    .finally(() => {
      loading.value = false
    })
}

useActivated(() => {
  const end = new Date()
  const start = new Date()
  start.setTime(start.getTime() - 30 * 60 * 1000 * 60 * 24)
  dateTime.value = [
    dayjs(start).format('YYYY-MM-DD HH:mm:ss'),
    dayjs(end).format('YYYY-MM-DD HH:mm:ss')
  ]
  dateTimeForMetrics.value = [
    dayjs(start).format('YYYY-MM-DD HH:mm:ss'),
    dayjs(end).format('YYYY-MM-DD HH:mm:ss')
  ]
  getMetrics()
  getStats()
  getMetricsData()
  getLastStats()
})
</script>

<template>
  <el-row>
    <el-col :span="24">
      <el-row
        :gutter="10"
        type="flex"
        align="middle"
      >
        <el-col :span="8">
          <el-card shadow="hover">
            <template #header>
              <div class="flex-center">应用信息</div>
            </template>
            <el-row :gutter="10">
              <el-col :span="8">
                <el-statistic :value="runApp">
                  <template #title>
                    <div class="value-icon-wrapper">
                      运行/注册应用
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-primary)"
                      >
                        <MessageBox />
                      </el-icon>
                    </div>
                  </template>
                  <template #suffix>{{ `/${mscApp}` }}</template>
                </el-statistic>
              </el-col>
              <el-col :span="8">
                <el-statistic :value="mscPerm">
                  <template #title>
                    <div class="value-icon-wrapper">
                      权限
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <Grid />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="8">
                <el-statistic :value="mscRunHost">
                  <template #title>
                    <div class="value-icon-wrapper">
                      主机
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <MessageBox />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
            </el-row>
            <el-row class="margin-top-10">
              <el-col :span="6">
                <el-statistic :value="runThread">
                  <template #title>
                    <div class="value-icon-wrapper">
                      线程
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <Cpu />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="6">
                <el-statistic
                  :value="mscRunMem"
                  :precision="2"
                >
                  <template #title>
                    <div class="value-icon-wrapper">
                      内存
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <Memo />
                      </el-icon>
                    </div>
                  </template>
                  <template #suffix>G</template>
                </el-statistic>
              </el-col>
              <el-col :span="6">
                <el-statistic :value="mscRunUser">
                  <template #title>
                    <div class="value-icon-wrapper">
                      用户
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <User />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="6">
                <el-statistic :value="mscRunAccess">
                  <template #title>
                    <div class="value-icon-wrapper">
                      请求
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <Paperclip />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
            </el-row>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card shadow="hover">
            <template #header>
              <div class="flex-center">系统容量</div>
            </template>
            <el-row :gutter="10">
              <el-col :span="8">
                <el-statistic :value="allSaas">
                  <template #title>
                    <div class="value-icon-wrapper">
                      saas系统
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-primary)"
                      >
                        <Box />
                      </el-icon>
                    </div>
                  </template>
                  <template #suffix>
                    <span class="addStyle">+&nbsp;{{ newSaasValue }}</span>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="8">
                <el-statistic :value="allGroup">
                  <template #title>
                    <div class="value-icon-wrapper">
                      部门
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <Grid />
                      </el-icon>
                    </div>
                  </template>
                  <template #suffix>
                    <span class="addStyle">+&nbsp;{{ newGroupValue }}</span>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="8">
                <el-statistic :value="allUser">
                  <template #title>
                    <div class="value-icon-wrapper">
                      用户
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <UserFilled />
                      </el-icon>
                    </div>
                  </template>
                  <template #suffix>
                    <span class="addStyle">+&nbsp;{{ newUserValue }}</span>
                  </template>
                </el-statistic>
              </el-col>
            </el-row>
            <el-row class="margin-top-10">
              <el-col :span="6">
                <el-statistic :value="userActive">
                  <template #title>
                    <div class="value-icon-wrapper">
                      活跃用户
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <UserFilled />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="6">
                <el-statistic :value="userLogon">
                  <template #title>
                    <div class="value-icon-wrapper">
                      登录用户
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <UserFilled />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="6">
                <el-statistic :value="logActionSuccess">
                  <template #title>
                    <div class="value-icon-wrapper">
                      成功操作
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <UserFilled />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="6">
                <el-statistic :value="logActionError">
                  <template #title>
                    <div class="value-icon-wrapper">
                      失败操作
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <UserFilled />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
            </el-row>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card shadow="hover">
            <template #header>
              <div class="flex-center">用户数量</div>
            </template>
            <el-row :gutter="10">
              <el-col :span="12">
                <el-statistic :value="userSaas">
                  <template #title>
                    <div class="value-icon-wrapper">
                      saas用户
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <UserFilled />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="12">
                <el-statistic :value="userMch">
                  <template #title>
                    <div class="value-icon-wrapper">
                      商户
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <UserFilled />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
            </el-row>
            <el-row class="margin-top-10">
              <el-col :span="6">
                <el-statistic :value="userRoot">
                  <template #title>
                    <div class="value-icon-wrapper">
                      root用户
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <UserFilled />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="6">
                <el-statistic :value="userAdmin">
                  <template #title>
                    <div class="value-icon-wrapper">
                      admin用户
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <UserFilled />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="6">
                <el-statistic :value="userOps">
                  <template #title>
                    <div class="value-icon-wrapper">
                      ops用户
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <UserFilled />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
              <el-col :span="6">
                <el-statistic :value="userRpc">
                  <template #title>
                    <div class="value-icon-wrapper">
                      rpc用户
                      <el-icon
                        style="margin-left: 4px"
                        :size="12"
                        color="var(--el-color-success)"
                      >
                        <UserFilled />
                      </el-icon>
                    </div>
                  </template>
                </el-statistic>
              </el-col>
            </el-row>
          </el-card>
        </el-col>
        <el-col
          :span="24"
          class="margin-top-10"
        >
          <el-card shadow="hover">
            <template #header>
              <div class="flex-center">登录信息(今日/昨日)</div>
            </template>
            <el-row :gutter="10">
              <el-col :span="24">
                <div
                  class="flex-start"
                  style="width: 100%"
                >
                  <div style="width: 10%">
                    <el-statistic :value="todayLoginSuccess">
                      <template #title>
                        <div class="value-icon-wrapper">
                          登录成功
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-success)"
                          >
                            <InfoFilled />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterDayLoginSuccess) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayLoginFail">
                      <template #title>
                        <div class="value-icon-wrapper">
                          登录失败
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-danger)"
                          >
                            <InfoFilled />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayLoginFail) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayLogout">
                      <template #title>
                        <div class="value-icon-wrapper">
                          退出登录
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-success)"
                          >
                            <Promotion />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayLogout) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayLoginDouble">
                      <template #title>
                        <div class="value-icon-wrapper">
                          双登录
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-success)"
                          >
                            <Connection />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayLoginDouble) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayLoginKickout">
                      <template #title>
                        <div class="value-icon-wrapper">
                          踢出登录
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-warning)"
                          >
                            <Warning />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayLoginKickout) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayRefreshTokenSuccess">
                      <template #title>
                        <div class="value-icon-wrapper">
                          刷新token成功
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-success)"
                          >
                            <Refresh />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayRefreshTokenSuccess) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayRefreshTokenFail">
                      <template #title>
                        <div class="value-icon-wrapper">
                          刷新token失败
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-danger)"
                          >
                            <Refresh />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayRefreshTokenFail) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayLoginCaptcha">
                      <template #title>
                        <div class="value-icon-wrapper">
                          captcha请求
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-primary)"
                          >
                            <Paperclip />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayLoginCaptcha) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayLoginCaptchaSuccess">
                      <template #title>
                        <div class="value-icon-wrapper">
                          captcha成功
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-success)"
                          >
                            <Paperclip />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayLoginCaptchaSuccess) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayLoginCaptchaFail">
                      <template #title>
                        <div class="value-icon-wrapper">
                          captcha失败
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-danger)"
                          >
                            <Paperclip />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayLoginCaptchaFail) }}
                      </template>
                    </el-statistic>
                  </div>
                </div>
              </el-col>
            </el-row>
            <el-row
              :gutter="10"
              class="margin-top-10"
            >
              <el-col :span="24">
                <div
                  class="flex-start"
                  style="width: 100%"
                >
                  <div style="width: 10%">
                    <el-statistic :value="todayGuestLoginSuccess">
                      <template #title>
                        <div class="value-icon-wrapper">
                          客户登录成功
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-success)"
                          >
                            <InfoFilled />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayGuestLoginSuccess) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayGuestLoginFail">
                      <template #title>
                        <div class="value-icon-wrapper">
                          客户登录失败
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-danger)"
                          >
                            <InfoFilled />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayGuestLoginFail) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayGuestLogout">
                      <template #title>
                        <div class="value-icon-wrapper">
                          客户退出登录
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-success)"
                          >
                            <Promotion />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayGuestLogout) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayGuestDouble">
                      <template #title>
                        <div class="value-icon-wrapper">
                          客户双登
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-success)"
                          >
                            <Connection />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayGuestDouble) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayGuestKickout">
                      <template #title>
                        <div class="value-icon-wrapper">
                          客户踢出
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-warning)"
                          >
                            <Warning />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayGuestKickout) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayGuestRefreshSuccess">
                      <template #title>
                        <div class="value-icon-wrapper">
                          客户刷新成功
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-success)"
                          >
                            <Refresh />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayGuestRefreshSuccess) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayGuestRefreshFail">
                      <template #title>
                        <div class="value-icon-wrapper">
                          客户刷新失败
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-danger)"
                          >
                            <Refresh />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayGuestRefreshFail) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayLoginCode">
                      <template #title>
                        <div class="value-icon-wrapper">
                          登录码请求
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-success)"
                          >
                            <CreditCard />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayLoginCode) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayLoginCodeSuccess">
                      <template #title>
                        <div class="value-icon-wrapper">
                          登录码成功
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-success)"
                          >
                            <CreditCard />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayLoginCodeSuccess) }}
                      </template>
                    </el-statistic>
                  </div>
                  <div style="width: 10%">
                    <el-statistic :value="todayLoginCodeFail">
                      <template #title>
                        <div class="value-icon-wrapper">
                          登录码失败
                          <el-icon
                            style="margin-left: 4px"
                            :size="12"
                            color="var(--el-color-danger)"
                          >
                            <CreditCard />
                          </el-icon>
                        </div>
                      </template>
                      <template #suffix>
                        {{ '/' + thousands(yesterdayLoginCodeFail) }}
                      </template>
                    </el-statistic>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-card>
        </el-col>
      </el-row>
      <el-card
        shadow="hover"
        style="margin-top: 10px"
      >
        <ECharts
          height="280px"
          :options="option1"
        />
      </el-card>
      <el-card
        shadow="hover"
        style="margin-top: 10px"
      >
        <ECharts
          height="280px"
          :options="option5"
        />
      </el-card>
      <el-card
        shadow="hover"
        style="margin-top: 10px"
      >
        <ECharts
          height="280px"
          :options="option2"
        />
      </el-card>
      <el-card
        shadow="hover"
        style="margin-top: 10px"
      >
        <ECharts
          height="280px"
          :options="option3"
        />
      </el-card>
      <el-card
        shadow="hover"
        style="margin-top: 10px"
      >
        <ECharts
          height="280px"
          :options="option4"
        />
      </el-card>
    </el-col>
  </el-row>
</template>

<style lang="scss" scoped>
.addStyle {
  font-size: 14px;
  color: var(--el-color-success);
}
:deep(.el-statistic) {
  text-align: center;
}

.value-icon-wrapper {
  display: inline-flex;
  align-items: center;
}

.solid {
  width: 100%;
  height: 10px;
}

.statistic-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  font-size: 12px;
  color: var(--el-text-color-regular);
  margin-top: 16px;
}

.statistic-footer .footer-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.statistic-footer .footer-item span:last-child {
  display: inline-flex;
  align-items: center;
  margin-left: 4px;
}
</style>
