/**
 * 图标配置
 * 用法：  路由路径作为key，图标作为value
 * @description 图标配置
 */
const iconEnum: Record<string, string> = {
  '/uwAuthCenter/ops/log': 'Memo',
  '/uwAuthCenter/ops/log/actionLog': 'DocumentChecked',
  '/uwAuthCenter/ops/log/loginLog': 'Document',
  '/uwAuthCenter/ops/home/dashboard': 'Odometer',
  '/uwAuthCenter/ops/log/critLog': 'DocumentChecked',
  '/uwAuthCenter/ops/log/dataHistory': 'Document',
  '/uwAuthCenter/ops/msc': 'Operation'
}

export default (permCode: string) => {
  if (iconEnum[permCode]) return iconEnum[permCode]
  return 'Menu'
}
