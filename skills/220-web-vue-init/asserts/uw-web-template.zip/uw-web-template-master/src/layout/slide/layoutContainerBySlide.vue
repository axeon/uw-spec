<script lang="ts" setup>
import { useMainStore } from '@/store/main'
import icon from '../../config/icon'
import { useI18n } from 'vue-i18n'
import layoutHeaderBySlide from './layoutHeaderBySlide.vue'
import { SHOW_SECOND_MENU_ICON } from '@/config/common'
import { formatToHump } from '@/utils/tool'
import { ElScrollbar } from 'element-plus'
import { useCustomDark } from '@/hooks/useCustomDark'
import ContextMenu, { type MenuType } from '@/components/ContextMenu/index.vue'
import logo1 from '@/assets/logo_cl_dark.png'
import logo2 from '@/assets/log_cl_lightBySlide.png'

interface sysTemMenuType {
  id?: number
  permCode?: string
  permName?: string
  permRank?: number
  children?: Array<sysTemMenuType>
}

const emits = defineEmits<{
  (e: 'showSettingForTheme', val: boolean): void
  (e: 'showSystemInfo', val: boolean): void
}>()

const mainStore = useMainStore()
const { t } = useI18n()
const router = useRouter()

const routeList = computed(() => {
  return mainStore.appMenu
})

// 路由
const route = useRoute()
// 当前路由
const currentRoute = computed(() => {
  return route.path
})

// 菜单选择
const handleMenuSelect = (index: string) => {
  if (index !== currentRoute.value) {
    router.push(index)
    // 当前激活模块名
    const appName = index.split('/')[1]
    // 当前激活模块索引
    const navIndex = routeList.value.findIndex(
      item => formatToHump(item.appName) === appName
    )
    if (navIndex !== -1) {
      mainStore.setNavIndex(navIndex)
    }
  }
}

const headerHeight = ref(
  getComputedStyle(document.documentElement).getPropertyValue('--header-height')
)
// 页签高度
const pageTabHeight = computed(() => {
  return isShowTabPag.value
    ? getComputedStyle(document.documentElement).getPropertyValue(
        '--page-tab-height'
      )
    : '0px'
})

// 是否显示页签
const isShowTabPag = computed(() => mainStore.showPaTab)

//  tab页签border
const tabBorder = computed(() => {
  if (isDark.value) {
    // 暗色
    return '1px solid transparent'
  }
  // 非暗色
  return '1px solid #f6f6f6'
})

//  滚动条
const tabScrollEl = ref<InstanceType<typeof ElScrollbar>>()
const tabWrapperEl = ref<HTMLDivElement>()
const scrollDistance = ref(0)
//  设置滚动功能实现
const handleScroll = (type: 'right' | 'left', scrollNum = 350) => {
  const width = tabWrapperEl.value?.clientWidth as number
  const scrollWidth = tabWrapperEl.value?.scrollWidth as number
  // 有滚动的距离
  const canScroll = scrollWidth - width
  if (type === 'right') {
    // 右边滚进
    if (canScroll) {
      if (scrollDistance.value + scrollNum > canScroll) {
        tabScrollEl.value &&
          tabScrollEl.value.scrollTo({
            left: canScroll + 15,
            behavior: 'smooth'
          })
        scrollDistance.value = canScroll
      } else {
        tabScrollEl.value &&
          tabScrollEl.value.scrollTo({
            left: scrollDistance.value + scrollNum,
            behavior: 'smooth'
          })
        scrollDistance.value = scrollDistance.value + scrollNum
      }
    }
  } else {
    // 左边滚回
    if (canScroll && scrollDistance.value) {
      if (scrollDistance.value - scrollNum < 0) {
        ResetTabScroll()
      } else {
        tabScrollEl.value &&
          tabScrollEl.value.scrollTo({
            left: scrollDistance.value - scrollNum,
            behavior: 'smooth'
          })
        scrollDistance.value = scrollDistance.value - scrollNum
      }
    }
  }
}

// 滚动重置
const ResetTabScroll = () => {
  tabScrollEl.value &&
    tabScrollEl.value.scrollTo({
      left: 0,
      behavior: 'smooth'
    })
  scrollDistance.value = 0
}

const pageTabs = computed(() => {
  return mainStore.pageTabs
})

const layoutMainRef = ref<Element>()
const menuList = computed(() => {
  return [
    {
      label: t('closeCurrent'),
      value: 1,
      icon: 'CloseBold'
    },
    {
      label: t('closeOther'),
      value: 2,
      icon: 'SemiSelect'
    },
    {
      label: t('closeAll'),
      value: 3,
      icon: 'Delete'
    },
    {
      label: t('fullScreenCurrent'),
      value: 4,
      icon: 'FullScreen'
    }
  ]
})

const clickMenu = (menu: MenuType, index: number) => {
  // 关闭当前
  if (menu.value === 1) {
    delPageTabs(index)
    return
  }
  // 关闭其他
  if (menu.value === 2) {
    // 因为是关闭其他所有页签，所以直接设置页签为当前页就好了
    mainStore.setPageTabs([pageTabs.value[index]])
    ResetTabScroll()
    return
  }
  // 关闭所有
  if (menu.value === 3) {
    mainStore.setPageTabs([])
    // 关闭所有，那么就要跳转到每个服务的默认首页去
    router.push(mainStore.defaultRoutePath!)
    ResetTabScroll()
    return
  }
  // 全屏页签内容
  if (menu.value === 4 && layoutMainRef.value) {
    router.push(pageTabs.value[index].path)
    document.documentElement.requestFullscreen()
    return
  }
}

// 当前激活的页签前一个tab的index
const activePrevTab = computed<number>(() => {
  if (currentTabIndex.value > -1) {
    if (currentTabIndex.value - 1 >= 0) {
      return currentTabIndex.value - 1
    }
    return -1
  }
  return -1
})

// 当前激活的页签后一个tab的index
const activeNextTab = computed<number>(() => {
  if (currentTabIndex.value > -1) {
    const target = pageTabs.value[currentTabIndex.value + 1]
    if (target) {
      return currentTabIndex.value + 1
    }
    return -1
  }
  return -1
})

// 返回当前页签的index
const currentTabIndex = computed<number>(() => {
  const targetIndex = pageTabs.value.findIndex(item => item.path === route.path)
  return targetIndex
})

// 菜单
const appMenu = computed(() => mainStore.appMenu)
// 页签点击
const handleClickForTabTag = (path: string) => {
  const appName = path.split('/')[1]
  const navIndex = appMenu.value.findIndex(
    item => formatToHump(item.appName) === appName
  )
  if (navIndex > -1) {
    if (navIndex !== mainStore.navIndex) {
      // 先切换导航
      mainStore.setNavIndex(navIndex)
      // 切换完导航，再切换路由
      nextTick(() => {
        router.push(path)
        handleMenuActive(path)
      })
    } else {
      router.push(path)
      handleMenuActive(path)
    }
  } else if (path === '/userInfo') {
    router.push(path)
  } else {
    let isFlag = false
    // 如果找不到，就从menu里面找
    for (const index in appMenu.value) {
      const target = findTarget(path, appMenu.value[index].children)
      if (target) {
        // 先切换导航
        mainStore.setNavIndex(Number(index))
        // 切换完导航，再切换路由
        nextTick(() => {
          router.push(path)
          handleMenuActive(path)
        })
        isFlag = true
        break
      }
    }
    if (!isFlag) {
      router.push(path)
      handleMenuActive(path)
    }
  }
  isClickForSelf.value = true
}

// 找到对应的target
const findTarget = (
  path: string,
  data: sysTemMenuType[]
): sysTemMenuType | undefined => {
  for (const target of data) {
    if (target.permCode === path) {
      return target
    }
    if (target.children) {
      const data = findTarget(path, target.children)
      if (data) {
        return data
      }
    }
  }
}

// 是否手动点击
const isClickForSelf = ref(false)
// 自动滚动依据路由进行滚动
const handleScrollAutoForRoute = (newVal: number, oldVal = 0) => {
  // 宽度
  const width = tabWrapperEl.value?.clientWidth as number
  // 滚动的宽度
  const scrollWidth = tabWrapperEl.value?.scrollWidth as number
  // 是否有滚动的距离
  const canScroll = scrollWidth - width > 0
  if (canScroll) {
    // 判断向左或向右
    const scrollDirection = newVal > oldVal ? 'right' : 'left'
    // 滚动距离 默认大概取值是130px
    const scrollDistanceForWatch = Math.abs(newVal - oldVal) * 100
    if (scrollDirection === 'right') {
      tabScrollEl.value &&
        tabScrollEl.value.scrollTo({
          left: scrollDistance.value + scrollDistanceForWatch,
          behavior: 'smooth'
        })
      scrollDistance.value = scrollDistance.value + scrollDistanceForWatch
    } else {
      const data = scrollDistance.value - scrollDistanceForWatch
      tabScrollEl.value &&
        tabScrollEl.value.scrollTo({
          left: data > 0 ? data : 0,
          behavior: 'smooth'
        })
      scrollDistance.value = data
    }
  }
}

//  是否是暗黑模式
const isDark = useCustomDark()
const delPageTabs = (index: number) => {
  mainStore.deletePageTabs(index)
}

//  刷新
const handleRefresh = () => {
  window.location.reload()
}

// 设置
const handleCommand = (val: string) => {
  if (val === '0') {
    // 重新加载
    handleRefresh()
  } else if (val === '1') {
    // 关闭当前
    if (currentTabIndex.value > -1) {
      delPageTabs(currentTabIndex.value)
    }
  } else if (val === '2') {
    // 关闭其他
    if (currentTabIndex.value > -1) {
      mainStore.setPageTabs([pageTabs.value[currentTabIndex.value]])
      ResetTabScroll()
    }
  } else if (val === '3') {
    // 关闭所有
    mainStore.setPageTabs([])
    // 关闭所有，那么就要跳转到每个服务的默认首页去
    router.push(mainStore.defaultRoutePath!)
    ResetTabScroll()
  } else if (val === '4') {
    // 全屏页签内容
    router.push(pageTabs.value[currentTabIndex.value].path)
    document.documentElement.requestFullscreen()
  }
}

//  特殊处理--相关首页不需要背景色
const isNeedBackground = computed(() => {
  const displayBackground = route.meta.displayBackgroundColor
  if (displayBackground === false) {
    return false
  }
  return true
})

// 不显示水印的页面
const unShowWatermarkPage = computed(() => {
  return !['/login', '/404', '/password'].includes(route.path)
})

// 字体颜色
const fontStyle = reactive({
  color: 'rgba(0, 0, 0, 0.04)'
})
// 水印内容
const watermarkContent = computed<string[]>(() => {
  if (!unShowWatermarkPage.value) {
    return []
  }
  return [
    `${mainStore.userInfo.id}@${mainStore.userInfo.saasId}`,
    `${mainStore.userInfo.realName || mainStore.userInfo.username || ''}@${
      mainStore.userInfo.lastLogonIp || ''
    }`,
    mainStore.waterMarkOperatorTime || ''
  ]
})

watch(
  isDark,
  () => {
    fontStyle.color = isDark.value
      ? 'rgba(255, 255, 255, 0.04)'
      : 'rgba(0, 0, 0, 0.04)'
  },
  {
    immediate: true
  }
)

// 首次登录处理菜单栏激活
const menuRef = ref()
const handleMenuActive = (activeIndex?: string) => {
  menuRef.value.updateActiveIndex(activeIndex || currentRoute.value)
}

// 侧边菜单宽度
const asideWidth = computed(() => {
  return !mainStore.collapse ? '200px' : '60px'
})

// 侧边栏菜单高度
const asideHeight = computed(() => {
  return !mainStore.collapse ? `calc(100vh - 60px)` : '100vh'
})

// 页签内容显示长度
const pageTabContentWidth = computed(() => {
  return !mainStore.collapse ? 'calc(100vw - 360px)' : 'calc(100vw - 220px)'
})

// 返回首页
const handleRouterGo = () => {
  clickTopNav(0)
}

// 点击头部菜单
const clickTopNav = (index: number) => {
  let route = routeList.value[index]
  if (route.children) {
    const childrenItem = route.children
    for (let i = 0; i < childrenItem.length; i++) {
      const item = childrenItem[i]
      if (item.children && item.children.length) {
        const li = item.children
        router.push(li[0].permCode!)
        break
      } else {
        router.push(item.permCode!)
        break
      }
    }
  }
  mainStore.setNavIndex(index)
}

onMounted(() => {
  nextTick(() => {
    // 依据路由以及页签进行滚动
    handleScrollAutoForRoute(currentTabIndex.value, 0)
  })
  handleMenuActive()
})
</script>

<template>
  <div class="layout-main-wrapper">
    <!-- 侧边菜单 -->
    <div class="layout-aside">
      <el-scrollbar>
        <div
          class="layout-logo flex-align flex-center"
          @click="handleRouterGo"
          v-show="!mainStore.collapse"
        >
          <el-image
            class="aside-logo__img"
            style="width: 105px; height: 40px"
            :src="isDark ? logo1 : logo2"
          />
        </div>
        <el-menu
          :collapse="mainStore.collapse"
          mode="vertical"
          @select="handleMenuSelect"
          ref="menuRef"
          class="el-menu-popper"
          :style="{ width: asideWidth }"
        >
          <el-sub-menu
            v-for="(item, index) in routeList"
            :key="index"
            :index="item.appName"
            class="level-1"
          >
            <template #title>
              <menuIcon :icon-name="icon(item.appName!)"></menuIcon>
              <span>{{ t(item.appName) }}</span>
            </template>
            <template
              v-for="subItem in item.children"
              :key="subItem.permCode"
            >
              <!-- 存在多级菜单 -->
              <el-sub-menu
                :index="subItem.permCode!"
                v-if="subItem.children?.length"
                class="second-menu-item"
              >
                <template #title>
                  <menuIcon :icon-name="icon(subItem.permCode!)"></menuIcon>
                  <span>{{ t(subItem.permCode!) }}</span>
                </template>
                <el-menu-item
                  :index="child.permCode"
                  v-for="child in subItem.children"
                  :key="child.permCode"
                  :class="{ specialStyle: !SHOW_SECOND_MENU_ICON }"
                >
                  <menuIcon
                    :icon-name="icon(child.permCode!)"
                    v-if="SHOW_SECOND_MENU_ICON"
                  ></menuIcon>
                  <ToolTipText :text="t(child.permCode!)" />
                </el-menu-item>
              </el-sub-menu>
              <!-- 不存在多级菜单 -->
              <el-menu-item
                :index="subItem.permCode"
                v-else
                class="second-menu-item"
              >
                <menuIcon
                  :icon-name="icon(subItem.permCode!)"
                  v-if="
                    SHOW_SECOND_MENU_ICON ||
                    subItem.permCode?.includes('dashboard')
                  "
                ></menuIcon>
                <span>{{ t(subItem.permCode!) }}</span>
              </el-menu-item>
            </template>
          </el-sub-menu>
        </el-menu>
      </el-scrollbar>
    </div>

    <el-container
      direction="vertical"
      class="layout-container"
    >
      <layoutHeaderBySlide
        @show-setting-for-theme="emits('showSettingForTheme', true)"
        @show-system-info="emits('showSystemInfo', true)"
        @update-active-menu="handleMenuActive"
      />
      <el-container direction="vertical">
        <!-- 页签 -->
        <div
          class="layout-tabs"
          v-show="isShowTabPag"
        >
          <div
            class="tab-arrowLeft commonIcon"
            @click="handleScroll('left')"
          >
            <el-icon>
              <DArrowLeft />
            </el-icon>
          </div>
          <el-scrollbar ref="tabScrollEl">
            <div
              class="layout-tab-wrapper"
              ref="tabWrapperEl"
            >
              <ContextMenu
                v-for="(item, index) in pageTabs"
                :key="index"
                :list="menuList"
                @click="menu => clickMenu(menu, index)"
              >
                <el-tag
                  class="layout-tab inline-flex flex-align cursor-p"
                  :class="{
                    active:
                      route.path === item.path ||
                      route.path === item.path.replace(/\?.+/g, ''),
                    prev: activePrevTab === index,
                    next: activeNextTab === index,
                    borderRight: !isDark
                  }"
                  @click="handleClickForTabTag(item.path)"
                  :color="
                    route.path === item.path ||
                    route.path === item.path.replace(/\?.+/g, '')
                      ? ''
                      : 'var(--el-header-tab-background)'
                  "
                >
                  <u v-if="route.path === item.path"></u>
                  {{
                    item.path.includes('?')
                      ? $t(item.path.replace(/\?.+/g, ''))
                      : $t(item.path)
                  }}
                  <s
                    @click.stop="delPageTabs(index)"
                    class="close-tab-icon"
                  >
                    ×
                  </s>
                </el-tag>
              </ContextMenu>
            </div>
          </el-scrollbar>
          <div
            class="tab-arrowRight commonIcon"
            @click="handleScroll('right')"
          >
            <el-icon>
              <DArrowRight />
            </el-icon>
          </div>
          <div
            class="tab-refresh commonIcon"
            @click="handleRefresh"
          >
            <el-icon>
              <RefreshRight />
            </el-icon>
          </div>
          <div class="tab-setting-wrapper">
            <el-dropdown @command="handleCommand">
              <div class="tab-setting commonIcon">
                <el-icon>
                  <Setting />
                </el-icon>
              </div>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item
                    icon="RefreshRight"
                    command="0"
                  >
                    <span class="font12">{{ t('reload') }}</span>
                  </el-dropdown-item>
                  <el-dropdown-item
                    icon="CloseBold"
                    command="1"
                  >
                    <span class="font12">{{ t('closeCurrent') }}</span>
                  </el-dropdown-item>
                  <el-dropdown-item
                    icon="SemiSelect"
                    command="2"
                  >
                    <span class="font12">{{ t('closeOther') }}</span>
                  </el-dropdown-item>
                  <el-dropdown-item
                    icon="Delete"
                    command="3"
                  >
                    <span class="font12">{{ t('closeAll') }}</span>
                  </el-dropdown-item>
                  <el-dropdown-item
                    icon="FullScreen"
                    command="4"
                  >
                    <span class="font12">{{ t('fullScreenCurrent') }}</span>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
        </div>
        <el-container>
          <el-watermark
            :font="fontStyle"
            :content="watermarkContent"
          >
            <el-main
              class="layout-main"
              ref="layoutMainRef"
              :class="{
                bgColor: isNeedBackground,
                'need-box-shadow': isNeedBackground
              }"
            >
              <router-view v-slot="{ Component }">
                <keep-alive :include="mainStore.keepAliveInclude">
                  <component :is="Component" />
                </keep-alive>
              </router-view>
              <el-backtop
                target=".layout-main"
                :right="50"
                :bottom="100"
              />
            </el-main>
          </el-watermark>
        </el-container>
      </el-container>
    </el-container>
  </div>
</template>

<style lang="scss" scoped>
.layout-main-wrapper {
  width: 100vw;
  height: 100vh;
  display: flex;
  .layout-aside {
    width: v-bind(asideWidth);
    height: 100vh;
    overflow: hidden auto;
    transition: all 0.4s;
    background: $asideBackgroundColor;
    .layout-logo {
      height: 60px;
      box-sizing: border-box;
    }
    :deep(.el-menu-popper) {
      height: v-bind(asideHeight);
      .el-sub-menu__title {
        color: $asidecolor;
        &:hover {
          background: $asideBackgroundColorActive;
        }
      }
      .el-menu-item {
        color: $asidecolor;
        &:hover {
          background: $asideBackgroundColorActive;
        }
      }

      .level-1 {
        & > .el-sub-menu__title {
          padding-left: 5px;
        }
      }

      .el-menu-item.is-active {
        background: $asideBackgroundColorActive;
      }

      .second-menu-item {
        padding-left: 10px;
        .el-sub-menu__title {
          padding-left: 0px;
        }
      }
      .specialStyle {
        padding-left: 50px;
        .el-text {
          color: #fff;
        }
      }
    }
    :deep(.el-menu) {
      background: $asideBackgroundColor;
      color: $asidecolor;
      border-right: unset;
    }
  }
  .layout-container {
    width: calc(100vw - v-bind(asideWidth));
    height: 100vh;
    transition: all 0.4s;
    .layout-tabs {
      display: flex;
      align-items: center;
      padding-left: 10px;
      border-bottom: 1px solid var(--el-border-color-light);
      box-sizing: border-box;

      .commonIcon {
        width: 36px;
        text-align: center;
        height: 34px;
        line-height: $pageTabHeight;
        color: var(--el-text-color-placeholder);

        &:hover {
          color: var(--el-color-primary);
        }
      }

      .tab-arrowRight {
        border-left: 1px solid var(--el-border-color);
        border-right: 1px solid var(--el-border-color);
      }

      .tab-refresh {
        border-right: 1px solid var(--el-border-color);
      }

      .layout-tab-wrapper {
        width: v-bind(pageTabContentWidth);
        height: $pageTabHeight;
        display: flex;
        align-items: center;

        .layout-tab {
          text-align: center;
          font-size: 12px;
          color: var(--el-text-color-primary);
          height: $pageTabHeight;
          transition: all 0.2s;
          margin: 0 auto;
          box-sizing: border-box;

          &.active {
            padding-left: 20px;
            padding-right: 10px;
            color: #666;
            background-color: $mainBackgroundColor;
            border-radius: 10px 10px 0 0;
            color: var(--el-color-primary);
          }

          &:hover {
            padding-left: 20px;
            padding-right: 10px;
            color: #666;
            background-color: $mainBackgroundColor !important;
            border-radius: 10px 10px 0 0;
            color: var(--el-color-primary);
          }

          s {
            display: inline-block;
            width: 16px;
            height: 16px;
            line-height: 16px;
            text-align: center;
            text-decoration: none;
            background-color: transparent;
            box-sizing: border-box;
            border-radius: 50%;
            transition: all 0.2s;

            &:hover {
              background-color: #b4bccc;
              color: #fff;
            }
          }

          &.prev {
            border-right: 1px solid transparent !important;
          }

          &:last-child {
            border: none;
          }

          &:first-child {
            border-right: v-bind(tabBorder);
          }
        }
      }
    }

    .layout-main {
      width: calc(100vw - v-bind(asideWidth));
      height: calc(100vh - v-bind(headerHeight) - v-bind(pageTabHeight));
      overflow: hidden auto;
      transition: all 0.4s;
      padding: 10px 0 10px 10px;

      .layout-main__view {
        box-sizing: border-box;
        border-radius: 4px;
        transition: box-shadow 0.3s ease;
      }

      .need-box-shadow {
        &:hover {
          box-shadow: var(--el-box-shadow-light);
        }
      }

      .padding15 {
        padding: 15px;
      }

      .bgColor {
        background-color: var(--el-bg-color);
      }
    }
  }
}

.font12 {
  font-size: 12px;
}
</style>
