import type { RouteRecordRaw } from 'vue-router'

/**
 eg: 
//  首页路由，不存在子级
  {
    path: '/uwAuthCenter/ops/home/dashboard',
    name: 'uwAuthCenter.opsHomeDashboard',
    component: () =>
      import('@/pages/uwAuthCenter/ops/home/dashboard/index.vue'),
    meta: {
      title: '仪表盘',
      isOwnHand: true,  // 手动添加的路由
      isShowInSlideMenu: true,  // 是否显示在侧边菜单
      isHomePage: true,  // 是否是首页
    }
  }
  
  // 默认普通路由
  {
    path: "/uwAuthCenter/ops/msc/mscPerm",
    name: "uwAuthCenter.opsMscMscPerm",
    component: () => import("@/pages/uwAuthCenter/ops/msc/mscPerm/index.vue"),
    meta: {
      title: "MSC权限管理",
    },
  }
  
  // 编辑页面的动态路由
   {
    path: "/uwAuthCenter/ops/msc/mscAppHost/:type",
    name: "uwAuthCenter.opsMscMscAppHost",
    component: () =>
      import("@/pages/uwAuthCenter/ops/msc/mscAppHost/index.vue"),
    meta: {
      title: "MSC应用主机编辑页面",
      isOwnHand: true,  // 手动添加的路由
      isShowInSlideMenu: false,  // 是否显示在侧边菜单, 不显示在菜单栏上，当然默认是false， 可以不设置
      dynamicRoute: "/uwAuthCenter/ops/msc/mscAppHost",  // 动态路由真正的值，用于tab页签上匹配
    },
  },
 */

const RouterList: RouteRecordRaw[] = [
  {
    path: '/uwAuthCenter/ops/home/dashboard',
    name: 'uwAuthCenter.opsHomeDashboard',
    component: () =>
      import('@/pages/uwAuthCenter/ops/home/dashboard/index.vue'),
    meta: {
      title: '仪表盘',
      isOwnHand: true,
      isShowInSlideMenu: true,
      isHomePage: true
    }
  },
  {
    path: '/uwAuthCenter/ops/msc/mscPerm',
    name: 'uwAuthCenter.opsMscMscPerm',
    component: () => import('@/pages/uwAuthCenter/ops/msc/mscPerm/index.vue'),
    meta: {
      title: 'MSC权限管理'
    }
  },
  {
    path: '/uwAuthCenter/ops/msc/live',
    name: 'uwAuthCenter.opsMscLive',
    component: () => import('@/pages/uwAuthCenter/ops/msc/live/index.vue'),
    meta: {
      title: 'MSC实时数据'
    }
  },
  {
    path: '/uwAuthCenter/ops/msc/mscAppHost',
    name: 'uwAuthCenter.opsMscMscAppHost',
    component: () =>
      import('@/pages/uwAuthCenter/ops/msc/mscAppHost/index.vue'),
    meta: {
      title: 'MSC应用主机管理'
    }
  },
  {
    path: '/uwAuthCenter/ops/msc/mscApp',
    name: 'uwAuthCenter.opsMscMscApp',
    component: () => import('@/pages/uwAuthCenter/ops/msc/mscApp/index.vue'),
    meta: {
      title: 'MSC应用管理'
    }
  },

  {
    path: '/uwAuthCenter/ops/log/loginLog',
    name: 'uwAuthCenter.opsLogLoginLog',
    component: () => import('@/pages/uwAuthCenter/ops/log/loginLog/index.vue'),
    meta: {
      title: '登录日志查询'
    }
  },
  {
    path: '/uwAuthCenter/ops/log/guestLoginLog',
    name: 'uwAuthCenter.opsLogGuestLoginLog',
    component: () =>
      import('@/pages/uwAuthCenter/ops/log/guestLoginLog/index.vue'),
    meta: {
      title: '客户登录日志'
    }
  },
  {
    path: '/uwAuthCenter/ops/log/critLog',
    name: 'uwAuthCenter.opsLogCritLog',
    component: () => import('@/pages/uwAuthCenter/ops/log/critLog/index.vue'),
    meta: {
      title: 'msc关键日志管理'
    }
  },
  {
    path: '/uwAuthCenter/ops/log/actionLog',
    name: 'uwAuthCenter.opsLogActionLog',
    component: () => import('@/pages/uwAuthCenter/ops/log/actionLog/index.vue'),
    meta: {
      title: '操作日志查询'
    }
  },
  {
    path: '/uwAuthCenter/ops/log/dataHistory',
    name: 'uwAuthCenter.opsLogDataHistory',
    component: () =>
      import('@/pages/uwAuthCenter/ops/log/dataHistory/index.vue'),
    meta: {
      title: '数据历史'
    }
  },
  {
    path: '/userInfo',
    component: () => import('@/pages/userInfo/index.vue'),
    name: 'userInfo', // 唯一值
    meta: {
      title: '用户资料',
      isOwnHand: true
    }
  }
]

export default RouterList
