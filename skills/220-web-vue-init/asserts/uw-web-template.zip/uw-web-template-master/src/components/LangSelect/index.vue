<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { useMainStore } from '@/store/main'
import { ElMessage } from 'element-plus'
import { I18N, localeEnum } from '@/i18n/i18n.type'

const mainStore = useMainStore()
const { locale, t } = useI18n()
const route = useRoute()
const currentRoute = route.path
const isLoginRoute =
  currentRoute.includes('/login') && !currentRoute.includes('/log/loginLog')

// 当前语言文字
const curLangText = computed(() => {
  return (
    localeEnum[locale.value as I18N] ||
    localeEnum[mainStore.curBrownerLang] ||
    localeEnum['en']
  )
})

function handleLanguageChange(lang: I18N) {
  ElMessage.closeAll()
  if (localeEnum[lang]) {
    locale.value = lang
    mainStore.setI18n(lang)
    ElMessage.success(t('switchLang'))
  }
}

// 获取当前语言的前两位字符
function getFirstChar(str: string): string {
  const EnglishRegex = /[a-zA-Z]+/g
  if (EnglishRegex.test(str)) {
    return str.substring(0, 2)
  }
  return str.substring(0, 1)
}

// 当前i18n文件包没有默认设置语言执行选择默认英文包
const useNoPackageI18N = () => {
  if (localeEnum[locale.value as I18N]) return
  let flag = false
  for (const key in localeEnum) {
    // 匹配当前i18n配置的所有语言包 没有匹配的默认使用'en'英文包
    if (locale.value === key) {
      flag = true
    }
  }
  if (!flag) {
    locale.value = 'zh-CN'
    mainStore.setI18n('zh-CN')
  }
}

onMounted(() => {
  // 没有配置i18n默认设置当前浏览器语言
  if (!mainStore.i18n) {
    locale.value = mainStore.curBrownerLang
    mainStore.setI18n(mainStore.curBrownerLang)
  }
  useNoPackageI18N()
})
</script>

<template>
  <el-dropdown
    trigger="click"
    @command="handleLanguageChange"
  >
    <div
      class="lang-select flex-align cursor-p"
      :class="{
        'lang-select__loginCss': isLoginRoute
      }"
    >
      <span class="lang-select__icon">{{ getFirstChar(curLangText) }}</span>
      <!-- <span class="lang-select__text">
        {{ curLangText }}
      </span>
      <el-icon class="el-icon--right"><ArrowDown /></el-icon> -->
    </div>
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item
          v-for="(key, value) in localeEnum"
          :key="value"
          :disabled="mainStore.i18n === value"
          :command="value"
        >
          {{ key }}
        </el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>

<style lang="scss" scoped>
.lang-select {
  color: #ffffff;
  &.lang-select__loginCss {
    .lang-select__icon {
      background: rgba(255, 255, 255, 0.4);
    }
    .lang-select__text {
      color: #ffffff;
    }
    .el-icon--right {
      color: #ffffff;
    }
  }
  .lang-select__icon {
    border-radius: 50%;
    padding: 5px;
    background: var(--el-color-primary);
  }
  .lang-select__text {
    color: var(--el-text-color-primary);
    margin-left: 7px;
  }
  .el-icon--right {
    color: var(--el-text-color-primary);
  }
}
</style>
