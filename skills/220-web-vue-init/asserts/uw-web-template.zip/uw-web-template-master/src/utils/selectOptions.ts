import { computed } from 'vue'
import { commonType } from '@/types'
import { useI18n } from 'vue-i18n'

/**
 * 返回多项公共的下拉类型，支持多语言切换
 * @returns
 */
export const useCommonSelectTypes = () => {
  const { t } = useI18n()
  // 依据value得到label
  const handleTypeForLabel = (
    data: string | number,
    findList: commonType[],
    staticValue?: string
  ): string => {
    const target = findList.find(item => item.value === data)
    if (target) {
      return target.label
    }
    return staticValue ? staticValue : '--'
  }
  //  登录类型
  const loginTypes = computed<commonType[]>(() => [
    {
      label: t('repeatedLogin'),
      value: -2
    },
    {
      label: t('kickOutUsers'),
      value: -4
    },
    {
      label: t('logOut'),
      value: -1
    },
    {
      label: t('TOKENRefresh'),
      value: 0
    },
    {
      label: t('loginWithUsernamePassword'),
      value: 1
    },
    {
      label: t('phoneNumberAndPasswordLogin'),
      value: 2
    },
    {
      label: t('emailPasswordLogin'),
      value: 3
    },
    {
      value: 20,
      label: t('TOTPRecoveryCodeLogin')
    },
    {
      value: 21,
      label: t('TOTPValidateCodeLogin')
    },
    {
      label: t('phoneValidateCodeLogin'),
      value: 23
    },
    {
      label: t('emailValidateCodeLogin'),
      value: 22
    },
    {
      label: t('WeChatCodeLogin'),
      value: 31
    }
  ])
  // 登录结果类型
  const loginResultTypes = computed<commonType[]>(() => {
    return [
      {
        label: t('success'),
        value: 'success'
      },
      {
        label: t('error'),
        value: 'error'
      },
      {
        label: t('catch'),
        value: 'warn'
      }
    ]
  })
  // 登录设备类型
  const loginDeviceTypes = computed<commonType[]>(() => {
    return [
      {
        label: 'PC-WEB',
        value: 0
      },
      {
        label: 'MOBILE-WEB',
        value: 2
      },
      {
        label: 'MOBILE-APP',
        value: 3
      },
      {
        label: 'WEIXIN-APP etc',
        value: 4
      }
    ]
  })
  // 通用类型
  const commonTypes = computed<commonType[]>(() => {
    return [
      {
        label: t('enable'),
        value: 1
      },
      {
        label: t('disabled'),
        value: 0
      },
      {
        label: t('delete'),
        value: -1
      }
    ]
  })
  //  用户类型
  const userTypes = computed<commonType[]>(() => {
    return [
      {
        value: 0,
        label: '任意用户'
      },
      {
        value: 1,
        label: t('CStationUser')
      },

      {
        value: 10,
        label: t('RPCUser')
      },
      {
        value: 100,
        label: t('systemAdministrator')
      },
      {
        value: 110,
        label: t('DevelopOperationAndMaintenanceUsers')
      },

      {
        value: 200,
        label: t('SASSAdmin')
      },
      {
        value: 300,
        label: t('SASSOperator')
      },
      {
        value: 310,
        label: t('SAASMerchant')
      }
    ]
  })

  // 全部用户类型列表
  const getAllUserTypes = computed<commonType[]>(() => {
    return userTypes.value.filter(item =>
      [100, 1, 10, 110, 0, 200, 300, 310].includes(Number(item.value))
    )
  })

  // 获得有菜单的用户类型
  const getMscMenuUserTypes = computed<commonType[]>(() => {
    return userTypes.value.filter(item =>
      [100, 110, 200, 300, 310].includes(Number(item.value))
    )
  })
  // 获得ROOT可管理类型列表
  const getRootManageTypes = computed<commonType[]>(() => {
    return userTypes.value.filter(item =>
      [100, 1, 110, 200].includes(Number(item.value))
    )
  })

  // 获得SAASROOT可管理类型列表
  const getSaasAdminManageTypes = computed<commonType[]>(() => {
    return userTypes.value.filter(item => [200].includes(Number(item.value)))
  })

  // 获得SAASAdmin可管理类型列表
  const getSaasOperatorManageTypes = computed<commonType[]>(() => {
    return userTypes.value.filter(item =>
      [300, 310].includes(Number(item.value))
    )
  })
  // 系统语言
  const systemLangTypes = computed(() => [
    {
      value: 'zh-CN',
      label: t('zh-cn')
    },
    {
      value: 'zh-TW',
      label: t('zh-tw')
    },
    {
      value: 'ja',
      label: t('ja')
    },
    {
      value: 'en',
      label: t('en')
    },
    {
      value: 'ko',
      label: t('ko')
    }
  ])
  // 货币类型
  const currencyTypes = computed<commonType[]>(() => [
    {
      value: 'CNY',
      label: t('CNY')
    },
    {
      value: 'USD',
      label: t('USD')
    },
    {
      value: 'HKD',
      label: t('HKD')
    },
    {
      value: 'JPY',
      label: t('JPY')
    },
    {
      value: 'MOP',
      label: t('MOP')
    },
    {
      value: 'TWD',
      label: t('TWD')
    },
    {
      value: 'EUR',
      label: t('EUR')
    },
    {
      value: 'GBP',
      label: t('GBP')
    },
    {
      value: 'THB',
      label: t('THB')
    },
    {
      value: 'VND',
      label: t('VND')
    },
    {
      value: 'KRW',
      label: t('KRW')
    },
    {
      value: 'SGD',
      label: t('SGD')
    },
    {
      value: 'BND',
      label: t('BND')
    },
    {
      value: 'INR',
      label: t('INR')
    },
    {
      value: 'KPW',
      label: t('KPW')
    },
    {
      value: 'MUR',
      label: t('MUR')
    },
    {
      value: 'USN',
      label: t('USN')
    },
    {
      value: 'USS',
      label: t('USS')
    },
    {
      value: 'CAD',
      label: t('CAD')
    },
    {
      value: 'IDR',
      label: t('IDR')
    },
    {
      value: 'NPR',
      label: t('NPR')
    },
    {
      value: 'LRD',
      label: t('LRD')
    },
    {
      value: 'MYR',
      label: t('MYR')
    },
    {
      value: 'RUR',
      label: t('RUR')
    },
    {
      value: 'CUP',
      label: t('CUP')
    },
    {
      value: 'BZD',
      label: t('BZD')
    },
    {
      value: 'GIP',
      label: t('GIP')
    },
    {
      value: 'HUF',
      label: t('HUF')
    },
    {
      value: 'GYD',
      label: t('GYD')
    },
    {
      value: 'KWD',
      label: t('KWD')
    },
    {
      value: 'CLP',
      label: t('CLP')
    },
    {
      value: 'HRK',
      label: t('HRK')
    },
    {
      value: 'SKK',
      label: t('SKK')
    },
    {
      value: 'XUA',
      label: t('XUA')
    },
    {
      value: 'DKK',
      label: t('DKK')
    },
    {
      value: 'BMD',
      label: t('BMD')
    },
    {
      value: 'FJD',
      label: t('FJD')
    },
    {
      value: 'SEK',
      label: t('SEK')
    },
    {
      value: 'XFU',
      label: t('XFU')
    },
    {
      value: 'SIT',
      label: t('SIT')
    },
    {
      value: 'XBD',
      label: t('XBD')
    },
    {
      value: 'VEF',
      label: t('VEF')
    },
    {
      value: 'CSD',
      label: t('CSD')
    },
    {
      value: 'XOF',
      label: t('XOF')
    },
    {
      value: 'XPF',
      label: t('XPF')
    },
    {
      value: 'FKP',
      label: t('FKP')
    },
    {
      value: 'SYP',
      label: t('SYP')
    },
    {
      value: 'BYN',
      label: t('BYN')
    },
    {
      value: 'OMR',
      label: t('OMR')
    },
    {
      value: 'ADP',
      label: t('ADP')
    },
    {
      value: 'NOK',
      label: t('NOK')
    },
    {
      value: 'AWG',
      label: t('AWG')
    },
    {
      value: 'IEP',
      label: t('IEP')
    },
    {
      value: 'LYD',
      label: t('LYD')
    },
    {
      value: 'ESP',
      label: t('ESP')
    },
    {
      value: 'KYD',
      label: t('KYD')
    },
    {
      value: 'BWP',
      label: t('BWP')
    },
    {
      value: 'LAK',
      label: t('LAK')
    },
    {
      value: 'DZD',
      label: t('DZD')
    },
    {
      value: 'MNT',
      label: t('MNT')
    },
    {
      value: 'SRG',
      label: t('SRG')
    },
    {
      value: 'MKD',
      label: t('MKD')
    },
    {
      value: 'LKR',
      label: t('LKR')
    },
    {
      value: 'TRL',
      label: t('TRL')
    },
    {
      value: 'GRD',
      label: t('GRD')
    },
    {
      value: 'MZM',
      label: t('MZM')
    },
    {
      value: 'DJF',
      label: t('DJF')
    },
    {
      value: 'ANG',
      label: t('ANG')
    },
    {
      value: 'MGA',
      label: t('MGA')
    },
    {
      value: 'BBD',
      label: t('BBD')
    },
    {
      value: 'BOB',
      label: t('BOB')
    },
    {
      value: 'GMD',
      label: t('GMD')
    },
    {
      value: 'XBC',
      label: t('XBC')
    },
    {
      value: 'IRR',
      label: t('IRR')
    },
    {
      value: 'BAM',
      label: t('BAM')
    },
    {
      value: 'AOA',
      label: t('AOA')
    },
    {
      value: 'RSD',
      label: t('RSD')
    },
    {
      value: 'TRY',
      label: t('TRY')
    },
    {
      value: 'RUB',
      label: t('RUB')
    },
    {
      value: 'KMF',
      label: t('KMF')
    },
    {
      value: 'TPE',
      label: t('TPE')
    },
    {
      value: 'ZWD',
      label: t('ZWD')
    },
    {
      value: 'JOD',
      label: t('JOD')
    },
    {
      value: 'NZD',
      label: t('NZD')
    },
    {
      value: 'ZMK',
      label: t('ZMK')
    },
    {
      value: 'PKR',
      label: t('PKR')
    },
    {
      value: 'NIO',
      label: t('NIO')
    },
    {
      value: 'SLL',
      label: t('SLL')
    },
    {
      value: 'FIM',
      label: t('FIM')
    },
    {
      value: 'GHC',
      label: t('GHC')
    },
    {
      value: 'ITL',
      label: t('ITL')
    },
    {
      value: 'UYU',
      label: t('UYU')
    },
    {
      value: 'AFA',
      label: t('AFA')
    },
    {
      value: 'ATS',
      label: t('ATS')
    },
    {
      value: 'LSL',
      label: t('LSL')
    },
    {
      value: 'SCR',
      label: t('SCR')
    },
    {
      value: 'ETB',
      label: t('ETB')
    },
    {
      value: 'XFO',
      label: t('XFO')
    },
    {
      value: 'COP',
      label: t('COP')
    },
    {
      value: 'MXN',
      label: t('MXN')
    },
    {
      value: 'LTL',
      label: t('LTL')
    },
    {
      value: 'UGX',
      label: t('UGX')
    },
    {
      value: 'ALL',
      label: t('ALL')
    },
    {
      value: 'BOV',
      label: t('BOV')
    },
    {
      value: 'AUD',
      label: t('AUD')
    },
    {
      value: 'DOP',
      label: t('DOP')
    },
    {
      value: 'XBA',
      label: t('XBA')
    },
    {
      value: 'BYB',
      label: t('BYB')
    },
    {
      value: 'MXV',
      label: t('MXV')
    },
    {
      value: 'XPD',
      label: t('XPD')
    },
    {
      value: 'XCD',
      label: t('XCD')
    },
    {
      value: 'GTQ',
      label: t('GTQ')
    },
    {
      value: 'RWF',
      label: t('RWF')
    },
    {
      value: 'HTG',
      label: t('HTG')
    },
    {
      value: 'SDG',
      label: t('SDG')
    },
    {
      value: 'ZAR',
      label: t('ZAR')
    },
    {
      value: 'CHW',
      label: t('CHW')
    },
    {
      value: 'BTN',
      label: t('BTN')
    },
    {
      value: 'AMD',
      label: t('AMD')
    },
    {
      value: 'PTE',
      label: t('PTE')
    },
    {
      value: 'AYM',
      label: t('AYM')
    },
    {
      value: 'TMM',
      label: t('TMM')
    },
    {
      value: 'KGS',
      label: t('KGS')
    },
    {
      value: 'PHP',
      label: t('PHP')
    },
    {
      value: 'BHD',
      label: t('BHD')
    },
    {
      value: 'PAB',
      label: t('PAB')
    },
    {
      value: 'MAD',
      label: t('MAD')
    },
    {
      value: 'BIF',
      label: t('BIF')
    },
    {
      value: 'XAF',
      label: t('XAF')
    },
    {
      value: 'MZN',
      label: t('MZN')
    },
    {
      value: 'NLG',
      label: t('NLG')
    },
    {
      value: 'CHF',
      label: t('CHF')
    },
    {
      value: 'TTD',
      label: t('TTD')
    },
    {
      value: 'ROL',
      label: t('ROL')
    },
    {
      value: 'YER',
      label: t('YER')
    },
    {
      value: 'PEN',
      label: t('PEN')
    },
    {
      value: 'STD',
      label: t('STD')
    },
    {
      value: 'SAR',
      label: t('SAR')
    },
    {
      value: 'XAG',
      label: t('XAG')
    },
    {
      value: 'SZL',
      label: t('SZL')
    },
    {
      value: 'AZM',
      label: t('AZM')
    },
    {
      value: 'ILS',
      label: t('ILS')
    },
    {
      value: 'ISK',
      label: t('ISK')
    },
    {
      value: 'XDR',
      label: t('XDR')
    },
    {
      value: 'ARS',
      label: t('ARS')
    },
    {
      value: 'BYR',
      label: t('BYR')
    },
    {
      value: 'YUM',
      label: t('YUM')
    },
    {
      value: 'TZS',
      label: t('TZS')
    },
    {
      value: 'IQD',
      label: t('IQD')
    },
    {
      value: 'SDD',
      label: t('SDD')
    },
    {
      value: 'BDT',
      label: t('BDT')
    },
    {
      value: 'GHS',
      label: t('GHS')
    },
    {
      value: 'ERN',
      label: t('ERN')
    },
    {
      value: 'TJS',
      label: t('TJS')
    },
    {
      value: 'GNF',
      label: t('GNF')
    },
    {
      value: 'XPT',
      label: t('XPT')
    },
    {
      value: 'CZK',
      label: t('CZK')
    },
    {
      value: 'UAH',
      label: t('UAH')
    },
    {
      value: 'MRO',
      label: t('MRO')
    },
    {
      value: 'GEL',
      label: t('GEL')
    },
    {
      value: 'MWK',
      label: t('MWK')
    },
    {
      value: 'HNL',
      label: t('HNL')
    },
    {
      value: 'AFN',
      label: t('AFN')
    },
    {
      value: 'LBP',
      label: t('LBP')
    },
    {
      value: 'NGN',
      label: t('NGN')
    },
    {
      value: 'XAU',
      label: t('XAU')
    },
    {
      value: 'VUV',
      label: t('VUV')
    },
    {
      value: 'TND',
      label: t('TND')
    },
    {
      value: 'EEK',
      label: t('EEK')
    },
    {
      value: 'CLF',
      label: t('CLF')
    },
    {
      value: 'MGF',
      label: t('MGF')
    },
    {
      value: 'XBB',
      label: t('XBB')
    },
    {
      value: 'SRD',
      label: t('SRD')
    },
    {
      value: 'ZWL',
      label: t('ZWL')
    },
    {
      value: 'CYP',
      label: t('CYP')
    },
    {
      value: 'ZWN',
      label: t('ZWN')
    },
    {
      value: 'CVE',
      label: t('CVE')
    },
    {
      value: 'QAR',
      label: t('QAR')
    },
    {
      value: 'DEM',
      label: t('DEM')
    },
    {
      value: 'BGL',
      label: t('BGL')
    },
    {
      value: 'VEB',
      label: t('VEB')
    },
    {
      value: 'MDL',
      label: t('MDL')
    },
    {
      value: 'MVR',
      label: t('MVR')
    },
    {
      value: 'CUC',
      label: t('CUC')
    },
    {
      value: 'KES',
      label: t('KES')
    },
    {
      value: 'LUF',
      label: t('LUF')
    },
    {
      value: 'GWP',
      label: t('GWP')
    },
    {
      value: 'TMT',
      label: t('TMT')
    },
    {
      value: 'BEF',
      label: t('BEF')
    },
    {
      value: 'PYG',
      label: t('PYG')
    },
    {
      value: 'CDF',
      label: t('CDF')
    },
    {
      value: 'UYI',
      label: t('UYI')
    },
    {
      value: 'NAD',
      label: t('NAD')
    },
    {
      value: 'LVL',
      label: t('LVL')
    },
    {
      value: 'CHE',
      label: t('CHE')
    },
    {
      value: 'EGP',
      label: t('EGP')
    },
    {
      value: 'RON',
      label: t('RON')
    },
    {
      value: 'ZMW',
      label: t('ZMW')
    },
    {
      value: 'PLN',
      label: t('PLN')
    },
    {
      value: 'PGK',
      label: t('PGK')
    },
    {
      value: 'MTL',
      label: t('MTL')
    },
    {
      value: 'KHR',
      label: t('KHR')
    },
    {
      value: 'SSP',
      label: t('SSP')
    },
    {
      value: 'SHP',
      label: t('SHP')
    },
    {
      value: 'MMK',
      label: t('MMK')
    },
    {
      value: 'WST',
      label: t('WST')
    },
    {
      value: 'JMD',
      label: t('JMD')
    },
    {
      value: 'COU',
      label: t('COU')
    },
    {
      value: 'TOP',
      label: t('TOP')
    },
    {
      value: 'BSD',
      label: t('BSD')
    },
    {
      value: 'SOS',
      label: t('SOS')
    },
    {
      value: 'SBD',
      label: t('SBD')
    },
    {
      value: 'CRC',
      label: t('CRC')
    },
    {
      value: 'AED',
      label: t('AED')
    },
    {
      value: 'XSU',
      label: t('XSU')
    },
    {
      value: 'UZS',
      label: t('UZS')
    },
    {
      value: 'BRL',
      label: t('BRL')
    },
    {
      value: 'KZT',
      label: t('KZT')
    },
    {
      value: 'ZWR',
      label: t('ZWR')
    },
    {
      value: 'BGN',
      label: t('BGN')
    },
    {
      value: 'FRF',
      label: t('FRF')
    },
    {
      value: 'XXX',
      label: t('XXX')
    }
  ])
  // 周数
  const weekTypes = computed(() => [
    {
      label: t('Sunday'),
      value: 0
    },
    {
      label: t('Monday'),
      value: 1
    },
    {
      label: t('Tuesday'),
      value: 2
    },
    {
      label: t('Wednesday'),
      value: 3
    },
    {
      label: t('Thursday'),
      value: 4
    },
    {
      label: t('Friday'),
      value: 5
    },
    {
      label: t('Saturday'),
      value: 6
    }
  ])

  // 日期选择器，快捷选项
  const shortcuts = computed(() => [
    {
      text: t('lastDay'),
      value: () => {
        const end = new Date()
        const start = new Date()
        start.setTime(start.getTime() - 3600 * 1000 * 24)
        return [start, end]
      }
    },
    {
      text: t('lastWeek'),
      value: () => {
        const end = new Date()
        const start = new Date()
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
        return [start, end]
      }
    },
    {
      text: t('lastMonth'),
      value: () => {
        const end = new Date()
        const start = new Date()
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
        return [start, end]
      }
    },
    {
      text: t('inThePastThreeMonths'),
      value: () => {
        const end = new Date()
        const start = new Date()
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
        return [start, end]
      }
    }
  ])
  // 组织类型
  const organizationalTypes = computed<commonType[]>(() => [
    {
      label: t('person'),
      value: 1
    },
    {
      label: t('enterprise'),
      value: 2
    }
  ])

  // 公告状态
  const noticeState = computed(() => [
    {
      value: -1,
      label: t('delete')
    },
    {
      value: 0,
      label: t('unpublished')
    },
    {
      value: 1,
      label: t('published')
    },
    {
      value: 2,
      label: t('published')
    }
  ])

  // 审核状态
  const auditStateTypes = computed(() => [
    {
      value: -1,
      label: t('auditRefuse')
    },
    {
      value: 0,
      label: t('pendingApproval')
    },
    {
      value: 1,
      label: t('approved')
    }
  ])
  // 公告对象类型
  const announcementObjectType = computed(() => [
    {
      value: 1,
      label: t('guestUser')
    },
    {
      value: 16,
      label: t('operator')
    },
    {
      value: 32,
      label: t('merchant')
    }
  ])

  // 证件类型
  const idTypes = computed(() => [
    {
      value: 0,
      label: '身份证'
    },
    {
      value: 1,
      label: '护照'
    },
    {
      value: 2,
      label: '香港身份证'
    },
    {
      value: 3,
      label: '澳门身份证'
    },
    {
      value: 4,
      label: '台胞证'
    },
    {
      value: 5,
      label: '外国人永久居留证'
    },
    {
      value: 10,
      label: '警官证'
    },
    {
      value: 11,
      label: '军官证'
    },
    {
      value: 12,
      label: '士兵证'
    },
    {
      value: 13,
      label: '外交官证'
    }
  ])

  // 付费类型
  const payTypes = computed(() => [
    {
      label: t('unpaid'),
      value: 0
    },
    {
      label: t('payAnnualFee'),
      value: 1
    },
    {
      label: t('shareRevenue'),
      value: 2
    }
  ])

  // 用户性别
  const genderTypes = computed(() => [
    {
      label: '男',
      value: 1
    },
    {
      label: '女',
      value: 0
    },
    {
      label: '未知',
      value: -1
    }
  ])

  // 上下线
  const appStates = computed(() => [
    {
      label: t('offline'),
      value: 0
    },
    {
      label: t('online'),
      value: 1
    },
    {
      label: t('delete'),
      value: -1
    }
  ])

  return {
    handleTypeForLabel,
    loginTypes,
    loginResultTypes,
    loginDeviceTypes,
    commonTypes,
    userTypes,
    systemLangTypes,
    currencyTypes,
    getAllUserTypes,
    getMscMenuUserTypes,
    getRootManageTypes,
    getSaasAdminManageTypes,
    getSaasOperatorManageTypes,
    shortcuts,
    organizationalTypes,
    noticeState,
    weekTypes,
    announcementObjectType,
    auditStateTypes,
    idTypes,
    payTypes,
    genderTypes,
    appStates
  }
}
