import { defineStore } from 'pinia'
import { ElMessage } from 'element-plus'
import type { RouteRecordRaw } from 'vue-router'
import router, { routes } from '@/router'
import type { I18N } from '@/i18n/i18n.type'
import { name, version } from '../../package.json'
import { TokenResponse } from '@/api/uwAuthCenterAuthApi'
import {
  MscUser,
  MscAppPermVo,
  userLogout,
  userLoadAppMenu,
  userProfile
} from '@/api/uwAuthCenterUserApi'
import { formatToHump } from '@/utils/tool'
import { handleBuildSlideMenu } from '@/utils/buildTreeMenu'
import dayjs from 'dayjs'

const ElTitle = document.querySelector('title')

interface MenuType {
  id?: number
  permCode?: string
  permName?: string
  permRank?: number
  displayState?: number //状态1:正常,2:vip
  children?: Array<MenuType>
}

export interface MenuAppType {
  appLabel: string
  appName: string
  appRank: number
  appVersion: string
  displayState: number
  id: number
  children: Array<MenuType>
}

// 页签设置
interface PageTab {
  title: string
  path: string
  name: string
  dynamicRoute?: string
  query?: any
  params?: any
}

// 搜索框显示模式 1 默认不显示 2 默认显示一行 3 默认显示全部
export type searchSettingModelType = 1 | 2 | 3

type layoutMode = 'default' | 'vertical' | 'slide'

export const useMainStore = defineStore('main', {
  state: () => {
    const loginInfo = JSON.parse(
      sessionStorage.getItem(`${name}-loginInfo`) || '{}'
    ) as TokenResponse

    const navIndex = Number(sessionStorage.getItem(`${name}-navIndex`)) || 0
    const pageTabs: PageTab[] = JSON.parse(
      sessionStorage.getItem(`${name}-pageTabs`) || '[]'
    )
    const i18n = localStorage.getItem(`${name}-lang`) as I18N
    const curBrownerLang = window.navigator.language as I18N // 当前浏览器语言
    //  系统主题色
    const systemThemeColors =
      localStorage.getItem(`${name}-systemThemeColors`) || '#409eff'
    // 侧边栏菜单主题
    const slideMenuColor =
      localStorage.getItem(`${name}-slideMenuColor`) || '#001529'
    // 搜索框显示模式
    const searchSettingModelValue = localStorage.getItem(
      `${name}-searchSettingModel`
    )
      ? Number(localStorage.getItem(`${name}-searchSettingModel`))
      : 1
    // 是否显示页签
    const showPaTab = localStorage.getItem(`${name}-showPaTab`)
      ? JSON.parse(localStorage.getItem(`${name}-showPaTab`) as string)
      : true
    // 部署环境显示的页签
    const deployEnv = sessionStorage.getItem('deployEnv')
      ? sessionStorage.getItem('deployEnv')
      : ''
    // 权限map, 用于v-permission指令判断
    const permissionMap = new Map()
    // 系统主题模式明亮light、暗黑dark两种 true代表暗黑、false代表明亮, 默认明亮模式
    const systemDark = localStorage.getItem(`${name}-systemDark`)
      ? JSON.parse(localStorage.getItem(`${name}-systemDark`) as string)
      : false
    // 是否加载过登录提示
    const hasLoadLoginNotice = sessionStorage.getItem(
      `${name}-hasLoadLoginNotice`
    )
      ? JSON.parse(
          sessionStorage.getItem(`${name}-hasLoadLoginNotice`) as string
        )
      : false
    // 页面布局模式
    const layoutMode =
      (localStorage.getItem(`${name}-layout`) as layoutMode) || 'default'
    return {
      collapse: false, // 是否水平折叠收起菜单
      navIndex, // 顶部激活索引
      loginInfo,
      userInfo: {} as MscUser,
      i18n,
      curBrownerLang,
      loadAppMenu: [] as MscAppPermVo[], // 未处理的导航栏接口数据
      appMenu: [] as MenuAppType[],
      // 用户类型枚举
      userTypeEnum: {
        '-1': 'C站用户',
        0: 'C站用户',
        1: 'RPC用户',
        100: '平台管理员',
        110: 'OPS用户',
        200: '运营商管理员',
        300: '运营商用户',
        310: 'SAAS商户'
      },
      pageTabs, // 页签数据
      systemThemeColors,
      slideMenuColor,
      systemDark, // 是否暗黑模式
      searchSettingModel: searchSettingModelValue as searchSettingModelType, // 搜索框显示模式
      showPaTab, // 是否显示页签
      deployEnv, // 部署环境显示的页签
      permissionMap, // 权限map，用于权限指令判断
      loginAgent: `${name}:${version}`, // 登录代理标识
      hasLoadLoginNotice: hasLoadLoginNotice, // 是否显示登录提示信息
      showProgress: false, // 是否显示进度弹窗
      progressValue: 0, // 进度条进度值
      allDownloaded: 0, // 下载总数
      alreadyDownloaded: 0, // 已下载进度
      waterMarkOperatorTime: dayjs().format('YYYY-MM-DDTHH:mm:ssZ'), // 水印操作时间
      layoutMode: layoutMode
    }
  },
  getters: {
    keepAliveInclude: state => {
      return state.pageTabs.map(item => item.name)
    },
    // 初始默认路由路径 根据顶部导航索引决定初始默认首页
    defaultRoutePath: state => {
      const item = state.appMenu[state.navIndex]
      if (!item) return ''
      const childrenLength = item.children[0]?.children?.length
      if (item.children[0]?.children && childrenLength) {
        return item.children[0].children[0].permCode
      }
      return item.children[0].permCode
    }
  },
  actions: {
    setLayoutMode(mode: layoutMode) {
      this.layoutMode = mode
      localStorage.setItem(`${name}-layout`, mode)
    },
    setWaterMarkOperatorTime(time: string) {
      this.waterMarkOperatorTime = time
    },
    setHasLoadLoginNotice(value: boolean) {
      this.hasLoadLoginNotice = value
      sessionStorage.setItem(
        `${name}-hasLoadLoginNotice`,
        JSON.stringify(value)
      )
    },
    setAllDownloaded(value: number) {
      this.allDownloaded = value
    },
    setAlreadyDownloaded(value: number) {
      this.alreadyDownloaded = value
    },
    // 设置进度条进度值
    setProgressValue(value: number) {
      this.progressValue = value
    },
    // 设置是否显示进度条
    setShowProgress(status: boolean) {
      this.showProgress = status
      if (!status) {
        this.progressValue = 0
      }
    },
    // 设置权限map指令
    setPermissionMap(pathKey: string, hasPermission: boolean) {
      this.permissionMap.set(pathKey, hasPermission)
    },
    // 设置部署环境dev
    setDeployEnv(value: string) {
      this.deployEnv = value
      sessionStorage.setItem('deployEnv', String(value))
    },
    // 设置是否显示页签
    setShowTabPage(value: boolean) {
      this.showPaTab = value
      localStorage.setItem(`${name}-showPaTab`, JSON.stringify(value))
    },
    // 设置搜索框的显示模式
    setSearchSettingModel(model: searchSettingModelType) {
      this.searchSettingModel = model
      localStorage.setItem(`${name}-searchSettingModel`, String(model))
    },
    // 设置暗黑模式
    setSystemDark(isDark: boolean) {
      this.systemDark = isDark
      localStorage.setItem(`${name}-systemDark`, JSON.stringify(isDark))
    },
    // 设置侧边栏主题色
    setSlideMenuColor(color: string) {
      this.slideMenuColor = color
      localStorage.setItem(`${name}-slideMenuColor`, color)
    },
    // 设置系统主题色
    setSystemThemeColors(color: string) {
      this.systemThemeColors = color
      localStorage.setItem(`${name}-systemThemeColors`, color)
    },
    // 设置侧边栏 展开/塌陷
    setCollapse(status?: boolean) {
      if (typeof status === 'boolean') {
        this.collapse = status
      } else {
        this.collapse = !this.collapse
      }
    },
    // 设置国家化语言
    setI18n(lang: I18N) {
      this.i18n = lang
      localStorage.setItem(`${name}-lang`, lang)
    },
    // 设置顶部Nav导航选择的是第几个
    setNavIndex(index: number) {
      this.navIndex = index
      sessionStorage.setItem(`${name}-navIndex`, String(index))
    },
    // 设置登录信息
    setLoginInfo(info: TokenResponse) {
      this.loginInfo = info
      sessionStorage.setItem(`${name}-loginInfo`, JSON.stringify(info))
    },
    // 更新token
    setRefreshTokenInfo(info: {
      createAt: number
      expiresIn: number
      token: string
    }) {
      this.loginInfo = {
        ...this.loginInfo,
        ...info
      }
      sessionStorage.setItem(
        `${name}-loginInfo`,
        JSON.stringify(this.loginInfo)
      )
    },
    // 设置用户信息
    setUserInfo(info: MscUser) {
      this.userInfo = info
      if (ElTitle) {
        ElTitle.innerText = (info?.realName || info?.username) + '@开发运维系统'
      }
    },
    // 设置菜单栏
    setAppMenu(menuList?: MscAppPermVo[]) {
      this.loadAppMenu = menuList || []
      return new Promise(resolve => {
        // 这个数据是后台返回的所有路由参数
        let voList: {
          id: number
          permCode: string
          permName: string
        }[] = []
        // 是否手动添加且需展示在菜单上的路由
        const isOwnHandRoutesAndShowInMenu: RouteRecordRaw[] = []
        // 是否是系统首页的页面路由  permCode 数组
        const isHomePageRoutes: string[] = []
        menuList?.forEach(items => {
          if (items.permVoList && items.permVoList.length) {
            items.permVoList.map(item => {
              // @ts-expect-error
              item.permCode = '/' + formatToHump(items.appName) + item.permCode
              return item
            })
            // @ts-expect-error
            voList = voList.concat(items.permVoList || [])
          }
        })
        // 动态添加路由
        routes.forEach(item => {
          for (let i = 0; i < voList.length; i++) {
            const element = voList[i]
            // 判断本地路由和接口拿到的权限路由是否一致 或者是否是手动添加的界面，如果是就一直就动态注册路由
            if (item.path === element.permCode || item.meta?.isOwnHand) {
              if (item.path === element.permCode) {
                // 判断是否存在list接口，存在list接口才设置界面
                const hasListApi = voList.find(
                  voListItem =>
                    voListItem.permCode === `${element.permCode}/list:GET`
                )
                if (hasListApi) {
                  item.meta = {
                    ...item.meta,
                    title: item.meta?.isOwnHand
                      ? item.meta.title
                      : element.permName,
                    keepAlive: true
                  }
                  if (item.meta?.isHomePage) {
                    // 是否是首页
                    isHomePageRoutes.push(item.path)
                  }
                  router.addRoute('app', item)
                  break
                }
              }
              // 手动添加的路由
              if (item.meta?.isOwnHand) {
                item.meta = {
                  ...item.meta,
                  title: item.meta?.isOwnHand
                    ? item.meta.title
                    : element.permName,
                  keepAlive: true
                }
                if (item.meta?.isShowInSlideMenu) {
                  // 是否需要显示在菜单上
                  isOwnHandRoutesAndShowInMenu.push(item)
                }
                if (item.meta?.isHomePage) {
                  // 是否是首页
                  isHomePageRoutes.push(item.path)
                }
                router.addRoute('app', item)
                break
              }
            }
          }
        })

        // 处理侧边导航栏显示
        const menu: MenuAppType[] = []
        menuList?.forEach(item => {
          const menuItem = {
            appLabel: item.appLabel,
            appName: item.appName,
            appRank: item.appRank,
            appVersion: item.appVersion,
            displayState: item.displayState,
            id: item.id,
            children: handleBuildSlideMenu(
              item.permVoList!,
              isOwnHandRoutesAndShowInMenu,
              isHomePageRoutes
            )
          }
          menu.push(menuItem as MenuAppType)
        })
        this.appMenu = menu
        resolve(true)
      })
    },
    // 设置 页签
    setPageTabs(tabInfo: Array<PageTab> | PageTab) {
      let flag = false
      // 如果是数组 那么就直接替换
      if (Array.isArray(tabInfo)) {
        this.pageTabs = tabInfo
        flag = true
      } else if (
        !/^\/login/.test(tabInfo.path) &&
        tabInfo.title !== '404' &&
        tabInfo.name !== 'password'
      ) {
        if (this.pageTabs.length === 0) {
          this.pageTabs.push(tabInfo)
        } else {
          let newPath = false
          for (let i = 0; i < this.pageTabs.length; i++) {
            const item = this.pageTabs[i]
            if (item.path === tabInfo.path || tabInfo.path === '/login') {
              newPath = false
              break
            } else {
              newPath = true
            }
          }
          if (newPath) {
            //  动态路由路径
            const isDynamicRoute = tabInfo.dynamicRoute
            //  路由是否包含参数
            const hasParams = tabInfo.path.includes('?')
            // 是否是动态匹配路由
            if (isDynamicRoute) {
              //  存在相同路径的动态路由就删除
              const targetIndex = this.pageTabs.findIndex(item =>
                item.path.includes(isDynamicRoute)
              )
              if (targetIndex !== -1) {
                // 删除重复的
                this.pageTabs.splice(targetIndex, 1)
              }
            }
            if (hasParams) {
              // 包含参数则去除掉?后的参数，进行对比，否则取原来的值
              const targetPath = tabInfo.path.replace(/\?.+/g, '')
              // 去除参数后有重复的
              const isRepeat = this.pageTabs.findIndex(
                item => item.path.replace(/\?.+/g, '') === targetPath
              )
              if (isRepeat !== -1) {
                // 删除重复的
                this.pageTabs.splice(isRepeat, 1)
              }
            }
            this.pageTabs.push(tabInfo)
            if (this.pageTabs.length > 10) {
              // 取最近的10个
              this.pageTabs.shift()
            }
            flag = true
          }
        }
      }
      if (flag) {
        sessionStorage.setItem(
          `${name}-pageTabs`,
          JSON.stringify(this.pageTabs)
        )
      }
    },
    // 删除 页签
    deletePageTabs(index: number) {
      const path = this.pageTabs[index].path
      this.pageTabs.splice(index, 1)
      sessionStorage.setItem(`${name}-pageTabs`, JSON.stringify(this.pageTabs))
      if (router.options.history.location.includes(path)) {
        if (this.pageTabs[index]) {
          router.replace(this.pageTabs[index].path)
        } else if (this.pageTabs[index - 1]) {
          router.replace(this.pageTabs[index - 1])
        } else {
          router.replace(this.defaultRoutePath!)
        }
      }
    },
    // 单一删除tabs,指定跳转页面
    singleDeletePageTabs(index: number, newPath: string) {
      this.pageTabs.splice(index, 1)
      sessionStorage.setItem(`${name}-pageTabs`, JSON.stringify(this.pageTabs))
      router.replace(newPath)
    },
    // -------------- 带接口请求 ----------------- start ----------------
    // 获取用户信息
    handleUserProfile() {
      userProfile()
        .then(res => {
          if (res.state === 'success') {
            this.setUserInfo(res.data as MscUser)
          } else {
            ElMessage.error('获取的数据为空')
          }
        })
        .catch(err => {
          ElMessage.error(JSON.stringify(err))
        })
    },
    // 退出登录
    Logout() {
      userLogout({
        loginAgent: this.loginAgent
      }).then(() => {
        this.$reset()
        this.loginInfo = {}
        this.pageTabs = []
        sessionStorage.clear()
        router.replace(
          `/login?fullPath=${encodeURIComponent(
            location.hash.replace('#', '')
          )}`
        )
      })
    },
    // 获取当前用户菜单信息
    handleUserLoadAppMenu() {
      return new Promise<MscAppPermVo[]>(resolve => {
        userLoadAppMenu({
          appId: 0
        }).then(res => {
          if (res.state === 'success' && res.data) {
            resolve(res.data)
          } else {
            ElMessage.error(res.msg || '账号无权限！')
          }
        })
      })
    }
    // -------------- 带接口请求 ----------------- end ----------------
  }
})
